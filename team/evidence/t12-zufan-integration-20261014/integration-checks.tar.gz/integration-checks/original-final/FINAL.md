# T12 本轮本地交付

完成时间：2026-10-14T21:38:52.185978+08:00（Asia/Shanghai）。最终本地提交 **`1ba275411d41b6454b14ecfc537be10cd7202739`**，分支 `t12-r2-20261014`；工作树干净，未push。完整结构化结果、实际命令/退出码及哈希见 [FINAL.json](FINAL.json)。

原190计划与精简RVV199计划分别完整通过，全片真实DiffTest、唯一有序完成、GOOD TRAP、实际exit0；不能把两套重叠输入相加为389个不同ISA用例。旧117矩阵本轮新编译回归15项（10合法+5异常）及7自检、3预期拒错，691095 cycles / 476497 instructions / 667.9 host秒 / exit0。其余102项明确本轮未重跑。

| 本地提交 | 内容 |
| --- | --- |
| `a4fea8f69f8c2c58f986858481257d3424a903f0` | 精确全状态比较、显式计划、无摘要碰撞的判定结果位图及来源绑定驱动；原190完整执行源 |
| `8af7b21857ba2c65dbc4d835f7b2152cd6684875` | 循环计数/异常瞬时快照负控、7/5/14条RVV、RAW链与最终ELF退休跨度检查；lean199完整执行源 |
| `1ba275411d41b6454b14ecfc537be10cd7202739` | 最终工具库复核、交付文档及275个小型证据文件；gzip二进制属性与逐Git blob字节校验 |

起点 `b8272f2e8a62557437869c936b6ea9ce5fff84fe`；总差异 294 files changed, 28559 insertions(+), 102 deletions(-)（大部分为证据JSON）。实际差异命令与完整路径列表在FINAL.json。生产`src/`和`build.sc`与EMU来源`fcb16a8764d342339670df0bbf1bc67ef2028b86`一致，没有重编整核或修改RTL、黄金NEMU、CSR比较、时钟复位或共享busy/ready。

定位显示旧000镜像在50k/90k周期仍持续退休，PC分别进入向量观察与find扫描；最小阶段版完整完成。软件逐字节复制/比较、FNV与重复扫描在约1k模拟周期/host秒下耗尽预算，未发现该对照的CPU停退或软件死循环。修复后三项在原80秒预算内42482 cycles完整通过。旧initial输出不全、compact和000/003/006/008的timeout124真实保留，均不改写为PASS；周期上限也会exit0，因此验收不只看返回值。

所有63条原始AB/BA/empty窗口、四个64位计数和完整配对顺序保留，没有挑最快或减空窗口。精简RVV以完整128位结果、非scratch全向量终态和六CSR等价为前提；16,800参考双路组+75 known+75 batch与全核11边界+64随机双路分别通过。主机28项Python、25项原C judge和98,321逐位/对齐/scratch/CSR/PC检查均exit0。参考层和合成负控不计为DUT测试数量。

算术精确范围[-130048,131072]，最低signed19位，低32补码、高96零。计数窗口尚无rdcycle流水/序列化校准，不能称FU latency或Fmax。时序前审区分真实输入管线寄存边界，列出RF/旁路、乘积/平衡树、flush/ready、共享WB的setup/hold/fanout风险及门控/操作数隔离风险。E0/E2/E3/II4仅为局部FU握手；II3融合未启用，没有STA/PPA或时序闭合声明。

| 固定资产 | SHA256 |
| --- | --- |
| emu | `43fd7b094a3fb8676395dc97ca08443fb2d2d37d1dbfea0d7b9078c67087718f` |
| reference | `e5f04192ad782581eef8cd17648933aa6da0fd0543944cb6e59eb931efc60cae` |
| flash | `a3360212cf7bb784119c1719c9258362f8567803601b2359aee2c104864fa994` |
| intake | `3c8aacfcef87242639b15396bae38126fdd6a8a84bed2b0d2aa37eabb357492d` |

AM固定`086a238062fdfb3281b745a537b361983d0154b5`，只在本工作区离线clone内构建。便携GCC11.4.0 SHA256 `0c54895c55568be5b5fee49e2426abcc8fb05ca2c121ca5685dea2cbc24a1c13`；binutils2.38、cc1/libgcc、便携库、主机工具及每个ELF/BIN/生成清单的完整哈希在FINAL.json和各build记录中。没有安装工具、提权或绕过文件安全限制。

交付入口：[实现与样本](repo/team/docs/t12-r2-delivery-20261014.md)、[定位记录](repo/team/docs/t12-r2-diagnosis.md)、[RVV合同](repo/team/docs/t12-rvv-baseline.md)、[时序前审](repo/team/docs/t12-timing-precheck.md)、[证据与复现命令](repo/team/evidence/t12-r2-20261014/README.md)。二进制与生成向量保留在runs，未加入Git；原始日志均保留，Git归档仅无损压缩。收尾逐文件检查证明旧21份历史材料、运行资产、intake及review终稿未改变，所有gzip解压及提交blob哈希通过。

未完成：旧102项本轮复跑；年轻vdot已发射后取消、实际ROB/FTQ索引绕回及共享WB碰撞的事件证据；候选真实RTL A/B/门控集成/STA/Liberty/PVT/SDC/布局后setup与hold/PPA；官方规格及M/HS/VS委托虚拟化。未联网回读或更新远端/Draft，交主审独立复核发布。

所有本任务重EMU与普通测试子进程已等待退出；46份进程回执结束，未发现遗留自有工作负载，未向无关进程发信号。没有子代理/其他模型调用、网络、push、Actions、模型或安全设置修改。repo原无身份，只设置本仓库T12 Local Builder <lizufan@localhost>，保留正常三次追加提交历史。
