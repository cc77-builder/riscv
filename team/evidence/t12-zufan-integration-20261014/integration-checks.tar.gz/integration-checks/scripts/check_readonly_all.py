#!/usr/bin/env python3
"""Compare all pre-existing workspace bytes and the two source Git states."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
evidence = Path(__file__).resolve().parents[1]
workspace = evidence.parent.parent
snapshot_file = evidence/'source-snapshot-before.json'
before = json.loads(snapshot_file.read_text())

def fileinfo(path):
    if path.is_symlink():
        return {'kind':'symlink','target':os.readlink(path)}
    if path.is_file():
        h = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):
                h.update(block)
        return {'bytes':path.stat().st_size,'sha256':h.hexdigest()}
    return {'kind':'missing_or_directory'}

def git(path,*args):
    return subprocess.check_output(['git','--no-optional-locks','-C',str(path),*args]).decode()

sources = {}
metadata_drift = []
for label, data in before['sources'].items():
    path = Path(data['path'])
    for name, item in data['files'].items():
        assert fileinfo(path/name)==item, 'source changed: '+str(path/name)
    for name,item in data['git_metadata'].items():
        actual = fileinfo(path/'.git'/name)
        if actual != item:
            metadata_drift.append({'source':label,'path':str(path/'.git'/name),'before':item,'after':actual})
    assert git(path,'rev-parse','HEAD').strip()==data['head']
    status=git(path,'status','--porcelain=v1','-uall')
    assert status==data['status'], label+' status changed'
    assert git(path,'show-ref')==data['refs'], label+' refs changed'
    assert git(path,'config','--local','--list')==data['config_local'], label+' config changed'
    sources[label]={'path':str(path),'head':data['head'],'parents':data['parents'],
        'files_unchanged':len(data['files']),'status_unchanged':True,'refs_unchanged':True,
        'git_metadata_unchanged':not any(d['source']==label for d in metadata_drift),'tracked_modified':sum(not s.startswith('??') for s in status.splitlines()),
        'untracked': [s[3:] for s in status.splitlines() if s.startswith('??')],
        'clean':not status,'status':status}
seen = set()
for base, dirs, names in os.walk(workspace):
    dirs[:]=sorted(d for d in dirs if d not in ['publish-zufan','.git'])
    for name in names:
        path=Path(base)/name
        rel=str(path.relative_to(workspace))
        seen.add(rel)
        assert rel in before['workspace_files'], 'new file in source workspace: '+rel
        assert fileinfo(path)==before['workspace_files'][rel], 'source workspace changed: '+rel
assert seen==set(before['workspace_files']), 'deleted source files'
result={'status':'SOURCE_CONTENT_AND_REFS_UNCHANGED_WITH_INDEX_BYTE_DRIFT' if metadata_drift else 'PASS_READONLY_SOURCES_UNCHANGED',
    'content_and_refs_gate_passed':True,'strict_git_metadata_gate_passed':not metadata_drift,
    'metadata_drift':metadata_drift,
    'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'snapshot_sha256':hashlib.sha256(snapshot_file.read_bytes()).hexdigest(),
    'workspace_existing_files_unchanged':len(seen),'new_files_outside_publish_zufan':0,
    'sources':sources}
a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='sources'},indent=2))
for label,data in sources.items():
    print(label,json.dumps({k:v for k,v in data.items() if k!='status'}))

# This broader collection preserves the strict gate's nonzero result.
if metadata_drift:
    raise SystemExit('STRICT_GIT_METADATA_GATE_FAILED: differences retained; source-content and refs checks passed separately')
