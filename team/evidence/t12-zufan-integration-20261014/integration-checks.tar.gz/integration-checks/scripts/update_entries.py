#!/usr/bin/env python3
"""Append historical status labels and publish the current integration entry."""
import hashlib
import json
from pathlib import Path

evidence = Path(__file__).resolve().parents[1]
repo = evidence.parent/'repo'
sha = lambda b: hashlib.sha256(b).hexdigest()
changes = []
old = (repo/'AGENTS.md').read_bytes()
history = repo/'team/docs/history/AGENTS-before-t12-zufan-integration-20261014.md'
with history.open('xb') as f:
    f.write(old)
new = '''# 团队 Agent 入口

## 当前状态：T12 已验收的软件与验证成果完成离线整合

先读 [T12 整合报告](team/docs/t12-zufan-integration-20261014.md)、[本次复核回执](team/evidence/t12-zufan-integration-20261014/README.md)、[原始全核证据](team/evidence/t12-r2-20261014/README.md) 和 [独立审查归档](team/evidence/t12-r2-independent-20261014/README.md)。最终实现来源为 `1ba275411d41b6454b14ecfc537be10cd7202739`；普通 merge 保留已发布审查 `f188f6f7588270714d94d970fe36f2f2cdda15b9` 及本机审查后继 `e5d084bbdcfad6936ccad29dff4c1df00f5abfef` 的完整历史。

既有真实全核运行：original190（源 `a4fea8f69f8c2c58f986858481257d3424a903f0`）与 lean199（源 `8af7b21857ba2c65dbc4d835f7b2152cd6684875`）分别完整通过 DiffTest、GOOD TRAP 和实际 exit0；两个计划输入重叠，不能相加为389个唯一ISA用例。T10/T11历史117唯一用例曾全量通过；此前本轮T12仅重跑15/117，其余102未重跑。本次整合只复核源/镜像/日志并运行主机与参考层检查，新增DUT运行数为0。

生产 `src/`、`build.sc`、`.gitmodules` 和10个gitlink与团队 `6bf3c2c3be0c88ff3a020786ff10cbec9aa126d3`、实际EMU来源 `fcb16a8764d342339670df0bbf1bc67ef2028b86` 一致。黄金NEMU保持已验收1.1.0及固定配置/二进制，不修改时钟、复位、位宽、吞吐率或共享busy/ready合同。保留全部63个计数窗口、失败记录与未启用实验包。

## 本次合入范围与硬件晋升门禁

本次允许合入已验收的软件、判定器、测试、证据和审查文档。旧报告要求“所有STA完成前不得合并zufan”的总闸门已由本次用户明确授权取代，不能用于无限延后这些成果。硬件候选保持独立晋升门禁：输入融合/II3未启用；真实候选RTL A/B、共享门控/OG2/WB/ROB集成、STA/Liberty/PVT/SDC、布局后setup/hold及PPA均未完成，不能写成已通过。

仍未取得年轻vdot已发射后取消、实际ROB/FTQ索引绕回和共享WB碰撞的事件证据；rdcycle流水/序列化未校准，局部E0/E2/E3/II4和原始窗口不能当全核指令延迟、Fmax或官方成绩。官方规格、M/HS/VS委托虚拟化、人工接口签字仍待后续明确任务。本次不启动新RTL优化。

## 发布与协作

团队唯一上游 `cc77-builder/riscv`，目标分支 `zufan`。当前交付只在新的 `publish-zufan/repo` 本地追加提交；最终候选完整SHA、干净状态、bundle及校验值在工作区 `publish-zufan/FINAL.md` / `FINAL.json`。最终联网核实与普通推送由主审ChatGPT负责；本入口不声称已push，不代签任何队友ACK。

保留所有原树/WIP/未跟踪工件，不reset/clean/stash、不强推、不重写历史，不改原PR分支及main/James_Hotten/zjhwork。当前任务禁止联网、安装工具和修改系统/网络/沙箱；不依赖GitHub Actions。既有协作约定见 [collaboration-current.md](team/docs/collaboration-current.md)，行动以用户当次明确授权为准。

当前实现入口：`team/scripts/t12-tests.py`、`verify_t12_evidence.py`、`audit_t12_live.py`、`team/tests/generate_t12.py`。复核输出必须使用全新目录，真实重跑须另获任务授权并固定来源；不得覆盖历史证据或把参考层/主机测试冒充全核。旧入口原字节见 [整合前快照](team/docs/history/AGENTS-before-t12-zufan-integration-20261014.md)。
'''
(repo/'AGENTS.md').write_text(new)
changes.append({'path':'AGENTS.md','before_sha256':sha(old),'after_sha256':sha(new.encode()),'original_bytes_preserved_at':str(history.relative_to(repo))})
labels = {
 'team/docs/collaboration-current.md': '''# 2026-10-14 当前授权与交付状态

本次仅在全新目录离线整合、验收和本地提交；主审ChatGPT负责后续联网核实与普通推送。最新状态见 [T12整合报告](t12-zufan-integration-20261014.md) 和 [复核回执](../evidence/t12-zufan-integration-20261014/README.md)。original190与lean199已有完整真实运行，本次整合新增DUT运行0；旧117本轮重跑15，另102未重跑。已验收的软件/验证成果可合入，硬件候选的RTL A/B、集成和STA/PPA晋升门禁继续独立保留。本任务不启动新开发、不联网、不push、不代签ACK。

以下保留2026-10-13协作约定及此前交付入口。各段“本轮/当前”按段落原日期理解；旧未验收描述不覆盖上述最新状态。\n\n---\n\n''',
 'team/docs/t12-review-gate-20261014.md': '''> 历史审查门禁（保留原文）。本文件对应早期Draft；其中“HOST-ONLY / NOT_RUN / Do not merge to zufan yet”已由[2026-10-14最终整合报告](t12-zufan-integration-20261014.md)对已验收软件/验证成果的结论取代。original190与lean199已完整运行，旧117本轮仅重跑15；不将缺少STA作为本批软件/证据合入的总闸门。第5项硬件候选晋升条件继续有效，未启用融合/II3。本文件跨RF/旁路寄存器的路径描述已由[时序前审](t12-timing-precheck.md)纠正。\n\n''',
 'team/docs/t12-r2-checkpoint-20261014.md': '''> 历史检查点：以下数字固定于原文20:52:41，不能作为最新完成数。后继original190、lean199分别完整通过；当前源码/来源/归档修复与边界见[T12最终整合报告](t12-zufan-integration-20261014.md)。原文保留，不回填后继结果。\n\n''',
 'team/docs/t12-perf-20261014.md': '''> 历史T12设计/早期执行状态，正文保留。最新已完成运行与全部63窗口见[实现交付](t12-r2-delivery-20261014.md)，发布范围见[整合报告](t12-zufan-integration-20261014.md)。旧NOT_RUN不代表后继软件状态；微架构事件覆盖与STA/PPA仍未完成。\n\n''',
 'team/docs/vdot-hardware-ab-20261014.md': '''> 历史硬件候选报告，实验包未启用、未晋升。正文关于RF/旁路直至融合乘法的组合路径描述已由[时序前审](t12-timing-precheck.md)纠正：`NewPipelineConnect`存在真实数据寄存边界。当前仅合入软件/验证成果，硬件晋升要求见[整合报告](t12-zufan-integration-20261014.md)，以下历史结果不改写。\n\n''',
 'team/docs/t12-r2-delivery-20261014.md': '''> 本文为`1ba275411d41b6454b14ecfc537be10cd7202739`最终实现交付的历史正文。后续已在新目录整合已发布审查历史，复核结果及审查压缩包修复见[T12整合报告](t12-zufan-integration-20261014.md)；原受测SHA和运行数字保持原样。\n\n''',
 'team/workloads/t12-perf/README.md': '''> 当前入口：最终构建/运行源码与`1ba275411d41b6454b14ecfc537be10cd7202739`一致；original190和lean199分别已有完整DiffTest运行。见[复现命令与原始证据](../../evidence/t12-r2-20261014/README.md)及[整合报告](../../docs/t12-zufan-integration-20261014.md)。以下是早期190计划的历史说明，“待编译/待运行”和缺少RAW链的描述不代表后继lean版本；不得直接照旧文覆盖输出目录。\n\n''',
 'team/evidence/t12-perf-20261014/README.md': '''> 历史早期证据入口：本目录空样本/NOT_RUN保留原状；后继实际190/199运行、全部63窗口见[最终原始证据](../t12-r2-20261014/README.md)，本次复核见[整合报告](../../docs/t12-zufan-integration-20261014.md)。\n\n''',
 'team/evidence/vdot-hardware-ab-20261014/README.md': '''> 历史硬件实验包，全部候选源码/patch/日志原样保留，未应用到生产、未启用。时序路径纠正见[前期时序审查](../../docs/t12-timing-precheck.md)；本次软件/验证合入不关闭[硬件晋升门禁](../../docs/t12-zufan-integration-20261014.md)。\n\n''',
 'team/evidence/t12-r2-independent-20261014/README.md': '''> 整合更新：本机`e5d084bbdcfad6936ccad29dff4c1df00f5abfef`及其全部审查历史已保留。该提交中的gzip曾被上级文本规则转换，未能匹配原`archive.json`；本次从两份相同的本机原包恢复，SHA256重新匹配原声明`8916a64dc4bf2c21e1c772f4d927f338ecb4ec2a290019e423ca5b2c64d03a96`，全部738个文本文件通过清单核验，新增`.gitattributes`保护。旧坏blob、原清单及失败回执保留，详见[整合报告](../../docs/t12-zufan-integration-20261014.md)。以下正文、展示报告及包内历史结论均不回填为后继运行。\n\n''',
}
for path, prefix in labels.items():
    target = repo/path
    before = target.read_bytes()
    after = prefix.encode()+before
    target.write_bytes(after)
    changes.append({'path':path,'before_sha256':sha(before),'after_sha256':sha(after),
                    'change':'prefix only; all original body bytes preserved','prefix_bytes':len(prefix.encode())})
(evidence/'documentation-changes.json').write_text(json.dumps(changes,indent=2)+'\n')
print(json.dumps({'updated_entries':len(changes),'original_agents_preserved':str(history)},indent=2))
