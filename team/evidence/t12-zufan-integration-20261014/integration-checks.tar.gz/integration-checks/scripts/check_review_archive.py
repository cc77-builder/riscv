#!/usr/bin/env python3
"""Validate the preserved review package without extracting or running it."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

p = argparse.ArgumentParser()
p.add_argument('directory', type=Path)
a = p.parse_args()
meta = json.loads((a.directory / 'archive.json').read_text())
data = (a.directory / meta['archive']).read_bytes()
sha = hashlib.sha256(data).hexdigest()
print(json.dumps({'bytes': len(data), 'sha256': sha, 'expected': meta}, indent=2), flush=True)
if len(data) != meta['bytes'] or sha != meta['sha256']:
    raise SystemExit('REJECTED: review archive bytes/SHA256 differ from original manifest')
raw = gzip.decompress(data)  # Check full stream, CRC and length, not just early tar entries.
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as t:
    members = t.getmembers()
    names = [m.name for m in members]
    assert len(names) == len(set(names)), 'duplicate member'
    assert all(m.isfile() and m.name.startswith('independent-review/') and
               '..' not in Path(m.name).parts for m in members), 'unsafe/non-file member'
    manifest = json.load(t.extractfile('independent-review/ARCHIVE_MANIFEST.json'))
    expected = {'independent-review/' + n for n in manifest['files']}
    assert set(names) == expected | {'independent-review/ARCHIVE_MANIFEST.json'}, 'member set differs'
    assert len(expected) == meta['text_files']
    for name, digest in manifest['files'].items():
        assert hashlib.sha256(t.extractfile('independent-review/' + name).read()).hexdigest() == digest, name
    assert manifest['excluded_regenerable_or_binary'] == meta['excluded']
print(json.dumps({'status': 'PASS', 'gzip_crc': 'PASS', 'members': len(names),
                  'manifest_files_checked': len(expected), 'sha256': sha}))
