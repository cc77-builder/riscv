#!/usr/bin/env python3
"""Offline integration checks; does not execute a DUT or alter source/evidence."""
import argparse
import csv
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
evidence = Path(__file__).resolve().parents[1]
pub = evidence.parent
workspace = pub.parent
repo = pub / 'repo'
FINAL = '1ba275411d41b6454b14ecfc537be10cd7202739'
REVIEW = 'e5d084bbdcfad6936ccad29dff4c1df00f5abfef'
TEAM = '6bf3c2c3be0c88ff3a020786ff10cbec9aa126d3'
EMU = 'fcb16a8764d342339670df0bbf1bc67ef2028b86'
A4 = 'a4fea8f69f8c2c58f986858481257d3424a903f0'
LEAN = '8af7b21857ba2c65dbc4d835f7b2152cd6684875'
sha = lambda b: hashlib.sha256(b).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(repo), *args])

def tree(ref):
    result = {}
    for line in git('ls-tree', '-rz', ref).split(b'\0'):
        if line:
            meta, name = line.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            result[name.decode()] = dict(mode=mode, kind=kind, oid=oid)
    return result

def read_file(path):
    return os.readlink(path).encode() if path.is_symlink() else path.read_bytes()

def blob_id(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

trees = {ref: tree(ref) for ref in (FINAL, REVIEW, TEAM, EMU, A4, LEAN)}
report = {'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'source, archived bytes and previously executed artifacts; no DUT execution',
          'candidate_head_at_check': git('rev-parse', 'HEAD').decode().strip()}
protected = [n for n, v in trees[FINAL].items()
             if n.startswith('src/') or n in ('build.sc', '.gitmodules') or v['kind']=='commit']
for ref in (REVIEW, TEAM, EMU):
    assert {n: trees[ref][n] for n in protected} == {n: trees[FINAL][n] for n in protected}, ref
    assert not git('diff', ref, 'HEAD', '--', 'src', 'build.sc', '.gitmodules').strip(), ref
golden = [n for n in trees[FINAL] if n.startswith('team/patches/nemu/')]
assert {n: trees[FINAL][n] for n in golden} == {n: trees[TEAM][n] for n in golden}
report['production'] = {'protected_entries': len(protected),
    'src_tree': git('rev-parse', FINAL+':src').decode().strip(),
    'build_sc_blob': trees[FINAL]['build.sc']['oid'],
    'gitmodules_blob': trees[FINAL]['.gitmodules']['oid'],
    'gitlinks': {n:v['oid'] for n,v in trees[FINAL].items() if v['kind']=='commit'},
    'equal_to': [FINAL, REVIEW, TEAM, EMU], 'rebuilt': False}
report['golden_patch'] = {'paths': len(golden), 'equal_to': [FINAL, REVIEW, TEAM],
    'version': '1.1.0', 'older_emu_commit_note': 'EMU source commit predates the accepted NEMU 1.1.0 patch; golden source is pinned independently.',
    'preexisting_patch_history': git('log', '--format=%H %s', EMU+'..'+TEAM,
                                   '--', 'team/patches/nemu').decode().splitlines()}
# Check every non-document/evidence source file, preserving mode and raw bytes.
source_files = {}
for name, info in trees[FINAL].items():
    if info['kind'] != 'blob' or name == 'AGENTS.md' or name.startswith(('team/docs/', 'team/evidence/')):
        continue
    data = read_file(repo/name)
    assert blob_id(data) == info['oid'], 'final source differs: '+name
    actual_mode = '120000' if (repo/name).is_symlink() else ('100755' if (repo/name).stat().st_mode & 0o111 else '100644')
    assert actual_mode == info['mode'], 'mode differs: '+name
    source_files[name] = dict(info, sha256=sha(data))
report['final_source_files_exact'] = len(source_files)
report['source_blobs'] = source_files
for name in ['team/scripts/audit_t12_live.py', 'team/tests/test_t12_live_audit.py']:
    assert blob_id(read_file(repo/name)) == trees[REVIEW][name]['oid']
report['review_auditor_exact'] = {n:trees[REVIEW][n] for n in
    ['team/scripts/audit_t12_live.py', 'team/tests/test_t12_live_audit.py']}
report['key_input_comparison'] = []
build190 = json.loads((workspace/'runs/matrix-190/build-000/build.json').read_text())
build199 = json.loads((workspace/'runs/matrix-199-lean/build-000/build.json').read_text())
assert set(build190['sources']) == set(build199['sources'])
for name in sorted(build190['sources']):
    hashes = {ref: sha(git('cat-file', 'blob', ref+':'+name)) for ref in (A4, LEAN, FINAL)}
    assert hashes[A4] == build190['sources'][name]
    assert hashes[LEAN] == build199['sources'][name] == hashes[FINAL] == sha(read_file(repo/name))
    report['key_input_comparison'].append({'path':name,'hashes':hashes,
        'candidate_equals_final_and_lean':True,'original190_equals_candidate':hashes[A4]==hashes[FINAL]})
archive = repo/'team/evidence/t12-r2-20261014'
archive_paths = [n for n in trees[FINAL] if n.startswith('team/evidence/t12-r2-20261014/')]
for name in archive_paths:
    assert blob_id(read_file(repo/name)) == trees[FINAL][name]['oid'], name
report['final_t12_archive_blobs_exact'] = len(archive_paths)
checksum_files = {}
for sums in sorted((repo/'team/evidence').rglob('SHA256SUMS')):
    count = 0
    for line in sums.read_text().splitlines():
        wanted, name = line.split('  ', 1)
        path = sums.parent/name
        assert sha(path.read_bytes()) == wanted, 'SHA256SUMS: '+str(path)
        count += 1
    checksum_files[str(sums.relative_to(repo))] = count
report['sha256sums'] = checksum_files
gzip_files = {}
for path in sorted((repo/'team/evidence').rglob('*.gz')):
    data = path.read_bytes()
    raw = gzip.decompress(data)
    gzip_files[str(path.relative_to(repo))] = dict(bytes=len(data),sha256=sha(data),uncompressed_sha256=sha(raw))
report['gzip_files'] = gzip_files
origins = json.loads((archive/'archive-origins.json').read_text())
for name, origin in origins.items():
    raw = Path(origin['original']).read_bytes()
    data = (archive/name).read_bytes()
    assert len(raw) == origin['original_bytes'] and sha(raw) == origin['original_sha256'], name
    assert sha(data) == origin['archived_sha256'], name
    assert origin['transform'] in ('verbatim', 'gzip-created')
    assert (gzip.decompress(data) if origin['transform']=='gzip-created' else data) == raw, name
report['archive_origins_exact'] = len(origins)
original_final = json.loads((workspace/'FINAL.json').read_text())
report['original_final_sha256'] = sha((workspace/'FINAL.json').read_bytes())
report['assets'] = {}
for name, item in original_final['assets'].items():
    assert sha(Path(item['path']).read_bytes()) == item['sha256'], name
    report['assets'][name] = item
for name, item in original_final['toolchain'].items():
    assert sha(Path(item.get('path',name)).read_bytes()) == item['sha256'], name
report['toolchain_entries_exact'] = len(original_final['toolchain'])
for name, item in original_final['host_tools']['tools'].items():
    assert sha(Path(item['path']).read_bytes()) == item['sha256'], name
report['host_tools'] = original_final['host_tools']['tools']
rechecked = []
for profile, source, result_file, final_key in [
    ('matrix-190', A4, 'verify-original-190.json', 'original_190'),
    ('matrix-199-lean', LEAN, 'verify-lean-199.json', 'lean_199')]:
    result = json.loads((evidence/result_file).read_text())
    assert result['source'] == source
    assert result['executed'] == original_final['tests'][final_key]['executed']
    for metric in result['metrics']:
        rechecked.append(dict(profile=profile,source=source,**metric))
    for run in result['evidence']:
        receipt = json.loads((Path(run['run'])/'receipt.json').read_text())
        b = json.loads((Path(receipt['build'])/'build.json').read_text())
        frozen = original_final['binary_build_hashes'][str(Path(receipt['build']).relative_to(workspace))]
        for key,value in frozen.items(): assert b[key] == value, (profile, key)
assert rechecked == json.loads((archive/'raw-metrics.json').read_text())
with (archive/'raw-metrics.csv').open(newline='') as f:
    csv_rows = list(csv.DictReader(f))
assert len(csv_rows) == len(rechecked) == 63
for row, expected in zip(csv_rows,rechecked):
    assert all(str(expected[k]) == v for k,v in row.items()), row
report['metrics'] = {'all_raw_windows_preserved':63,'original':27,'lean':36,
    'four_counter_values_order_and_csv_exact':True,'subtracted_or_fastest_selected':False}
failed_files = 0
for failure in original_final['historical_failures']:
    for name, item in failure['artifacts'].items():
        raw = (Path(failure['directory'])/name).read_bytes()
        assert sha(raw) == item['sha256'] and len(raw) == item['bytes'], name
        failed_files += 1
report['historical_failure_files_exact'] = failed_files
golden_receipt = evidence/'commands/golden-nemu-provenance.log'
assert sha(golden_receipt.read_bytes()) == original_final['reference_provenance']['verification_sha256']
report['golden_provenance_exact_to_original'] = sha(golden_receipt.read_bytes())
am = original_final['am']
assert subprocess.check_output(['git','--no-optional-locks','-C',am['path'],'rev-parse','HEAD']).decode().strip()==am['source']
assert not subprocess.check_output(['git','--no-optional-locks','-C',am['path'],'status','--porcelain=v1','-uall']).strip()
report['am'] = am
report['status'] = 'PASS'
a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','final_source_files_exact',
    'final_t12_archive_blobs_exact','archive_origins_exact','sha256sums','metrics',
    'historical_failure_files_exact','toolchain_entries_exact']},indent=2))
print('GZIP_FILES_VERIFIED',len(gzip_files))
