#!/usr/bin/env python3
"""Record a finite local command without changing its exit status."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('--name', required=True)
p.add_argument('--cwd', type=Path, required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
root = Path(__file__).resolve().parents[1] / 'commands'
log = root / (a.name + '.log')
receipt = root / (a.name + '.json')
if log.exists() or receipt.exists():
    raise SystemExit('Refusing to overwrite an existing command record')
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0',
           GIT_TERMINAL_PROMPT='0', LC_ALL='C.UTF-8')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
r = {'argv': command, 'cwd': str(a.cwd.resolve()), 'started_at': now(),
     'environment_overrides': {k: env[k] for k in ['PYTHONDONTWRITEBYTECODE',
         'GIT_OPTIONAL_LOCKS', 'GIT_TERMINAL_PROMPT', 'LC_ALL']},
     'log': str(log), 'classification': 'offline integration; no new DUT run'}
start = time.monotonic()
with log.open('xb') as f:
    proc = subprocess.Popen(command, cwd=a.cwd, env=env,
                            stdout=f, stderr=subprocess.STDOUT)
    r['pid'] = proc.pid
    r['exit_code'] = proc.wait()
r.update(finished_at=now(), elapsed_seconds=time.monotonic()-start,
         log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
         log_bytes=log.stat().st_size)
receipt.write_text(json.dumps(r, indent=2)+'\n')
print(json.dumps(r, ensure_ascii=False))
print(log.read_text(errors='replace')[-8000:])
sys.exit(r['exit_code'])
