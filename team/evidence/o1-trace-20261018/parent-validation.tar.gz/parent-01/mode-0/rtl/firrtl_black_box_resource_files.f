ClockGate.sv
