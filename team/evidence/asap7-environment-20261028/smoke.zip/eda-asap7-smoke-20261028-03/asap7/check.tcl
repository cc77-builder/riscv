read_liberty /home/amesotten/.cache/codex-rvinno/eda-asap7-smoke-20261028-03/asap7/combined.lib
read_verilog /home/amesotten/.cache/codex-rvinno/eda-asap7-smoke-20261028-03/asap7/mapped.v
link_design probe
set_cmd_units -time ns -capacitance fF
create_clock -name clk -period 1 [get_ports clock]
set_input_delay 0.1 -clock clk [get_ports {a* b*}]
set_output_delay 0.1 -clock clk [get_ports q*]
set_input_transition 0.05 [get_ports {a* b*}]
set_load 5 [get_ports q*]
report_checks -path_delay max -digits 6
exit
