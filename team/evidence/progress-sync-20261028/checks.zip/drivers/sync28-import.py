from pathlib import Path
import subprocess,json,hashlib,sys,gzip
root=Path.cwd();out=root/'team/out/sync-20261028'
def git(*args):return subprocess.check_output(['git',*args])
def tree(ref):
 result={}
 for row in git('ls-tree','-rz',ref).split(b'\0'):
  if row:
   info,name=row.split(b'\t',1);result[name.decode()]=info.split()[2].decode()
 return result
base=tree('e611eafb1');sources={r:tree(r) for r in ('ffd668bf1','10b71ad4b')};index={}
for row in git('ls-files','--stage','-z').split(b'\0'):
 if row:
  info,name=row.split(b'\t',1);mode,blob,stage=info.split();assert stage==b'0';index[name.decode()]=blob.decode()
changed=git('diff','--cached','--name-only','-z','e611eafb1').decode().strip('\0').split('\0')
raw=subprocess.check_output(['git','hash-object','--no-filters','--stdin-paths'],input=('\n'.join(json.dumps(p,ensure_ascii=False) for p in changed)+'\n').encode()).decode().splitlines()
rows=[];combined=[];drift=[]
for p,h in zip(changed,raw):
 matches=[r for r,t in sources.items() if index.get(p)==t.get(p)]
 if matches:
  if h!=index[p]:drift.append(p)
  rows.append(dict(path=p,blob=index[p],upstream=matches))
 else:combined.append(p)
print('exact imported',len(rows),'combined',len(combined),'drift',len(drift));print(json.dumps(dict(combined=combined,drift=drift),ensure_ascii=False,indent=2))
(out/'import-check.json').write_text(json.dumps(dict(base='e611eafb1af2730d8d86c768ee98f1b80f5fe0b2',sources=list(sources),imported=rows,combined=combined,working_byte_drift=drift),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not drift
sys.path.insert(0,str(root/'team/optimizations/o2/parent'))
import check_trace,check_negative
results={}
archive=root/'team/optimizations/o2/r3-div-gate/evidence/20261024-local'
for label in ('green-parent-01','red-parent-01'):
 path=archive/'files/runs'/label/'result.log.gz';text=gzip.decompress(path.read_bytes()).decode()
 try:
  value=check_trace.check_trace(text)
  if label.startswith('red'):raise AssertionError('red must fail')
  replay=check_negative.check_positive(text)
  results[label]=dict(status='PASS',trace=value,replay=replay)
 except check_trace.TraceError as error:
  if not label.startswith('red'):raise
  results[label]=dict(status='EXPECTED_REJECTION',error=str(error))
(out/'parent-frozen-replay.json').write_text(json.dumps(results,indent=2)+'\n')
print({k:v['status'] for k,v in results.items()})
