from pathlib import Path
import json,hashlib,zipfile
repo=Path('/mnt/c/Code/RVInno/riscv');root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261028');windows=repo/'team/out/sync-20261028'
norm=json.loads((root/'norm-recheck/result.json').read_bytes());assert norm['status']=='NORM_ARCHIVE_RAW_RECHECK_PASS' and norm['performance']['selected']=='HOLD'
assert json.loads((root/'orchestration-linux.json').read_bytes())['exit_code']==0
zjh=json.loads((windows/'zjh-evidence-after-restoration.json').read_bytes());assert len(zjh[-1]['missing'])==29
summary=dict(status='INTEGRATED_WITH_DECLARED_EVIDENCE_GAP',base='e611eafb1af2730d8d86c768ee98f1b80f5fe0b2',upstream_norm='ffd668bf1bc80850d382f514d13bb00316c85582',upstream_zjhwork='10b71ad4bff25cd2070e775c74a4717b01602f75',norm=norm,zjh_evidence=zjh,review=json.loads((windows/'review.json').read_bytes()),current_parent_host_tests=53,c8_host_tests=22,clock_host_tests=11,orchestration_linux_tests=15,new_emu_runs=0,new_nemu_runs=0,new_parent_rtl_runs=0,current_hardware_qualified=False)
out=repo/'team/evidence/progress-sync-20261028';out.mkdir(exist_ok=False);files={}
for p in windows.iterdir():
 if p.is_file() and p.suffix in ('.log','.json'):files['windows/'+p.name]=p
for p in root.iterdir():
 if p.is_file() and p.suffix in ('.log','.json'):files['native/'+p.name]=p
for p in (root/'norm-recheck').rglob('result.json'):files['native/'+p.relative_to(root).as_posix()]=p
for p in (root/'norm-recheck').glob('*.log'):files['native/'+p.relative_to(root).as_posix()]=p
for p in (repo/'team/out').glob('sync28-*.py'):files['drivers/'+p.name]=p
rows={}
with zipfile.ZipFile(out/'checks.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in sorted(files.items()):
  data=path.read_bytes();z.writestr(name,data);rows[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
manifest=dict(files=rows,archive_sha256=hashlib.sha256((out/'checks.zip').read_bytes()).hexdigest(),status=summary['status'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(out/'checks.zip') as z:
 assert set(z.namelist())==set(rows)
 for name,row in rows.items():assert hashlib.sha256(z.read(name)).hexdigest()==row['sha256']
print('Sealed',len(rows),'members,',(out/'checks.zip').stat().st_size,'bytes; 29 missing upstream members remain declared.')
