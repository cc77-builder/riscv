from pathlib import Path
import gzip,json,hashlib,subprocess
out=Path('team/out/sync-20261028');results=[]
for name in ('team/optimizations/o2/r3-div-gate/evidence/20261024-local','team/optimizations/o2/integration/firstdot-v2-0f/acceptance/evidence'):
 root=Path(name);manifest=json.loads((root/'manifest.json').read_bytes());expected=set();present=set();total=0;missing=[]
 for row in manifest['files']:
  p=root/row['stored'];assert p.resolve().is_relative_to(root.resolve()) and row['stored'] not in expected;expected.add(row['stored'])
  if not p.is_file():
   missing.append(dict(path=row['stored'],sha256=row['stored_sha256'],bytes=row['stored_bytes'],source_commit='10b71ad4bff25cd2070e775c74a4717b01602f75',missing_from_git=subprocess.run(['git','cat-file','-e','origin/zjhwork:'+p.as_posix()],capture_output=True).returncode!=0));continue
  present.add(row['stored']);data=p.read_bytes();assert len(data)==row['stored_bytes'] and hashlib.sha256(data).hexdigest()==row['stored_sha256']
  raw=gzip.decompress(data) if row['gzip'] else data
  assert len(raw)==row['raw_bytes'] and hashlib.sha256(raw).hexdigest()==row['raw_sha256'];total+=len(raw)
 actual={p.relative_to(root).as_posix() for p in (root/'files').rglob('*') if p.is_file()}
 assert actual==present
 results.append(dict(path=name,status='BLOCKED_MISSING_PUBLISHED_MEMBERS' if missing else 'ORIGINAL_BYTES_PASS',declared_members=len(expected),verified_members=len(present),verified_raw_bytes=total,missing=missing,manifest_sha256=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()))
(out/'zjh-evidence-bytes.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k!='missing'}|dict(missing_count=len(r['missing'])) for r in results],indent=2))
