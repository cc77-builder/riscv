from pathlib import Path
import gzip,json,hashlib
out=Path('team/out/sync-20261028');results=[]
for name in ('team/optimizations/o2/r3-div-gate/evidence/20261024-local','team/optimizations/o2/integration/firstdot-v2-0f/acceptance/evidence'):
 root=Path(name);manifest=json.loads((root/'manifest.json').read_bytes());seen=set();total=0
 for row in manifest['files']:
  p=root/row['stored'];assert p.resolve().is_relative_to(root.resolve()) and row['stored'] not in seen;seen.add(row['stored'])
  data=p.read_bytes();assert len(data)==row['stored_bytes'] and hashlib.sha256(data).hexdigest()==row['stored_sha256']
  raw=gzip.decompress(data) if row['gzip'] else data
  assert len(raw)==row['raw_bytes'] and hashlib.sha256(raw).hexdigest()==row['raw_sha256'];total+=len(raw)
 assert {p.relative_to(root).as_posix() for p in (root/'files').rglob('*') if p.is_file()}==seen
 results.append(dict(path=name,status='ORIGINAL_BYTES_PASS',members=len(seen),raw_bytes=total,manifest_sha256=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()))
(out/'zjh-evidence-bytes.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
