from pathlib import Path
import subprocess
p=Path('.gitattributes')
check=subprocess.run(['git','diff','--cached','--check'],capture_output=True,text=True,encoding='utf-8')
files=sorted({line.split(':')[0] for line in check.stdout.splitlines() if ': trailing whitespace.' in line or ': new blank line at EOF.' in line})
with p.open('a',encoding='utf-8') as f:
 f.write('\n# Imported frozen source/patch formatting is part of its recorded identity.\n')
 for path in files:
  assert path.startswith('team/')
  f.write(path+' -whitespace\n')
 f.write('team/evidence/progress-sync-20261028/** -text -whitespace\n')
print('Preserved formatting for',len(files),'frozen files.')
p=Path('team/README.md');s=p.read_text(encoding='utf-8')
s=s.replace('[稳定使用说明](optimizations/o2/r2-select/STABLE.md)', '[firstdot V2稳定入口](optimizations/o2/r2-select/FIRSTDOT_STABLE.md)、[V1回退](optimizations/o2/r2-select/STABLE.md)')
key='| 工具与依赖、可复现输入 |'
s=s.replace(key, '| 独立0f硬件上的C8包与冻结验收（不等于当前James合并硬件资格） | [C8使用](optimizations/o2/integration/firstdot-v2-0f/package/c8/README.md)、[已发布的0f验收](docs/r5-g5-publication-20261027.md) |\n'+key)
p.write_text(s,encoding='utf-8')
p=Path('team/progress.md');s=p.read_text(encoding='utf-8')
s=s.replace('2026-10-27 整理：', '2026-10-28 整理：').replace('旧正文可由Git提交', 'norm和独立0f/C8进度已接入当前路线；旧“等待norm发布”不再作为待办。旧正文可由Git提交')
p.write_text(s,encoding='utf-8')
p=Path('team/docs/development-route-current.md');s=p.read_text(encoding='utf-8')
s=s.replace('更新：2026-10-27（UTC+08:00）','更新：2026-10-28（UTC+08:00）',1)
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('> James_Hotten 同步边界'):
  lines[i]='> James_Hotten 同步边界（2026-10-28）：并入 `zufan:ffd668bf1` 的norm/consumer阶段成果及 `zjhwork:10b71ad4b` 的0f/C8和研究资料，复核见[同步记录](latest-integration-20261023.md#sync-20261028)。当前生产RTL保留James在e611eafb1的实现，含更完整的取消关钟和O1观测；0f/C8、T17/ff840与本地bc9/e66证据各自绑定原身份，不拼接为新全核PASS。O1/O2默认关闭。旧firstdot扩数据、等待norm发布及0f/C1/C2/C3已完成筛选队列不再重启；在途首token与离线调度工具以协作Issue的实际终态和正式发布为准。'
s='\n'.join(lines)+'\n'
key='| R3 |'
row='| 独立0f/C8交付 | [0f发布记录](r5-g5-publication-20261027.md)及[C8包](../optimizations/o2/integration/firstdot-v2-0f/package/c8/README.md)已并入；保留0f硬件、c823a软件和冻结清单的R5/G5资格与明确回退 | 仅作独立可选包和受测版本资料，不将0f硬件替换当前James源码，不更改firstdot V2默认。原freeze之后的发布状态见发布记录；旧“未上传/未授权”只描述当时操作。当前合并父级新增覆盖已通过host与冻结原流检查，新的组合RTL执行仍NOT_RUN。 |\n'
assert key in s;s=s.replace(key,row+key,1)
p.write_text(s,encoding='utf-8')
