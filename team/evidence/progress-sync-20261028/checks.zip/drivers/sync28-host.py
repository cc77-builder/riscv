from pathlib import Path
import json,subprocess,sys,time
out=Path('team/out/sync-20261028');results=[]
checks=[('parent','team/optimizations/o2/parent','test_*.py'),('c8','team/optimizations/o2/integration/firstdot-v2-0f/package/c8','test_c8_package.py'),('clock','team/optimizations/o2/integration/firstdot-v2-0f/acceptance','test_clock_supplement.py'),('orchestration','team/optimizations/o2/integration/firstdot-v2-0f/audit','test_orchestration_receipt.py')]
for label,path,pattern in checks:
 command=[sys.executable,'-B','-m','unittest','discover','-s',path,'-p',pattern,'-v'];started=time.time()
 with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:
  p=subprocess.run(command,stdout=stdout,stderr=stderr)
 results.append(dict(name=label,command=command,exit_code=p.returncode,seconds=time.time()-started))
 (out/'host-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(label,p.returncode,flush=True)
assert all(x['exit_code']==0 for x in results)
