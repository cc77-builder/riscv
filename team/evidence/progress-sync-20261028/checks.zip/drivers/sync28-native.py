from pathlib import Path
import hashlib,json,os,subprocess,time
repo=Path('/mnt/c/Code/RVInno/riscv');root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261028');root.mkdir(exist_ok=False)
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
stage=repo/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/forward-host/stages';norm=stage/'norm'
index=json.loads((norm/'evidence/index.json').read_bytes());package=index['packages']['norm']
steps=[]
def run(label,args):
 argv=list(map(str,args));start=time.time()
 with (root/(label+'.stdout.log')).open('xb') as stdout,(root/(label+'.stderr.log')).open('xb') as stderr:
  result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 steps.append(dict(name=label,command=argv,exit_code=result.returncode,started=start,finished=time.time()))
 (root/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(label,result.returncode,flush=True)
 if result.returncode:raise RuntimeError(label)
run('norm-join',['python3','-B',stage/'restore.py','--archive',norm/package['path'],'--output',root/'norm-joined'])
run('norm-restore',['python3','-B',stage/'archive.py','verify','--archive',root/'norm-joined/payload.zip','--expected-sha256',package['archive_sha256'],'--output',root/'norm-restored'])
run('norm-recheck',['python3','-B',norm/'evidence.py','recheck','--root',root/'norm-restored','--manifest',root/'norm-joined/manifest.json','--expected-manifest-sha256',package['manifest_sha256'],'--output',root/'norm-recheck'])
print('NORM frozen raw recheck complete; zero new EMU/NEMU.',flush=True)
