from pathlib import Path
import subprocess,json,time
root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261028');repo=Path('/mnt/c/Code/RVInno/riscv')
args=['python3','-B','-m','unittest','discover','-s',str(repo/'team/optimizations/o2/integration/firstdot-v2-0f/audit'),'-p','test_orchestration_receipt.py','-v']
with (root/'orchestration-linux.stdout.log').open('xb') as out,(root/'orchestration-linux.stderr.log').open('xb') as err:
 result=subprocess.run(args,stdout=out,stderr=err)
(root/'orchestration-linux.json').write_text(json.dumps(dict(command=args,exit_code=result.returncode),indent=2)+'\n')
print('Linux orchestration',result.returncode)
