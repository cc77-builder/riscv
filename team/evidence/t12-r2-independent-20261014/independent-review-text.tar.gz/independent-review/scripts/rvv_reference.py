#!/usr/bin/env python3
"""Assemble and execute RVV candidates in pinned NEMU; no full-core simulation.

Independent expected values use Python unbounded integers, not RTL's sum tree.
The register-copy ABI is checked against the supplied pinned layout and SO.
"""
import ctypes as C
import importlib.util
import itertools
import json
import random
import struct
import sys
from pathlib import Path
from reviewlib import ROOT, run, sha, jsonout

TOOLROOT=Path('/home/lizufan/xiangshan-t10-t11-supervisor-20261013/tools/ubuntu-root')
TOOLENV={'LD_LIBRARY_PATH':str(TOOLROOT/'usr/lib/x86_64-linux-gnu')}
OUT=ROOT/'validation/rvv'; OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'sources/baseline/team/tests'))
import generate_t12 as original
from generate_baseline import scratch_registers

def allocation(vd,a,b):
    return next(p for p in range(2,32,2) if not {p,p+1}&{vd,a,b,0})

def short(vd,a,b,known=False,early_clear=False,tail='tu',narrow=False):
    p=allocation(vd,a,b)
    pre=[] if known else ['csrr t3, vl','csrr t4, vtype']
    mul=[f'vwmul.vv v{p}, v{a}, v{b}']
    clear=['vsetivli zero, 4, e32, m1, tu, mu',f'vmv.v.i v{vd}, 0']
    red=[f'vsetivli zero, 8, e16, m1, {tail}, mu',
         f'{"vredsum" if narrow else "vwredsum"}.vs v{vd}, v{p}, v{vd}']
    return pre+(clear+['vsetivli zero, 8, e8, m1, tu, mu']+mul if early_clear else mul+clear)+red+[
        'vsetivli zero, 8, e8, m1, tu, mu' if known else 'vsetvl zero, t3, t4']

def batch_short():
    return [f'vwmul.vv v{16+2*i}, v8, v9' for i in range(4)]+[
        'vsetivli zero, 4, e32, m1, tu, mu']+[
        f'vmv.v.i v{10+i}, 0' for i in range(4)]+[
        'vsetivli zero, 8, e16, m1, tu, mu']+[
        f'vwredsum.vs v{10+i}, v{16+2*i}, v{10+i}' for i in range(4)]+[
        'vsetivli zero, 8, e8, m1, tu, mu']

def old_allocated(vd,a,b):
    p,h,z,r=scratch_registers(vd,a,b)
    return ['csrr t3, vl','csrr t4, vtype','vsetivli zero, 4, e32, m1, tu, mu',
            f'vmv.v.i v{z}, 0','vsetivli zero, 8, e8, m1, tu, mu',f'vwmul.vv v{p}, v{a}, v{b}',
            'vsetivli zero, 8, e16, m2, tu, mu',f'vwredsum.vs v{r}, v{p}, v{z}',
            'vsetivli zero, 4, e32, m1, tu, mu',f'vmv.x.s t2, v{r}',f'vmv.v.i v{vd}, 0',
            f'vmv.s.x v{vd}, t2','vsetvl zero, t3, t4']

def assemble(name, sequences):
    asm=['.option norvc','.text','.balign 4']; offsets={}; offset=0
    for key,lines in sequences:
        offsets[key]=(offset,len(lines)*4)
        asm += [f'.globl block_{key}',f'block_{key}:']+lines
        offset+=len(lines)*4
    path=OUT/(name+'.S');path.write_text('\n'.join(asm)+'\n')
    for suffix,args in [
        ('as',['as','-march=rv64gcv','-mabi=lp64d','-o',str(OUT/(name+'.o')),str(path)]),
        ('objcopy',['objcopy','-j','.text','-O','binary',str(OUT/(name+'.o')),str(OUT/(name+'.bin'))]),
        ('objdump',['objdump','-d',str(OUT/(name+'.o'))])]:
        argv=[str(TOOLROOT/'usr/bin'/('riscv64-linux-gnu-'+args[0])),*args[1:]]
        assert run(name+'-'+suffix,argv,env=TOOLENV)==0
    data=(OUT/(name+'.bin')).read_bytes()
    assert len(data)==offset, (len(data),offset)
    jsonout('validation/rvv/'+name+'-blocks.json',{str(k):list(v) for k,v in offsets.items()})
    return {key:data[o:o+n] for key,(o,n) in offsets.items()}

class Reference:
    def __init__(self):
        self.layout=json.loads((ROOT/'evidence/reference-layout.json').read_text())
        assert sha(ROOT/'evidence/reference.so')=='e5f04192ad782581eef8cd17648933aa6da0fd0543944cb6e59eb931efc60cae'
        self.lib=C.CDLL(str(ROOT/'evidence/reference.so'))
        assert C.c_uint.in_dll(self.lib,'DIFFTEST_REG_SIZE').value==self.layout['size']
        for name,args in [('difftest_set_ramsize',[C.c_size_t]),('difftest_init_v2',[C.c_uint]),
                          ('difftest_regcpy',[C.c_void_p,C.c_bool]),
                          ('difftest_memcpy',[C.c_uint64,C.c_void_p,C.c_size_t,C.c_bool]),
                          ('difftest_exec',[C.c_uint64])]:
            fn=getattr(self.lib,name);fn.argtypes=args;fn.restype=None
        self.lib.difftest_set_ramsize(16*1024*1024)
        self.lib.difftest_init_v2(self.layout['size'])
        self.initial=self.read()
        self.code_addresses={}
        self.next_code_address=0x80000000
    def read(self):
        b=C.create_string_buffer(self.layout['size']); self.lib.difftest_regcpy(b,False);return bytearray(b.raw)
    def put(self,b):self.lib.difftest_regcpy(C.create_string_buffer(bytes(b)),True)
    def get(self,b,key):return struct.unpack_from('<Q',b,self.layout[key])[0]
    def set(self,b,key,value):struct.pack_into('<Q',b,self.layout[key],value)
    def memwrite(self,addr,data):self.lib.difftest_memcpy(addr,C.create_string_buffer(data),len(data),True)
    def memread(self,addr,n):
        b=C.create_string_buffer(n);self.lib.difftest_memcpy(addr,b,n,False);return b.raw
    def start(self,regs,policy=0,vxrm=3,vxsat=1,vl=8,vstart=0):
        state=bytearray(self.initial)
        for n in range(1,32):struct.pack_into('<Q',state,8*n,0x12340000+n)
        for k,v in dict(pc=0x80000000,mode=3,mstatus=(self.get(state,'mstatus')&~(3<<9))|(1<<9),
                        mtvec=0x80040000,mcause=0,mepc=0,vl=vl,vtype=policy,vstart=vstart,
                        vlenb=16,vxrm=vxrm,vxsat=vxsat,vcsr=(vxrm<<1)|vxsat).items():self.set(state,k,v)
        state[self.layout['vr']:self.layout['vr']+512]=b''.join(regs)
        return state
    def execute(self,code,state):
        # The pinned reference caches decoded instructions. Code memory is
        # immutable per PC: never overwrite a previous sequence in place.
        if code not in self.code_addresses:
            addr=self.next_code_address
            self.next_code_address+=(len(code)+63)&~63
            assert self.next_code_address<0x80c00000
            self.memwrite(addr,code);self.code_addresses[code]=addr
        addr=self.code_addresses[code]
        state=bytearray(state);self.set(state,'pc',addr);self.put(state)
        # This reference was built with CONFIG_DIFFTEST_REF_QUERY and accepts
        # only single-instruction cpu_exec calls (checked in the initial probe).
        for _ in range(len(code)//4):self.lib.difftest_exec(1)
        out=self.read()
        assert self.get(out,'pc')==addr+len(code),('unexpected trap/PC',hex(self.get(out,'pc')))
        return out

def expected(regs,vd,a,b):
    result=list(regs)
    signed=lambda x:x if x<128 else x-256
    value=sum(signed(x)*signed(y) for x,y in zip(regs[a][:8],regs[b][:8]))
    result[vd]=(value&0xffffffff).to_bytes(4,'little')+bytes(12)
    return result

def check(ref,before,after,want,scratch,gpr_scratch=(28,29),policy=None):
    offset=ref.layout['vr']
    for r in range(32):
        if r not in scratch:assert after[offset+16*r:offset+16*(r+1)]==want[r],('vector',r)
        if r not in gpr_scratch:assert after[8*r:8*(r+1)]==before[8*r:8*(r+1)],('gpr',r)
    for csr in ('vl','vtype','vstart','vlenb','vxrm','vxsat','vcsr'):
        target=policy if csr=='vtype' and policy is not None else ref.get(before,csr)
        assert ref.get(after,csr)==target,('csr',csr,ref.get(after,csr),target)
    assert (ref.get(after,'mstatus')>>9)&3==3

def main():
    triples=list(itertools.product(range(32),repeat=3))
    codes=assemble('short-all-aliases',[(i,short(*triple)) for i,triple in enumerate(triples)])
    cases=[('old_general',original.general()),('old_known',original.general(known=True)),
           ('short_known',short(10,8,9,known=True)),('old_batch',original.batched()),
           ('short_batch',batch_short()),('early_clear',short(8,8,9,early_clear=True)),
           ('tail_agnostic',short(10,8,9,tail='ta')),('narrow',short(10,8,9,narrow=True)),
           ('old_source_v4',original.general(10,4,9))]
    alias_triples=[(0,0,0),(31,31,31),(8,8,9),(9,8,9),(10,0,31),(0,8,9),(31,31,0)]
    cases += [(f'old_alloc_{i}',old_allocated(*t)) for i,t in enumerate(alias_triples)]
    others=assemble('directed-candidates',cases)
    ref=Reference();rng=random.Random(0x20261014)
    bank=[bytes(rng.randrange(256) for _ in range(16)) for _ in range(32)]
    counts={'all_register_triples':0,'boundary_policy_csr_alias':0,'random':0,'old_sequences':0,'batch':0}
    for i,t in enumerate(triples):
        vd,a,b=t;p=allocation(*t);state=ref.start(bank,(i%4)<<6,(i//4)%4,(i//16)%2)
        after=ref.execute(codes[i],state);check(ref,state,after,expected(bank,*t),{p,p+1})
        counts['all_register_triples']+=1
    vectors=[([0]*8,[127]*8),([1]*8,[1]*8),([-1]*8,[1]*8),([127]*8,[127]*8),
             ([-128]*8,[127]*8),([-128]*8,[-128]*8),([1,-2,3,-4,5,-6,7,-8],[8,7,6,5,4,3,2,1]),
             ([-128]+[0]*7,[-1]+[0]*7),([0]*7+[-128],[0]*7+[127])]
    for av,bv in vectors:
      for t in alias_triples:
       vd,a,b=t;regs=list(bank);regs[a]=bytes(x&255 for x in av)+bytes([0xa5]*8);regs[b]=bytes(x&255 for x in bv)+bytes([0x5a]*8)
       for policy,vxrm,vxsat in itertools.product((0,64,128,192),range(4),range(2)):
        state=ref.start(regs,policy,vxrm,vxsat);index=(vd*32+a)*32+b;p=allocation(*t)
        out=ref.execute(codes[index],state);check(ref,state,out,expected(regs,*t),{p,p+1})
        counts['boundary_policy_csr_alias']+=1
    for i in range(1000):
        regs=[bytes(rng.randrange(256) for _ in range(16)) for _ in range(32)]
        t=triples[rng.randrange(len(triples))];vd,a,b=t;p=allocation(*t)
        state=ref.start(regs,(i%4)<<6,i%4,i%2)
        out=ref.execute(codes[(vd*32+a)*32+b],state);check(ref,state,out,expected(regs,*t),{p,p+1});counts['random']+=1
    for i,t in enumerate(alias_triples):
        regs=list(bank);p,h,z,r=scratch_registers(*t)
        for policy in (0,64,128,192):
            state=ref.start(regs,policy);out=ref.execute(others[f'old_alloc_{i}'],state)
            check(ref,state,out,expected(regs,*t),{p,h,z,r},(7,28,29));counts['old_sequences']+=1
    for row in original.corpus():
        if row['kind']!='equivalence' or row['method']!='rvv':continue
        regs=[bytes.fromhex(x) for x in row['before']]
        for policy in (0,64,128,192):
            state=ref.start(regs,policy);out=ref.execute(others['old_general'],state)
            check(ref,state,out,expected(regs,10,8,9),{2,3,4,5},(7,28,29));counts['old_sequences']+=1
    for key,scratch,gprs in [('old_batch',{4,*range(16,28)},(7,)),('short_batch',set(range(16,24)),())]:
        state=ref.start(bank);want=list(bank)
        for d in range(10,14):want=expected(want,d,8,9)
        out=ref.execute(others[key],state);check(ref,state,out,want,scratch,gprs);counts['batch']+=1
    # Explicit counterexamples, verified against actual instructions (not string tests).
    negatives=[]
    for key,t in [('early_clear',(8,8,9)),('narrow',(10,8,9)),('old_source_v4',(10,4,9)),('tail_agnostic',(10,8,9))]:
        vd,a,b=t;regs=list(bank);regs[a]=bytes([128]*8)+bytes([0xa5]*8);regs[b]=bytes([127]*8)+bytes([0x5a]*8)
        state=ref.start(regs);out=ref.execute(others[key],state);o=ref.layout['vr']+16*vd
        actual=bytes(out[o:o+16]);want=expected(regs,*t)[vd]
        assert actual!=want,(key,'negative control unexpectedly matched')
        negatives.append(dict(name=key,vd=vd,vs1=a,vs2=b,expected=want.hex(),actual=actual.hex()))
    state=ref.start(bank,192);out=ref.execute(others['old_known'],state)
    assert ref.get(out,'vtype')==0
    negatives.append(dict(name='known_config_does_not_preserve_arbitrary_policy',initial_vtype=192,actual_vtype=0))
    # Outside the supported entry domain. This specific NEMU build rejects
    # nonzero vstart at the first arithmetic instruction; do not continue into
    # its trap vector or assume portable restart support from a host model.
    state=ref.start(bank,vstart=1);idx=(10*32+8)*32+9;addr=ref.code_addresses[codes[idx]]
    ref.set(state,'pc',addr);ref.put(state)
    for _ in range(3):ref.lib.difftest_exec(1)
    out=ref.read();assert ref.get(out,'mcause')==2 and ref.get(out,'mepc')==addr+8
    negatives.append(dict(name='nonzero_vstart_outside_legal_domain',reference_observation='illegal instruction at vwmul',
                          mcause=2,vstart=ref.get(out,'vstart'),not_a_portable_restart_claim=True))
    products=[a*b for a in range(-128,128) for b in range(-128,128)]
    assert (min(products),max(products))==(-16256,16384)
    result=dict(status='PASS_REFERENCE_ISA_ONLY',counts=counts,negative_controls=negatives,
                single_product_range=[min(products),max(products)],sum_range=[8*min(products),8*max(products)],
                instruction_counts=dict(old_general=len(original.general()),short_general=8,old_known=len(original.general(known=True)),short_known=6,
                                        old_batch=len(original.batched()),short_batch=len(batch_short())),
                reference_sha256=sha(ROOT/'evidence/reference.so'),full_core='NOT_RUN',RTL='NOT_RUN',
                caveat='Pinned NEMU execution plus independent integer oracle; does not replace official ISA confirmation or candidate RTL/core validation.')
    jsonout('validation/rvv/results.json',result);print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
