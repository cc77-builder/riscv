#!/usr/bin/env python3
"""Synthetic minimal acceptance counterexamples, explicitly NOT DUT evidence."""
import importlib.util
import json
import sys
from pathlib import Path
from reviewlib import ROOT, jsonout, run
sys.path.insert(0,str(ROOT/'sources/baseline/team/tests'))
import generate_t12 as gen
import test_t12 as oldtests

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

compact=load('compact','sources/baseline/team/scripts/check_t12_compact.py')
full=oldtests.checker
out=ROOT/'validation/checkers';out.mkdir(parents=True,exist_ok=True)
data=out/'data'
if not data.exists():gen.generate(data)
m,rows=compact.load(data)
results=[]

def full_counterexample(name,transform):
    content=transform(oldtests.fixture(data))
    (out/(name+'.SYNTHETIC.log')).write_text(content+'\n')
    result=full.validate(content,0,data)
    results.append(dict(id=name,result='CONFIRMED_ACCEPTANCE_GAP',checker_result=result['status'],synthetic=True))

full_counterexample('full_impossible_instret',lambda text:text.replace('instret_end=120','instret_end=101',1))
full_counterexample('full_counter_exceeds_uint64',lambda text:text.replace('cycle_end=200',f'cycle_end={2**64+1}',1))
full_counterexample('full_fault_pc_self_consistency_only',lambda text:text.replace('0x80001000','0x80002000'))

seq=next(i for i,x in enumerate(m['schedule']) if x['id']=='perf-complete-vdot')
digest,selected=compact.expected_digest(m,rows,seq,1)
template='\n'.join(['Difftest enabled',f'T12C_BEGIN start={seq} limit=1',
    'T12_CONTROLS high96=1 preserved=1 csr=1',f'T12C_PERF seq={seq} cy=100,101 ir=100,101',
    f'T12C_END executed=1 hash=0x{digest:016x}','HIT GOOD TRAP'])+'\n'
for name,text in [('compact_impossible_instret',template),
                  ('compact_counter_exceeds_uint64',template.replace('cy=100,101',f'cy=100,{2**64+1}')),
                  ('compact_counter_digest_not_bound',template.replace('cy=100,101','cy=100,1000000000000'))]:
    (out/(name+'.SYNTHETIC.log')).write_text(text)
    result=compact.check(text,data,seq,1,0)
    results.append(dict(id=name,result='CONFIRMED_ACCEPTANCE_GAP',checker_result=result['status'],
                        seq=seq,required_dots=16,reported_instret=result['metrics'][0]['instret'],digest=f'{digest:016x}',synthetic=True))

receipt=dict(source='b8272f2e8a62557437869c936b6ea9ce5fff84fe',start=seq,limit=1,
    manifest_sha256=compact.sha(data/'manifest.json'),runtime_pins=compact.PINS,exit_code=0,completed=True,
    difftest=True,ram='128MB',pid=123,started_at='2026-10-14T00:00:00+08:00',finished_at='2026-10-14T00:00:01+08:00',
    image_sha256='0'*64,argv=['/definitely/nonexistent/emu','--diff','/definitely/nonexistent/ref.so','-i','/definitely/nonexistent/image.bin'])
compact.bind(receipt,data,receipt['source'])
jsonout('validation/checkers/unbound_receipt.SYNTHETIC.json',receipt)
assert run('compact-counterexample-cli',[sys.executable,'-B','sources/baseline/team/scripts/check_t12_compact.py',
    '--log',str(out/'compact_impossible_instret.SYNTHETIC.log'),'--data',str(data),
    '--receipt',str(out/'unbound_receipt.SYNTHETIC.json'),'--expected-source',receipt['source'],
    '--output',str(out/'ACCEPTED_SYNTHETIC_COUNTEREXAMPLE.json')])==0
results.append(dict(id='compact_receipt_has_no_real_image_log_or_runtime_binding',result='CONFIRMED_ACCEPTANCE_GAP',
                    example='nonexistent argv paths and all-zero image digest accepted by CLI',synthetic=True))

# Negative controls: acceptance still fails closed on actual timeout or missing completion.
negative=[]
for name,log,code in [('timeout',template,124),('missing_end',template.replace(f'T12C_END executed=1 hash=0x{digest:016x}\n',''),0)]:
    try:compact.check(log,data,seq,1,code)
    except ValueError as e:negative.append(dict(name=name,result='REJECTED_AS_REQUIRED',message=str(e)))
    else:raise AssertionError(name)

# Actual archived slices: no fabricated completion and no ISA/performance PASS.
archived=[]
old=ROOT/'evidence/old_runs/stress-slices-1'
for name in ('000','003','006','008'):
    meta=json.loads((old/name/'receipt.json').read_text());text=(old/name/'run.log').read_text()
    assert meta['exit_code']==124 and not any(x.startswith('T12C_END ') for x in text.splitlines())
    archived.append(dict(slice=name,start=meta['start'],limit=meta['limit'],exit_code=124,end_present=False,status='NOT_ACCEPTED'))

# End-state test weakness, not an assertion that the real machine skipped loops.
corpus={r['id']:r for r in gen.corpus()}
loops=[]
for name,onepass in [
 ('vfex4-div-mix',[('div',14,8,9),('dot',10,8,9),('div',15,9,8),('dot',11,14,15)]),
 ('branch-dependent-candidate',[('dot',10,8,8)]),
 ('rob-ftq-wrap-candidate',[('dot',10,8,9),('dot',11,8,9),('dot',12,8,9),('dot',13,8,9)]),
 ('perf-complete-vdot',[('dot',10,8,9)])]:
    row=corpus[name];regs=[bytes.fromhex(v) for v in row['before']]
    for kind,d,a,b in onepass:
        if kind=='dot':gen.apply(regs,d,a,b)
        else:
            value=bytearray(regs[d])
            for lane in range(8):
                x,y=gen.s8(regs[a][lane]),gen.s8(regs[b][lane])
                value[lane]=((abs(x)//abs(y))*(-1 if (x<0)!=(y<0) else 1) if y else -1)&255
            regs[d]=bytes(value)
    assert [x.hex() for x in regs]==row['expected']
    loops.append(dict(id=name,reduced_execution=onepass,final_state_indistinguishable=True))

jsonout('validation/checkers/results.json',dict(status='COUNTEREXAMPLES_REPRODUCED',synthetic_not_DUT=True,
    findings=results,required_rejections=negative,archived_slices=archived,loop_count_blind_spots=loops))
print(json.dumps(dict(findings=len(results),required_rejections=negative,archived_slices=archived,loops=loops),indent=2))
