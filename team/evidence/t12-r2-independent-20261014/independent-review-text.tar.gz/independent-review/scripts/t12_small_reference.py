#!/usr/bin/env python3
"""Run original T12 stress bodies + trap harness + C judge in reference only.
No AM/platform build, RTL EMU, or producer workspace modifications.
"""
import importlib.util
import json
import struct
import sys
from pathlib import Path
from reviewlib import ROOT, run, jsonout, sha
from rvv_reference import Reference, TOOLROOT, TOOLENV

OUT=ROOT/'validation/software'
assert (OUT/'probes.c').exists(), 'run software_reference.py first'
code=(OUT/'probes.c').read_text()+r'''
uint64_t probe_real_run(uint64_t index) {
  return run(&t12_cases[index],0);
}
'''
(OUT/'real-t12.c').write_text(code)
harness=ROOT/'sources/baseline/team/workloads/vdot-exceptions'
gcc=str(TOOLROOT/'usr/bin/riscv64-linux-gnu-gcc')
flags=['-march=rv64gcv','-mabi=lp64d','-O2','-fno-tree-vectorize','-fno-tree-slp-vectorize',
       '-ffreestanding','-fno-builtin','-fno-stack-protector','-fno-pic','-fno-pie','-mcmodel=medany',
       '-mno-relax','-ffunction-sections','-fdata-sections','-nostdinc',
       '-I'+str(OUT/'include'),'-I'+str(harness),'-I'+str(OUT/'data')]
for name,path in [('real-t12',OUT/'real-t12.c'),('real-sites',OUT/'data/t12-sites.S'),('real-harness',harness/'harness.S')]:
    assert run('small-t12-compile-'+name,[gcc,*flags,'-c',str(path),'-o',str(OUT/(name+'.o'))],env=TOOLENV)==0
assert run('small-t12-link',[gcc,*flags,'-nostdlib','-static','-no-pie','-Wl,--gc-sections','-Wl,--no-relax',
    '-Wl,-T,'+str(OUT/'link.ld'),'-Wl,-e,probe_real_run',
    *[str(OUT/(x+'.o')) for x in ('real-t12','judge','real-sites','real-harness')],'-o',str(OUT/'real-t12.elf')],env=TOOLENV)==0
for name,args in [('objcopy',['objcopy','-O','binary',str(OUT/'real-t12.elf'),str(OUT/'real-t12.bin')]),
                  ('objdump',['objdump','-d',str(OUT/'real-t12.elf')]),('nm',['nm','-n',str(OUT/'real-t12.elf')])]:
    assert run('small-t12-'+name,[str(TOOLROOT/'usr/bin'/('riscv64-linux-gnu-'+args[0])),*args[1:]],env=TOOLENV)==0
symbols={}
for line in (ROOT/'logs/small-t12-nm.log').read_text().splitlines():
    f=line.split()
    if len(f)==3:symbols[f[2]]=int(f[0],16)
ref=Reference();ref.memwrite(0x80000000,(OUT/'real-t12.bin').read_bytes())
cases=json.loads((OUT/'data/cases.json').read_text());records=[]
for index in range(13):
    state=ref.start([bytes(16)]*32);ref.set(state,'pc',symbols['probe_real_run'])
    struct.pack_into('<Q',state,8,0x80f00000);struct.pack_into('<Q',state,16,0x80e00000)
    struct.pack_into('<Q',state,80,index);ref.put(state)
    # Each reference instruction is stepped with a bounded host watchdog. Trap
    # entry/resume is the unmodified pinned assembly, not a host substitute.
    dots=0
    for count in range(1,200001):
        before=ref.read();pc=ref.get(before,'pc')
        if 0x80000000<=pc<0x80c00000:
            word=int.from_bytes(ref.memread(pc,4),'little')
            if word&0xfe00707f==0x0200000b:dots+=1
        ref.lib.difftest_exec(1);after=ref.read()
        if ref.get(after,'pc')==0x80f00000:
            rc=struct.unpack_from('<Q',after,80)[0];assert rc==0,(index,rc)
            break
    else:raise AssertionError(('watchdog',index))
    records.append(dict(index=index,id=cases[index]['id'],return_code=rc,reference_instructions=count,
                        custom_instruction_attempts=dots,scope='reference architectural execution only'))
    print(json.dumps(records[-1]),flush=True)
spec=importlib.util.spec_from_file_location('compact',ROOT/'sources/baseline/team/scripts/check_t12_compact.py')
compact=importlib.util.module_from_spec(spec);spec.loader.exec_module(compact)
m,byid=compact.load(OUT/'data');want,_=compact.expected_digest(m,byid,0,13)
actual=int.from_bytes(ref.memread(symbols['transcript'],8),'little')
done=int.from_bytes(ref.memread(symbols['done'],4),'little')
assert done==13 and actual==want,(done,hex(actual),hex(want))
jsonout('validation/software/real-t12-results.json',dict(status='PASS_SMALL_REFERENCE_STRESS_ONLY',cases=records,
    digest=f'{actual:016x}',done=done,elf_sha256=sha(OUT/'real-t12.elf'),
    claim='Source-level loops/recovery/digest terminate in pinned NEMU; this neither explains nor clears the old full-core timeouts.',
    full_core='NOT_RUN',microarchitectural_events='NOT_OBSERVED',AM_build='NOT_RUN'))
