#!/usr/bin/env python3
"""Produce the review index from actual frozen manifests and command receipts."""
import hashlib
import json
from pathlib import Path
from reviewlib import ROOT, jsonout, sha

m=json.loads((ROOT/'evidence/source_manifest.json').read_text())
extra=json.loads((ROOT/'evidence/extra_manifest.json').read_text())
by_path={f['path']:f for f in m['files'] if f.get('label')=='baseline'}
def ref(path,lo,hi=None):
    f=by_path[path]
    return dict(commit=f['commit'],git_blob=f['blob'],sha256=f['sha256'],path=path,
                snapshot=f['snapshot'],line_start=lo,line_end=hi or lo)
def fpath(name):return 'src/main/scala/xiangshan/'+name
def finding(id,classification,severity,title,sources,evidence,impact,recommendation):
    return dict(id=id,classification=classification,severity=severity,title=title,
                sources=sources,evidence=evidence,impact=impact,recommendation=recommendation)

findings=[
finding('H01','CONFIRMED_SOURCE_FACT','P1','原输入融合时序论证遗漏真实的 EXU 输入寄存器',
 [ref(fpath('backend/Backend.scala'),641,653),ref(fpath('backend/datapath/NewPipelineConnect.scala'),40,50),
  ref(fpath('backend/exu/ExeUnit.scala'),304,308),ref(fpath('backend/fu/FuConfig.scala'),63)],
 ['EARLY_TIMING_REVIEW.md'],'RF/OG2/bypass 与乘法不能跨该寄存器直接串成同周期组合路径。',
 '从真实 bypassNetwork2vfExuBlock.data.Q 追到 productsReg.D；若物理综合 retime，按实际网表重追端点。'),
finding('H02','SOURCE_DEDUCTION_NEEDS_RTL','P2','取消后 uncertain clock enable 未清除，可能持续开钟',
 [ref(fpath('backend/exu/ExeUnit.scala'),102,121),ref(fpath('backend/exu/ExeUnit.scala'),127,141),
  ref(fpath('backend/fu/wrapper/VDot.scala'),40,52)],['validation/timing/results.json'],
 '接受后 kill 无 out.fire，busy 清而 uncer_en_reg 保持；这是活动/门控风险，未证明功能死锁或测得功耗。',
 '在真实 EXU/ICG 上验证 cancel 后 idle gate 关闭；清使能应保留 kill 沿以清 FU 状态。'),
finding('H03','CONFIRMED_SOURCE_FACT_AND_DEDUCTION','P1','单请求与共享 busy 阻止单改 piped/队列获得 II1',
 [ref(fpath('backend/fu/wrapper/VDot.scala'),20,75),ref(fpath('backend/exu/ExeUnit.scala'),224,226),
  ref(fpath('backend/datapath/WbArbiter.scala'),177,224)],['validation/timing/results.json'],
 '基线局部 E0/E2/E3/II4，融合预测 E0/E1/E2/II3；真实 full-core 吞吐还受 input buffer/OG2/WB 影响。',
 '用实际 gated EXU/WB/ROB 验证；不把局部握手或 generic cells 当 PPA。'),
finding('H04','SOURCE_DEDUCTION_NEEDS_ACTIVITY_AND_PHYSICAL_VALIDATION','P2','融合去掉了源寄存器的操作数隔离',
 [ref(fpath('backend/fu/wrapper/VDot.scala'),30,48),ref(fpath('backend/exu/ExeUnit.scala'),304,308)],
 ['evidence/fusion_patch_check.json','EARLY_TIMING_REVIEW.md'],
 '共享 VFEX 输入为其他 FU 更新时，融合的组合乘法也可能翻转；clockgate 只冻结寄存器，不冻结直接输入的组合逻辑。',
 '用同 workload 的活动和真实库验证能耗；若加 operand isolation，将新增逻辑与共享 Q 负载纳入 STA，不凭寄存器声明数量估计 PPA。'),
finding('B01','CONFIRMED_REFERENCE_ISA_VALIDATION','P1','现 RVV 基线可缩短：13→8，11→6，batch26→15',
 [ref('team/tests/generate_t12.py',28,48),ref('team/tests/generate_baseline.py',13,17),ref('team/tests/generate_baseline.py',39,49)],
 ['validation/rvv/results.json','logs/rvv-reference.command.json','RVV_BASELINE_REVIEW.md'],
 '旧版独立 seed 清零、scalar 往返和冗余配置会抬高相对 VDot 的耗时；尚无全核周期比。',
 '先 vwmul 保存乘积，再完整清 vd，e16/m1 VL8 用 vd 兼 seed/dest 做 widening reduction，tu，恢复原配置。'),
finding('B02','CONFIRMED_REFERENCE_COUNTEREXAMPLES_SCOPED','P2','固定 scratch 与 known-config 有适用域限制',
 [ref('team/tests/generate_t12.py',28,36),ref('team/tests/generate_t12.py',119,144)],
 ['validation/rvv/results.json'],
 'general(a=v4) 提前清源；known=True 将任意 vtype 策略恢复为0。当前使用8/9/10和入态0未触发此错误。',
 '以 T09 allocator 或本审查 allocator 规避目的/源/v0与产品组重叠，明确已知配置合同，不夸大 corpus 覆盖。'),
finding('S01','CONFIRMED_CHECKER_BUG','P1','验收接受超过64位计数及明显不足的退休量',
 [ref('team/scripts/check-t12-run.py',30,32),ref('team/scripts/check-t12-run.py',99,105),
  ref('team/scripts/check_t12_compact.py',52,59),ref(fpath('backend/decode/DecodeUnit.scala'),212,218),
  ref(fpath('backend/dispatch/NewDispatch.scala'),792,816)],
 ['validation/checkers/results.json','validation/checkers/compact_impossible_instret.SYNTHETIC.log'],
 '16-dot complete-vdot 可报告 instret 差1；cycle_end=2^64+1也被接受，无法保证性能数据可信。',
 '校验 uint64 范围、溢出策略和由最终 ELF 路径推导的退休下界/计数；保留原始计数。'),
finding('S02','CONFIRMED_ACCEPTANCE_BINDING_GAP','P1','compact digest 不覆盖性能计数',
 [ref('team/workloads/t12-perf/main.c',83,91),ref('team/scripts/check_t12_compact.py',18,32)],
 ['validation/checkers/compact_counter_digest_not_bound.SYNTHETIC.log','validation/checkers/results.json'],
 '保持 digest 不变，将周期终点101改成10^12仍通过；状态摘要不能验证加速比字段。',
 '摘要和可信回执绑定四个计数器、测量域、执行量与 raw log SHA；FNV 不是认证机制。'),
finding('S03','CONFIRMED_ACCEPTANCE_BINDING_GAP','P1','receipt/source/镜像/PC 仅自报字段之间比较',
 [ref('team/scripts/check_t12_compact.py',62,74),ref('team/scripts/check-t12-run.py',39,52),
  ref('team/scripts/check-t12-run.py',89,95)],
 ['logs/compact-counterexample-cli.log','validation/checkers/unbound_receipt.SYNTHETIC.json','validation/checkers/results.json'],
 'CLI 接受不存在的运行工具/镜像路径与全0 image SHA；full checker 同改 epc/expected_pc 也通过。不是实际 DUT 错 PC 证据。',
 '由可信 launcher 验证真实文件 SHA、ELF 符号、实际 argv 和 wait 状态，绑定日志；保留原始 provenance。'),
finding('S04','CONFIRMED_OBSERVABILITY_GAP','P2','多个长循环缩短后具有相同终态与 case digest',
 [ref('team/tests/generate_t12.py',87,99),ref('team/tests/generate_t12.py',123,144)],
 ['validation/checkers/results.json','validation/software/real-t12-results.json'],
 '终态无法单独证明32/128/1024/16轮均执行；不能把标签命名当共享竞争/取消/ROB wrap覆盖。',
 '增加依赖迭代次数的可检查签名或核验退休/PC trace；微架构事件需要 RTL 观测。'),
finding('S05','CONFIRMED_COMPILED_VERIFIER_OBSERVABILITY_GAP','P2','异常 recovery 可覆盖 fault 时 v10 的瞬时错误',
 [ref('team/tests/generate_t12.py',100,112),ref('team/workloads/vdot-exceptions/harness.S',199,202),
  ref('team/workloads/vdot-exceptions/harness.S',109,132),ref('team/workloads/t12-perf/main.c',48,57)],
 ['validation/software/results.json','logs/software-reference.command.json'],
 '实际编译 C verifier 接受 recovery 擦除的 v10 故障注入；持久 v16 故障被拒绝。完整逐步 DiffTest 可能另行捕获，未证明 RTL 存在该缺陷。',
 'fault CSR 捕获后、recovery 执行前保存完整向量快照并检查；保留精确异常/身份与无部分更新的独立证据。'),
finding('S06','CONFIRMED_SMALL_REFERENCE_TESTS_NO_ROOT_CAUSE_CLAIM','INFO','hex/decimal/digest 与13个 stress 参考执行均终止',
 [ref('team/workloads/t12-perf/main.c',19,29),ref('team/workloads/t12-perf/main.c',77,91),ref('team/tests/generate_t12.py',59,112)],
 ['validation/software/results.json','validation/software/real-t12-results.json','evidence/historical_formatter_comparison.json'],
 '未复现源级无限循环或序列化不匹配；不能仅凭旧日志截断归因。旧四片 exit124仍未验收。',
 '下一轮真 EMU 最小定位保留最近退休 PC/count 与逐段 heartbeat、UART、子进程退出原因。')]

receipts=[]
for path in sorted((ROOT/'logs').glob('*.command.json')):
    d=json.loads(path.read_text())
    # Earlier driver attempts were deliberately retained under new file names.
    oldlog=d.get('log')
    sibling=path.with_name(path.name.replace('.command.json','.log'))
    if 'initial-' in path.name or 'vstart-probe-failure' in path.name:
        d.setdefault('original_log_path',oldlog);d['log']=str(sibling.relative_to(ROOT))
        path.write_text(json.dumps(d,indent=2)+'\n')
    receipts.append(dict(receipt=str(path.relative_to(ROOT)),**d))

pins={k:{x:v[x] for x in ('commit','repo','available')} for k,v in m['pins'].items()}
review=dict(schema_version=1,status='REVIEW_COMPLETE_FOR_AVAILABLE_PINS_WITH_OPEN_GATES',
    constraints=dict(writes_only_review=True,subagents=0,other_AI_model_calls=0,network_used=False,
        privilege_or_security_changes=False,AM_builds=0,full_core_EMU_runs=0,git_pushes=0),
    source_pins=pins,source_manifest='evidence/source_manifest.json',extra_manifest='evidence/extra_manifest.json',
    provenance=dict(working_tree_source_used_as_fixed=False,fusion_patch='evidence/fusion_patch_check.json',
        draft1='NOT_AVAILABLE_IN_FOUR_RELEVANT_LOCAL_OBJECT_STORES'),
    findings=findings,validation=dict(
        RVV=json.loads((ROOT/'validation/rvv/results.json').read_text()),
        software=json.loads((ROOT/'validation/software/results.json').read_text()),
        original_T12_stress_reference=json.loads((ROOT/'validation/software/real-t12-results.json').read_text()),
        checkers='validation/checkers/results.json',timing_deductions='validation/timing/results.json',
        snapshot_integrity='evidence/snapshot_integrity.json'),
    hardware_acceptance=dict(candidate_promoted=False,candidate_RTL_AB='NOT_RUN',integrated_clockgate_OG2_WB_ROB='NOT_RUN',
        full_core='NOT_RUN',STA='NOT_RUN',Liberty=None,PVT=None,clock_period=None,frequency=None,area=None,power=None,
        generic_gate_statistics='NOT_RUN',current_four_timeout_slices='NOT_ACCEPTED'),
    promotion_gates=['Resolve and inspect the actual Draft #1 Git object before attributing any result to it.',
        'Candidate/default real RTL with gated EXU, input pipeline, OG2 retries, WB stalls, redirect/self/wrap/reset and identity negative controls.',
        'Same declared clock/Liberty/PVT/SDC and actual post-map/post-route launch/capture paths: max/min, gate checks, fanout/slew/cap, unconstrained endpoints.',
        'True completed full-core DiffTest plus strengthened legal RVV paired measurement on the same hardware; compare cycles times achievable clock period.'],
    commands=receipts,documents=['EARLY_TIMING_REVIEW.md','RVV_BASELINE_REVIEW.md','TIMEOUT_REVIEW.md','FINAL.md'],
    reproducible_entry='scripts/run_validation.py')
jsonout('REVIEW.json',review)

keypaths=[fpath(x) for x in ['backend/fu/wrapper/VDot.scala','backend/fu/vector/VDotDatapath.scala',
    'backend/fu/FuConfig.scala','backend/exu/ExeUnit.scala','backend/Backend.scala',
    'backend/datapath/NewPipelineConnect.scala','backend/datapath/Og2ForVector.scala',
    'backend/datapath/BypassNetwork.scala','backend/datapath/WbArbiter.scala','backend/rob/RobBundles.scala']]
keypaths+=['team/tests/generate_t12.py','team/tests/generate_baseline.py','team/workloads/t12-perf/main.c',
    'team/scripts/check-t12-run.py','team/scripts/check_t12_compact.py','team/workloads/vdot-exceptions/harness.S']
lines=['# Exact source index','',
       'Commit: `b8272f2e8a62557437869c936b6ea9ce5fff84fe`. All line numbers in the reports refer to these unmodified Git-blob snapshots.',
       '', '| Source | Git blob SHA1 | SHA256 |','|---|---|---|']
for path in keypaths:
    f=by_path[path];lines.append(f'| [{path}]({f["snapshot"]}) | `{f["blob"]}` | `{f["sha256"]}` |')
lines+=['','Full file index, commits and git command exits: [source_manifest.json](evidence/source_manifest.json).',
        'Utility/historical C/NEMU source/binary ABI pins: [extra_manifest.json](evidence/extra_manifest.json).',
        'Tool versions and hashes: [tool_inventory.json](evidence/tool_inventory.json).']
(ROOT/'SOURCE_INDEX.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(dict(status=review['status'],findings=len(findings),command_receipts=len(receipts)),indent=2))
