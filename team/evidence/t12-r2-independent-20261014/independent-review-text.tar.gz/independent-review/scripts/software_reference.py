#!/usr/bin/env python3
"""Compile pinned T12 C locally (no AM) and single-step small probes in NEMU."""
import json
import re
import struct
import sys
from pathlib import Path
from reviewlib import ROOT, run, jsonout, sha
from rvv_reference import Reference, TOOLROOT, TOOLENV
sys.path.insert(0,str(ROOT/'sources/baseline/team/tests'))
import generate_t12 as gen

OUT=ROOT/'validation/software';OUT.mkdir(parents=True,exist_ok=True)
include=OUT/'include';include.mkdir(exist_ok=True)
(include/'stdint.h').write_text('typedef unsigned long uint64_t; typedef unsigned int uint32_t; typedef unsigned short uint16_t; typedef unsigned char uint8_t;\n#define UINT64_C(x) x##UL\n')
(include/'stddef.h').write_text('typedef unsigned long size_t;\n#define offsetof(t,m) __builtin_offsetof(t,m)\n')
data=OUT/'data'
if not data.exists():gen.generate(data)
source=ROOT/'sources/baseline/team/workloads/t12-perf/main.c'
harness=ROOT/'sources/baseline/team/workloads/vdot-exceptions'
probe=r'''
#define main ignored_workload_main
#include "PINNED_SOURCE"
#undef main
unsigned char probe_output[256];
uint64_t probe_length, probe_results[5];
void _putc(char c) { if (probe_length < 256) probe_output[probe_length++]=(unsigned char)c; }
void _halt(int code) { (void)code; for (;;) {} }
uint64_t probe_hex(uint64_t n) { probe_length=0; hex(n); return probe_length; }
uint64_t probe_decimal(uint64_t n) { probe_length=0; decimal(n); return probe_length; }
static const struct t12_case *prepare(unsigned i) {
  const struct t12_case *c=&t12_cases[i];
  zero(&record,sizeof(record));zero(&after,sizeof(after));
  zero(&t12_recovery_csrs,sizeof(t12_recovery_csrs));t12_recovery_status=0;
  after.head[0]=after.head[1]=after.tail[0]=after.tail[1]=canary;
  record.pre=(struct vector_csrs){0,8,0,3,1,7};record.post=record.pre;
  record.pre_status=1UL<<9; record.raw_status=3UL<<9;record.phase=1;record.pre_valid=1;
  for(unsigned r=0;r<32;r++) for(unsigned b=0;b<16;b++) {
    record.pre_regs[r][b]=c->before[r][b];after.regs[r][b]=c->expected[r][b];
  }
  if(c->fault_vl>=0) {
    record.post.vl=c->fault_vl;record.trap_count=1;record.cause=2;
    record.epc=record.expected_pc=(uint64_t)c->fault;
    t12_recovery_csrs=record.pre;t12_recovery_status=3UL<<9;
  }
  return c;
}
uint64_t probe_digest(uint64_t i) {
  const struct t12_case *c=prepare(i);transcript=UINT64_C(0xcbf29ce484222325);
  record_digest(c,0,i);return transcript;
}
uint64_t probe_verify_recovery(uint64_t ignored) {
  (void)ignored;const struct t12_case *c=prepare(8);
  probe_results[0]=verify(c);
  after.regs[16][0]^=1;probe_results[1]=verify(c);after.regs[16][0]^=1;
  /* A hypothetical illegal-operation non-destination corruption is erased by
     the subsequent legal vdot v10. Existing trap_record has no fault-time VR snapshot. */
  after.regs[10][0]^=0x80;probe_results[4]=after.regs[10][0];
  for(unsigned b=0;b<16;b++)after.regs[10][b]=c->expected[10][b];
  probe_results[2]=verify(c);
  t12_recovery_csrs.vl=7;probe_results[3]=verify(c);
  return probe_results[0] || probe_results[1]!=7 || probe_results[2] || probe_results[3]!=20;
}
'''.replace('PINNED_SOURCE',str(source))
(OUT/'probes.c').write_text(probe)
rows=gen.corpus();stubs=['.option norvc','.text']
for row in rows:
    name='t12_'+row['id'].replace('-','_')
    stubs += [f'.globl {name}',f'{name}:','ret']
    if row['fault_vl'] is not None:
        name=row['id'].replace('-','_')+'_fault';stubs += [f'.globl {name}',f'{name}:','ret']
(OUT/'unused_case_address_stubs.S').write_text('\n'.join(stubs)+'\n')
(OUT/'link.ld').write_text('SECTIONS { . = 0x80000000; .text : { KEEP(*(.text.probe_*)) *(.text*) } .rodata : { *(.rodata*) } .data : { *(.data*) *(.sdata*) } .bss : { *(.bss*) *(.sbss*) *(COMMON) } }\n')
gcc=str(TOOLROOT/'usr/bin/riscv64-linux-gnu-gcc')
flags=['-march=rv64gcv','-mabi=lp64d','-O2','-fno-tree-vectorize','-fno-tree-slp-vectorize','-ffreestanding',
       '-fno-builtin','-fno-stack-protector','-fno-pic','-fno-pie','-mcmodel=medany','-mno-relax',
       '-ffunction-sections','-fdata-sections','-nostdinc','-I'+str(include),'-I'+str(harness),'-I'+str(data)]
assert run('software-gcc-version',[gcc,'--version'],env=TOOLENV)==0
for name,path in [('probes',OUT/'probes.c'),('judge',harness/'judge.c'),('stubs',OUT/'unused_case_address_stubs.S')]:
    assert run('software-compile-'+name,[gcc,*flags,'-c',str(path),'-o',str(OUT/(name+'.o'))],env=TOOLENV)==0
assert run('software-link',[gcc,*flags,'-nostdlib','-static','-no-pie','-Wl,--gc-sections','-Wl,--no-relax',
    '-Wl,-T,'+str(OUT/'link.ld'),'-Wl,-e,probe_hex',*[str(OUT/(x+'.o')) for x in ('probes','judge','stubs')],
    '-o',str(OUT/'probes.elf')],env=TOOLENV)==0
for name,args in [('objcopy',['objcopy','-O','binary',str(OUT/'probes.elf'),str(OUT/'probes.bin')]),
                  ('objdump',['objdump','-d',str(OUT/'probes.elf')]),('nm',['nm','-n',str(OUT/'probes.elf')])]:
    assert run('software-'+name,[str(TOOLROOT/'usr/bin'/('riscv64-linux-gnu-'+args[0])),*args[1:]],env=TOOLENV)==0
symbols={}
for line in (ROOT/'logs/software-nm.log').read_text().splitlines():
    fields=line.split()
    if len(fields)==3:symbols[fields[2]]=int(fields[0],16)
ref=Reference();ref.memwrite(0x80000000,(OUT/'probes.bin').read_bytes())
def call(name,arg):
    state=ref.start([bytes(16)]*32);ref.set(state,'pc',symbols[name])
    # No execute() call here: linked code and all data addresses remain immutable.
    struct.pack_into('<Q',state,8,0x80f00000);struct.pack_into('<Q',state,16,0x80e00000)
    struct.pack_into('<Q',state,80,arg);ref.put(state)
    for count in range(1,100001):
        ref.lib.difftest_exec(1);after=ref.read()
        if ref.get(after,'pc')==0x80f00000:return struct.unpack_from('<Q',after,80)[0],count
    raise AssertionError('bounded probe did not return: '+name)
formatting=[]
for value in (0,1,9,10,99,100,2**32-1,2**63,2**64-1):
    for name,want in [('probe_decimal',str(value)),('probe_hex',f'0x{value:016x}')]:
        length,steps=call(name,value);actual=ref.memread(symbols['probe_output'],length).decode()
        assert actual==want,(name,value,actual,want)
        formatting.append(dict(function=name,value=str(value),output=actual,instructions=steps))

# Compare exact compiled compact serialization to the pinned Python checker.
import importlib.util
spec=importlib.util.spec_from_file_location('compact',ROOT/'sources/baseline/team/scripts/check_t12_compact.py')
compact=importlib.util.module_from_spec(spec);spec.loader.exec_module(compact)
m,byid=compact.load(data);digests=[]
for i in (0,8):
    actual,steps=call('probe_digest',i);want,_=compact.expected_digest(m,byid,i,1)
    assert actual==want,(hex(actual),hex(want))
    digests.append(dict(seq=i,id=m['schedule'][i]['id'],hash=f'{actual:016x}',instructions=steps))
rc,steps=call('probe_verify_recovery',0);assert rc==0
verdicts=list(struct.unpack('<5Q',ref.memread(symbols['probe_results'],40)))
assert verdicts[:4]==[0,7,0,20],verdicts
result=dict(status='PASS_SMALL_COMPILED_C_PROBES_REFERENCE_ONLY',formatting=formatting,compact_digest=digests,
    recovery_counterexample=dict(result='CONFIRMED_OBSERVABILITY_GAP',baseline_verdict=verdicts[0],
    persistent_v16_corruption_verdict=verdicts[1],transient_v10_corruption_erased_by_recovery_verdict=verdicts[2],
    bad_recovery_vl_verdict=verdicts[3],instructions=steps,
    scope='Synthetic fault injection into real compiled C verifier; not a claim of an actual RTL illegal-write defect'),
    image_sha256=sha(OUT/'probes.elf'),source_sha256=sha(source),reference_sha256=sha(ROOT/'evidence/reference.so'),
    full_core='NOT_RUN',AM_build='NOT_RUN')
jsonout('validation/software/results.json',result);print(json.dumps(result,indent=2))
