#!/usr/bin/env python3
"""Reproduce this review's bounded checks. Writes only beside these artifacts."""
import sys
from reviewlib import run

jobs=[('finish-checks','finish_checks.py'),('rvv-reference','rvv_reference.py'),
      ('software-reference','software_reference.py'),('small-t12-reference','t12_small_reference.py'),
      ('checker-counterexamples','checker_counterexamples.py'),('timing-counterexamples','timing_counterexamples.py')]
for name,script in jobs:
    code=run(name,[sys.executable,'-B','scripts/'+script],timeout=60)
    if code:
        raise SystemExit(code if code>0 else 128-code)
print('All bounded review checks passed. RTL/full-core/STA/PPA remain NOT_RUN.')
