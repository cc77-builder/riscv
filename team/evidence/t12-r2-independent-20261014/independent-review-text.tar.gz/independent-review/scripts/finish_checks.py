#!/usr/bin/env python3
"""Verify frozen evidence, record tool scope and check original research patch."""
import json
import os
from pathlib import Path
import shutil
import subprocess
from reviewlib import ROOT, run, jsonout, sha

m=json.loads((ROOT/'evidence/source_manifest.json').read_text())
extra=json.loads((ROOT/'evidence/extra_manifest.json').read_text())
for entry in m['files']+extra:
    assert sha(ROOT/entry['snapshot'])==entry['sha256'],entry['snapshot']
jsonout('evidence/snapshot_integrity.json',dict(status='PASS',files=len(m['files'])+len(extra)))

toolroot=Path('/home/lizufan/xiangshan-t10-t11-supervisor-20261013/tools/ubuntu-root')
env={'LD_LIBRARY_PATH':str(toolroot/'usr/lib/x86_64-linux-gnu')}
tools=[]
for name in ('as','gcc','objcopy','objdump','ld'):
    path=toolroot/'usr/bin'/('riscv64-linux-gnu-'+name)
    assert run('tool-'+name+'-version',[str(path),'--version'],env=env)==0
    tools.append(dict(name='riscv64-linux-gnu-'+name,path=str(path),sha256=sha(path.resolve())))
search_dirs=[Path(p) for p in os.environ.get('PATH','').split(':') if p]
search_dirs += [Path('/usr/bin'),Path('/usr/local/bin'),toolroot/'usr/bin',
    Path('/home/lizufan/xiangshan-validation-20261013/tools/bin'),
    Path('/home/lizufan/xiangshan-validation-20261013/tools/verilator-5.052/bin'),
    Path('/home/lizufan/chatpc-workspaces/xiangshan-t12-20261014/tools/root/usr/bin')]
eda={name:[str(d/name) for d in search_dirs if (d/name).is_file()] for name in ('sta','opensta','openroad','yosys','verilator')}
jsonout('evidence/tool_inventory.json',dict(cross_tools=tools,eda_discovery=eda,
    searched_directories=[str(d) for d in search_dirs],liberty_supplied=False,SDC_supplied=False,
    real_STA='NOT_RUN',technology_area_power_frequency='NOT_RUN',generic_gate_counting='NOT_RUN',
    scope='Bounded local discovery only; not a claim that no tool or library exists anywhere on the machine.'))
base=(ROOT/'sources/baseline/team/workloads/t12-perf/main.c').read_text()
initial=(ROOT/'sources/initial/team/workloads/t12-perf/main.c').read_text()
formatter=lambda s:s[s.index('static void decimal'):s.index('static void vector')]
assert formatter(base)==formatter(initial)
jsonout('evidence/historical_formatter_comparison.json',dict(status='BYTE_IDENTICAL_FUNCTIONS',
    initial_commit='9a4a67a92161beb9b13742bdb7af21c26a043bd9',
    baseline_commit='b8272f2e8a62557437869c936b6ea9ce5fff84fe',functions=['decimal','hex']))
patch='sources/original_research/team/evidence/vdot-hardware-ab-20261014/experiments/fuse-input-stage.patch'
rc=run('fusion-patch-check',['git','apply','--check','--directory=sources/baseline',patch])
assert rc==0
jsonout('evidence/fusion_patch_check.json',dict(status='APPLIES_TO_FIXED_REVIEW_COPY',applied=False,
    base_commit=m['pins']['baseline']['commit'],patch_sha256=sha(ROOT/patch),production_modified=False))

# Re-check the unavailable user-specified Draft object in one further relevant
# prior local workspace. No fetch and no use of its concurrent working files.
repo='/home/lizufan/chatpc-workspaces/xiangshan-t12-20261014/repo'
rc=run('draft1-prior-workspace',['git','--no-optional-locks','--no-replace-objects','-C',repo,
    'cat-file','-t','f8e8276681e0f4cfdc4ce0d8e2a76ebb4897493e'],expected=(0,128))
jsonout('evidence/draft1_extra_lookup.json',dict(repo=repo,exit_code=rc,available=rc==0,network_used=False))
print('Frozen snapshot integrity PASS; real STA and PPA NOT_RUN.')
