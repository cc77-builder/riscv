#!/usr/bin/env python3
"""Copy immutable Git blobs and hash external evidence; never read live source as a commit."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
REPOS = [
    '/home/lizufan/xiangshan-t12-perf-20261014/supervisor-repo',
    '/home/lizufan/chatpc-workspaces/xiangshan-t12-20261014-r2/repo',
    '/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/t12-perf-20261014/hardware/hardware-repo',
]
PINS = {
    'baseline': 'b8272f2e8a62557437869c936b6ea9ce5fff84fe',
    'team': '6bf3c2c3be0c88ff3a020786ff10cbec9aa126d3',
    'draft1': 'f8e8276681e0f4cfdc4ce0d8e2a76ebb4897493e',
}
records, commands = [], []
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1')

def git(repo, *args):
    argv = ['git', '--no-optional-locks', '--no-replace-objects', '-C', repo, *args]
    p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    commands.append(dict(argv=argv, exit_code=p.returncode, stderr=p.stderr.decode(errors='replace')))
    return p

def save(target, data, **metadata):
    target = ROOT / target
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    records.append(dict(snapshot=str(target.relative_to(ROOT)), bytes=len(data),
                        sha256=hashlib.sha256(data).hexdigest(), **metadata))

def selected(path):
    return (path.startswith('src/main/scala/') or
            path.startswith(('team/spec/', 'team/scripts/', 'team/tests/', 'team/rtl/',
                             'team/models/', 'team/workloads/', 'team/research/')) or
            path in ('build.sc', 'AGENTS.md', '.gitmodules', 'team/docs/environment.md',
                     'team/docs/collaboration-current.md', 'team/docs/t10-t11-acceptance-20261013.md')
            or path.startswith('team/evidence/rtl-fu-'))

pins = {}
for label, commit in PINS.items():
    repo = next((r for r in REPOS if git(r, 'cat-file', '-t', commit).stdout.strip() == b'commit'), None)
    pins[label] = dict(commit=commit, repo=repo, available=repo is not None)
    if repo is None:
        continue
    tree = git(repo, 'ls-tree', '-rz', commit)
    assert tree.returncode == 0
    entries = []
    for item in tree.stdout.split(b'\0'):
        if not item:
            continue
        head, rawpath = item.split(b'\t', 1)
        mode, kind, blob = head.decode().split()
        path = rawpath.decode()
        if kind != 'blob' or not selected(path):
            continue
        entries.append(dict(path=path, mode=mode, blob=blob))
        # Team snapshot only needs blobs different from the baseline.
        baseline = next((x for x in records if x.get('label') == 'baseline' and x.get('path') == path), None)
        if label == 'team' and baseline and baseline['blob'] == blob:
            continue
        p = git(repo, 'cat-file', 'blob', blob)
        assert p.returncode == 0
        actual = hashlib.sha1(b'blob ' + str(len(p.stdout)).encode() + b'\0' + p.stdout).hexdigest()
        assert actual == blob
        save(Path('sources') / label / path, p.stdout, kind='git_blob', label=label,
             repo=repo, commit=commit, blob=blob, path=path)
    pins[label]['selected_tree'] = entries

external = Path(REPOS[2])
for relative in ['team/docs/vdot-hardware-ab-20261014.md',
                 'team/evidence/vdot-hardware-ab-20261014/experiments']:
    source = external / relative
    files = [source] if source.is_file() else sorted(source.rglob('*'))
    for file in files:
        if not file.is_file() or '__pycache__' in file.parts:
            continue
        data = file.read_bytes()
        rel = file.relative_to(external)
        # This is explicitly a hashed observed artifact, not a claimed commit snapshot.
        save(Path('sources/original_research') / rel, data, kind='observed_artifact',
             origin=str(file), mtime_ns=file.stat().st_mtime_ns)

runroot = Path('/home/lizufan/xiangshan-t12-perf-20261014/supervisor-runs')
suffixes = {'.json', '.jsonl', '.log', '.sha', '.sha256', '.exit', '.py', '.sh', '.h', '.S', '.txt'}
for file in sorted(runroot.rglob('*')):
    if not file.is_file() or file.suffix not in suffixes or file.stat().st_size > 8_000_000:
        continue
    # Keep disassemblies, logs and generated input to bind known runs to actual bytes.
    data = file.read_bytes()
    save(Path('evidence/old_runs') / file.relative_to(runroot), data,
         kind='observed_run_artifact', origin=str(file), mtime_ns=file.stat().st_mtime_ns)

(ROOT / 'evidence').mkdir(exist_ok=True)
(ROOT / 'evidence/source_manifest.json').write_text(json.dumps(dict(
    captured_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), pins=pins, files=records,
    commands=commands), indent=2) + '\n')
print(json.dumps(dict(pins={k:{x:v[x] for x in ['commit','repo','available']} for k,v in pins.items()},
                      files=len(records)), indent=2))
