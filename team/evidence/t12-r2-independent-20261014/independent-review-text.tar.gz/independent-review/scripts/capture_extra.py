#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from reviewlib import ROOT, sha, jsonout

OLD = Path('/home/lizufan/xiangshan-t10-t11-supervisor-20261013')
BASE = '/home/lizufan/xiangshan-t12-perf-20261014/supervisor-repo'
manifest=[]
def blob(repo, commit, path, label):
    cmd=['git','--no-optional-locks','--no-replace-objects','-C',str(repo)]
    oid=subprocess.check_output(cmd+['rev-parse',commit+':'+path],text=True).strip()
    data=subprocess.check_output(cmd+['cat-file','blob',oid])
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
    dest=ROOT/'sources'/label/path
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    manifest.append(dict(repo=str(repo),commit=commit,path=path,blob=oid,sha256=sha(dest),snapshot=str(dest.relative_to(ROOT))))

for file in ['ClockGate.scala','Hold.scala','CircularQueuePtr.scala']:
    blob(OLD/'repo/utility','a8ca0c6564865ee69b564d431ecbc52074ba8060','src/main/scala/utility/'+file,'utility')
for label,commit in [('initial','9a4a67a92161beb9b13742bdb7af21c26a043bd9'),('compact','36d390a6917e1d74c414b3edd876a3816d845287')]:
    for path in ['team/workloads/t12-perf/main.c','team/tests/generate_t12.py']:
        blob(BASE,commit,path,label)
for path in ['src/isa/riscv64/instr/rvv/vcompute_impl.c','src/isa/riscv64/instr/rvv/vreg_impl.c',
             'src/isa/riscv64/instr/rvv/vcompute.h','src/isa/riscv64/instr/rvv/exec.h',
             'src/isa/riscv64/difftest/ref.c']:
    blob(OLD/'nemu/base','a48a11f208ff81ad765591d83271d1b339fb3861',path,'nemu_base')
for path,destname in [
    (OLD/'runs/reference-api-probe/layout.json','reference-layout.json'),
    (OLD/'nemu-xs-tval/reference/build/riscv64-nemu-interpreter-so','reference.so')]:
    dest=ROOT/'evidence'/destname
    shutil.copyfile(path,dest)
    manifest.append(dict(origin=str(path),snapshot=str(dest.relative_to(ROOT)),sha256=sha(dest),kind='observed_binary_or_ABI'))
assert sha(ROOT/'evidence/reference.so')=='e5f04192ad782581eef8cd17648933aa6da0fd0543944cb6e59eb931efc60cae'
jsonout('evidence/extra_manifest.json',manifest)
print(json.dumps(dict(files=len(manifest)),indent=2))
