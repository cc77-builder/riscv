#!/usr/bin/env python3
"""Executable source-level deductions, explicitly not RTL or STA results."""
from reviewlib import jsonout
import json

def after(a,b):
    return (a[0]!=b[0]) ^ (a[1]>b[1])

cases=0
for redirect in range(96):
    r=(redirect//48,redirect%48)
    for distance in range(-47,48):
        request=(redirect+distance)%96;q=(request//48,request%48)
        for flush_self in (False,True):
            actual=after(q,r) or (flush_self and q==r)
            assert actual==(distance>0 or (distance==0 and flush_self))
            cases+=1

trace=[];busy=False;uncer_en=False;state='idle'
# Parent EXU registers use the pre-edge events; the FU kill has priority.
for cycle,request,kill,ready in [(0,True,False,True),(1,False,True,True),
                                 (2,False,False,True),(3,False,False,True)]:
    in_fire=request and not busy and state=='idle' and not kill
    out_fire=state=='respond' and not kill and ready
    trace.append(dict(cycle=cycle,state=state,busy=busy,uncer_en=uncer_en,
                      in_fire=in_fire,out_fire=out_fire,kill=kill,
                      clock_enable=in_fire or uncer_en))
    if kill:busy=False;state='idle'
    elif out_fire:busy=False;state='idle'
    elif in_fire:busy=True;state='mul'
    elif state=='mul':state='reduce'
    elif state=='reduce':state='respond'
    if in_fire:uncer_en=True
    elif out_fire:uncer_en=False
assert state=='idle' and not busy and uncer_en

def continuous(fused):
    state='idle';busy=False;accept=[];response=[]
    for cycle in range(17):
        infire=(state=='idle') and not busy
        outfire=state=='respond'
        if infire:accept.append(cycle)
        if outfire:response.append(cycle)
        if outfire:state='idle';busy=False
        elif infire:state='reduce' if fused else 'mul';busy=True
        elif state=='mul':state='reduce'
        elif state=='reduce':state='respond'
    return dict(accepted_edges=accept,response_edges=response,min_ii=min(b-a for a,b in zip(accept,accept[1:])))
a,b=continuous(False),continuous(True)
assert a['accepted_edges'][:3]==[0,4,8] and a['response_edges'][:3]==[3,7,11]
assert b['accepted_edges'][:3]==[0,3,6] and b['response_edges'][:3]==[2,5,8]
result=dict(status='SOURCE_DEDUCTIONS_REPRODUCED_NOT_RTL',rob_age_cases=cases,
    index_only_counterexample=dict(redirect_flag=0,redirect_index=47,request_flag=1,request_index=0,
                                  correct_need_flush=True,index_only_need_flush=False),
    cancel_clock_enable_trace=trace,baseline_local_timing=a,fused_local_timing_prediction=b,
    same_cycle_release_counterexample=dict(pre_busy=True,out_fire=True,FU_ready=True,EXU_in_ready=False),
    RTL='NOT_RUN',STA='NOT_RUN',PPA='NOT_RUN')
jsonout('validation/timing/results.json',result);print(json.dumps(result,indent=2))
