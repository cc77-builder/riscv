#!/usr/bin/env python3
"""Final self-audit: no production mutation, no process-wide cleanup actions."""
import hashlib
import json
import os
from pathlib import Path
import re
import time
from reviewlib import ROOT, jsonout, sha

review=json.loads((ROOT/'REVIEW.json').read_text())
manifest=json.loads((ROOT/'evidence/source_manifest.json').read_text())
extra=json.loads((ROOT/'evidence/extra_manifest.json').read_text())
for item in manifest['files']+extra:
    assert sha(ROOT/item['snapshot'])==item['sha256'],item['snapshot']
for item in review['commands']:
    assert (ROOT/item['receipt']).is_file()
    assert (ROOT/item['log']).is_file(),item['log']
for name in ('rvv-reference','software-reference','small-t12-reference','checker-counterexamples','timing-counterexamples','finish-checks'):
    receipt=json.loads((ROOT/'logs'/f'{name}.command.json').read_text())
    assert receipt['exit_code']==0,(name,receipt['exit_code'])
links=[]
for doc in ('FINAL.md','EARLY_TIMING_REVIEW.md','RVV_BASELINE_REVIEW.md','TIMEOUT_REVIEW.md','SOURCE_INDEX.md'):
    for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)',(ROOT/doc).read_text()):
        link=match.group(1).split('#')[0]
        if not link or '://' in link:continue
        path=ROOT/link
        # FINAL.json/cleanup are written immediately below.
        if link not in ('FINAL.json','evidence/cleanup.json'):assert path.exists(),(doc,link)
        links.append(dict(document=doc,target=link))
entrypoints=['run_validation.py','rvv_reference.py','software_reference.py','t12_small_reference.py',
             'checker_counterexamples.py','timing_counterexamples.py','finish_checks.py']
for file in entrypoints:assert os.access(ROOT/'scripts'/file,os.X_OK)

# Only inspect exact review workloads. Never signal another task's processes.
matches=[];own=os.getpid()
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name)==own:continue
    try:
        cwd=(proc/'cwd').resolve()
        argv=(proc/'cmdline').read_bytes().split(b'\0')
        args=[x.decode(errors='replace') for x in argv if x]
    except (OSError,PermissionError):continue
    if cwd!=ROOT:continue
    if any(a in ['scripts/'+x for x in entrypoints]+[str(ROOT/'scripts'/x) for x in entrypoints] for a in args):
        matches.append(dict(pid=int(proc.name),argv=args))
assert not matches, matches
cleanup=dict(status='NO_REVIEW_WORKLOAD_CHILDREN_REMAIN',remaining_review_workloads=matches,terminated_pids=[],
    method='All ordinary tool/subprocess jobs were synchronous and reaped. Final read-only /proc scan found no exact review validation workload. No unrelated process signalled.',
    known_tool_sessions_closed=[71650,1228,93974,55544],subagents_created=0)
jsonout('evidence/cleanup.json',cleanup)
jsonout('evidence/final_audit.json',dict(status='PASS',source_files_verified=len(manifest['files'])+len(extra),
    documents_checked=5,links_checked=len(links),latest_required_checks_exit_zero=True,links=links,
    command_receipts_checked=len(review['commands']),cleanup_status=cleanup['status']))
final=dict(status=review['status'],finished_at=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
    source_pins=review['source_pins'],findings_count=len(review['findings']),
    key_findings=['H01: true registered input boundary corrects original timing argument',
        'B01: shorter legal RVV baseline passes actual assembly/reference tests',
        'S01/S02/S03: counter plausibility, digest and provenance acceptance gaps reproduced',
        'S04/S05: final-state-only loop and fault/recovery observability gaps',
        'H02/H04: cancel clock-enable and lost operand isolation require real RTL/activity evidence'],
    instruction_counts=review['validation']['RVV']['instruction_counts'],
    reference_validation_counts=review['validation']['RVV']['counts'],
    original_stress_cases_reference_passed=13,source_files_integrity_passed=598,
    hardware_acceptance=review['hardware_acceptance'],constraints=review['constraints'],cleanup=cleanup,
    reports=['FINAL.md','REVIEW.json','EARLY_TIMING_REVIEW.md','RVV_BASELINE_REVIEW.md','TIMEOUT_REVIEW.md','SOURCE_INDEX.md'],
    final_audit='evidence/final_audit.json',reproduce='./scripts/run_validation.py',
    open_items=review['promotion_gates'])
jsonout('FINAL.json',final)
with (ROOT/'PROGRESS.md').open('a') as f:
    f.write('\n## Final: review delivered\n\n'
        '- FINAL.md / FINAL.json written; REVIEW.json contains 12 classified findings and 38 exact command receipts.\n'
        '- Final audit PASS: 598 source/evidence snapshots unchanged, all report links present, all six latest required bounded checks exit0.\n'
        '- All review ordinary child processes reaped; no exact review validation process remains. No other task process was signalled.\n'
        '- Candidate remains unpromoted. Draft object unavailable; candidate RTL/full-core/STA/PPA NOT_RUN; all four old timeout slices remain NOT_ACCEPTED.\n'
        '- Main implementation may consume the stronger RVV baseline and counterexamples; no parent repo/runs or old-project file was modified.\n')

# Hash only explicit review outputs; do not traverse protected environment dirs.
files=[]
for directory in ('sources','scripts','logs','validation','evidence'):
    files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and p.name!='artifact_manifest.json')
files += [p for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.md','.json','.log')]
entries=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(set(files))]
jsonout('evidence/artifact_manifest.json',dict(excludes_self=True,files=entries))
print(json.dumps(dict(status='FINAL_AUDIT_PASS',source_files=598,links=len(links),artifact_files=len(entries),
                      cleanup=cleanup['status'],STA='NOT_RUN',full_core='NOT_RUN'),indent=2))
