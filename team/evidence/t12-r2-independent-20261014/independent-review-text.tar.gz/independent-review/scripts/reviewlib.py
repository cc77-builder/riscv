"""Bounded subprocesses, outputs and exact command receipts, confined to review."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(name, argv, *, env=None, timeout=60, expected=(0,)):
    logs = ROOT / 'logs'
    logs.mkdir(exist_ok=True)
    started = time.time()
    effective = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(ROOT / 'tmp'))
    (ROOT / 'tmp').mkdir(exist_ok=True)
    if env:
        effective.update(env)
    with (logs / (name + '.log')).open('wb') as out:
        p = subprocess.run(argv, cwd=ROOT, env=effective, stdout=out,
                           stderr=subprocess.STDOUT, timeout=timeout)
    receipt = dict(argv=[str(x) for x in argv], cwd=str(ROOT), env_overrides=env or {},
                   started_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(started)),
                   elapsed_seconds=time.time()-started, exit_code=p.returncode,
                   expected_exit_codes=list(expected), log=str((logs/(name+'.log')).relative_to(ROOT)))
    (logs/(name+'.command.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt), flush=True)
    return p.returncode

def jsonout(path, data):
    path=ROOT/path
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2)+'\n')
