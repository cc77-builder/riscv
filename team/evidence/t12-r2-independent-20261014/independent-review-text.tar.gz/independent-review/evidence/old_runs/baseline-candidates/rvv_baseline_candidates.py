"""Ordinary RVV equivalent sequences: product-first and fractional LMUL.
The multiply precedes destination clearing, preserving every source/dest alias.
No claim of core performance is implied by shorter instruction sequences.
"""
VARIANTS = ('legacy', 'product-first', 'fractional')
def sequence(vd=10, a=8, b=9, variant='fractional', known=False):
    if variant not in VARIANTS: raise ValueError('variant')
    if any(type(r) is not int or not 0<=r<32 for r in (vd,a,b)): raise ValueError('register')
    used={0,vd,a,b}
    p=next(n for n in range(2,32,2) if not {n,n+1}&used)
    scratch=[p] if variant=='fractional' else [p,p+1]
    body=[] if known else ['csrr t3, vl','csrr t4, vtype']
    if variant=='legacy':
        z,r=[n for n in range(1,32) if n not in used|{p,p+1}][:2]
        scratch += [z,r]
        body += ['vsetivli zero, 4, e32, m1, tu, mu',f'vmv.v.i v{z}, 0',
          'vsetivli zero, 8, e8, m1, tu, mu',f'vwmul.vv v{p}, v{a}, v{b}',
          'vsetivli zero, 8, e16, m2, tu, mu',f'vwredsum.vs v{r}, v{p}, v{z}',
          'vsetivli zero, 4, e32, m1, tu, mu',f'vmv.x.s t2, v{r}',f'vmv.v.i v{vd}, 0',f'vmv.s.x v{vd}, t2']
    else:
        if variant=='fractional': body += ['vsetivli zero, 8, e8, mf2, tu, mu']
        body += [f'vwmul.vv v{p}, v{a}, v{b}','vsetivli zero, 4, e32, m1, tu, mu',
          f'vmv.v.i v{vd}, 0',f'vsetivli zero, 8, e16, {"m1" if variant=="fractional" else "m2"}, tu, mu',
          f'vwredsum.vs v{vd}, v{p}, v{vd}']
    body += ['vsetivli zero, 8, e8, m1, tu, mu'] if known else ['vsetvl zero, t3, t4']
    return body,tuple(scratch)

def batch4(variant='fractional'):
    if variant not in ('product-first','fractional'): raise ValueError('variant')
    products=[16,18,20,22] if variant=='product-first' else [16,17,18,19]
    body=['vsetivli zero, 8, e8, mf2, tu, mu'] if variant=='fractional' else []
    body += [f'vwmul.vv v{p}, v8, v9' for p in products]
    body += ['vsetivli zero, 4, e32, m1, tu, mu']+[f'vmv.v.i v{d}, 0' for d in range(10,14)]
    body += [f'vsetivli zero, 8, e16, {"m1" if variant=="fractional" else "m2"}, tu, mu']
    body += [f'vwredsum.vs v{10+i}, v{p}, v{10+i}' for i,p in enumerate(products)]
    body += ['vsetivli zero, 8, e8, m1, tu, mu']
    return body,tuple(range(16,24)) if variant=='product-first' else tuple(products)
