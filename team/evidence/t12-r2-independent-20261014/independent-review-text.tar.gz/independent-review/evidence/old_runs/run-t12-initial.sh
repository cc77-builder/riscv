#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/xiangshan-t12-perf-20261014
repo="$root/supervisor-repo"
old=/home/lizufan/xiangshan-t10-t11-supervisor-20261013
out="$root/supervisor-runs/t12-initial"
exec > "$out/launcher.log" 2>&1
trap 'rc=$?; printf "%s\n" "$rc" > "$out/exit-code.txt"; printf "exit_code=%s\nfinished_at=%s\n" "$rc" "$(date -Is)" >> "$out/run.status"' EXIT
printf 'started_at=%s\npid=%s\n' "$(date -Is)" "$$" > "$out/run.status"
cd "$repo"
printf 'source=%s\n' "$(git rev-parse HEAD)" >> "$out/run.status"
git diff --quiet fcb16a8764d342339670df0bbf1bc67ef2028b86 HEAD -- src build.sc
sha256sum -c "$out/binaries.sha256"
sha256sum -c "$root/supervisor-runs/preflight/runtime.sha256"
python3 -B team/scripts/artifact_guard.py nemu-runtime --repo "$old/nemu-xs-tval/reference" --binary "$old/nemu-xs-tval/reference/build/riscv64-nemu-interpreter-so" --mode reference > "$out/reference-verification.json"
/usr/bin/time -v timeout 1200s "$old/repo/build/emu" -i "$out/t12-perf.bin" --flash "$old/runs/final-acceptance-20261013-2155/run-0/evidence/boot-flash.bin" --ram-size=128MB --diff "$old/nemu-xs-tval/reference/build/riscv64-nemu-interpreter-so" -C 5000000 > "$out/run.log" 2>&1