# Exact source index

Commit: `b8272f2e8a62557437869c936b6ea9ce5fff84fe`. All line numbers in the reports refer to these unmodified Git-blob snapshots.

| Source | Git blob SHA1 | SHA256 |
|---|---|---|
| [src/main/scala/xiangshan/backend/fu/wrapper/VDot.scala](sources/baseline/src/main/scala/xiangshan/backend/fu/wrapper/VDot.scala) | `9e393f3ee4d0cafc002d5fa1c301b0761da16882` | `e508395b1a94a91a8da67c5b7ddebe75bc27876007b3032becdd29a047c7a401` |
| [src/main/scala/xiangshan/backend/fu/vector/VDotDatapath.scala](sources/baseline/src/main/scala/xiangshan/backend/fu/vector/VDotDatapath.scala) | `e0703191ed2b626179e36fb40eb9741cdb843151` | `161df70403fd131a3adf445230ed637dc7ad7c619d05c0a890aa8aa1791546d8` |
| [src/main/scala/xiangshan/backend/fu/FuConfig.scala](sources/baseline/src/main/scala/xiangshan/backend/fu/FuConfig.scala) | `09e389b216d9c741959e988ff3058d103798f858` | `e799344a2497dd510a4c3d66cf92c28c7270232c61eee74bc4c13aa06e60e7ba` |
| [src/main/scala/xiangshan/backend/exu/ExeUnit.scala](sources/baseline/src/main/scala/xiangshan/backend/exu/ExeUnit.scala) | `ad652efa8b1a3525f6071f6cce7a97a645659e5a` | `3456bd48a6618f86584de80a769b01f5142b612712e4b8b19d186ad86182d448` |
| [src/main/scala/xiangshan/backend/Backend.scala](sources/baseline/src/main/scala/xiangshan/backend/Backend.scala) | `d301285fded394606ca04608384e0bd360cf2809` | `346c2677150a5a64e8e865b9ec3929dcfbdcfb43697c04b468e1bccc2bd812d7` |
| [src/main/scala/xiangshan/backend/datapath/NewPipelineConnect.scala](sources/baseline/src/main/scala/xiangshan/backend/datapath/NewPipelineConnect.scala) | `955896649ad6ad2ab167d9df21d6a6778b478b0a` | `2f75ec67304a35f96a85254351ff00d71911bd40d17fb83fe8beb0f1b19c9060` |
| [src/main/scala/xiangshan/backend/datapath/Og2ForVector.scala](sources/baseline/src/main/scala/xiangshan/backend/datapath/Og2ForVector.scala) | `f9a85f25e82a422105c75c19671e082a6f5ae10b` | `f82bd6a675662a5f3975d340dde9dbd88c006db92d55b14f2a06ffd1bb9c94c7` |
| [src/main/scala/xiangshan/backend/datapath/BypassNetwork.scala](sources/baseline/src/main/scala/xiangshan/backend/datapath/BypassNetwork.scala) | `b156b6124e310ad3da718bd103d7de13faa93e04` | `abd0c9b90f7db9233ba0f9914472f85cb03d5e473be415d610dd42f00c73be66` |
| [src/main/scala/xiangshan/backend/datapath/WbArbiter.scala](sources/baseline/src/main/scala/xiangshan/backend/datapath/WbArbiter.scala) | `156bb8c90055bf76d066df95538e6dc3e98753bb` | `da263ea553f27a25cb9fc98c209138dffb700248a6ef5b64104bdc8abb5abbb4` |
| [src/main/scala/xiangshan/backend/rob/RobBundles.scala](sources/baseline/src/main/scala/xiangshan/backend/rob/RobBundles.scala) | `33dc6666c835478efb848db5527a3394b2c8c1eb` | `0d167e385b2bad31785a1db466fc0126f9a5cbfe74fe2ad0964d97c31b486849` |
| [team/tests/generate_t12.py](sources/baseline/team/tests/generate_t12.py) | `7ea8222bd5b71aa07dc0ccc9d55e8ad619f376a9` | `1524e33888a54298bd4d6f82ea1bfd34c650d82cf8d73eebd8625cf72fb0b457` |
| [team/tests/generate_baseline.py](sources/baseline/team/tests/generate_baseline.py) | `21f297bda0d29b20b75267ecb8eb7f773638c6c7` | `8d5e94dfde3092086a70e5fbaa65801bcbbbb7df592d67dde30913373c26f24a` |
| [team/workloads/t12-perf/main.c](sources/baseline/team/workloads/t12-perf/main.c) | `0d1e8d8233e97c42e8a6944575efabec4a63e6cb` | `05810545d9c7505dc1ada84c5e1a64f6263e8a8b8d5266f2ff648430e6e6b39c` |
| [team/scripts/check-t12-run.py](sources/baseline/team/scripts/check-t12-run.py) | `13b26be0255fd8d22b6000d9923fab27e2468b37` | `20904c9d312c629ec4b2a9b6c8e04567d5131ec680c512b8fcbbffa6f2237be4` |
| [team/scripts/check_t12_compact.py](sources/baseline/team/scripts/check_t12_compact.py) | `9884dd63a208c69986a74a9de8f108359319f3c0` | `e1ef71032dbc276a221c508ab84c1b71ebc6040d412f4fcb358ca219ffdf3af9` |
| [team/workloads/vdot-exceptions/harness.S](sources/baseline/team/workloads/vdot-exceptions/harness.S) | `56f540a053be7ba7b1fbb88576db8b249917a979` | `9f178134e5b06ba23eb941c9d32d7a63f551615d5178c514899f71c3e7e51cfe` |

Full file index, commits and git command exits: [source_manifest.json](evidence/source_manifest.json).
Utility/historical C/NEMU source/binary ABI pins: [extra_manifest.json](evidence/extra_manifest.json).
Tool versions and hashes: [tool_inventory.json](evidence/tool_inventory.json).
