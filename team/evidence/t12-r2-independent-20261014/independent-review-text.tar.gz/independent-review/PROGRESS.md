# Independent T12 / VDot review progress

- Phase: source pinning and evidence collection (2026-10-14).
- Scope: immutable Git blobs at baseline b8272f2e8a62557437869c936b6ea9ce5fff84fe, team 6bf3c2c3be0c88ff3a020786ff10cbec9aa126d3, and Draft #1 f8e8276681e0f4cfdc4ce0d8e2a76ebb4897493e; original research and existing run evidence.
- Boundaries: writes only in this review directory; no subagents, other models, network, privilege/security changes, production changes, AM builds, heavy EMU, or Git push.
- Pending: immutable snapshots/manifests, datapath/control timing audit, RVV baseline/assembly checks, timeout/checker counterexamples, final reports.
- Real STA/PPA and full-core correctness/performance are not yet established. Existing exit-124 runs must not be reported as passing.

## Phase 1 complete: fixed sources and first substantive timing finding

- `evidence/source_manifest.json`: 584 immutable source/hashed historical artifacts; `evidence/extra_manifest.json`: utility submodule a8ca0c6, initial/compact historical C, pinned NEMU source and reference library/ABI.
- Draft #1 object unavailable in the three named local repositories; clarification pending. No live main-task files used as frozen source.
- Confirmed correction to original hardware review: `Backend.scala:645` instantiates `NewPipelineConnect`, whose `data=RegEnable(left.bits,left.fire)` at `NewPipelineConnect.scala:43` cuts the RF/OG2/bypass data path before VFEX. VDot `srcNeedCopy=false`; its operand wires bypass Dispatcher data logic. Fusion STA must start at this actual pipeline data register, not concatenate RF+mux+multiply across a register.
- Single request, E0/E2/E3/II4, shared EXU busy, WB arbitration and redirect control inspected. Candidate remains unpromoted; real STA/PPA NOT_RUN.
- Portable GNU RISC-V assembler 2.38 works read-only. 32,768 alias-layout candidates assembled. Pinned NEMU reference probe first rejected multi-instruction exec calls (SIGABRT); preserved log, changed driver to the required single-step ABI and rerunning. This is short reference execution only, no full-core EMU or AM build.
- Existing four slices 000/003/006/008 each exit 124, with no T12C_END: NOT_ACCEPTED.

## Phase 2 complete: stronger RVV baseline and actionable checker failures

- `EARLY_TIMING_REVIEW.md` is available for the main reviewer now, including the true register boundary, control/gate risks, and promotion blockers.
- Real GNU binutils assembly plus pinned NEMU execution PASS: all 32,768 register triples, 2,016 boundary/policy/vxrm/vxsat/alias cases, 1,000 random cases; 328 old-baseline checks and two batch variants. Full 128-bit destination, all non-scratch vector/GPR registers, VL/vtype/vstart/vxrm/vxsat/vcsr and dirty VS checked. `validation/rvv/results.json`.
- Short baseline uses product-first, full vd zero, e16/m1 VL8 widening reduction with vd as seed/dest and tu, restore. Instruction counts: general 13→8, known-config 11→6, batch-four 26→15. These are static counts, not cycle speedups.
- Concrete ISA negative controls confirm early clear breaks aliasing, narrow reduction truncates, ta pollutes high96, fixed T12 general(a=v4) clobbers source, and known-config cannot restore arbitrary policy. Legal-domain preconditions remain explicit.
- `validation/checkers/results.json`: seven acceptance counterexamples, including impossible instret, counters >uint64, changed compact timing with same digest, and receipt paths/hashes not independently verified. Timeout and missing-end negative controls are correctly rejected.
- Real standalone cross-compiled pinned C probes (no AM) PASS for hex/decimal edge values and C/Python compact digest serialization. Compiled verifier also confirms recovery can erase transient v10 corruption before final comparison; persistent v16 corruption is caught. `validation/software/results.json`.
- NEMU driver bring-up failures preserved separately (single-step ABI, immutable-PC decode cache, nonzero-vstart out-of-domain trap); none is reported as DUT/RTL failure.

## Phase 3 complete: integrated software reference probes and report assembly

- All 13 original stress bodies were linked with the unmodified trap harness and C judge (no AM) and single-stepped in the pinned NEMU reference. They returned 0, including all five illegal-VL recovery cases; digest `2e51e6e6b71a5ebd` matches the checker. This does not clear old full-core timeouts or observe speculative/ROB events.
- Added H04: input fusion removes operand isolation provided by VDot source registers. Shared VFEX input changes can toggle its combinational multipliers even while VDot clock is gated; activity/physical validation remains required.
- Reports available: EARLY_TIMING_REVIEW.md, RVV_BASELINE_REVIEW.md, TIMEOUT_REVIEW.md, REVIEW.json, SOURCE_INDEX.md. 598 captured source/evidence files verified unchanged.
- Bounded tool inventory found Yosys and Verilator paths; no applicable real STA tool/PVT/Liberty/SDC was supplied or found in the inspected tool paths. STA/PPA/generic gate statistics NOT_RUN.
- Original fusion patch applies under `git apply --check` to fixed review snapshots, exit0; not applied. Draft #1 also absent from the prior relevant XiangShan workspace Git store (four stores checked, no fetch).
- Finishing final artifact/link/receipt audit and confirming all review child processes have exited.

## Final: review delivered

- FINAL.md / FINAL.json written; REVIEW.json contains 12 classified findings and 38 exact command receipts.
- Final audit PASS: 598 source/evidence snapshots unchanged, all report links present, all six latest required bounded checks exit0.
- All review ordinary child processes reaped; no exact review validation process remains. No other task process was signalled.
- Candidate remains unpromoted. Draft object unavailable; candidate RTL/full-core/STA/PPA NOT_RUN; all four old timeout slices remain NOT_ACCEPTED.
- Main implementation may consume the stronger RVV baseline and counterexamples; no parent repo/runs or old-project file was modified.
