#define TEAM_ID "LiZufan001"
#define HOST_IP "172.27.184.54"
#define IDENTITY_STATUS "configured"
