import hashlib,json,pathlib,shutil,tarfile
root=pathlib.Path('/mnt/c/Code/RVInno/riscv')
cache=pathlib.Path('/home/amesotten/.cache/codex-rvinno/o1-complete-20261018')
pack=root/'team/out/o1-complete-20261018-pack'
core=pathlib.Path((pack/'build-copy.txt').read_text().strip())
out=root/'team/evidence/o1-complete-20261018'
if json.loads((cache/'recheck.json').read_text())['status']!='O1_EXTENDED_OFFLINE_RECHECK_PASS':
    raise ValueError('campaign not accepted')
out.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def archive(name,files):
    manifest={}
    with tarfile.open(out/name,'w:gz',compresslevel=6) as dst:
        for label,path in sorted(files.items()):
            if not path.is_file() or path.is_symlink():raise ValueError('invalid archive source '+str(path))
            dst.add(path,arcname=label,recursive=False);manifest[label]=sha(path)
    save(out/(name+'.json'),dict(archive_sha256=sha(out/name),files=manifest))
payload={}
for folder in ('core-build','runs-01','preflight'):
    for p in (cache/folder).rglob('*'):
        if p.is_file():payload[p.relative_to(cache).as_posix()]=p
for p in cache.glob('*.json'):payload[p.name]=p
for name in ('run.log','run.status','host-tests.log','host-tests.json'):
    p=cache/name
    if p.exists():payload[name]=p
archive('validation.tar.gz',payload)
binding=json.loads((core/'build/source-binding.json').read_text())
archive('compiler-inputs.tar.gz',{**{n:core/n for n in binding['physical_root_sha256']},'source-binding.json':core/'build/source-binding.json'})
for name in ('source-pack.json','changes.patch'):shutil.copyfile(pack/name,out/name)
for name in ('recheck.json','negatives.json','host-tests.json'):
    if (cache/name).exists():shutil.copyfile(cache/name,out/name)
(out/'instrumented-rtl').mkdir()
for name in ('Rob.sv','CSR.sv','NewCSR.sv','ExeUnit_17.sv'):
    shutil.copyfile(core/'build/rtl'/name,out/'instrumented-rtl'/name)
review={p.relative_to(root).as_posix():p for p in (root/'team/optimizations/o1').glob('*.py')}
for n in ('team/workloads/vdot-perf/check.py','team/scripts/check-vdot-run.py','team/scripts/check-vdot-negative.py',
          'team/scripts/artifact_guard.py','team/scripts/core-baseline-split.sh','team/scripts/core-baseline-compile.sh',
          'team/scripts/prepare-core-baseline.py','team/optimizations/o1/TRACE-EXTENDED.md'):
    review[n]=root/n
for p in (root/'team/out').glob('o1-complete-*'):
    if p.is_file() and p.suffix in ('.py','.sh'):review['drivers/'+p.name]=p
archive('review-inputs.tar.gz',review)
(out/'.gitattributes').write_text('* -text -whitespace\n')
print(out)
