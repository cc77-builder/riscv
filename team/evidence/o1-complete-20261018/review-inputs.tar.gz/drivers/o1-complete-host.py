import hashlib,json,pathlib,subprocess,datetime
root=pathlib.Path('/mnt/c/Code/RVInno/riscv')
cache=pathlib.Path('/home/amesotten/.cache/codex-rvinno/o1-complete-20261018')
cmd=['python3','-OO','-B','-m','unittest','discover','-s',str(root/'team/optimizations/o1'),'-p','test_*.py','-v']
with (cache/'host-tests.log').open('wb') as log:
    rc=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
record=dict(command=cmd,exit_code=rc,finished=datetime.datetime.now().astimezone().isoformat(),
            log_sha256=hashlib.sha256((cache/'host-tests.log').read_bytes()).hexdigest(),
            files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'team/optimizations/o1').glob('*.py')})
(cache/'host-tests.json').write_text(json.dumps(record,indent=2)+'\n')
print((cache/'host-tests.log').read_text()[-250:])
raise SystemExit(rc)
