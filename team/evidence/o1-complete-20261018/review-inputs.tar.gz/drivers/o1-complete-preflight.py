import importlib.util,json,pathlib,subprocess,sys
root=pathlib.Path('/mnt/c/Code/RVInno/riscv')
sys.path.insert(0,str(root/'team/optimizations/o1'))
import run_extended_core as r
out=pathlib.Path('/home/amesotten/.cache/codex-rvinno/o1-complete-20261018/preflight')
out.mkdir()
inventory=r.extract_images(out/'images')
r.save(out/'inventory.json',inventory)
r.save(out/'matrix.json',r.matrix_union(out/'images'))
perf=r.module('preflight_perf',root/'team/workloads/vdot-perf/check.py')
for folder in ('calibration','t13-images/performance-d0-s06'):
    data=out/'images'/folder
    manifest=json.loads((data/'data/manifest.json').read_text())
    perf.verify_build_record(data)
    perf.verify_generation(data,manifest)
    perf.check_compiled_cases(data/'vdot-perf.elf',manifest)
    print(folder,len(manifest['plan']),'COMPILED_PLAN_PASS',flush=True)
result=subprocess.run(['ldd',str(out/'images/negative-reference-v2.so')],capture_output=True,text=True)
(out/'ldd.log').write_text(result.stdout+result.stderr)
print('MATRIX_117_UNIQUE_124_EXECUTIONS_PASS',flush=True)
print(result.stdout)
