import json,pathlib,subprocess,time
root=pathlib.Path('/mnt/c/Code/RVInno/riscv')
cache=pathlib.Path('/home/amesotten/.cache/codex-rvinno/o1-complete-20261018')
status=cache/'core-build/launch.status'
while not status.exists():time.sleep(5)
if status.read_text().strip()!='0':raise SystemExit('build failed; execution not started')
core=(root/'team/out/o1-complete-20261018-pack/build-copy.txt').read_text().strip()
command=['python3','-OO','-B',str(root/'team/optimizations/o1/run_extended_core.py'),
         '--core',core,'--receipt',str(cache/'core-build'),'--pack',str(root/'team/out/o1-complete-20261018-pack'),
         '--reference-root','/home/amesotten/.cache/codex-rvinno/fullcore-20261016/nemu/reference',
         '--output',str(cache/'runs-01'),'--jobs','4']
(cache/'run-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (cache/'run.log').open('wb') as log:
    rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
(cache/'run.status').write_text(str(rc)+'\n')
raise SystemExit(rc)
