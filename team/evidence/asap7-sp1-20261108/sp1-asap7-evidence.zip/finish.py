import pathlib,subprocess,json,datetime,time,hashlib,shutil,os
root=pathlib.Path('/home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108')
transfer=pathlib.Path('/mnt/c/Code/RVInno/.cache/sp1-asap7-20261108')
def run(label,argv):
 rec=dict(label=label,argv=list(map(str,argv)),started=datetime.datetime.now(datetime.timezone.utc).isoformat());start=time.monotonic()
 with (root/(label+'.log')).open('wb') as log:r=subprocess.run(list(map(str,argv)),stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 rec.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/(label+'.receipt.json')).write_text(json.dumps(rec,indent=2));print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for name in ['fu_timing.py','review_sp1.py','finish.py']:shutil.copy2(transfer/name,root/name)
run('fu-five-profiles',['python3',root/'fu_timing.py'])
for b in ['fu','parent']:
 run('area-'+b,['python3',root/'tools/asap7/verify_area.py','--run',root/(b+'-map-01'),'--lef-areas',root/'lef-areas.json','--output',root/(b+'-area-check.json')])
deadline=time.monotonic()+360
while not (root/'parent-five-profiles.receipt.json').exists():
 if time.monotonic()>deadline:raise SystemExit('parent timing receipt missing')
 time.sleep(1)
assert json.loads((root/'parent-five-profiles.receipt.json').read_text())['exit_code']==0
run('review-sp1',['python3',root/'review_sp1.py'])
files=json.loads((root/'release-inputs.json').read_text())
assert all(hashlib.sha256((root/'source'/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in files)
(root/'release-inputs-after.json').write_text(json.dumps(dict(status='PASS',files_unchanged=len(files)),indent=2))
cp=root/'source/out/vdotCost/runClasspath.json'
shutil.copy2(cp,root/'runClasspath.json')
entries=[]
def collect(v):
 if isinstance(v,str) and v.startswith('ref:'):
  p=pathlib.Path(v.split(':',3)[3])
  if p.is_file():entries.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
  elif p.is_dir():
   fs={f.relative_to(p).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file()}
   entries.append(dict(path=str(p),files=fs))
 elif isinstance(v,list):
  for a in v:collect(a)
 elif isinstance(v,dict):
  for a in v.values():collect(a)
collect(json.loads(cp.read_text()))
(root/'classpath-hashes.json').write_text(json.dumps(entries,indent=2))
print('FINAL_CHECKS_COMPLETE',len(entries),flush=True)
