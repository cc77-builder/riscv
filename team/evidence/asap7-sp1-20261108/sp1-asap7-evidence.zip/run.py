import pathlib, subprocess, json, os, time, datetime, hashlib, sys
root=pathlib.Path('/home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108')
repo=root/'source'
eda=pathlib.Path('/home/amesotten/.cache/codex-rvinno/eda-asap7-20261028-03')
tools=root/'tools/asap7'
env=dict(os.environ)
env.update(JAVA_HOME='/home/amesotten/zjhwork-stage1-repro/tools/graalvm-jdk-21.0.12',CHISEL_FIRTOOL_PATH='/home/amesotten/.cache/llvm-firtool/1.62.1/bin',NOOP_HOME=str(repo),MILL_WORKSPACE_ROOT=str(repo),DESIGN_DIR=str(repo),JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=2 -Xmx5G -Xss16m',LANG='C.UTF-8',LC_ALL='C.UTF-8')
env['PATH']=env['JAVA_HOME']+'/bin:/home/amesotten/zjhwork-stage1-repro/tools/bin:'+env['PATH']
for key in list(env):
 if key.startswith('VDOT_'):del env[key]
flags=dict(VDOT_O2_ELASTIC='1',VDOT_T14_FUSED_INPUT='1',VDOT_P4_ONE_CYCLE='1',VDOT_SP1_TRACE='0',VDOT_T13_TRACE='0',VDOT_O2_TRACE='0',VDOT_O1_HANDOFF='0',VDOT_O1_TRACE='0',VDOT_T12_TRACE='0')
env.update(flags)
(root/'build-config.json').write_text(json.dumps(dict(flags=flags,java_home=env['JAVA_HOME'],firtool=env['CHISEL_FIRTOOL_PATH'],processor_limit=2,source='ffb52e4504244b7d833d311d0ce0589f883abaf8',note='cost evaluation disables traces; production default switches unchanged'),indent=2))
def run(label,argv,timeout):
 start=time.monotonic();rec=dict(label=label,argv=list(map(str,argv)),cwd=str(repo),started=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='RUNNING',timeout_seconds=timeout)
 (root/'state.json').write_text(json.dumps(rec,indent=2));print('START',label,flush=True)
 with (root/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(list(map(str,argv)),cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  rec['pid']=p.pid;(root/'state.json').write_text(json.dumps(rec,indent=2))
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(p.pid,signal.SIGTERM);time.sleep(2)
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
   p.wait();code=124
 rec.update(exit_code=code,elapsed_seconds=time.monotonic()-start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS' if code==0 else 'FAILED')
 (root/(label+'.receipt.json')).write_text(json.dumps(rec,indent=2));(root/'state.json').write_text(json.dumps(rec,indent=2))
 print('END',label,code,round(rec['elapsed_seconds'],2),flush=True)
 if code:raise SystemExit(code)
run('tool-java',['java','-version'],30)
run('tool-firtool',[env['CHISEL_FIRTOOL_PATH']+'/firtool','--version'],30)
for boundary in ['parent','fu']:
 dest=root/(boundary+'-generation-01');dest.mkdir(exist_ok=False)
 run('generate-'+boundary,['mill','-i','-j','2','vdotCost.runMain','team.vdot.GenerateVDotCost',boundary,dest/'rtl'],2400)
 manifest={p.relative_to(dest).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in dest.rglob('*') if p.is_file()}
 (dest/'manifest.json').write_text(json.dumps(manifest,indent=2))
for boundary in ['parent','fu']:
 run('map-'+boundary,['python3',tools/'check_environment.py','--environment',eda,'--output',root/(boundary+'-map-01'),'--rtl',root/(boundary+'-generation-01/rtl'),'--top','CommonParentCostTop' if boundary=='parent' else 'CommonFuCostTop'],2200)
run('parent-five-profiles',['python3',tools/'parent_timing.py','--mapping',root/'parent-map-01','--environment',eda,'--output',root/'parent-timing-01'],1900)
print('MAPPING_AND_PARENT_TIMING_COMPLETE',flush=True)
