"""Read-only SP1 structural review; counts are measured for this architecture."""
import pathlib,json,re,hashlib,sys
root=pathlib.Path('/home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108')
sys.path.insert(0,str(root/'tools'))
from compact import topology
import canonical
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(status='RUNNING',platform='asap7',scope='structural and setup coverage only; no full functional equivalence',boundaries={})
for boundary,top in [('fu','CommonFuCostTop'),('parent','CommonParentCostTop')]:
 mapping=root/(boundary+'-map-01/asap7')
 original=json.loads((mapping/'mapped.json').read_text())['modules'][top]
 new=json.loads((mapping/'canonical.json').read_text())['modules'][top]
 new=canonical.bind(new,original,{'c'+str(i):n for i,n in enumerate(sorted(original['cells']))})
 assert topology(original)==topology(new,True),'format conversion changed connectivity'
 assert {n:(v['direction'],len(v['bits'])) for n,v in original['ports'].items()}=={n:(v['direction'],len(v['bits'])) for n,v in new['ports'].items()}
 rtl=(root/(boundary+'-generation-01/rtl/VDotElastic.sv')).read_text()
 assert re.search(r'reg\s+\[31:0\]\s+pResult\s*;',rtl),'SP1 result buffer absent'
 assert 'pProducts' not in rtl,'two-cycle buffer remained'
 assert 'else if (directR)' in rtl and 'pResult <= incomingResult;' in rtl
 assert "assign io_out_bits_res_data = {96'h0, rPacket_res_data};" in rtl
 assert 'VDOT_SP1_' not in rtl and '$fwrite' not in rtl,'trace logic present'
 cells=original['cells'];flops={n:c for n,c in cells.items() if c['type'].startswith('DFF')}
 vdot={n:c for n,c in flops.items() if '/VDotElastic.sv:' in c.get('attributes',{}).get('src','')}
 assert len(vdot)>100
 clocks={tuple(c['connections']['CLK']) for c in vdot.values()}
 assert len(clocks)==1
 timing=json.loads((root/(boundary+'-timing-01/result.json')).read_text())
 profiles=timing['profiles']['asap7'] if boundary=='parent' else timing['profiles']
 assert timing['status']==('PARENT_SINGLE_LIBRARY_SETUP_COVERAGE_PASS' if boundary=='parent' else 'FU_SETUP_COVERAGE_PASS')
 assert {x['profile'] for x in profiles}=={'nominal','period050','period200','load001','load020'} and len(profiles)==5
 expected_paths={'r2r','i2r','r2o','i2o','ready'}
 if boundary=='parent':expected_paths|={'vdot_r2r','vdot_i2r','vdot_r2o','gate_enable'}
 for p in profiles:
  assert p['crpr_enabled'] is False
  assert set(p['paths'])==expected_paths and all(x['exists'] for x in p['paths'].values())
 record=dict(mapped_cells=len(cells),flops=len(flops),vdot_flops=len(vdot),port_signals=len(original['ports']),netlist_sha256=sha(mapping/'canonical.v'),profiles=len(profiles),path_reports=sum(len(p['paths']) for p in profiles),minimum_slacks={p['profile']:min(x['slack_ns'] for x in p['paths'].values()) for p in profiles})
 if boundary=='parent':
  gate=json.loads((mapping/'gate-audit.json').read_text())
  gates={n:c for n,c in cells.items() if c['type']==gate['cell']}
  assert len(gates)==3 and len(gate['transitions'])==16
  assert all(c['connections'][gate['clock_pin']]==original['ports']['clock']['bits'] and c['connections']['SE']==original['ports']['testEnable']['bits'] for c in gates.values())
  fanout={n:sum(c['connections']['CLK']==g['connections'][gate['output_pin']] for c in flops.values()) for n,g in gates.items()}
  assert all(v>0 for v in fanout.values())
  assert clocks<={tuple(g['connections'][gate['output_pin']]) for g in gates.values()}
  assert all(p['vdot_registers']==len(vdot) and p['gates']==3 for p in profiles)
  record.update(gates=3,gate_flop_fanout=fanout,gate_audit_sha256=sha(mapping/'gate-audit.json'))
 else:assert clocks=={tuple(original['ports']['clock']['bits'])}
 report['boundaries'][boundary]=record
# Freeze identity is rechecked after synthesis, not inferred from a directory name.
src=json.loads((root/'source-manifest.json').read_text())['files']
assert all(sha(root/'source'/f['path'])==f['sha256'] for f in src)
frozen=json.loads((root/'tool-freeze.json').read_text())['files']
assert all(sha(pathlib.Path(p))==h for p,h in frozen.items())
report.update(status='SP1_ASAP7_STRUCTURE_AND_SETUP_COVERAGE_PASS',source_files_unchanged=len(src),frozen_tool_files_unchanged=len(frozen),physical_signoff=False,mapped_netlist_formal_equivalence=False,power_measured=False)
(root/'review.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
