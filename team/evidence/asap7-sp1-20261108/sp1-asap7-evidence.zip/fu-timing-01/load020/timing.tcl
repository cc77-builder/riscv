sta::set_crpr_enabled false
if {[sta::crpr_enabled]} {error "CRPR must be disabled"}
puts "CRPR_DISABLED_CONFIRMED"
read_liberty /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-map-01/asap7/combined.lib
read_verilog /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-map-01/asap7/canonical.v
link_design CommonFuCostTop
set_cmd_units -time ns -capacitance fF
set_wire_load_mode top
set_wire_load_model -name rvinno_pin_only
create_clock -name clk -period 1 [get_ports clock]
set_clock_uncertainty 0.05 [get_clocks clk]
set_clock_transition 0.05 [get_clocks clk]
set inputs {}
foreach p [all_inputs] {if {[get_full_name $p] ne "clock"} {lappend inputs $p}}
set outputs [all_outputs]
set_input_delay -max 0.1 -clock clk $inputs
set_output_delay -max 0.1 -clock clk $outputs
set_input_transition 0.05 $inputs
set_load 20 $outputs
check_setup -verbose > /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-timing-01/load020/setup.rpt
set q [all_registers -output_pins]
set d [all_registers -data_pins]
report_checks -from $q -to $d -path_delay max -group_count 1 -endpoint_count 1 -digits 6 > /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-timing-01/load020/r2r.rpt
report_checks -from $inputs -to $d -path_delay max -group_count 1 -endpoint_count 1 -digits 6 > /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-timing-01/load020/i2r.rpt
report_checks -from $q -to $outputs -path_delay max -group_count 1 -endpoint_count 1 -digits 6 > /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-timing-01/load020/r2o.rpt
report_checks -from $inputs -to $outputs -path_delay max -group_count 1 -endpoint_count 1 -digits 6 > /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-timing-01/load020/i2o.rpt
report_checks -from [get_ports io_out_ready] -to [get_ports io_in_ready] -path_delay max -group_count 1 -endpoint_count 1 -digits 6 > /home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108/fu-timing-01/load020/ready.rpt
puts "SP1_FU_STA_COMPLETE"
exit
