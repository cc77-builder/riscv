"""Five-profile setup coverage for the full SP1 FU, with explicit CRPR policy."""
import pathlib,sys,json,os,subprocess,re,time,hashlib
root=pathlib.Path('/home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108')
sys.path.insert(0,str(root/'tools'))
from timing import parse_path,constant_warnings
from compact import topology
import canonical
mapping=root/'fu-map-01/asap7';out=root/'fu-timing-01';out.mkdir(exist_ok=False)
eda=pathlib.Path('/home/amesotten/.cache/codex-rvinno/eda-asap7-20261028-03')
env=dict(os.environ,LD_LIBRARY_PATH=str(eda/'tools/usr/lib/x86_64-linux-gnu'),TCL_LIBRARY=str(eda/'tools/usr/share/tcltk/tcl8.6'))
env.pop('LD_PRELOAD',None)
original=json.loads((mapping/'mapped.json').read_text())['modules']['CommonFuCostTop']
design=json.loads((mapping/'canonical.json').read_text())['modules']['CommonFuCostTop']
design=canonical.bind(design,original,{'c'+str(i):n for i,n in enumerate(sorted(original['cells']))})
assert topology(original)==topology(design,True)
result=dict(status='RUNNING',profiles=[],scope='SP1 full FU setup coverage; no physical signoff')
try:
 for label,period,load in [('nominal',1,5),('period050',.5,5),('period200',2,5),('load001',1,1),('load020',1,20)]:
  dest=out/label;dest.mkdir()
  commands=['sta::set_crpr_enabled false','if {[sta::crpr_enabled]} {error "CRPR must be disabled"}','puts "CRPR_DISABLED_CONFIRMED"',f'read_liberty {mapping/"combined.lib"}',f'read_verilog {mapping/"canonical.v"}','link_design CommonFuCostTop','set_cmd_units -time ns -capacitance fF','set_wire_load_mode top','set_wire_load_model -name rvinno_pin_only',f'create_clock -name clk -period {period} [get_ports clock]','set_clock_uncertainty 0.05 [get_clocks clk]','set_clock_transition 0.05 [get_clocks clk]','set inputs {}','foreach p [all_inputs] {if {[get_full_name $p] ne "clock"} {lappend inputs $p}}','set outputs [all_outputs]','set_input_delay -max 0.1 -clock clk $inputs','set_output_delay -max 0.1 -clock clk $outputs','set_input_transition 0.05 $inputs',f'set_load {load} $outputs',f'check_setup -verbose > {dest/"setup.rpt"}','set q [all_registers -output_pins]','set d [all_registers -data_pins]']
  paths=dict(r2r='-from $q -to $d',i2r='-from $inputs -to $d',r2o='-from $q -to $outputs',i2o='-from $inputs -to $outputs',ready='-from [get_ports io_out_ready] -to [get_ports io_in_ready]')
  for name,selector in paths.items():commands.append(f'report_checks {selector} -path_delay max -group_count 1 -endpoint_count 1 -digits 6 > {dest/(name+".rpt")}')
  commands+=['puts "SP1_FU_STA_COMPLETE"','exit']
  (dest/'timing.tcl').write_text('\n'.join(commands)+'\n')
  start=time.monotonic()
  with (dest/'sta.log').open('w') as log:subprocess.run([str(eda/'tools/usr/bin/sta'),'-no_init','-exit',str(dest/'timing.tcl')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
  log=(dest/'sta.log').read_text()
  assert not re.search(r'(?im)^(error|warning)',log) and log.count('SP1_FU_STA_COMPLETE')==1 and log.count('CRPR_DISABLED_CONFIRMED')==1
  parsed={n:parse_path((dest/(n+'.rpt')).read_text()) for n in paths}
  assert all(x['exists'] for x in parsed.values())
  allowed=constant_warnings((dest/'setup.rpt').read_text(),design)
  result['profiles'].append(dict(profile=label,period_ns=period,load_ff=load,paths=parsed,allowed_constant_endpoints=allowed,crpr_enabled=False,elapsed_seconds=time.monotonic()-start))
 result['status']='FU_SETUP_COVERAGE_PASS'
finally:(out/'result.json').write_text(json.dumps(result,indent=2))
print(result['status'])
