import pathlib,subprocess,json,hashlib,shutil,datetime,tarfile
transfer=pathlib.Path('/mnt/c/Code/RVInno/.cache/sp1-asap7-20261108')
root=pathlib.Path('/home/amesotten/.cache/codex-rvinno/sp1-asap7-20261108')
repo=root/'source'
modules=json.loads((transfer/'dependencies-final.json').read_text())['modules']
changed=[]
with tarfile.open(transfer/'source.tar') as t:
 for member in t.getmembers():
  p=repo/member.name
  if member.isfile():
   b=p.read_bytes()
   if b'\r\n' in b and b'\x00' not in b:
    p.write_bytes(b.replace(b'\r\n',b'\n'));changed.append(member.name)
(root/'lf-normalization.json').write_text(json.dumps(dict(reason='Windows git archive text conversion; restored LF and verified release hashes',files=changed),indent=2))
manifest=json.loads((transfer/'source-manifest-v1.json').read_text())['files']
assert all(hashlib.sha256((repo/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in manifest)
shutil.copy2(transfer/'source-manifest-v1.json',root/'source-manifest.json')
# Build metadata is local-only and explicitly distinct from the source release identity.
subprocess.run(['git','init','-q',str(repo)],check=True)
subprocess.run(['git','-C',str(repo),'add','src','macros','scripts','build.sc','.mill-version','.gitmodules','team'],check=True)
subprocess.run(['git','-C',str(repo),'-c','user.name=Local synthesis snapshot','-c','user.email=local@invalid','commit','-qm','SP1 synthesis snapshot from ffb52e450; dependencies pinned separately'],check=True)
tools=root/'tools';tools.mkdir()
o4=pathlib.Path('/mnt/c/Code/RVInno/riscv/team/optimizations/o4')
for f in o4.glob('*.py'):shutil.copy2(f,tools/f.name)
shutil.copytree(o4/'asap7',tools/'asap7',ignore=shutil.ignore_patterns('__pycache__'))
for name in ['check_environment.py','parent_timing.py','review_parent.py']:
 p=tools/'asap7'/name;s=p.read_text()
 s=s.replace("['nangate45', 'asap7']","['asap7']").replace("['nangate45','asap7']","['asap7']")
 # Scope labels must not claim a dual-library run.
 s=s.replace('DUAL_LIBRARY_', 'SINGLE_LIBRARY_').replace('PARENT_PAIR_REVIEW_PASS','PARENT_SINGLE_REVIEW_PASS')
 p.write_text(s)
(root/'identity.json').write_text(json.dumps(dict(release_commit='ffb52e4504244b7d833d311d0ce0589f883abaf8',source_files_verified=len(manifest),dependency_modules=len(modules),created=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='SP1 FU and full VFEX4 parent; ASAP7 RVT TT; pin-only prelayout reference'),indent=2))
print('READY',root,flush=True)
