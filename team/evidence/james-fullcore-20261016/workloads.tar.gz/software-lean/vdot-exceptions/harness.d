/home/amesotten/.cache/codex-rvinno/fullcore-20261016/workloads/software-lean/objects/../vdot-exceptions/harness.o: \
 /home/amesotten/.cache/codex-rvinno/fullcore-20261016/source-9a5c75274233d410/team/workloads/vdot-exceptions/harness.S \
 /home/amesotten/.cache/codex-rvinno/fullcore-20261016/source-9a5c75274233d410/team/workloads/vdot-exceptions/layout.h
