/home/amesotten/.cache/codex-rvinno/fullcore-20261016/workloads/software-original/objects/../vdot-exceptions/judge.o: \
 /home/amesotten/.cache/codex-rvinno/fullcore-20261016/source-9a5c75274233d410/team/workloads/vdot-exceptions/judge.c \
 /home/amesotten/.cache/codex-rvinno/fullcore-20261016/source-9a5c75274233d410/team/workloads/vdot-exceptions/harness.h \
 /home/amesotten/.cache/codex-rvinno/fullcore-20261016/source-9a5c75274233d410/team/workloads/vdot-exceptions/layout.h
