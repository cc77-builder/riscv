# 实测 dot16 硬件与交付源码的对应关系

核对时间：2026-11-07 22:40 UTC。此文件只整理已完成构建的身份及交付入口，不新增构建、性能或 PPA 资格。机器可读摘录见 `binding.json`，原始资格以文中既有模块记录为准。

## 1. 应交付的版本名称

**本轮整核和软件目标实验使用的硬件是 `c981529dc6e493fb7deee8429b9ce05fd197497b` 加固定 dot16 候选补丁。** 已测 EMU 的 SHA256 为 `f14918658fcd2f19c9fb6c1d493025d98f727ac985ea73129edc58270fa6977d`，大小 71,043,280 字节。不能只用基底 HEAD 或最新发布提交代替这个组合。

| 对象 | 真实含义 | 当前使用范围 |
| --- | --- | --- |
| `c981529…` + `candidate.patch` (`5b5824…`) | 原构建时的未提交 dot16 源码组合 | 固定六例整核冒烟及本轮沿用该 EMU 的软件实验 |
| 发布提交 `5ca4ea1f3593cdb7f8d0033745e0a623902e2d99` | 本轮源码、候选、结果和证据的共享入口 | 不能单独称为当前实测硬件 |
| `rtl-integration/cost/signed8/{csa,prefix}` | 后续局部硬件候选 | 各自局部算术/FU/综合时序证据；尚未替换上述 EMU |

2026-11-07 22:32 UTC 的原生 Windows Git 只读检查确认：`5ca4ea1` 的五个补丁前置文件、两个不变依赖与 manifest 守卫相符，第六个新增文件 `VDot16Feature.scala` 尚不存在；其 `src`、`build.sc`、`Makefile` 相对 `c981529…` 无变化。该检查没有把历史构建 HEAD 改成 `5ca4ea1`，也没有重新核对该提交中的全部 435 个硬件文件或 21,236 个依赖文件。因此，本交付仍以实际受测的 `c981529… + patch` 命名。

源码、补丁及已有资格入口：

- [固定提交中的 candidate.patch](https://github.com/cc77-builder/riscv/blob/5ca4ea1f3593cdb7f8d0033745e0a623902e2d99/team/optimizations/o2/dot16/rtl-integration/candidate.patch)
- [source-manifest.json](https://github.com/cc77-builder/riscv/blob/5ca4ea1f3593cdb7f8d0033745e0a623902e2d99/team/optimizations/o2/dot16/rtl-integration/source-manifest.json)
- [整核原始结果和范围](https://github.com/cc77-builder/riscv/blob/5ca4ea1f3593cdb7f8d0033745e0a623902e2d99/team/optimizations/o2/dot16/rtl-integration/fullcore/RESULT.md)
- [局部 CSA / prefix 结果](https://github.com/cc77-builder/riscv/blob/5ca4ea1f3593cdb7f8d0033745e0a623902e2d99/team/optimizations/o2/dot16/rtl-integration/cost/RESULT.md)

## 2. 完整开关和运行依赖

以下八个开关来自已测硬件记录及原成功构建输入，两处一致。

| 开关 | 值 |
| --- | ---: |
| `VDOT_DOT16` | 1 |
| `VDOT_O2_ELASTIC` | 1 |
| `VDOT_T14_FUSED_INPUT` | 1 |
| `VDOT_O1_HANDOFF` | 0 |
| `VDOT_O1_TRACE` | 0 |
| `VDOT_O2_TRACE` | 0 |
| `VDOT_T12_TRACE` | 0 |
| `VDOT_T13_TRACE` | 0 |

| 固定对象 | SHA256 |
| --- | --- |
| 候选补丁 | `5b5824bac200c2a775598686e550854f8276d5db007b72f4b7be92437b4d3416` |
| 源码 manifest | `fd556a8c498ab4a3928ecd1cae46f4ac7af4fa8b319d3741d31713f5c2fdba89` |
| feature1 NEMU reference | `cc768488944941d59442727a96e0a19206e24872dcefed0052cf6cb3694a3fae` |
| boot flash | `a3360212cf7bb784119c1719c9258362f8567803601b2359aee2c104864fa994` |
| 生成及 reference 使用的 `diffstate.h` | `6a2ce3ab51893908f74452522ab03c553cf7fa7e8aa25f74ea84d79aa45f044d` |
| 原六例 smoke 镜像 | `6f800620b3ed6e504691ef1a060e701d781f2c888765d006a04cf0a4cfce3a49` |

原 ABI 验证对应 1,400 字节布局。上表 smoke 镜像不是本轮完整 forward 或 packed-Ws 镜像；每项软件结果必须使用自己的 ELF/BIN、reference、合同和窗口身份，不能跨镜像沿用周期分母。

## 3. 构建链与复现边界

原整核配置为 `MinimalConfig`、`NUM_CORES=1`、`EMU_THREADS=1`，`EMU_TRACE=0`、`NO_DIFF=0`，关闭 ChiselDB / Constantin / RollingDB。它是该配置的整核模拟器，不能扩写成已完成所有配置或物理实现验证。

实际构建分为两段：

1. `build-01` 完成 Scala 编译和 Verilator 生成，但原生 GCC 编译失败。原状态仍为 `FAILED`，没有覆盖成成功。
2. `native-02` 使用同一冻结生成物，显式采用 Clang 19、GNU `ld.bfd`，以 `OPT_FAST=-O3`、`OPT_SLOW=-O0`、`VM_PARALLEL_BUILDS=1`、历史 `-j3` 完成原生编译和链接。内部记录时间为 2026-11-06 04:16:33.123384—04:21:04.370215 UTC。

成功构建的 `build-inputs.json` 为 3,311,847 字节，SHA256 `76853412c2c2f27e3e91fbdb0c25b89064023c908d648aa33491372fb5d6231e`，包含 435 个硬件文件、21,236 个依赖文件、126 个递归依赖身份，以及候选和驱动源码身份。原 2,014 个生成输入共 2,018,152,258 字节，另有 generation freeze、工具及编译器运行库身份。当前摘录保留关键字段和原文件引用，没有把历史清单冒充对现时依赖的重新扫描。

这些记录位于常驻 WSL 开发区的 `runs/dot16-fullcore-20261106-pro2/`；归档入口为 [fullcore/evidence-v1](https://github.com/cc77-builder/riscv/tree/5ca4ea1f3593cdb7f8d0033745e0a623902e2d99/team/optimizations/o2/dot16/rtl-integration/fullcore/evidence-v1)。既有 `raw.zip` 保存 144 个成员、89,127,207 字节原始内容，压缩后 23,182,665 字节，SHA256 `dc2929eb9399b7274ec7111a87b5ac00f7a9aecc89bbbf6c3cab31d95e60449c`；大体积生成物和缓存保留在原构建目录。原工具、失败日志、生成清单及命令应从该入口取用。

**现有 `resume_native.py` 是对原失败构建的受控续编入口，绑定原 HEAD、路径、失败日志和生成物；不能作为任意干净 checkout 的通用重建命令。** 目前可准确交付的是已测源码组合、固定 EMU 及完整历史构建证据，尚未在本轮重做独立干净构建。未来重新构建应复用既有合同与工具设计、使用独立输出并重新确认环境；不能承诺所得二进制必与当前 EMU 字节相同。

## 4. 使用、回退与资格

当前运行仍引用冻结的 resident EMU 和输入，主仓与常驻 WSL 工作区均有受保护内容。此核对没有应用补丁、切换工作树、重建 EMU 或改变任何在途作业。另行采用候选时，应先核对 manifest 的五个前置 SHA、两个不变依赖及新增文件不存在，再核对应用后的六个 SHA；回退也要先确认后置身份及反向补丁适用，保留未参与本次候选的修改。静态 manifest 中的 `production_applied=false` 等字段是当时准备阶段的快照，不应因后续测试而改写。

原固定六例证明 2 个 dot8、4 个 dot16 合法场景在该整核和 reference 下通过；它没有覆盖完整 G3、非法/异常矩阵及全部别名/随机组合。本轮软件结果分别声明正确性与周期观测范围。后续 CSA/prefix 修改了 datapath/wrapper，原 FU、父级和整核 PASS 不能自动转授；prefix 的局部面积、时序与本轮旧 EMU 上的应用周期也不能拼成同一组合的实测收益。

本目录的 `REVIEW.md` 为独立只读审查，`published-base-identity.json` 和 `binding.json` 记录本次核对。工程结果的权威入口仍是上述模块 RESULT，不另建一套资格判定。
