# Four-arm TRACE0 target source

{
  "max_cycles": 40000000,
  "external_timeout_seconds": 43200,
  "max_output_file_bytes": 16777216
}

Exactly four fresh normal EMU processes; each instance uses one declared CPU. The shared total remains at most four CPUs. No automatic restart or budget extension. The existing 64 KiB physical-line and 16 MiB complete text limits remain in the raw reader. The resource profile must separately bind real CPU slots, operation ID, all input identities, the completed new reference campaign and the four method-only images before launch. The outer operation owner and its wall-clock/cleanup budget are not created here. This preparer launches no build, host probe, reference or EMU.
