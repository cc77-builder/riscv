"""Audit complete dot16 TRACE0 raw logs without claiming retirement traces."""
from contextlib import ExitStack
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import struct

HERE = Path(__file__).resolve().parent
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

ref = load('first_token_audit_reference', HERE / 'reference.py')
b, c = ref.b, ref.c
norm = load('first_token_prior_raw_gates', b.TOOL_REPO / b.STAGES / 'norm/run.py')
stream = norm.stream
need, read, save = b.need, b.read, b.save
PROFILE = 'r3-dot16-first-forward-w2np-resources-v1'
TARGET_CASES = (('paired16', 0x50313631, False), ('paired16_quantize', 0x50535131, False),
                ('dot16', 0x44313631, False), ('dot16_quantize', 0x44313651, False))
need(b.CONTRACT == 'r3-dot16-first-forward-w2np-v1' and
     all(b.METHODS[name] == method for name, method, _ in TARGET_CASES),
     'exact four-arm dot16 workload and method words')


def profile_case_binding(profile):
    """Bind the profile to the four fixed cases, independently of its receipts."""
    need(profile.get('contract') == PROFILE and profile.get('workload_contract') == b.CONTRACT and
         profile.get('status') == 'FROZEN_BEFORE_EMU' and
         profile.get('cases') == [list(case) for case in TARGET_CASES] and
         profile.get('performance_qualified') is False and profile.get('full_retirement_window_audited') is False,
         'exact four-case dot16 TRACE0 target profile')
    images = profile['target_images']['images']
    need(set(images) == {name for name, _, _ in TARGET_CASES} and
         all(images[name]['method'] == method and images[name]['controls'] == [method, 0, 1]
             for name, method, _ in TARGET_CASES), 'fixed four-arm image names, methods and UART controls')


def case_binding(dest, receipt, profile):
    profile_case_binding(profile)
    name, method, negative = receipt['name'], receipt['method'], receipt['negative']
    need((name, method, negative) in TARGET_CASES and negative is False, 'exact fixed normal target case identity')
    root = Path(profile['paths']['output'])
    need(root.is_absolute() and root == root.resolve() and dest.resolve() == root / name,
         'exact canonical target case directory')
    need(receipt['image_sha256'] == profile['target_images']['images'][name]['sha256'],
         'actual receipt uses its own predeclared target image')


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''): value.update(block)
    return value.hexdigest()


def gates():
    return tuple(load('first_token_' + name, b.TOOL_REPO / path) for name, path in (
        ('banner', 'team/optimizations/o2/fullcore/run_suite.py'),
        ('gate', 'team/optimizations/o1/audit/runtime_gate.py'),
        ('fatal', 'team/optimizations/o2/fullcore/recheck.py'),
        ('observer', 'team/optimizations/o2/fullcore/analyze.py')))


def raw_gates(paths, negative, gate, fatal):
    """The unchanged per-line gates with allocation bounded before length check."""
    for path in paths:
        with path.open('r', encoding='utf-8') as source:
            tail = ''
            while True:
                line = source.readline(stream.MAX_LINE + 1)
                if not line: break
                need(len(line) <= stream.MAX_LINE, 'bounded raw physical line')
                plain = gate.normalize_console(line); fatal.reject_fatal_output(tail + plain)
                tail = (tail + plain)[-4096:]
                if negative and 'HIT BAD TRAP' in plain:
                    need(re.fullmatch(r'(?:Core 0: )?HIT BAD TRAP at pc = 0x[0-9a-f]+\n?', plain) is not None,
                         'canonical sole expected raw bad trap')
                else: gate.validate_failure_markers(plain)


def validate(dest, build_dir, build, receipt, cfg, profile, output):
    need(not output.exists(), 'fresh separate audit output')
    method, negative = receipt['method'], receipt['negative']
    need(build.get('exact_flags_guard') == 1 and all(v == 1 for v in build['expected_flags'].values()) and
         read(build_dir / 'derivation.json')['exact_flags_guard'] == 1, 'new image enforces precise flags before either transcript')
    case_binding(dest, receipt, profile)
    need(receipt['contract'] == b.CONTRACT and receipt['operation_id'] == profile['operation_id'] and
         receipt['profile_sha256'] == sha(dest.parent / 'resource-contract.json') and
         read(dest.parent / 'resource-contract.json') == profile and
         receipt['environment_overrides'] == profile['environment_overrides'] ==
         {'XS_NEGATIVE_VECTOR_TARGET': None, 'OMP_NUM_THREADS': '1', 'EMU_THREADS': '1'} and
         receipt['log_profile'] == profile['log_profile'], 'exact runtime resource/source and environment binding')
    need(receipt.get('process_started') is True and receipt.get('direct_child_reaped') is True and
         receipt.get('process_group_absent_after_exit') is True and not receipt.get('residual_process_group') and
         not receipt.get('timed_out') and receipt.get('exit_code') == (1 if negative else 0), 'complete owned expected EMU exit')
    raw, control = ref.image(build_dir, build, method, negative, 1)
    need(sha(dest / 'image.bin') == hashlib.sha256(raw).hexdigest() == receipt['image_sha256'] and
         read(dest / 'image-control.json') == control, 'actual loaded image and explicit controls')
    del raw
    max_cycles, timeout, limit = (profile[k] for k in ('max_cycles', 'external_timeout_seconds', 'max_output_file_bytes'))
    need(all(receipt[k] == profile[k] for k in ('max_cycles', 'external_timeout_seconds', 'max_output_file_bytes')),
         'actual resource contract unchanged')
    need(receipt['command'] == [str(Path(cfg['hardware_source']) / 'build/emu'), '-i', str(dest / 'image.bin'),
         '--flash=' + cfg['flash'], '--ram-size=128MB', '--diff=' + cfg['reference'], '--max-cycles=' + str(max_cycles),
         '--seed=1', '--log-end=0'], 'exact actual frozen EMU invocation')
    logs = [dest / 'stderr.log', dest / 'stdout.log']
    need(receipt['raw_sha256'] == {p.name: sha(p) for p in logs} and
         receipt['raw_bytes'] == {p.name: p.stat().st_size for p in logs} and
         all(p.stat().st_size < limit for p in logs), 'complete original raw bytes and hashes within resource bound')
    banner, gate, fatal, observer = gates()
    raw_gates(logs, negative, gate, fatal)
    elf = c.base.f.g.ELF((build_dir / (b.PREFIX + '.elf')).read_bytes())
    # Reuse only the original bounded raw-line reader, not its trace protocol.
    # The old non-O2 residue limit remains the complete TRACE0 text limit.
    with ExitStack() as stack:
        reader = stream.Reader([stack.enter_context(path.open('r', encoding='utf-8')) for path in logs])
        parts, size = [], 0
        for line in reader.lines():
            size += len(line.encode())
            need(size <= stream.MAX_RESIDUAL, 'complete TRACE0 text within original residue bound')
            parts.append(line)
        uart = ''.join(parts)
    banner.validate_runtime(uart, cfg['reference']); fatal.reject_fatal_output(uart)
    need(uart.count('The first instruction of core 0 has commited. Difftest enabled.') == 1,
         'one actual DiffTest enabled banner')
    plain = gate.normalize_console(uart)
    lines = [line for line in plain.splitlines() if line.startswith('CONSUMER_')]
    begin = 'CONSUMER_BEGIN token=1 position=0'
    need(len(lines) == 3 and lines[0] == begin, 'exact first-token application transcript')
    match = re.fullmatch(r'CONSUMER_COUNTERS ([0-9]+) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16})', lines[1])
    need(match is not None and int(match[1]) == method, 'one canonical full-width counter row')
    values = [int(value, 16) for value in match.groups()[1:]]
    c0, i0, i1, c1 = values
    need(0 < c1 - c0 < max_cycles and 0 < i1 - i0 < 2**32, 'bounded actual UART deltas')
    expected_end = 'CONSUMER_REJECT code=94 byte=152476' if negative else f'CONSUMER_PASS bytes={b.S} flags={build["expected_flags"][str(method)]}'
    need(lines[2] == expected_end, 'entire state compared or precise actual last-logit rejection')
    trap_lines = [line for line in plain.splitlines() if 'HIT ' in line and ' TRAP' in line]
    trap_kind = 'BAD' if negative else 'GOOD'
    need(len(trap_lines) == 1 and plain.count('HIT ' + trap_kind + ' TRAP') == 1, 'one expected terminal trap')
    trap = re.fullmatch(r'(?:Core 0: )?HIT ' + trap_kind + r' TRAP at pc = (0x[0-9a-f]+)', trap_lines[0])
    need(trap is not None, 'canonical terminal trap')
    trap_pc = int(trap[1], 16)
    expected_pcs = [int(x, 16) for x in build['failure_traps']] if negative else [int(build['success_trap'], 16)]
    need(trap_pc in expected_pcs and elf.read(trap_pc, 4) == struct.pack('<I', 0x0005006b), 'actual expected a0-consuming trap PC/word')
    gate.validate_failure_markers('\n'.join(line for line in plain.splitlines() if not (negative and line == trap_lines[0])))
    spent = re.findall(r'Guest cycle spent: (\d+)', plain)
    need(len(spent) == 1 and 0 < int(spent[0]) <= max_cycles, 'complete bounded guest terminal count')
    samples = [dict(cycles=c1 - c0, instret=i1 - i0)]
    # These are exact UART words and static CSR sites, not a retirement proof.
    counters = lines[1] + '\n'
    protocol = dict(status='NOT_COLLECTED_TRACE0', event_protocol_verified=False)
    timing = dict(status='UART_CSR_OBSERVATION_ONLY',
        counter_hex=list(match.groups()[1:]), counter_values=values,
        static_counter_sites=build['counter_sites'], retirement_association_verified=False,
        samples=samples)
    custom = dict(status='NOT_COLLECTED_TRACE0', retired_count=None,
        exact_dynamic_count_claimed=False, pc_digest=None)
    output.mkdir(parents=True)
    save(output / 'protocol.json', protocol); save(output / 'counter-audit.json', timing); save(output / 'custom.json', custom)
    (output / 'uart.txt').write_text(uart); (output / 'uart-counter-row.txt').write_text(counters)
    return dict(contract=b.CONTRACT, status='EXPECTED_FIRST_TOKEN_TARGET_REJECTION' if negative else 'FIRST_FORWARD_W2NP_TARGET_DIFFTEST_PASS',
        name=receipt['name'], method=method, negative=negative, transcript=lines, flags=build['expected_flags'][str(method)],
        flags_evidence='fixed-program flags==1 gate before COUNTERS/REJECT' if negative else 'exact PASS flags plus fixed-program flags==1 gate',
        guest_cycles=int(spent[0]), counter_values=values, counter_hex=list(match.groups()[1:]),
        counter_retirement_verified=False, samples=samples, trap_pc=hex(trap_pc), custom=custom,
        protocol={k: v for k, v in protocol.items() if k != 'input_sha256'}, counter_audit=timing,
        target_correctness_qualified=not negative, performance_qualified=False, full_retirement_window_audited=False,
        scope='one prescribed-prepare first p0 token1 complete forward, original DiffTest and UART CSR observations; TRACE0 retirement evidence not collected')
