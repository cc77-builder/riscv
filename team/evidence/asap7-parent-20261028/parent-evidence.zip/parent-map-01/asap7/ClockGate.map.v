module ClockGate(input TE, E, CK, output Q);
  ICGx1_ASAP7_75t_R impl(.CLK(CK), .ENA(E), .SE(TE), .GCLK(Q));
endmodule
