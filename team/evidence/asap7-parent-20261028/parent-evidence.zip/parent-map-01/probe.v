module probe(input clock, input [7:0] a,b, output reg [7:0] q); always @(posedge clock) q <= a+b; endmodule
