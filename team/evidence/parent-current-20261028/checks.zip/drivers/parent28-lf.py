from pathlib import Path
import tarfile,hashlib,json,subprocess
out=Path('team/out/parent-current-20261028');old=json.loads((out/'source.json').read_text())
with (out/'source-lf.tar').open('wb') as f:subprocess.run(['git','-c','core.autocrlf=false','-c','core.eol=lf','archive','--format=tar',old['head'],*old['sha256']],stdout=f,check=True)
with tarfile.open(out/'source-lf.tar') as t:rows={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}
(out/'source-lf.json').write_text(json.dumps({'head':old['head'],'sha256':rows},indent=2)+'\n');print('LF delta',[n for n,h in rows.items() if old['sha256'].get(n)!=h])
