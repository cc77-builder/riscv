from pathlib import Path
import subprocess,json,tarfile,hashlib
root=Path.cwd(); out=root/'team/out/parent-current-20261028';out.mkdir(exist_ok=False)
paths=['src','macros','scripts','build.sc','.mill-version','Makefile','Makefile.test','.gitmodules','.gitattributes','.gitignore','team/scripts/activate.sh','team/scripts/prepare-core-baseline.py','team/optimizations/o1/build_inputs.py','team/optimizations/o2/parent','team/optimizations/o2/run_rtl.py','team/optimizations/o4/perf/audit.py','team/rtl/vdot','team/models/vdot']
subprocess.run(['git','archive','--format=tar','--output='+str(out/'source.tar'),'HEAD',*paths],check=True)
with tarfile.open(out/'source.tar') as t:
 rows={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()}
(out/'source.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sha256':rows},indent=2)+'\n')
print(len(rows),'inputs')
