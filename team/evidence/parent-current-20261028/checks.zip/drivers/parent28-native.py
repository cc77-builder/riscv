from pathlib import Path
import os,subprocess,json,hashlib,shutil,time
cache=Path('/home/amesotten/.cache/codex-rvinno'); root=cache/'parent-current-20261028'; root.mkdir(exist_ok=False)
donor=cache/'h1-integration-20261021/repo'; repo=root/'repo'; win=Path('/mnt/c/Code/RVInno/riscv/team/out/parent-current-20261028')
binding=json.loads((win/'source.json').read_text()); records=[]
def run(args):
 p=subprocess.run(list(map(str,args)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT); records.append({'args':list(map(str,args)),'rc':p.returncode,'output':p.stdout.decode(errors='replace')});(root/'prepare.json').write_text(json.dumps(records,indent=2));assert p.returncode==0,records[-1];return p.stdout
run(['git','clone','--shared','--no-checkout',donor,repo])
run(['git','-C',repo,'config','core.autocrlf','false']);run(['git','-C',repo,'config','core.sparseCheckout','true'])
patterns=['/src/','/macros/','/scripts/','/build.sc','/.mill-version','/Makefile','/Makefile.test','/.gitmodules','/.gitattributes','/.gitignore','/team/scripts/activate.sh','/team/scripts/prepare-core-baseline.py','/team/optimizations/o1/build_inputs.py','/team/optimizations/o2/parent/','/team/optimizations/o2/run_rtl.py','/team/optimizations/o4/perf/audit.py','/team/rtl/vdot/','/team/models/vdot/']
(repo/'.git/info/sparse-checkout').write_text('\n'.join(patterns)+'\n');run(['git','-C',repo,'checkout','--detach',binding['head']])
# Independent writable dependency copies; existing object donors stay untouched.
links=[]
for row in run(['git','-C',repo,'ls-tree','-rz','HEAD']).split(b'\0'):
 if not row:continue
 info,name=row.split(b'\t',1)
 if info.split()[0]==b'160000':links.append(name.decode())
for name in links:
 src=donor/name; dst=repo/name
 shutil.copytree(src,dst,dirs_exist_ok=True,symlinks=True)
for r in [repo]+[p.parent for name in links for p in (repo/name).rglob('.gitmodules')]:
 if (r/'.gitmodules').exists():run(['git','-C',r,'submodule','init'])
for name,h in binding['sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,name
shutil.copy2(win/'source.json',root/'source-binding.json')
# Reuse dependency compiler cache only; Mill validates inputs and recompiles changed modules.
shutil.copytree(donor/'out',repo/'out',symlinks=True)
env=os.environ.copy();env.update(JAVA_HOME='/usr/lib/jvm/java-21-openjdk-amd64',VDOT_RTL_JAVA_OPTS='-Xmx7G -Xss16m',VDOT_RTL_JOBS='2',COURSIER_CACHE=str(Path.home()/'.cache/coursier/v1'))
env['PATH']=str(cache/'h1-integration-20261021/rtl-tools')+':'+str(cache/'o5-fullcore-20261021/tools')+':'+env['PATH']
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
with (root/'driver.log').open('xb') as f:
 p=subprocess.run(['python3','-B',str(repo/'team/optimizations/o2/run_rtl.py'),'parent',str(root/'run-01')],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
(root/'driver.json').write_text(json.dumps({'returncode':p.returncode,'budget_seconds':1800,'jobs':2}));print('parent runner exit',p.returncode,flush=True)
