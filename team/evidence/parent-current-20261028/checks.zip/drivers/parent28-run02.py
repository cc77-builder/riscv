from pathlib import Path
import os,subprocess,json,hashlib,shutil,signal
cache=Path('/home/amesotten/.cache/codex-rvinno');root=cache/'parent-current-20261028';repo=root/'repo';win=Path('/mnt/c/Code/RVInno/riscv/team/out/parent-current-20261028');donor=cache/'h1-integration-20261021/repo'
binding=json.loads((win/'source-lf.json').read_text())
for name,h in binding['sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h,name
shutil.copy2(win/'source-lf.json',root/'source-binding.json')

for name in ('check_trace.py','test_trace.py'):
 shutil.copy2(Path('/mnt/c/Code/RVInno/riscv')/'team/optimizations/o2/parent'/name,repo/'team/optimizations/o2/parent'/name)

env=os.environ.copy();env.update(JAVA_HOME='/usr/lib/jvm/java-21-openjdk-amd64',VDOT_RTL_JAVA_OPTS='-Xmx7G -Xss16m',VDOT_RTL_JOBS='2',COURSIER_CACHE=str(Path.home()/'.cache/coursier/v1'))
env['COURSIER_REPOSITORIES']='https://repo.maven.apache.org/maven2'
env['PATH']=str(cache/'h1-integration-20261021/rtl-tools')+':'+str(cache/'o5-fullcore-20261021/tools')+':'+env['PATH'];os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
with (root/'driver-02.log').open('xb') as f:
 p=subprocess.Popen(['python3','-B',str(repo/'team/optimizations/o2/run_rtl.py'),'parent',str(root/'run-02')],env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=p.wait(timeout=1800)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  rc=124
(root/'driver-02.json').write_text(json.dumps({'returncode':rc,'budget_seconds':1800,'jobs':2}));print('parent runner exit',rc,flush=True)
