from pathlib import Path
import gzip,sys,json,subprocess,importlib.util,hashlib
root=Path.cwd();out=root/'team/out/parent-current-20261028'
parent=root/'team/optimizations/o2/parent';sys.path.insert(0,str(parent))
import check_trace,check_negative
raw=gzip.decompress((root/'team/optimizations/o2/r3-div-gate/evidence/20261024-local/files/runs/green-parent-01/result.log.gz').read_bytes()).decode()
oldpath=out/'checker-before.py';oldpath.write_bytes(subprocess.check_output(['git','show','HEAD:team/optimizations/o2/parent/check_trace.py']))
spec=importlib.util.spec_from_file_location('old',oldpath);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
results={'original_current':check_trace.check_trace(raw)}
mutations={}
mutations['rob-phase-labels-swapped']=raw.replace('-p0 ', '-TEMP ').replace('-p1 ', '-p0 ').replace('-TEMP ', '-p1 ')
lines=raw.splitlines();hits=[]
for i,line in enumerate(lines):
 if line.startswith('O2_PARENT_CYCLE ') and 'case=DIV-legacy-reset ' in line and ' reset=1 ' in line and ' redirect=1 ' in line:
  hits.append(i)
assert len(hits)==6
lines[hits[0]]=lines[hits[0]].replace(' redirect=1 ',' redirect=0 ')
mutations['reset-overlap-duplicated']= '\n'.join(lines)+'\n'
for name,text in mutations.items():
 before=old.check_trace(text)
 try:check_trace.check_trace(text)
 except ValueError as e:after=str(e)
 else:raise AssertionError('mutation escaped '+name)
 results[name]={'old_status':before['status'],'new_rejection':after,'mutant_sha256':hashlib.sha256(text.encode()).hexdigest()}
results['original_positive_gate']=check_negative.check_positive(raw)
(out/'phase-integration.json').write_text(json.dumps(results,indent=2)+'\n')
print({k:{x:y for x,y in v.items() if x in ('status','old_status','new_rejection')} for k,v in results.items()})
