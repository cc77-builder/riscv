from pathlib import Path
import hashlib,json,subprocess,zipfile
repo=Path('/mnt/c/Code/RVInno/riscv')
root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261027')
assert json.loads((root/'state.json').read_bytes())['status']=='SYNC_FROZEN_REPLAY_PASS'
identity=json.loads((root/'source-identity.json').read_bytes())
for name,row in identity['files'].items():
 assert hashlib.sha256((root/'published-source'/name).read_bytes()).hexdigest()==row['sha256'],name
additional=json.loads((root/'additional-source-identity.json').read_bytes())
for name,row in additional['extra_source_files'].items():
 assert hashlib.sha256((root/'published-source'/name).read_bytes()).hexdigest()==row['sha256'],name
stage=json.loads((root/'current-checks/stage1-tests-02/tests.json').read_bytes())
assert stage['status']=='PASS'
summary=dict(status='OFFLINE_SYNC_CHECKS_COMPLETE',published_revision=identity['revision'],
 source_export_files_verified_after_replay=len(identity['files'])+len(additional['extra_source_files']),stage1_tool_checks=len(stage['checks']),
 new_emu_runs=0,new_nemu_runs=0,current_hardware_qualified=False,
 matrix=json.loads((root/'firstdot-matrix.json').read_bytes()),
 w2=json.loads((root/'w2-recheck/result.json').read_bytes()),
 expected_current_source_rejections=['config-state: frozen generator pin differs','r3-raw: current idle clock gate rejects old hardware log'])
assert summary['w2']['stage_performance_qualified'] is False
assert len(summary['w2']['cases'])==4
(root/'sync-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for pattern in ('*.json','*.log'):
 for p in root.glob(pattern):files['native/'+p.name]=p
 for p in (root/'current-checks').glob(pattern):files['native/current-checks/'+p.name]=p
for p in (root/'w2-recheck').rglob('*'):
 if p.is_file() and p.name not in ('stdout.log','stderr.log'):files['native/'+str(p.relative_to(root))]=p
for p in (root/'current-checks').glob('stage1-tests*/tests.json'):files['native/'+str(p.relative_to(root))]=p
for p in (repo/'team/out/sync-20261027').iterdir():
 if p.is_file() and p.suffix in ('.log','.json'):files['windows/'+p.name]=p
for p in (repo/'team/out').glob('sync27-*.py'):files['drivers/'+p.name]=p
out=repo/'team/evidence/progress-sync-20261027';out.mkdir(exist_ok=False)
rows={}
with zipfile.ZipFile(out/'checks.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  data=p.read_bytes();z.writestr(name,data)
  rows[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
manifest=dict(status=summary['status'],published_revision=identity['revision'],files=rows,
 archive_sha256=hashlib.sha256((out/'checks.zip').read_bytes()).hexdigest(),
 new_emu_runs=0,new_nemu_runs=0,current_hardware_qualified=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(out/'checks.zip') as z:
 assert set(z.namelist())==set(rows)
 for name,row in rows.items():assert hashlib.sha256(z.read(name)).hexdigest()==row['sha256']
print(json.dumps(dict(evidence_members=len(rows),archive_bytes=(out/'checks.zip').stat().st_size,stage1_checks=len(stage['checks']),matrix=summary['matrix']['status'],w2=summary['w2']['status'])))
