from pathlib import Path
import json,os,subprocess,time

repo=Path('/mnt/c/Code/RVInno/riscv')
root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261027')
source=root/'published-source'
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
env=dict(PATH='/usr/bin:/bin',LANG='C.UTF-8',LC_ALL='C.UTF-8',TZ='UTC',PYTHONDONTWRITEBYTECODE='1')
steps=[]
import zipfile,hashlib
additional=json.loads((repo/'team/out/sync-20261027/matrix-inputs.json').read_bytes())
archive_zip=repo/'team/out/sync-20261027/matrix-inputs.zip'
assert hashlib.sha256(archive_zip.read_bytes()).hexdigest()==additional['archive_sha256']
with zipfile.ZipFile(archive_zip) as z:
 for name in z.namelist():
  target=(source/name.removeprefix('extra/')) if name.startswith('extra/') else (root/'firstdot-matrix-archive'/name.removeprefix('archive/'))
  assert not target.exists()
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(z.read(name))
for name,row in additional['extra_source_files'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==row['sha256']
(root/'additional-source-identity.json').write_text(json.dumps(additional,indent=2)+'\n')
def call(label,args):
    row=dict(name=label,command=list(map(str,args)),environment=env,started=time.time())
    with (root/(label+'.stdout.log')).open('xb') as out,(root/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(row['command'],cwd=source,env=env,stdout=out,stderr=err)
    row.update(exit_code=p.returncode,finished=time.time());steps.append(row)
    (root/'replay-steps-04.json').write_text(json.dumps(steps,indent=2)+'\n')
    print(label,p.returncode,flush=True)
    if p.returncode:raise RuntimeError(label+' failed; original log retained')

firstdot=repo/'team/optimizations/o2/r2-vector-accum/evidence/firstdot-v1'
call('firstdot-matrix-04',['python3','-B',source/'team/optimizations/o2/r2-vector-accum/firstdot_evidence.py',
    '--action','audit','--repo',source,'--archive',root/'firstdot-matrix-archive','--output',root/'firstdot-matrix.json'])
stage=repo/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/forward-host/stages'
w2=stage/'w2'
idx=json.loads((w2/'evidence/index.json').read_bytes())['packages']['target']
call('w2-join',['python3','-B',stage/'restore.py','--archive',w2/idx['directory'],'--output',root/'w2-joined'])
call('w2-restore',['python3','-B',stage/'archive.py','verify','--archive',root/'w2-joined/payload.zip',
    '--expected-sha256',idx['archive_sha256'],'--output',root/'w2-restored'])
call('w2-recheck',['python3','-B',w2/'recheck.py','--kind','target','--root',root/'w2-restored',
    '--manifest',root/'w2-joined/manifest.json','--expected-manifest-sha256',idx['manifest_sha256'],
    '--output',root/'w2-recheck'])
(root/'state.json').write_text(json.dumps(dict(status='SYNC_FROZEN_REPLAY_PASS',new_emu_runs=0,
    published_revision='431938271dd3b9eda8595a45d2bcf4e429d25797',current_hardware_qualified=False),indent=2)+'\n')
