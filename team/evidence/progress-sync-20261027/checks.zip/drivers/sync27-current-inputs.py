from pathlib import Path
import hashlib,json,subprocess
paths=['team/optimizations/o2/parent/'+n for n in ('check_trace.py','test_trace.py','test_negative.py','check_negative.py','parent_test.cpp')]
paths+=['team/optimizations/o2/fullcore/'+n for n in ('build_fullcore.py','test_build_profiles.py')]
paths+=['team/optimizations/o2/run_rtl.py','team/optimizations/o4/perf/audit.py','team/optimizations/o2/r2-select/verify_firstdot_stable.py','team/optimizations/o2/r2-select/FIRSTDOT_STABLE_MANIFEST.json','team/optimizations/o2/r2-config-reuse/test_candidate.py','team/optimizations/o2/r2-config-reuse/candidate.py','team/optimizations/o2/r2-config-reuse/check.py','team/workloads/o3-gemv/generate.py','src/main/scala/xiangshan/backend/fu/wrapper/VDotO2.scala','src/main/scala/xiangshan/backend/fu/wrapper/VDotHandoff.scala']
paths+=['team/optimizations/o1/'+n for n in ('build_recipe.py','split_recipe.py','build_inputs.py')]
rows={p:dict(sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest(),bytes=Path(p).stat().st_size) for p in paths}
out=Path('team/out/sync-20261027')
(out/'current-source-identity.json').write_text(json.dumps(dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=rows,production_o1_default=False,production_o2_default=False),indent=2)+'\n')
refs=subprocess.check_output(['git','for-each-ref','--format=%(refname) %(objectname)','refs/heads','refs/remotes'],text=True)
(out/'branch-snapshot.json').write_text(json.dumps(dict(refs=refs.splitlines()),indent=2)+'\n')
print(len(rows),'current input hashes')
