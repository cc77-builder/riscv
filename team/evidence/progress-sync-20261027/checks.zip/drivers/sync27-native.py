from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time

repo=Path('/mnt/c/Code/RVInno/riscv')
delivery=repo/'team/out/sync-20261027'
root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261027')
root.mkdir(exist_ok=False)
source=root/'published-source';source.mkdir()
manifest=json.loads((delivery/'published-source.json').read_bytes())
archive=delivery/'published-source.tar'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
with tarfile.open(archive) as tar:
    members=tar.getmembers()
    assert {m.name for m in members}==set(manifest['files'])
    for member in members:
        target=source/member.name
        assert member.isfile() and target.resolve().is_relative_to(source)
        data=tar.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest()==manifest['files'][member.name]['sha256']
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(root/'source-identity.json').write_bytes((delivery/'published-source.json').read_bytes())
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
env=dict(PATH='/usr/bin:/bin',LANG='C.UTF-8',LC_ALL='C.UTF-8',TZ='UTC',PYTHONDONTWRITEBYTECODE='1')
steps=[]
def call(label,args):
    row=dict(name=label,command=list(map(str,args)),environment=env,started=time.time())
    with (root/(label+'.stdout.log')).open('xb') as out,(root/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(row['command'],cwd=source,env=env,stdout=out,stderr=err)
    row.update(exit_code=p.returncode,finished=time.time())
    steps.append(row);(root/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
    print(label,p.returncode,flush=True)
    if p.returncode:raise RuntimeError(label+' failed; original log retained')

call('config-tests',['python3','-B',source/'team/optimizations/o2/r2-config-reuse/test_candidate.py'])
call('native-store-tests',['python3','-B',source/'team/scripts/test_prepare_native_source.py'])
call('firstdot-tests',['python3','-B',source/'team/optimizations/o2/r2-vector-accum/test_firstdot.py',
                      '--repo',source,'--output',root/'firstdot-tests.json'])
evidence=repo/'team/optimizations/o4/perf/evidence/r3-parent-v2'
call('r3-frozen-raw',['python3','-B',source/'team/optimizations/o4/perf/audit.py',
    '--control',evidence/'files/run-02/result.log.gz','--metadata',evidence/'files/run-02/metadata.log.gz',
    '--negative-checks','--output',root/'r3-frozen-raw.json'])
firstdot=repo/'team/optimizations/o2/r2-vector-accum/evidence/firstdot-v1'
call('firstdot-matrix',['python3','-B',source/'team/optimizations/o2/r2-vector-accum/firstdot_evidence.py',
    'audit','--repo',source,'--archive',firstdot/'matrix-archive','--output',root/'firstdot-matrix.json'])
stage=repo/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/forward-host/stages'
w2=stage/'w2'
idx=json.loads((w2/'evidence/index.json').read_bytes())['packages']['target']
call('w2-join',['python3','-B',stage/'restore.py','--archive',w2/idx['directory'],'--output',root/'w2-joined'])
call('w2-restore',['python3','-B',stage/'archive.py','verify','--archive',root/'w2-joined/payload.zip',
    '--expected-sha256',idx['archive_sha256'],'--output',root/'w2-restored'])
call('w2-recheck',['python3','-B',w2/'recheck.py','--kind','target','--root',root/'w2-restored',
    '--manifest',root/'w2-joined/manifest.json','--expected-manifest-sha256',idx['manifest_sha256'],
    '--output',root/'w2-recheck'])
(root/'state.json').write_text(json.dumps(dict(status='SYNC_FROZEN_REPLAY_PASS',new_emu_runs=0,
    published_revision=manifest['revision'],current_hardware_qualified=False),indent=2)+'\n')
