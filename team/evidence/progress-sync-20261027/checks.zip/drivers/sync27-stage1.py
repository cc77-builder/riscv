from pathlib import Path
import gzip,json,subprocess,hashlib
repo=Path('/mnt/c/Code/RVInno/riscv')
root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261027/current-checks')
wave=root/'stage1-wave-fixture';wave.mkdir()
archive=repo/'team/evidence/stage1-current-20261025/wave'
for name in ('wave.json','selected.fst','selected.vcd'):
 p=archive/name
 (wave/name).write_bytes(p.read_bytes() if p.exists() else gzip.decompress(p.with_name(name+'.gz').read_bytes()))
argv=['python3','-B',str(repo/'team/tests/test-stage1-tools.py'),'--run',str(root/'stage1-fixture'),'--wave',str(wave/'wave.json'),'--output',str(root/'stage1-tests-02')]
with (root/'stage1-02.stdout.log').open('xb') as out,(root/'stage1-02.stderr.log').open('xb') as err:
 result=subprocess.run(argv,stdout=out,stderr=err)
(root/'stage1-02-receipt.json').write_text(json.dumps(dict(command=argv,exit_code=result.returncode,fixture='lossless decompression of tracked original'),indent=2)+'\n')
print('stage1',result.returncode)
raise SystemExit(result.returncode)
