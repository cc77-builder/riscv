import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'team/out/sync-20261027'
out.mkdir(exist_ok=False)
base='a669af7801aca9ddf67db978935f2c56cfafff1a'
upstream='431938271dd3b9eda8595a45d2bcf4e429d25797'
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
names=git('diff','--name-only','-z',base+'...'+upstream).decode().strip('\0').split('\0')
tree={}
for row in git('ls-tree','-rz',upstream).split(b'\0'):
    if row:
        info,name=row.split(b'\t',1)
        tree[name.decode()]=info.split()[2].decode()
index={}
for row in git('ls-files','--stage','-z').split(b'\0'):
    if row:
        info,name=row.split(b'\t',1)
        mode,blob,stage=info.split()
        assert stage==b'0',name
        index[name.decode()]=blob.decode()
intentional={'.gitattributes','AGENTS.md','team/docs/development-route-current.md',
             'team/optimizations/o2/parent/check_trace.py','team/optimizations/o2/parent/parent_test.cpp',
             'team/optimizations/o2/parent/test_trace.py','team/optimizations/o2/run_rtl.py',
             'team/optimizations/o4/README.md','开发计分板.md'}
unchanged=[p for p in names if p not in intentional and p in tree]
raw=git('hash-object','--no-filters','--stdin-paths') if False else subprocess.check_output(
    ['git','hash-object','--no-filters','--stdin-paths'],cwd=root,
    input=('\n'.join(json.dumps(p,ensure_ascii=False) for p in unchanged)+'\n').encode())
hashes=raw.decode().splitlines()
assert len(hashes)==len(unchanged)
drift=[p for p,h in zip(unchanged,hashes) if h!=tree[p] or index.get(p)!=tree[p]]
assert not drift,drift
summary=dict(base=base,upstream=upstream,new_commits=int(git('rev-list','--count',base+'..'+upstream)),
             upstream_changed_paths=len(names),imported_byte_identical=len(unchanged),
             intentional_combined_paths=sorted(intentional),new_emu_runs=0)
(out/'import-check.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)

commands=[
 ('parent-protocol',['-m','unittest','discover','-s','team/optimizations/o2/parent','-p','test_trace.py','-v']),
 ('config-state',['team/optimizations/o2/r2-config-reuse/test_candidate.py']),
 ('fullcore-guards',['-m','unittest','discover','-s','team/optimizations/o2/fullcore','-p','test_build_profiles.py','-v']),
 ('r3-bytes',['team/optimizations/o2/result-width/h1/seal.py','--verify','team/optimizations/o4/perf/evidence/r3-parent-v2']),
 ('r3-raw',['team/optimizations/o4/perf/audit.py','--control','team/optimizations/o4/perf/evidence/r3-parent-v2/files/run-02/result.log.gz',
            '--metadata','team/optimizations/o4/perf/evidence/r3-parent-v2/files/run-02/metadata.log.gz',
            '--negative-checks','--output',str(out/'r3-raw.json')]),
]
results=[]
for label,args in commands:
    started=time.time()
    with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:
        result=subprocess.run([sys.executable,'-B',*args],cwd=root,stdout=stdout,stderr=stderr)
    results.append(dict(name=label,command=[sys.executable,'-B',*args],exit_code=result.returncode,seconds=time.time()-started))
    (out/'host-checks.json').write_text(json.dumps(results,indent=2)+'\n')
    print(label,result.returncode,flush=True)
assert all(r['exit_code']==0 for r in results)
