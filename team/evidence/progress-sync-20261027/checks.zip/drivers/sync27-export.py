import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'team/out/sync-20261027'
revision='431938271dd3b9eda8595a45d2bcf4e429d25797'
raw=subprocess.check_output(['git','ls-tree','-rz',revision,'team'],cwd=root)
selected=[]
for row in raw.split(b'\0'):
    if not row: continue
    info,name=row.split(b'\t',1)
    path=Path(name.decode())
    if 'evidence' not in path.parts and 'archive' not in path.parts and 'out' not in path.parts and (
        path.suffix in ('.py','.c','.cpp','.h','.S','.json','.ld') or path.name=='Makefile'):
        selected.append((name.decode(),info.split()[2].decode()))
requests=out/'export-objects.txt'
requests.write_text(''.join(blob+'\n' for _,blob in selected))
manifest={}
with requests.open('rb') as request,tarfile.open(out/'published-source.tar','x') as archive:
    proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=request,stdout=subprocess.PIPE)
    for name,blob in selected:
        fields=proc.stdout.readline().split()
        assert fields[:2]==[blob.encode(),b'blob']
        data=proc.stdout.read(int(fields[2])); assert proc.stdout.read(1)==b'\n'
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644
        archive.addfile(member,io.BytesIO(data))
        manifest[name]=dict(git_blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
    assert proc.wait()==0
body=dict(revision=revision,files=manifest,archive_sha256=hashlib.sha256((out/'published-source.tar').read_bytes()).hexdigest())
(out/'published-source.json').write_text(json.dumps(body,indent=2)+'\n')
print(len(manifest),(out/'published-source.tar').stat().st_size)
