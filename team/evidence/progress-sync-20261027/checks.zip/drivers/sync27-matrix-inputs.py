from pathlib import Path
import json,subprocess,zipfile,hashlib
repo=Path.cwd(); out=repo/'team/out/sync-20261027'
archive=repo/'team/optimizations/o2/r2-vector-accum/evidence/firstdot-v1/matrix-archive'
original=json.loads((out/'published-source.json').read_bytes())
manifest=json.loads((archive/'archive-manifest.json').read_bytes())
extra={}
with zipfile.ZipFile(out/'matrix-inputs.zip','x',compression=zipfile.ZIP_STORED) as z:
 for p in archive.rglob('*'):
  if p.is_file():z.writestr('archive/'+p.relative_to(archive).as_posix(),p.read_bytes())
 for row in manifest['files']:
  name=row['stored']
  if not name.startswith('files/tools/'):continue
  rel=name.removeprefix('files/tools/')
  if row['encoding']=='gzip':rel=rel.removesuffix('.gz')
  if rel in original['files']:continue
  data=subprocess.check_output(['git','show',original['revision']+':'+rel])
  assert hashlib.sha256(data).hexdigest()==row['raw_sha256'],rel
  z.writestr('extra/'+rel,data);extra[rel]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
(out/'matrix-inputs.json').write_text(json.dumps(dict(revision=original['revision'],extra_source_files=extra,archive_sha256=hashlib.sha256((out/'matrix-inputs.zip').read_bytes()).hexdigest()),indent=2)+'\n')
print('extra',len(extra),'zip',(out/'matrix-inputs.zip').stat().st_size)
