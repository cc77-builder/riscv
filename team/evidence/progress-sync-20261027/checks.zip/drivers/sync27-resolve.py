from pathlib import Path
import re

root=Path(__file__).resolve().parents[2]
pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/zufan\n',re.M|re.S)
for name,mode in [('.gitattributes','both'),('开发计分板.md','both'),
                  ('team/docs/development-route-current.md','upstream'),('team/optimizations/o4/README.md','upstream')]:
    path=root/name
    body=path.read_text(encoding='utf-8')
    assert len(pattern.findall(body))==1,name
    body=pattern.sub(lambda m:m[1]+m[2] if mode=='both' else m[2],body)
    path.write_text(body,encoding='utf-8',newline='\n')
path=root/'AGENTS.md'
body=path.read_text(encoding='utf-8')
assert body.startswith('> 本地 James_Hotten 接续（2026-10-23）')
path.write_text(body[body.index('# 项目开发指南'):],encoding='utf-8',newline='\n')
path=root/'team/progress.md'
path.write_text('''# 工程进度入口

当前进度和下一步统一维护在[当前开发路线](docs/development-route-current.md)，逐轮成果见[开发计分板](../开发计分板.md)，软件使用见[firstdot V2](optimizations/o2/r2-select/FIRSTDOT_STABLE.md)。

2026-10-27 整理：已移除本页重复的旧“当前进度”和已完成待办，包括2026-10-21的G3缺项及后续重复推进计划。旧正文可由Git提交 `a669af780` 的本文件追溯；原始结果、失败证据与回退合同保留在各模块。不要按旧正文重新启动任务。
''',encoding='utf-8',newline='\n')
path=root/'team/docs/development-route-current.md'
body=path.read_text(encoding='utf-8')
marker='## 1. 当前从哪里出发'
note='> James_Hotten 同步边界（2026-10-27）：已并入团队 `zufan` 的 `431938271` 及此前50个新增提交。本地bc9/e66的G3补充验收与firstdot旧探针作为独立历史证据保留，不能与T17/ff840的完整C调用资格混用。旧“补firstdot dataset1/2”队列已撤下，采用本页完整上游进度。O1/O2生产默认关闭；最新norm认领与运行保护以协作Issue为准，本次不接管。\n\n'
assert body.count(marker)==1
path.write_text(body.replace(marker,note+marker),encoding='utf-8',newline='\n')
path=root/'team/optimizations/o2/r2-first-dot/README.md'
body=path.read_text(encoding='utf-8')
notice='> 已封存的本地8×32/dataset0探针（2026-10-27）：其bc9/e66身份与原始合同继续保留用于追溯，不再作为活动开发队列。上游已完成独立完整矩阵及[firstdot V2源包](../r2-select/FIRSTDOT_STABLE.md)；后续按[当前路线](../../../docs/development-route-current.md)执行，不重复本页五次运行或旧dataset扩展计划。\n\n'
path.write_text(notice+body,encoding='utf-8',newline='\n')
path=root/'team/docs/latest-integration-20261023.md'
body=path.read_text(encoding='utf-8')
notice='> 本文件保留2026-10-23/24本机整合的历史记录，文中的“下一步”仅描述当时状态。2026-10-27已同步后续50个提交，旧firstdot扩数据集计划退役；当前任务和稳定入口以[开发路线](development-route-current.md)为准。历史负控/G3数据保持原身份。\n\n'
path.write_text(notice+body,encoding='utf-8',newline='\n')
path=root/'team/optimizations/o4/README.md'
body=path.read_text(encoding='utf-8')
body=body.replace('以下为2026-10-20原O4评估的历史边界与结果，后续资格按',
                  '原O4硬件不包含James分支后来加入的DIV取消时钟修复，旧面积/时序不转授当前源码。以下为2026-10-20原O4评估的历史边界与结果，后续资格按')
path.write_text(body,encoding='utf-8',newline='\n')
print('Resolved five merge conflicts; retired superseded active progress.')
