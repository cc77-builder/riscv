from pathlib import Path
import copy,gzip,hashlib,importlib.util,json,os,subprocess,time
repo=Path('/mnt/c/Code/RVInno/riscv')
root=Path('/home/amesotten/.cache/codex-rvinno/sync-progress-20261027')
out=root/'current-checks';out.mkdir(exist_ok=False)
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2])
steps=[]
for label,args in [('build-profiles',['-m','unittest','discover','-s',str(repo/'team/optimizations/o2/fullcore'),'-p','test_build_profiles.py','-v'])]:
    with (out/(label+'.stdout.log')).open('xb') as stdout,(out/(label+'.stderr.log')).open('xb') as stderr:
        p=subprocess.run(['python3','-B',*args],stdout=stdout,stderr=stderr)
    steps.append(dict(name=label,exit_code=p.returncode,command=['python3','-B',*args]));assert p.returncode==0
module=repo/'team/optimizations/o2/r2-select'
spec=importlib.util.spec_from_file_location('stable_v2',module/'verify_firstdot_stable.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
manifest=v.read(module/'FIRSTDOT_STABLE_MANIFEST.json')
for name,sha in manifest['input_sha256'].items():assert v.sha(repo/name)==sha,name
identity=v.read(repo/v.IDENTITY)
v.hardware_identity(manifest,identity)
controls=[]
for field in ('source_commit','emu_sha256','reference_sha256'):
    changed=copy.deepcopy(manifest);changed['hardware'][field]='0'*64
    controls.append((field,changed))
for name,value in [('missing',None),('list',[]),('extra',dict(manifest['hardware'],extra=True)),
                   ('no-emu',{k:x for k,x in manifest['hardware'].items() if k!='emu_sha256'})]:
    changed=copy.deepcopy(manifest)
    if value is None:changed.pop('hardware')
    else:changed['hardware']=value
    controls.append((name,changed))
for name,changed in controls:
    try:v.hardware_identity(changed,identity)
    except ValueError:pass
    else:raise AssertionError(name)
(out/'v2-identity.json').write_text(json.dumps(dict(status='V2_SOURCE_PINS_AND_HARDWARE_CONTROLS_PASS',
    input_files=len(manifest['input_sha256']),rejected_controls=[n for n,_ in controls],new_builds=0,new_emu_runs=0),indent=2)+'\n')
evidence=repo/'team/evidence/stage1-current-20261025'
fixture=out/'stage1-fixture';fixture.mkdir()
for name in ('emulator-output.log','emulator-stderr.log','run.json'):
    path=evidence/'production-run'/name
    data=path.read_bytes() if path.exists() else gzip.decompress(path.with_name(name+'.gz').read_bytes())
    (fixture/name).write_bytes(data)
argv=['python3','-B',str(repo/'team/tests/test-stage1-tools.py'),'--run',str(fixture),
      '--wave',str(evidence/'wave/wave.json'),'--output',str(out/'stage1-tests')]
with (out/'stage1.stdout.log').open('xb') as stdout,(out/'stage1.stderr.log').open('xb') as stderr:
    p=subprocess.run(argv,stdout=stdout,stderr=stderr)
steps.append(dict(name='stage1',exit_code=p.returncode,command=argv))
(out/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
assert p.returncode==0
print('Current build profiles, V2 identity and stage1 checks passed.')
