"""Read-only independent review; outputs only in this operation's runtime directory."""
from pathlib import Path
import collections,datetime,hashlib,json,os,re,subprocess,zipfile
ROOT=Path(r'D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan')
BACKUP=Path(r'D:\Projects\daily\codex\diagnostics\xiangshan-consolidation-20261025')
OUT=Path(r'D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runtime-space-20261025-0510')
GIT=r'D:\Programs\Git\cmd\git.exe'
PINS=json.loads(r'''{"final-validation.json":"f93494cdefa00db70590bdd31f6f1b829cd24e1fec7afd4745f11d6fe9c7087b","plan.json":"ca41df56f5c6cbc7cadd152e23038dec78ddb850dea1026826a545d13efc0b3a","archive-integrity.json":"03c19f79a47d646cfba26c84c1ef064f21605a15e573f6b5a6d8e7c18c6dcaa5","orphan-objects-preserved.json":"0786a729c254450edff8925ffbf6699a8176bea0d2cea54f7261fd620d08b22d","git-fsck-final.txt":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","preservation-verified.json":"0aeca10e616d476207175c5e6c72bce42359a4177cf92860371508fba5c3755e","restore.py":"f257e65f5c592f617ba13e5db14fdb9295152addb852a104dd3b32d11d16b8c9","post-handoff-validation.json":"6247d3f90949047a04ac61720de90a7e377ea8135bc2fe7b9174b4f251e180ff","scoreboard-append.json":"d8c1888214da23afb4bd37ed3c208b2051fe17c4f59829a29ab7e34c4f092db2","working-r2s2-fixed-20261024-0001-restore-verified.json":"0e6fc3470ab99d922924319e66a361c85479819b8725c7f2f3e510c1a585d7a5","working-r2s2-fixed-20261024-0001-deleted.json":"ff97096ad3d9be6b4c99915ae1f0bb838c2743823185e2f9175300452f0f3aa8","preserve.py":"24c0867bb165d5f3c0b080f34e2d9b425a1c76116694d3ce4be6da2c55a746f7","audit.py":"5ee857bd7175d18bbf99e58e9eaab7380543299b47acdf5f54685b185605b858"}''')
ENV={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0'}
GIT_ENV_KEYS=('GIT_DIR','GIT_COMMON_DIR','GIT_WORK_TREE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_INDEX_FILE')
assert not any(ENV.get(k) for k in GIT_ENV_KEYS),'Unexpected Git environment override'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def read(name):return json.loads((BACKUP/name).read_text(encoding='utf-8-sig'))
def git(path,*args,bare=False):
 command=[GIT,'--no-optional-locks','-c','gc.auto=0','-c','maintenance.auto=false','-c','core.quotePath=true']
 command+=['--git-dir='+str(path)] if bare else ['-C',str(path)]
 command+=list(args)
 r=subprocess.run(command,capture_output=True,env=ENV,timeout=180)
 assert r.returncode==0,(command,r.returncode,r.stderr.decode(errors='replace')[-2000:])
 return r.stdout.decode('utf8',errors='strict')
assert not (OUT/'windows-review-02.json').exists()
for name,h in PINS.items():assert sha(BACKUP/name)==h,('input changed',name)
plan=read('plan.json');final=read('final-validation.json');post=read('post-handoff-validation.json')
integrity=read('archive-integrity.json');pres=read('preservation-verified.json')
assert len(plan['remove'])==17 and len(plan['keep'])==5 and len(set(plan['remove']))==17
assert set(plan['remove']).isdisjoint(plan['keep'])
for rel,h in integrity.items():
 p=(BACKUP/rel).resolve()
 assert p.is_relative_to(BACKUP.resolve()) and p.is_file(),rel
 assert sha(p)==h,('integrity mismatch',rel)
print('INTEGRITY',len(integrity),flush=True)
recovery=BACKUP/'recovery.git'
assert not (recovery/'objects/info/alternates').exists(),'recovery must be self-contained'
objects=git(recovery,'cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)',bare=True).splitlines()
otypes=dict(line.split() for line in objects)
assert len(otypes)==pres['git_objects']
refs=dict((ref,oid) for oid,ref in (line.split(' ',1) for line in git(recovery,'for-each-ref','--format=%(objectname) %(refname)',bare=True).splitlines()))
orphans=read('orphan-objects-preserved.json')
for _,kind,oid in orphans:
 assert otypes[oid]==kind and refs['refs/recovered-orphans/'+oid]==oid
assert set(x.removeprefix('refs/recovered-orphans/') for x in refs if x.startswith('refs/recovered-orphans/'))=={r[2] for r in orphans}
fsck=git(recovery,'fsck','--full','--no-reflogs',bare=True)
(OUT/'windows-review-02-fsck.txt').write_text(fsck,encoding='utf8')
print('GIT',len(otypes),'objects',len(refs),'refs',flush=True)
cases=[];work_refs=0;all_refs=0
with zipfile.ZipFile(BACKUP/'files.zip') as z:
 infos=z.infolist();assert len(infos)==len({x.filename for x in infos})==pres['raw_blobs']
 sizes={x.filename:x.file_size for x in infos}
 for entry in infos:
  assert re.fullmatch('[0-9a-f]{64}',entry.filename)
  h=hashlib.sha256()
  with z.open(entry) as f:
   for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
  assert h.hexdigest()==entry.filename,entry.filename
 print('ZIP',len(infos),'members verified',flush=True)
 for name in plan['remove']:
  assert not (ROOT/name).exists(),('deleted source present',name)
  m=read(name+'-manifest.json');rest=read(name+'-restore-verified.json');deleted=read(name+'-deleted.json')
  assert m['name']==name and rest['name']==name and deleted['name']==name
  assert otypes[m['head']]=='commit' and refs['refs/heads/saved/'+name]==m['head']
  assert rest['head']==m['head'] and rest['head_status_staged_unstaged_and_all_raw_bytes']=='PASS'
  assert deleted['status']=='DELETED_AND_ABSENT'
  for line in m['refs'].splitlines():
   oid,ref=line.split();assert refs['refs/preserved/'+name+'/'+ref.removeprefix('refs/')]==oid
  seen=set();counts=collections.Counter()
  for e in m['files']:
   assert e['kind'] in ('work','git','common')
   rel=Path(e['path']);assert not rel.is_absolute() and '..' not in rel.parts
   key=(e['kind'],e['path']);assert key not in seen;seen.add(key)
   assert sizes[e['sha256']]==e['bytes']
   counts[e['kind']]+=1
  assert counts['work']==rest['raw_files']
  index=next(e for e in m['files'] if e['kind']=='git' and e['path']=='index')
  copy=BACKUP/(name+'-original.index')
  if copy.exists():assert sha(copy)==index['sha256']
  all_refs+=len(m['files']);work_refs+=counts['work']
  cases.append(dict(name=name,head=m['head'],dirty=bool(m['status']),file_references=len(m['files']),
   work_files=counts['work'],original_index_in_archive=True,source_absent=True,
   original_restore_receipt_sha256=sha(BACKUP/(name+'-restore-verified.json')),
   normalization_only_paths=rest.get('normalization_only_paths'),receipt_has_normalization_field='normalization_only_paths' in rest))
current_names=sorted(p.name for p in ROOT.iterdir() if p.is_dir() and (p/'.git').exists())
assert set(current_names)==set(plan['keep']),current_names
post_by_name={r['name']:r for r in post['retained']}
kept=[]
for name in plan['keep']:
 p=ROOT/name
 head=git(p,'rev-parse','HEAD').strip();branch=git(p,'branch','--show-current').strip()
 status=git(p,'status','--porcelain=v1','-uall').splitlines()
 assert head==post_by_name[name]['head'] and branch==post_by_name[name]['branch'],name
 assert status==post_by_name[name]['status'],(name,'status changed',status)
 gd=git(p,'rev-parse','--absolute-git-dir').strip()
 common=git(p,'rev-parse','--path-format=absolute','--git-common-dir').strip()
 al=Path(common)/'objects/info/alternates'
 links=al.read_text().splitlines() if al.exists() else []
 for a in links:
  target=(Path(common)/'objects'/a).resolve() if not Path(a).is_absolute() else Path(a).resolve()
  assert target.is_dir() and not any(target.is_relative_to((ROOT/n).resolve()) for n in plan['remove'])
 kept.append(dict(name=name,head=head,branch=branch,status=status,git_dir=gd,common_dir=common,alternates=links))
append=read('scoreboard-append.json')
assert sha(Path(append['path']))==append['after_sha256']
board=Path(append['path']).read_bytes()
assert hashlib.sha256(board[:-append['appended_bytes']]).hexdigest()==append['before_sha256']
for name,h in PINS.items():assert sha(BACKUP/name)==h,('input changed during review',name)
backup_bytes=sum(p.stat().st_size for p in BACKUP.rglob('*') if p.is_file())
assert final['source_logical_bytes']==plan['source_bytes']
assert final['logical_net_reclaimed']==final['source_logical_bytes']-final['backup_and_evidence_bytes']
report=dict(status='PASS',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 operation_id='20261025-LiZufan001-space-0510',input_pins=PINS,integrity_entries_verified=len(integrity),
 zip_members_verified=len(infos),manifest_file_references=all_refs,manifest_work_file_references=work_refs,
 git_objects_verified=len(otypes),git_types=dict(collections.Counter(otypes.values())),
 git_refs_verified=len(refs),orphan_refs_verified=len(orphans),orphan_types=dict(collections.Counter(r[1] for r in orphans)),
 recovery_has_alternates=False,git_environment={k:ENV.get(k) for k in GIT_ENV_KEYS},git_fsck='PASS',cases=cases,retained=kept,actual_top_level_git_checkouts=current_names,
 external_final_measurement={k:final[k] for k in ('at','source_logical_bytes','backup_and_evidence_bytes','logical_net_reclaimed','free_before','free_after','observed_free_increase')},
 backup_logical_bytes_at_review=backup_bytes,review_time_logical_net=plan['source_bytes']-backup_bytes,
 r3_external_scoreboard_append_verified=True,
 scope='Independent current-file SHA256, ZIP member contents, manifest coverage, refs/types/fsck, path absence and retained identity/status review. Existing 17 actual restore receipts reviewed; no new checkout restoration performed.',
 preservation='No modifications to the external archive or retained repositories; no delete, gc, prune, repack, fetch or push.')
dest=OUT/'windows-review-02.json';dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:report[k] for k in ('status','recorded_at','integrity_entries_verified','zip_members_verified','manifest_file_references','git_objects_verified','git_refs_verified','orphan_refs_verified','backup_logical_bytes_at_review','review_time_logical_net')},indent=2))
print('report_sha256',sha(dest))
