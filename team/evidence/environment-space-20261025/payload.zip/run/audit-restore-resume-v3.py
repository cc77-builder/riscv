#!/usr/bin/env python3
"""Complete seven-source preservation using source-01's real v2 proof and six v3 restorations."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,shutil,zipfile
if not __debug__:raise RuntimeError('Python optimization not allowed')
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
BACKUP=WIN/'retained-audit-checkouts-01';HELPER=BACKUP/'restore-v3.py'
HELPER_SHA='958a5ecad5f9f38635917719d1f2168fcd67bfb58346a4bdd71a9e5eb147eec5'
V2_PROOF_SHA='fb2de7151a84d2213c8b91b260b76018efed348fcc93b1e83496785671a733dc'
def require(v,msg):
 if not v:raise RuntimeError(msg)
require(hashlib.sha256(HELPER.read_bytes()).hexdigest()==HELPER_SHA,'restore-v3 helper pin')
spec=importlib.util.spec_from_file_location('audit_restore_v3',HELPER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.environment_gate();manifest=m.verified_manifest(BACKUP/'manifest.json')
profile=m.verified_profile(BACKUP/'normalization-profile.json',manifest)
payload=m.verify_payload(BACKUP/'payload.zip',manifest)
roots=[Path(s['original_path']).resolve(strict=True) for s in manifest['sources']]
new=OUT/'audit-restore-validation-03'
require(not new.exists() and not new.is_symlink(),'new restore output exists')
require(all(not new.resolve().is_relative_to(p) and not p.is_relative_to(new.resolve()) for p in roots),'temporary overlap')
new.mkdir()
def save_both(name,obj):
 a=m.save(OUT/name,obj);b=m.save(WIN/name,obj);require(a==b,'receipt bytes');return a
v2path=OUT/'audit-restore-v2-source-01.json'
require(m.sha(v2path)==V2_PROOF_SHA and m.sha(WIN/v2path.name)==V2_PROOF_SHA,'source-01 v2 proof pin')
v2=json.loads(v2path.read_text());require(v2['id']=='source-01' and v2['status']=='PASS_EXACT_BYTES_AND_GIT_RESTORATION_V2','source-01 prior result')
first=manifest['sources'][0];first_rechecked=m.verify_tree(Path(first['original_path']),first['entries'],physical=True)
require(not (OUT/'audit-restore-validation-01/source-01').exists(),'source-01 temporary already expected removed')
for name in ('audit-restore-v2-cleanup-journal-01.jsonl',):
 with (WIN/name).open('xb') as f:f.write((OUT/name).read_bytes())
save_both('audit-restore-v3-start-01.json',dict(recorded_at=m.now(),contract='audit-checkout-restore-v3-profiled-stat-differences',helper_sha256=HELPER_SHA,payload=payload,profile_sha256=m.PROFILE_SHA,source_01_prior_v2_proof_sha256=V2_PROOF_SHA,originals_removed=False,earlier_failures_preserved=True))
results=[dict(id='source-01',entries=v2['entries'],version='v2',status=v2['status'],status_equivalence=v2['status_equivalence']['kind'],proof_sha256=V2_PROOF_SHA,original_entries_rechecked=first_rechecked,temporary_removed=True,reexecuted=False)]
negative=[];journal=(OUT/'audit-restore-v3-cleanup-journal-01.jsonl').open('x')
def event(obj):
 journal.write(json.dumps(obj)+'\n');journal.flush();os.fsync(journal.fileno())
with zipfile.ZipFile(BACKUP/'payload.zip') as z:
 for source in manifest['sources'][1:]:
  original=Path(source['original_path']);before=m.verify_tree(original,source['entries'],physical=True)
  if source['id']=='source-02':
   root=OUT/'audit-restore-validation-02/source-02';require(root.exists(),'prior source-02 actual restore absent')
   origin='v2 actual restoration reused; v2 unregistered binary status failure retained'
  else:
   root=new/source['id'];m.restore(root,source['entries'],z);origin='new v3 actual restoration'
  identity=root.lstat();proof=m.verify_restored(root,source,profile)
  if source['id']=='source-02':
   status=proof['git_status'];base_lines=source['preflight']['records']['status']['stdout'].splitlines()
   new_lines=[x for x in status['stdout'].splitlines() if x not in set(base_lines)]
   require(len(new_lines)==2 and base_lines,'source-02 expected two diagnosed additions')
   for label in ('unknown-source','wrong-head','wrong-original-path','extra-unrelated-status','duplicate-profiled-status','removed-existing-status'):
    badsource=copy.deepcopy(source);badstatus=copy.deepcopy(status)
    if label=='unknown-source':badsource['id']='source-unknown'
    elif label=='wrong-head':badsource['preflight']['records']['head']['stdout']='0'*40+'\n'
    elif label=='wrong-original-path':badsource['original_path']+='-unrelated'
    elif label=='extra-unrelated-status':badstatus['stdout']+=' M unrelated-file\n'
    elif label=='duplicate-profiled-status':badstatus['stdout']+=new_lines[0]+'\n'
    elif label=='removed-existing-status':
     changed=badstatus['stdout'].splitlines();changed.remove(base_lines[0]);badstatus['stdout']='\n'.join(changed)+'\n'
    try:m.status_equivalence(root,badsource,badstatus,profile)
    except RuntimeError as e:negative.append(dict(case=label,status='REJECTED',reason=str(e)))
    else:raise RuntimeError('negative accepted: '+label)
   save_both('audit-restore-v3-negatives-01.json',dict(recorded_at=m.now(),cases=negative,scope='Profile identity, unrelated/duplicate additions, and missing existing status; source/index/attributes untouched'))
  after=m.verify_tree(original,source['entries'],physical=True)
  current=m.git(original,'status','--porcelain=v1','-uall')
  require(current['exit_code']==0 and current['stdout']==source['preflight']['records']['status']['stdout'],'original status changed')
  proof.update(original_entries_before=before,original_entries_after=after,restoration_origin=origin,helper_sha256=HELPER_SHA,original_status_unchanged=True)
  digest=save_both('audit-restore-v3-'+source['id']+'.json',proof)
  require(root.resolve(strict=True)==root and not root.is_symlink(),'temporary canonical identity')
  require(root.parent in (OUT/'audit-restore-validation-02',new) and root.name==source['id'],'temporary parent/id')
  require(all(not root.is_relative_to(p) and not p.is_relative_to(root) for p in roots),'temporary overlaps original')
  cur=root.lstat();require(cur.st_dev==identity.st_dev and cur.st_ino==identity.st_ino,'temporary inode changed')
  event(dict(recorded_at=m.now(),action='remove_verified_temporary_copy_intent',path=str(root),proof_sha256=digest,originals_removed=False))
  shutil.rmtree(root);require(not root.exists(),'temporary remains')
  event(dict(recorded_at=m.now(),action='removed_verified_temporary_copy',path=str(root),originals_removed=False))
  results.append(dict(id=source['id'],entries=proof['entries'],version='v3',status=proof['status'],status_equivalence=proof['status_equivalence']['kind'],added_status_count=proof['status_equivalence']['added_count'],proof_sha256=digest,temporary_removed=True,reexecuted=False))
  print(json.dumps(dict(event='restoration_v3_pass',source=source['id'],entries=proof['entries'],added_status_count=proof['status_equivalence']['added_count'],temporary_removed=True)),flush=True)
journal.close()
with (WIN/'audit-restore-v3-cleanup-journal-01.jsonl').open('xb') as f:f.write((OUT/'audit-restore-v3-cleanup-journal-01.jsonl').read_bytes())
require(all(p.is_dir() for p in roots),'original unexpectedly absent')
summary=dict(recorded_at=m.now(),status='READY_FOR_RETIREMENT_REVIEW_NOT_EXECUTED',contract='one-real-v2-proof-plus-six-real-v3-proofs',source_count=7,restored_sources=len(results),sources=results,source_allocated_bytes=sum(s['preflight']['allocated_bytes'] for s in manifest['sources']),source_regular_logical_bytes=sum(r.get('bytes',0) for s in manifest['sources'] for r in s['entries']),archive_bytes=(BACKUP/'payload.zip').stat().st_size,manifest_bytes=(BACKUP/'manifest.json').stat().st_size,helper_bytes=HELPER.stat().st_size,profile_bytes=(BACKUP/'normalization-profile.json').stat().st_size,archive_sha256=m.ARCHIVE_SHA,manifest_sha256=m.MANIFEST_SHA,helper_sha256=HELPER_SHA,profile_sha256=m.PROFILE_SHA,unique_members=manifest['unique_members'],unique_raw_bytes=manifest['unique_raw_bytes'],originals_removed=False,all_originals_unchanged=True,temporary_copies_removed=7,negative_cases=negative,earlier_failures_preserved=True,source_paths=[s['original_path'] for s in manifest['sources']],qualification='Exact source/Git bytes and listed metadata, complete fsck. Recorded finite stat/attribute differences. source-01 retains actual v2 qualification; source-02..07 actual v3. No new build/EMU qualification and no original retirement permission.')
save_both('audit-backup-preparation-result-03.json',summary)
print(json.dumps(summary,indent=2),flush=True)

