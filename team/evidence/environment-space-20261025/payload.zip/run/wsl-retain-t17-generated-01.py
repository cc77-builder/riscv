#!/usr/bin/env python3
from pathlib import Path
if not __debug__:raise RuntimeError('Python optimization is not allowed')
import datetime,hashlib,json,os,stat,time,zipfile
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
OLD=Path('/home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/source/build/emu-compile')
DEST=WIN/'retained-t17-generated-01'
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
 return d.hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def emit(name,obj):
 data=(json.dumps(obj,indent=2)+'\n').encode()
 for root in (OUT,WIN):
  with (root/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return sha(OUT/name)
proof=json.loads((OUT/'t17-regeneration-comparison-01.json').read_text())
assert proof['passed'] is False and proof['exit_code']==-15 and proof['timed_out'] is True
assert proof['changed_inputs']==[] and all(x['regenerated_sha256'] is None for x in proof['comparison'])
rows=json.loads((OUT/'t17-generated-before-01.json').read_text())['files'];assert len(rows)==324
assert not DEST.exists();DEST.mkdir()
for row in rows:
 p=Path(row['path']);s=p.lstat()
 assert p.parent==OLD and p.suffix in ('.cpp','.h') and p.name==row['name']
 assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and p.resolve()==p
 assert s.st_size==row['bytes'] and sha(p)==row['sha256']
archive=DEST/'t17-generated-cpp-h.zip';t=time.monotonic()
emit('t17-cache-archive-start-01.json',dict(recorded_at=now(),source_directory=str(OLD),archive_path=str(archive),member_count=len(rows),source_manifest_sha256=sha(OUT/'t17-generated-before-01.json'),failed_regeneration_sha256=sha(OUT/'t17-regeneration-comparison-01.json'),method='lossless retention of generated cache; no claim of Verilator regeneration PASS'))
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for row in rows:z.write(row['path'],arcname=row['name'])
with archive.open('rb') as f:os.fsync(f.fileno())
compared=[]
with zipfile.ZipFile(archive,'r') as z:
 names=z.namelist();assert len(names)==len(set(names))==324 and set(names)=={x['name'] for x in rows}
 for row in rows:
  zi=z.getinfo(row['name']);assert zi.file_size==row['bytes'] and not zi.is_dir()
  d=hashlib.sha256();count=0
  with z.open(zi) as f:
   for b in iter(lambda:f.read(1024*1024),b''):d.update(b);count+=len(b)
  assert count==row['bytes'] and d.hexdigest()==row['sha256']
  assert sha(row['path'])==row['sha256'],'original changed'
  compared.append(dict(name=row['name'],bytes=count,sha256=d.hexdigest()))
report=dict(recorded_at=now(),status='PASS_LOSSLESS_CACHE_RETENTION',archive_path=str(archive),archive_windows_path='D:\\Projects\\competitions\\2026-10-CIE-RISCV-XiangShan\\runtime-space-20261025-0510\\retained-t17-generated-01\\t17-generated-cpp-h.zip',archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,raw_bytes=sum(x['bytes'] for x in rows),member_count=len(rows),members=rows,compared=compared,seconds=time.monotonic()-t,source_before_sha256=sha(OUT/'t17-generated-before-01.json'),source_preserved=True,regeneration_passed=False,retention_rule='Keep archive and this manifest as recovery inputs. This receipt proves lossless decompression, not a new Verilator or EMU qualification.')
data=(json.dumps(report,indent=2)+'\n').encode()
with (DEST/'manifest.json').open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
emit('t17-cache-archive-manifest-01.json',report)
print(json.dumps({k:v for k,v in report.items() if k not in ('members','compared')},indent=2))
