$ErrorActionPreference='Stop'
$drive=[ordered]@{recorded_at=[DateTime]::UtcNow.ToString('o');free_bytes=(Get-PSDrive D).Free;used_bytes=(Get-PSDrive D).Used;attributable_to_this_operation=$false}
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json,shutil
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326')
out=Path('/home/lizufan/riscv-lab/space-20261025-0510')
proof=out/'cleanup-proof-02.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(proof)=='01c4f507c71cb7977cbbe290917b4da162202cce0ee0b2a9c6749d2b4521c601'
d=json.loads(proof.read_text())
for row in d['protected_files']+d['targets']:
 p=Path(row['path'])
 assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
assert not (out/'cleanup-state-01.json').exists()
assert sha(root/'campaign-01.json')==d['campaign_sha256']
report=dict(status='VERIFIED_NO_DELETE',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 operation_id='20261025-LiZufan001-space-0510',proof_sha256=sha(proof),
 candidate_files=6,candidate_logical_bytes=d['target_logical_bytes'],candidate_allocated_bytes=d['target_allocated_bytes'],
 protected_files_unchanged=702,targets_unchanged=6,state_file_exists=False,
 native_deleted_files=0,native_reclaimed_bytes=0,windows_deleted_files=0,windows_reclaimed_bytes=0,
 attempts=[
 dict(operation_id='1bcd341bbd2162e3d9e297ccd2678ca0.cce033996ad359129ddc20955de74dce',exit_code=1,stage='pre-unlink process occupancy guard',unreadable_pid=351),
 dict(operation_id='1bcd341bbd2162e3d9e297ccd2678ca0.966111890bfd55e1b2f8ca9fb0d818cd',exit_code=1,stage='pre-unlink process occupancy guard',unreadable_pid=341)],
 decision='Retain six caches and stop this bounded cleanup attempt. Original process guard was not weakened. No further deletion attempts planned in this round.',
 filesystem_after=dict(zip(('total','used','free'),shutil.disk_usage(root))),
 other_windows_cleanup='User-reported completed external Windows cleanup; independent review in progress in a separate report.',
 git_operations='No gc, prune, object relocation, donor removal or Windows copy deletion.')
dest=out/'cleanup-after-01.json';assert not dest.exists()
dest.write_text(json.dumps(report,indent=2)+'\n')
win=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')/dest.name
assert not win.exists();win.write_bytes(dest.read_bytes())
print(json.dumps(report,indent=2))
print('sha256',sha(dest))
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$p='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runtime-space-20261025-0510\windows-after-01.json'
if(Test-Path -LiteralPath $p){throw 'new observation output required'}
[System.IO.File]::WriteAllText($p,($drive|ConvertTo-Json)+[Environment]::NewLine,(New-Object System.Text.UTF8Encoding($false)))
$drive|ConvertTo-Json