#!/usr/bin/env python3
"""One-use cleanup with lossless retained C++ archive; regeneration timeout preserved."""
from pathlib import Path
if not __debug__:
 raise RuntimeError('Safety checks require Python without -O/PYTHONOPTIMIZE')
import collections, datetime, hashlib, json, os, stat, subprocess, zipfile
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
T17=Path('/home/lizufan/riscv-lab/t17-clean-20261024-0854')
OLD=T17/'clean-02/source/build/emu-compile'
HOIST=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326')
SUFFIXES={'.o','.d','.gch','.a','.cpp','.h'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
 return d.hexdigest()
def emit(name,obj):
 data=(json.dumps(obj,indent=2)+'\n').encode()
 for root in (OUT,WIN):
  with (root/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return sha(OUT/name)
def load(name,digest=None):
 p=OUT/name
 if digest:assert sha(p)==digest,name
 return json.loads(p.read_text())
def info(p):
 s=p.lstat()
 assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and p.resolve()==p,str(p)
 return dict(path=str(p),bytes=s.st_size,allocated_bytes=s.st_blocks*512,mode=s.st_mode,links=s.st_nlink,device=s.st_dev,inode=s.st_ino,mtime_ns=s.st_mtime_ns,sha256=sha(p))
def fs():
 s=os.statvfs(OUT)
 return dict(recorded_at=now(),block_size=s.f_frsize,total_bytes=s.f_blocks*s.f_frsize,free_bytes=s.f_bfree*s.f_frsize,available_bytes=s.f_bavail*s.f_frsize,used_bytes=(s.f_blocks-s.f_bfree)*s.f_frsize)
def proc_guard():
 uid=os.getuid();rows={};heavy=[];disappeared=[]
 heavy_names={'emu','verilator_bin','verilator_bin_dbg','java','javac','yosys','sta','opensta','make','gmake','cc1plus','cc1','clang++','g++','c++'}
 for d in Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:
   fields={a:b.strip() for a,b in (x.split(':',1) for x in (d/'status').read_text().splitlines() if ':' in x)}
   name=fields['Name'];pid=int(d.name)
   if name in heavy_names:heavy.append(dict(pid=pid,comm=name,uid=fields['Uid']))
   if int(fields['Uid'].split()[0])!=uid:continue
   tail=(d/'stat').read_text().rsplit(')',1)[1].split()
   r=dict(pid=pid,comm=name,ppid=int(fields['PPid']),uids=fields['Uid'].split(),start_ticks=int(tail[19]),cgroup=(d/'cgroup').read_text(),errors={},fd_links=[])
   try:r['argv']=[v.decode(errors='replace') for v in (d/'cmdline').read_bytes().split(b'\0') if v]
   except OSError as e:r['errors']['argv']=str(e)
   for key in ('cwd','exe'):
    try:r[key]=os.readlink(d/key)
    except OSError as e:r['errors'][key]=str(e)
   try:
    for p in (d/'fd').iterdir():
     try:r['fd_links'].append(os.readlink(p))
     except FileNotFoundError:pass
     except OSError as e:r['errors']['fd-'+p.name]=str(e)
   except OSError as e:r['errors']['fd']=str(e)
   try:
    maps=(d/'maps').read_text()
    r['mapped_target_lines']=[x for x in maps.splitlines() if str(OLD) in x or str(HOIST) in x]
   except OSError as e:r['errors']['maps']=str(e)
   rows[pid]=r
  except FileNotFoundError:disappeared.append(int(d.name))
 ancestors=set();pid=os.getpid()
 while pid in rows and pid not in ancestors:ancestors.add(pid);pid=rows[pid]['ppid']
 blockers=[];helpers=[]
 unit=Path('/usr/lib/systemd/system/user@.service').read_text()
 assert '\nUser=%i\n' in unit and '\nPAMName=systemd-user\n' in unit and '\nExecStart=/lib/systemd/systemd --user\n' in unit
 expected_cgroup='0::/user.slice/user-'+str(uid)+'.slice/user@'+str(uid)+'.service/init.scope\n'
 for pid,r in rows.items():
  if pid in ancestors:r['classification']='this inspection or its ancestors';continue
  parent=rows.get(r['ppid'],{})
  helper=(r['comm']=='(sd-pam)' and r.get('argv')==['(sd-pam)']
    and r['uids']==[str(uid)]*4 and parent.get('comm')=='systemd'
    and parent.get('ppid')==1 and parent.get('uids')==[str(uid)]*4
    and parent.get('exe')=='/usr/lib/systemd/systemd'
    and parent.get('argv')==['/lib/systemd/systemd','--user']
    and r['cgroup']==expected_cgroup and parent.get('cgroup')==expected_cgroup)
  observed=json.dumps({k:r.get(k) for k in ('argv','cwd','exe','fd_links','mapped_target_lines')})
  relevant=str(OLD) in observed or str(HOIST) in observed
  if helper and not relevant:
   r['classification']='identified systemd PAM session helper; protected proc fields not read'
   helpers.append(dict(pid=pid,start_ticks=r['start_ticks'],parent_pid=r['ppid'],parent_start_ticks=parent['start_ticks'],unreadable_fields=r['errors']))
   continue
  if r['errors'] or relevant:blockers.append(dict(pid=pid,unreadable=r['errors'],target_related=relevant))
  r['classification']='blocker' if (r['errors'] or relevant) else 'readable, no target relation observed'
 # Bind classification to these instances, not a reusable PID allowlist.
 for pid,r in rows.items():
  if pid in ancestors:continue
  p=Path('/proc')/str(pid)
  try:assert int((p/'stat').read_text().rsplit(')',1)[1].split()[19])==r['start_ticks'],'PID reused'
  except FileNotFoundError:pass
 result=dict(recorded_at=now(),self_pid=os.getpid(),ancestors=sorted(ancestors),same_uid_processes=list(rows.values()),identified_pam_helpers=helpers,heavy_processes=heavy,blockers=blockers,disappeared=disappeared,unit_sha256=sha('/usr/lib/systemd/system/user@.service'),systemd_sha256=sha('/usr/lib/systemd/systemd'),scope='Current permission; no elevation; inaccessible helper fd/maps not inspected; not a global handle proof')
 assert not blockers and not heavy,json.dumps(dict(blockers=blockers,heavy=heavy))
 return result
assert not (OUT/'wsl-large-cleanup-start-01.json').exists(),'never replay a started mutation'
review=load('wsl-cache-review-01.json','d47f24318b93c000a54929854ed6da388a6072c0a4a1f2ab110812400e3bad2d')
regen=load('t17-regeneration-comparison-01.json','ae07a11c47ead1009c8e76e2036f2ec4dc440d952b8c2b622a052ce29bd9d1b1')
assert regen['passed'] is False and regen['timed_out'] is True and regen['changed_inputs']==[]
retention=load('t17-cache-archive-manifest-01.json','30bc3521614873922d89d11aa96d9b06a0f538b7adacc382bdd7b0b9edff87d6')
assert retention['status']=='PASS_LOSSLESS_CACHE_RETENTION' and retention['member_count']==324
archive=WIN/'retained-t17-generated-01/t17-generated-cpp-h.zip'
assert str(archive)==retention['archive_path'] and sha(archive)==retention['archive_sha256']
generated=load('t17-generated-before-01.json',retention['source_before_sha256'])['files']
assert len(generated)==324 and generated==retention['members']
restore_checks=[]
with zipfile.ZipFile(archive) as z:
 names=z.namelist()
 assert len(names)==len(set(names))==324 and set(names)=={x['name'] for x in generated}
 for row in generated:
  assert Path(row['name']).name==row['name'] and row['name'] not in ('.','..')
  member=z.getinfo(row['name']);assert member.file_size==row['bytes'] and not member.is_dir()
  d=hashlib.sha256();count=0
  with z.open(member) as f:
   for chunk in iter(lambda:f.read(1024*1024),b''):d.update(chunk);count+=len(chunk)
  assert d.hexdigest()==row['sha256'] and count==row['bytes']
  restore_checks.append(dict(name=row['name'],bytes=count,sha256=d.hexdigest()))
assert len(review['candidates'])==708
oldproof=load('cleanup-proof-02.json','01c4f507c71cb7977cbbe290917b4da162202cce0ee0b2a9c6749d2b4521c601')
assert oldproof['status']=='SIX_DISASSEMBLY_CACHES_REGENERATED_BYTE_EXACT' and len(oldproof['targets'])==6
assert {x['path'] for x in oldproof['targets']}=={str(HOIST/('build-'+k+'-01')/'vdot-perf.txt') for k in ('b4','h4','h0','h1','h2','h3')}
assert all(x['byte_equal'] and x['generator_exit_code']==0 and x['archive_excludes_target'] for x in oldproof['targets'])
candidates=[]
for old in review['candidates']+generated+oldproof['targets']:
 p=Path(old['path'])
 if p.parent==OLD:assert p.suffix in SUFFIXES
 else:assert p.name=='vdot-perf.txt' and p.parent.parent==HOIST
 cur=info(p)
 for key in ('bytes','sha256'):assert cur[key]==old[key],str(p)+' changed '+key
 for key in ('device','inode','mtime_ns'):
  if key in old:assert cur[key]==old[key],str(p)+' changed '+key
 candidates.append(cur)
paths={x['path'] for x in candidates};assert len(paths)==1038
assert {str(p) for p in OLD.iterdir() if p.suffix in SUFFIXES}=={p for p in paths if Path(p).parent==OLD}
protected=load('t17-regeneration-inputs-01.json','090567c856899f1dd1e8fc7522be9cf6194d529e89363be731d6bef4ee0be447')['inputs']
protected[str(archive)]=retention['archive_sha256']
protected[str(archive.parent/'manifest.json')]=sha(OUT/'t17-cache-archive-manifest-01.json')
assert sha(archive.parent/'manifest.json')==protected[str(archive.parent/'manifest.json')]
for x in oldproof['protected_files']:protected[x['path']]=x['sha256']
for x in oldproof['targets']:
 protected[x['generator_argv'][0]]=x['tool_sha256'];protected[x['generator_argv'][2]]=x['elf_sha256']
for p in OLD.iterdir():
 if str(p) not in paths:protected[str(p)]=sha(p)
identity=json.loads((T17/'identity-02.json').read_text())
refroot=Path(identity['configuration']['reference']).parent.parent
nemu_deps=list((refroot/'build').rglob('*.d'));assert nemu_deps,'reference dependency provenance missing'
for p in nemu_deps+[refroot/'.config',refroot/'build/vdot-provenance.json']:
 assert p.is_file(),str(p);protected[str(p)]=sha(p)
am=Path(identity['configuration']['am_home'])
for p in [am/'am/build/am-riscv64-xs.a',am/'libs/klib/build/klib-riscv64-xs.a',Path('/home/lizufan/riscv-lab/t04-current-20261025-0054/trace/build/emu')]:
 assert p.is_file(),str(p);protected[str(p)]=sha(p)
assert not paths.intersection(protected)
for p,d in protected.items():assert sha(p)==d,'protected precheck '+p
# Actual protection/occupancy check after expensive hashing, immediately before deletion.
processes=proc_guard()
groups=collections.defaultdict(lambda:dict(count=0,logical_bytes=0,allocated_bytes=0))
for row in candidates:
 key=('t17'+Path(row['path']).suffix) if Path(row['path']).parent==OLD else 'hoisted_disassembly'
 g=groups[key];g['count']+=1;g['logical_bytes']+=row['bytes'];g['allocated_bytes']+=row['allocated_bytes']
plan=dict(recorded_at=now(),contract='space-exact-cache-retention-v3',operation_id='20261025-LiZufan001-space-0510',candidates=candidates,groups=dict(groups),protected=protected,protected_count=len(protected),protected_intersection=[],proofs={n:sha(OUT/n) for n in ('wsl-cache-review-01.json','t17-generated-before-01.json','t17-regeneration-comparison-01.json','t17-regeneration-inputs-01.json','cleanup-proof-02.json','t17-cache-archive-manifest-01.json')},lossless_restore_recheck=restore_checks,process_guard=processes,filesystem_before=fs())
emit('wsl-large-cleanup-plan-01.json',plan)
emit('wsl-large-cleanup-start-01.json',dict(recorded_at=now(),status='STARTED_DO_NOT_REPLAY',plan_sha256=sha(OUT/'wsl-large-cleanup-plan-01.json'),target_count=len(candidates),script_sha256=sha(__file__)))
deleted=[]
try:
 with (OUT/'wsl-large-cleanup-journal-01.jsonl').open('x') as journal:
  def journal_entry(row):
   journal.write(json.dumps(row)+'\n');journal.flush();os.fsync(journal.fileno())
  for row in candidates:
   p=Path(row['path']);cur=info(p)
   for key in ('bytes','sha256','device','inode','mtime_ns'):assert cur[key]==row[key],'changed before unlink '+str(p)
   journal_entry(dict(event='intent',path=str(p),sha256=row['sha256']))
   p.unlink();assert not p.exists()
   deleted.append(str(p));journal_entry(dict(event='deleted',path=str(p)))
 # No change to old contracts or evidence; rehash every physical protected item.
 changed=[p for p,d in protected.items() if sha(p)!=d]
 remaining=[p for p in paths if Path(p).exists()]
 assert not changed and not remaining
 report=dict(recorded_at=now(),status='PASS_EXACT_CACHE_CLEANUP',deleted_count=len(deleted),deleted_logical_bytes=sum(x['bytes'] for x in candidates),deleted_allocated_bytes=sum(x['allocated_bytes'] for x in candidates),groups=dict(groups),protected_count=len(protected),protected_changed=changed,remaining_targets=remaining,filesystem_before=plan['filesystem_before'],filesystem_after=fs(),retained_emu_compile_names=[p.name for p in sorted(OLD.iterdir())],plan_sha256=sha(OUT/'wsl-large-cleanup-plan-01.json'),journal_sha256=sha(OUT/'wsl-large-cleanup-journal-01.jsonl'),historical_zero_delete_phase_preserved=True,retained_archive_windows_path=retention['archive_windows_path'],retained_archive_bytes=retention['archive_bytes'],retained_archive_sha256=retention['archive_sha256'],cross_filesystem_logical_net_bytes=sum(x['bytes'] for x in candidates)-retention['archive_bytes'],regeneration_passed=False)
 emit('wsl-large-cleanup-result-01.json',report)
 with (WIN/'wsl-large-cleanup-journal-01.jsonl').open('xb') as f:f.write((OUT/'wsl-large-cleanup-journal-01.jsonl').read_bytes())
 print(json.dumps(report,indent=2))
except BaseException as e:
 emit('wsl-large-cleanup-failure-01.json',dict(recorded_at=now(),status='FAILED_DO_NOT_REPLAY',error=repr(e),deleted_paths=deleted,filesystem=fs()))
 raise
