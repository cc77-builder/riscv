#!/usr/bin/env python3
"""Read-only, complete regular-index profile of raw versus Git-filtered blob identities."""
from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess
if not __debug__:raise RuntimeError('Python optimization not allowed')
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
MANIFEST=WIN/'retained-audit-checkouts-01/manifest.json'
MANIFEST_SHA='87311d16105e03cff7f839307b7caeb3b20f4ee72370a308f0f31d70fb689af4'
def require(v,msg):
 if not v:raise RuntimeError(msg)
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def git(root,args,data=None):
 env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0';env['GIT_NO_LAZY_FETCH']='1';env['GIT_TERMINAL_PROMPT']='0'
 p=subprocess.run(['git','--no-optional-locks','-C',str(root),*args],env=env,input=data,capture_output=True)
 require(p.returncode==0,'Git failed: '+str(args)+' '+p.stderr.decode(errors='replace'))
 return p.stdout
def save_both(name,obj):
 data=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
 for root in (OUT,WIN):
  with (root/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return hashlib.sha256(data).hexdigest()
os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:4]))
require(not any(os.environ.get(k) for k in ('GIT_DIR','GIT_COMMON_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_CONFIG','GIT_CONFIG_COUNT','GIT_CONFIG_PARAMETERS')),'Git environment override')
require(sha(MANIFEST)==MANIFEST_SHA,'manifest pin')
manifest=json.loads(MANIFEST.read_text());sources=[];full=[]
for source in manifest['sources']:
 root=Path(source['original_path']);pinned=source['preflight']
 require(git(root,['rev-parse','HEAD']).decode()==pinned['records']['head']['stdout'],'HEAD changed')
 require(git(root,['status','--porcelain=v1','-uall']).decode()==pinned['records']['status']['stdout'],'status changed')
 bypath={r['path']:r for r in source['entries']};rows=[];excluded=[]
 index_raw=git(root,['ls-files','--stage','-z'])
 for entry in index_raw.rstrip(b'\0').split(b'\0'):
  if not entry:continue
  meta,name=entry.split(b'\t',1);mode,oid,stage=meta.decode().split();rel=name.decode('utf-8');p=root/rel
  if stage!='0':excluded.append(dict(path=rel,reason='nonzero-index-stage',stage=stage));continue
  if mode not in ('100644','100755'):excluded.append(dict(path=rel,reason='symlink-gitlink-or-other-mode',mode=mode));continue
  if not p.exists():excluded.append(dict(path=rel,reason='missing-working-file'));continue
  require(not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode),'unexpected regular-index file type')
  require('\n' not in rel and '\r' not in rel and not rel.startswith('"'),'cannot represent --stdin-paths unambiguously')
  require(rel in bypath and bypath[rel]['kind']=='file' and sha(p)==bypath[rel]['sha256'],'source byte change')
  rows.append(dict(path=rel,mode=mode,index_oid=oid,raw_sha256=bypath[rel]['sha256'],bytes=bypath[rel]['bytes']))
 paths=[r['path'] for r in rows]
 attrs_bytes=git(root,['check-attr','--all','-z','--stdin'],b''.join(p.encode()+b'\0' for p in paths))
 parts=attrs_bytes.rstrip(b'\0').split(b'\0') if attrs_bytes else []
 require(len(parts)%3==0,'attribute triplets')
 attributes={p:{} for p in paths}
 for i in range(0,len(parts),3):
  path,key,value=[x.decode('utf-8') for x in parts[i:i+3]];attributes[path][key]=value
 for path,a in attributes.items():
  require(a.get('filter') in (None,'unset','unspecified'),'external filter is outside read-only profile contract: '+path)
 cached_bytes=git(root,['check-attr','--cached','--all','-z','--stdin'],b''.join(p.encode()+b'\0' for p in paths))
 cached_parts=cached_bytes.rstrip(b'\0').split(b'\0') if cached_bytes else []
 require(len(cached_parts)%3==0,'cached attribute triplets')
 cached_attributes={p:{} for p in paths}
 for i in range(0,len(cached_parts),3):
  path,key,value=[x.decode('utf-8') for x in cached_parts[i:i+3]];cached_attributes[path][key]=value
 for path,a in cached_attributes.items():
  require(a.get('filter') in (None,'unset','unspecified'),'cached external filter is outside read-only profile contract: '+path)
 raw=git(root,['hash-object','--no-filters','--stdin-paths'],(''.join(p+'\n' for p in paths)).encode()).decode().splitlines()
 filtered=git(root,['hash-object','--stdin-paths'],(''.join(p+'\n' for p in paths)).encode()).decode().splitlines()
 require(len(raw)==len(filtered)==len(rows),'hash output count')
 candidates=[];existing_differences=0
 for row,r,f in zip(rows,raw,filtered):
  row.update(raw_oid=r,filtered_oid=f,attributes=attributes[row['path']],cached_attributes=cached_attributes[row['path']])
  if r==row['index_oid'] and f!=r:
   require(row['path'].isascii() and not any(c in row['path'] for c in '"\\\t'),'candidate needs separate porcelain quoting review')
   candidates.append(row)
  if r!=row['index_oid']:existing_differences+=1
 profile=dict(id=source['id'],original_path=str(root),head=pinned['records']['head']['stdout'].strip(),index_sha256=sha(root/'.git/index'),regular_index_files_profiled=len(rows),excluded_modes_or_missing=excluded,raw_not_equal_index_count=existing_differences,candidates=candidates,external_filters_present=False,ls_files_stage_sha256=hashlib.sha256(index_raw).hexdigest())
 sources.append(profile);full.append(dict(id=source['id'],all_regular_rows=rows,profile=profile))
 print(json.dumps(dict(event='profiled',id=source['id'],regular_files=len(rows),excluded=len(excluded),potential_filtered_status_paths=[x['path'] for x in candidates])),flush=True)
full_sha=save_both('audit-normalization-full-01.json',dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_sha256=MANIFEST_SHA,sources=full,originals_modified=False))
report=dict(contract='audit-normalization-profile-v1',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_sha256=MANIFEST_SHA,full_scan_sha256=full_sha,sources=sources,originals_modified=False,scope='All existing ordinary stage-0 index files; external filters forbidden. Only raw==index and filtered!=index paths are candidate additions. Other modes/missing files retain strict status matching.')
profile_sha=save_both('audit-normalization-profile-01.json',report)
print(json.dumps(dict(profile_sha256=profile_sha,full_scan_sha256=full_sha,source_count=len(sources),regular_files_profiled=sum(s['regular_index_files_profiled'] for s in sources),potential_path_occurrences=sum(len(s['candidates']) for s in sources)),indent=2),flush=True)

