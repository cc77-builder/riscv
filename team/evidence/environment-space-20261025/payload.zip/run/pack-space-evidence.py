#!/usr/bin/env python3
"""Seal existing R0 evidence only; never restore, delete, run Git or modify sources."""
import hashlib, json, os, stat, zipfile
from datetime import datetime, timezone
from pathlib import Path

WBASE=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan')
RUN=WBASE/'runtime-space-20261025-0510'
NATIVE=Path('/home/lizufan/riscv-lab/space-20261025-0510')
EXTERNAL=Path('/mnt/d/Projects/daily/codex/diagnostics/xiangshan-consolidation-20261025')
OUT=WBASE/'working-r2s3-hoisted-20261025-0326/team/evidence/environment-space-20261025'
RESULT=RUN/'space-package-result-01.json'
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
need(__debug__,'optimized Python forbidden')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def dump_new(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def winpath(p):
    s=str(p)
    return 'D:'+s.removeprefix('/mnt/d').replace('/','\\') if s.startswith('/mnt/d/') else s
need(OUT.is_dir(),'documentation output directory must already exist')
for p in [OUT/'payload.zip',OUT/'manifest.json',RESULT]:
    need(not p.exists() and not p.is_symlink(),'new output required: '+str(p))
sources={}
def add(p,name):
    need(name not in sources,'duplicate member '+name)
    need(not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode),'regular input required '+str(p))
    need(not name.startswith('/') and '..' not in Path(name).parts,'unsafe member name')
    sources[name]=p
for p in sorted(RUN.iterdir()):
    if p.is_file() and not p.is_symlink() and p.name!='space-package-result-01.json':
        need(p.suffix in {'.json','.jsonl','.py','.ps1','.log','.txt'},'unreviewed runtime extension '+p.name)
        add(p,'run/'+p.name)
for p in sorted(NATIVE.iterdir()):
    if p.is_file() and not (RUN/p.name).exists():
        need(p.suffix in {'.json','.jsonl','.log','.txt'},'unreviewed native-only input '+p.name)
        add(p,'native-only/'+p.name)
for folder,names in [
    ('retained-audit-checkouts-01',['manifest.json','restore.py','restore-v3.py','normalization-profile.json']),
    ('retained-t17-generated-01',['manifest.json','restore.py'])
]:
    for n in names: add(RUN/folder/n,folder+'/'+n)
external_names=['archive-integrity.json','plan.json','audit.json','final-validation.json',
'post-handoff-validation.json','preservation-verified.json','orphan-objects-preserved.json',
'scoreboard-append.json','restore.py','preserve.py','audit.py','final_audit.py',
'git-fsck.txt','git-fsck-final.txt','恢复与清理结果.txt']
for n in external_names: add(EXTERNAL/n,'external-windows/'+n)
for suffix in ['-restore-verified.json','-deleted.json','-predelete.json']:
    matches=sorted(EXTERNAL.glob('*'+suffix))
    need(len(matches)==17,'expected seventeen external '+suffix)
    for p in matches: add(p,'external-windows/'+p.name)

pins={
 'run/audit-backup-preparation-result-03.json':'e8d07843ef3c22f268aa954e5547bb7b329c4e6f676b98d6681c303815e8c687',
 'run/host-allocation-final-01.json':'30a3a5cd20674b504856abc876f3cb54ab809d8aa8e064b9c35d8b80af0e3244',
 'run/current-attribute-after-01.json':'1f9d5edb0db8553d167682c31c34aad6ac60aa894d45235957ffcd35e7d9bafe',
 'run/wsl-retirement-readiness-final-01.json':'a609ed159554ded3a7f8e405178f83cbac334b40bb6837642ae19098d3acd2a2',
 'run/wsl-large-cleanup-result-01.json':'b8f2100eb039ac32645418571723103124fd7a977b71890979a9c21cc07ebbce',
 'retained-audit-checkouts-01/manifest.json':'87311d16105e03cff7f839307b7caeb3b20f4ee72370a308f0f31d70fb689af4',
 'retained-audit-checkouts-01/restore-v3.py':'958a5ecad5f9f38635917719d1f2168fcd67bfb58346a4bdd71a9e5eb147eec5',
 'retained-audit-checkouts-01/normalization-profile.json':'521323f64962642af0b397ac7cbd500687e82a9e5cf42f0c5b15f02acf8bd736'
}
rows=[]
with zipfile.ZipFile(OUT/'payload.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    for name,p in sorted(sources.items()):
        before=p.stat()
        h=hashlib.sha256();count=0
        zi=zipfile.ZipInfo(name,date_time=(2026,10,24,23,0,0))
        zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=(stat.S_IFREG|0o644)<<16
        with p.open('rb') as f,z.open(zi,'w',force_zip64=True) as o:
            for b in iter(lambda:f.read(1024*1024),b''):
                o.write(b);h.update(b);count+=len(b)
        after=p.stat()
        need((before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino),'input changed '+name)
        need(count==before.st_size,'short input '+name)
        digest=h.hexdigest()
        if name in pins: need(digest==pins[name],'fixed input pin mismatch '+name)
        rows.append({'path':name,'bytes':count,'sha256':digest,'source_path':winpath(p)})
byname={r['path']:r for r in rows}
need(set(pins)<=set(byname),'missing fixed inputs')
with zipfile.ZipFile(OUT/'payload.zip') as z:
    need(len(z.namelist())==len(rows) and set(z.namelist())==set(byname),'archive membership mismatch')
    for name in z.namelist():
        h=hashlib.sha256();n=0
        with z.open(name) as f:
            for b in iter(lambda:f.read(1024*1024),b''):h.update(b);n+=len(b)
        need(n==byname[name]['bytes'] and h.hexdigest()==byname[name]['sha256'],'archive mismatch '+name)
external_integrity=json.loads((EXTERNAL/'archive-integrity.json').read_text(encoding='utf-8-sig'))
need(external_integrity['files.zip']=='60689a86978c907641afd5191cc52d6cf6ba0800427cea629c0eb6d139606b17','external archive identity changed')
audit_result=json.loads((RUN/'audit-backup-preparation-result-03.json').read_text())
need(audit_result['originals_removed'] is False and audit_result['all_originals_unchanged'] is True,'unexpected audit outcome')
large_dependencies=[
 {'role':'seven_full_audit_checkouts','root':winpath(RUN/'retained-audit-checkouts-01'),
  'payload':'payload.zip','bytes':1173334644,'sha256':'5d479fae7c94bf54fc27ce975a7a96098eb3f6bb2287812fd9e7bfd301ca901d',
  'required_metadata_members':['retained-audit-checkouts-01/'+n for n in ['manifest.json','restore-v3.py','normalization-profile.json']],
  'historical_helper_member':'retained-audit-checkouts-01/restore.py',
  'validation_basis':'original full streamed payload hash and seven actual restores; not rerun by this packaging operation'},
 {'role':'t17_generated_cpp_h','root':winpath(RUN/'retained-t17-generated-01'),
  'payload':'t17-generated-cpp-h.zip','bytes':27472009,'sha256':'d7027b4bf97082eaaa13baa295d712fe5d8c2dcf52ddf72254752978fcf501b8',
  'required_metadata_members':['retained-t17-generated-01/manifest.json','retained-t17-generated-01/restore.py'],
  'validation_basis':'original complete ZIP verification before precise deletion and actual default helper verification'},
 {'role':'external_windows_recovery','root':winpath(EXTERNAL),
  'payload':'files.zip','bytes':(EXTERNAL/'files.zip').stat().st_size,
  'sha256':external_integrity['files.zip'],'other_required_tree':'recovery.git',
  'identity_index_member':'external-windows/archive-integrity.json',
  'restoration_inputs':'Keep the entire external root, including its original per-checkout manifests, original indexes and scripts; not all are duplicated in this Git package.',
  'validation_basis':'root independent windows-review-02 audited all 364 indexed files, streamed 14210 payloads, Git objects/refs and a new fsck'}
]
for d in large_dependencies:
    path=Path('/mnt/d'+d['root'][2:].replace('\\','/'))/d['payload']
    need(path.is_file() and path.stat().st_size==d['bytes'],'external payload size changed')
manifest={
 'schema':'xiangshan-space-evidence-v1','operation_id':'20261025-LiZufan001-space-0510',
 'base_commit':'e301a360d21a0a942882921f8b481c81eff1e478',
 'created_at':datetime.now(timezone.utc).isoformat(),'archive':'payload.zip',
 'archive_bytes':(OUT/'payload.zip').stat().st_size,'archive_sha256':sha(OUT/'payload.zip'),
 'member_count':len(rows),'member_bytes':sum(r['bytes'] for r in rows),'members':rows,
 'verification':'every member streamed, exact name set/size/SHA-256 PASS',
 'external_dependencies':large_dependencies,
 'status':{
   'windows_external_review':'PASS; root did not reexecute the external seventeen restores',
   'wsl_precise_cleanup':'1038 files deleted; 26064 protected SHA values unchanged',
   'audit_checkouts':'READY_FOR_RETIREMENT_REVIEW_NOT_EXECUTED',
   'audit_actual_restore_proofs':'one prior v2 plus six final v3; source02 used existing unpacked copy',
   'original_seven_removed':False,'t17_regeneration':'TIMEOUT; not PASS',
   'vhd_compaction_shutdown_config_change':False,
   'new_rtl_function_performance_ppa_qualification':False
 },
 'scope_note':'Exact original evidence bytes except explicitly labelled structured host receipt captures. No official program changes. Full recovery payloads and Windows recovery.git remain external. The package is not a stand-alone source recovery archive.'
}
dump_new(OUT/'manifest.json',manifest)
receipt={'status':'SPACE_EVIDENCE_SEAL_PASS','at':datetime.now(timezone.utc).isoformat(),
'member_count':len(rows),'member_bytes':manifest['member_bytes'],'archive_bytes':manifest['archive_bytes'],
'archive_sha256':manifest['archive_sha256'],'manifest_sha256':sha(OUT/'manifest.json'),
'source_mutations':0,'originals_deleted':0,'external_payloads_repacked':0}
dump_new(RESULT,receipt)
print(json.dumps(receipt,ensure_ascii=False))
