#!/usr/bin/env python3
"""One-use T17 generated-C++ reconstruction proof; never edits original inputs."""
from pathlib import Path
import datetime, hashlib, json, os, shlex, signal, stat, subprocess, time
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
T17=Path('/home/lizufan/riscv-lab/t17-clean-20261024-0854')
SRC=T17/'clean-02/source'
OLD=SRC/'build/emu-compile'
NEW=OUT/'t17-regenerated-01'
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
 return d.hexdigest()
def record(name,obj):
 data=(json.dumps(obj,indent=2)+'\n').encode()
 p=OUT/name
 with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 w=WIN/name
 with w.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return sha(p)
def timestamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not NEW.exists()
assert sha(T17/'build-01/emu-build.log')=='7a735de54bbc652378a23bd46789d17d12b19a0ed1aeb02b2963cb2187deb253'
assert sha(SRC/'build/emu')=='ff840528eb1009e94906eefb3773ca321050f309553543ab26f0db23c410e30f'
state=json.loads((T17/'build-01/build-state.json').read_text())
assert state['status']=='T17_CLEAN_BUILD_PASS' and state['build_exit_code']==0
lines=(T17/'build-01/emu-build.log').read_text().splitlines()
matches=[(i+1,s) for i,s in enumerate(lines) if ' verilator --exe ' in s and ' -Mdir ' in s]
assert len(matches)==1
line_no,line=matches[0]
original=shlex.split(line); start=original.index('verilator');argv=original[start:]
assert argv.count('-Mdir')==1 and argv.count('-o')==1
assert argv[argv.index('-Mdir')+1]==str(OLD)
assert argv[argv.index('-o')+1]==str(SRC/'build/emu')
assert not any(x in argv for x in ('--build','--binary','--main','--hierarchical'))
tool=Path('/home/lizufan/riscv-tools/verilator-5.052/bin/verilator')
bin_tool=Path('/home/lizufan/riscv-tools/verilator-5.052/bin/verilator_bin')
assert tool.is_file() and bin_tool.is_file()
argv[0]=str(tool);argv[argv.index('-Mdir')+1]=str(NEW)
# shlex intentionally does not perform shell variable expansion. Preserve make
# placeholders exactly as literal text, matching the original generated Makefile.
argv=[x.replace('\\$', '$') for x in argv]
env=os.environ.copy();env['VERILATOR_ROOT']='/home/lizufan/riscv-tools/verilator-5.052/share/verilator'
env['OMP_NUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1'
affinity=sorted(os.sched_getaffinity(0))[:4];os.sched_setaffinity(0,affinity)
version=subprocess.run([str(tool),'--version'],env=env,capture_output=True,text=True,check=True).stdout
assert '5.052' in version
before=[]
for p in sorted(OLD.iterdir()):
 if p.suffix not in ('.cpp','.h'):continue
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and p.resolve()==p
 with p.open('rb') as f:head=f.read(200)
 assert b'Verilated' in head, str(p)
 before.append(dict(path=str(p),name=p.name,bytes=s.st_size,allocated_bytes=s.st_blocks*512,device=s.st_dev,inode=s.st_ino,mode=s.st_mode,links=s.st_nlink,mtime_ns=s.st_mtime_ns,sha256=sha(p)))
assert len(before)==324
generated=json.loads((T17/'build-01/generated-artifacts.json').read_text())
trace=json.loads(Path('/home/lizufan/riscv-lab/t04-current-20261025-0054/evidence/trace-inputs.json').read_text())
protected={str(SRC/x['path']) for x in generated}
protected.update(str(Path(base)/rel) for base in (trace['source'],trace['trace_root']) for rel in trace['copied_inputs'])
assert not ({x['path'] for x in before}&protected)
pins=json.loads((T17/'build-01/hardware-inputs.json').read_text())
inputs={}
for key in ('files','dependency_files'):
 for rel,digest in pins[key].items():inputs[str(SRC/rel)]=digest
for x in generated:inputs[str(SRC/x['path'])]=x['sha256']
for base in (trace['source'],trace['trace_root']):
 for rel,digest in trace['copied_inputs'].items():inputs[str(Path(base)/rel)]=digest
identity=json.loads((T17/'identity-02.json').read_text())
for rel,digest in identity['metadata_sha256'].items():inputs[str(T17/'build-01'/rel)]=digest
for key in ('reference','flash'):
 inputs[identity['configuration'][key]]=identity[key+'_sha256']
for p in (SRC/'build/constantin.txt',SRC/'build/plusArgs',tool,bin_tool):
 inputs[str(p)]=sha(p)
for path,digest in inputs.items():assert sha(path)==digest, 'input mismatch '+path
record('t17-regeneration-inputs-01.json',dict(recorded_at=timestamp(),inputs=inputs))
record('t17-generated-before-01.json',dict(recorded_at=timestamp(),files=before))
NEW.mkdir()
record('t17-regeneration-start-01.json',dict(recorded_at=timestamp(),cwd=str(SRC/'difftest'),source_log=str(T17/'build-01/emu-build.log'),source_line=line_no,original_shell_line=line,argv=argv,environment={k:env[k] for k in ('VERILATOR_ROOT','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS')},cpu_affinity=affinity,tools={str(tool):sha(tool),str(bin_tool):sha(bin_tool)},version=version,original_files=324,protected_input_count=len(inputs),old_directory=str(OLD),new_directory=str(NEW),no_build=True))
t=time.monotonic()
with (OUT/'t17-regeneration-01.stdout.log').open('xb') as so,(OUT/'t17-regeneration-01.stderr.log').open('xb') as se:
 proc=subprocess.Popen(argv,cwd=SRC/'difftest',env=env,stdout=so,stderr=se,start_new_session=True)
 record('t17-regeneration-process-01.json',dict(recorded_at=timestamp(),pid=proc.pid,parent_pid=os.getpid(),argv=argv,cpu_affinity=affinity))
 timed_out=False
 try:rc=proc.wait(timeout=240)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(proc.pid,signal.SIGTERM)
  try:rc=proc.wait(timeout=10)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait(timeout=10)
elapsed=time.monotonic()-t
comparison=[]
for row in before:
 p=NEW/row['name']
 got=sha(p) if p.is_file() else None
 comparison.append(dict(name=row['name'],bytes=row['bytes'],original_sha256=row['sha256'],regenerated_sha256=got,match=got==row['sha256']))
mismatches=[x for x in comparison if not x['match']]
changed=[p for p,d in inputs.items() if sha(p)!=d]
result=dict(recorded_at=timestamp(),exit_code=rc,timed_out=timed_out,seconds=elapsed,comparison=comparison,mismatches=mismatches,changed_inputs=changed,passed=rc==0 and not mismatches and not changed,original_untouched=True,new_generated_duplicates_removed=False)
record('t17-regeneration-comparison-01.json',result)
# Only remove newly-created byte-exact duplicate outputs after the proof is durable.
# No old emu-compile file is changed by this script.
if result['passed']:
 removed=[]
 for row in before:
  p=NEW/row['name'];assert p.is_file() and not p.is_symlink() and sha(p)==row['sha256']
  p.unlink();removed.append(row['name'])
 record('t17-regeneration-temp-clean-01.json',dict(recorded_at=timestamp(),directory=str(NEW),removed_names=removed,removed_count=len(removed),proof_sha256=sha(OUT/'t17-regeneration-comparison-01.json'),retained_names=[p.name for p in sorted(NEW.iterdir())]))
print(json.dumps(dict(exit_code=rc,seconds=elapsed,passed=result['passed'],compared=len(comparison),mismatches=len(mismatches),changed_inputs=len(changed),protected_inputs=len(inputs),original_untouched=True),indent=2))
raise SystemExit(0 if result['passed'] else 1)
