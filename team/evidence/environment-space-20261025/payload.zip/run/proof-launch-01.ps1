$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326')
out=Path('/home/lizufan/riscv-lab/space-20261025-0510')
labels=('b4','h4','h0','h1','h2','h3')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
meta=lambda p:dict(bytes=p.stat().st_size,sha256=sha(p))
target_report=out/'cleanup-proof-01.json';assert not target_report.exists()
campaign=read(root/'campaign-01.json')
assert campaign['status']=='COMPLETE' and campaign['active_command'] is None and campaign['active_pid'] is None and campaign['new_emu_runs']==18
protected=[];rows=[]
for label in labels:
 build=root/('build-'+label+'-01');run=root/('run-'+label+'-01');archive=root/('archive-'+label+'-01')
 state=read(run/'state.json')
 assert state['status']=='CALLER_CAMPAIGN_PASS' and state['active_pid'] is None and state['active_result'] is None
 manifest=read(archive/'archive-manifest.json')
 paths=[r['path'] for r in manifest['files']]
 assert 'build/vdot-perf.txt' not in paths
 for item in manifest['files']:
  rel=Path(item['path']);assert rel.parts[0] in ('build','run')
  p=(build if rel.parts[0]=='build' else run).joinpath(*rel.parts[1:])
  assert not p.is_symlink() and meta(p)=={k:item[k] for k in ('bytes','sha256')},str(p)
  protected.append(dict(path=str(p),**meta(p)))
 for p in sorted(archive.iterdir()):
  assert p.is_file() and not p.is_symlink()
  protected.append(dict(path=str(p),**meta(p)))
 record=read(build/'build.json')
 assert set(record['artifacts'])=={'vdot-perf.elf','vdot-perf.bin','gemv-reference.o'}
 for name,pin in record['artifacts'].items():assert sha(build/name)==pin
 tool=Path(record['toolchain']['objdump']['path']);assert sha(tool)==record['toolchain']['objdump']['sha256']
 target=build/'vdot-perf.txt';assert target.resolve()==target
 for p in (target,*target.parents):
  assert not p.is_symlink()
 st=target.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
 elf=build/'vdot-perf.elf'
 expected_line=str(tool)+' -d '+str(elf)+' > '+str(target)
 log=(build/'make-command/stdout.log').read_text()
 assert expected_line in log,expected_line
 argv=[str(tool),'-d',str(elf)]
 result=subprocess.run(argv,cwd=build/'source',stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 original=target.read_bytes()
 if result.returncode or result.stdout!=original:
  (out/('failed-'+label+'-stdout.log')).write_bytes(result.stdout)
  (out/('failed-'+label+'-stderr.log')).write_bytes(result.stderr)
  raise RuntimeError('regeneration differs: '+label)
 rows.append(dict(label=label,path=str(target),bytes=len(original),allocated_bytes=st.st_blocks*512,sha256=sha(target),
  generator_argv=argv,generator_cwd=str(build/'source'),generator_stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),generator_stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),generator_exit_code=result.returncode,byte_equal=True,
  tool_sha256=sha(tool),elf_sha256=sha(elf),archive_excludes_target=True,make_stdout_sha256=sha(build/'make-command/stdout.log')))
for row in protected:assert meta(Path(row['path']))=={k:row[k] for k in ('bytes','sha256')}
report=dict(status='SIX_DISASSEMBLY_CACHES_REGENERATED_BYTE_EXACT',operation_id='20261025-LiZufan001-space-0510',
 recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),campaign_sha256=sha(root/'campaign-01.json'),
 target_count=len(rows),target_logical_bytes=sum(r['bytes'] for r in rows),target_allocated_bytes=sum(r['allocated_bytes'] for r in rows),
 targets=rows,protected_files=protected,protected_file_count=len(protected),deleted_files=0,
 scope='Only six explicit vdot-perf.txt ordinary disassembly caches; canonical no-aliases logs, ELF/BIN, reference objects, all objects/*.o/.d, R3 out, sources and Git donors retained.')
target_report.write_text(json.dumps(report,indent=2)+'\n')
win=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')/target_report.name
assert not win.exists();win.write_bytes(target_report.read_bytes())
print(json.dumps({k:report[k] for k in ('status','recorded_at','target_count','target_logical_bytes','target_allocated_bytes','protected_file_count','deleted_files')},indent=2))
print('proof_sha256',sha(target_report))
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE