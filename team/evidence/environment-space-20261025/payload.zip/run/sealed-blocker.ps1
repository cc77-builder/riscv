$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json,os
out=Path('/home/lizufan/riscv-lab/space-20261025-0510')
proof=out/'cleanup-proof-02.json'
assert hashlib.sha256(proof.read_bytes()).hexdigest()=='01c4f507c71cb7977cbbe290917b4da162202cce0ee0b2a9c6749d2b4521c601'
d=json.loads(proof.read_text())
targets=[]
for r in d['targets']:
 p=Path(r['path']);assert p.is_file() and not p.is_symlink()
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 assert h==r['sha256'] and p.stat().st_size==r['bytes']
 targets.append(dict(path=str(p),sha256=h,bytes=p.stat().st_size))
assert not (out/'cleanup-state-01.json').exists()
p=Path('/proc/351');info=dict(pid=351,exists=p.exists())
if p.exists():
 lines=(p/'status').read_text().splitlines()
 info['status']=[x for x in lines if x.startswith(('Name:','State:','PPid:','Uid:','Gid:','Threads:','NSpid:'))]
 try:
  info['command_argv0']=(p/'cmdline').read_bytes().split(b'\0')[0].decode(errors='replace')
 except OSError as e:info['cmdline_error']=str(e)
 for name in ('cwd','exe','root'):
  try:info[name]=os.readlink(p/name)
  except OSError as e:info[name+'_error']=str(e)
 try:info['fd_count']=len(list((p/'fd').iterdir()))
 except OSError as e:info['fd_error']=str(e)
report=dict(status='BLOCKED_NO_DELETE',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 operation_id='20261025-LiZufan001-space-0510',failed_operation='1bcd341bbd2162e3d9e297ccd2678ca0.cce033996ad359129ddc20955de74dce',
 failure_stage='same_uid_process_occupancy_guard_before_state_or_unlink',process=info,
 all_six_targets_unchanged=True,targets=targets,state_file_exists=False,windows_files_deleted=0,native_files_deleted=0,
 decision='Retain caches. No privilege escalation, no weakened occupancy guard, no replay.')
dest=out/'cleanup-blocker-01.json';assert not dest.exists()
dest.write_text(json.dumps(report,indent=2)+'\n')
win=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')/dest.name
assert not win.exists();win.write_bytes(dest.read_bytes())
print(json.dumps(report,indent=2))
print('sha256',hashlib.sha256(dest.read_bytes()).hexdigest())
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE