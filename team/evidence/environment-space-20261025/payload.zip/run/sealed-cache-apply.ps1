$ErrorActionPreference='Stop'
$windowsBefore=(Get-PSDrive D).Free
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json,os,shutil,stat
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326')
out=Path('/home/lizufan/riscv-lab/space-20261025-0510')
proof=out/'cleanup-proof-02.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(proof)=='01c4f507c71cb7977cbbe290917b4da162202cce0ee0b2a9c6749d2b4521c601'
data=json.loads(proof.read_text())
assert data['status']=='SIX_DISASSEMBLY_CACHES_REGENERATED_BYTE_EXACT'
expected={str(root/('build-'+label+'-01/vdot-perf.txt')) for label in ('b4','h4','h0','h1','h2','h3')}
assert {r['path'] for r in data['targets']}==expected and len(data['targets'])==6
state_path=out/'cleanup-state-01.json';assert not state_path.exists()
campaign=json.loads((root/'campaign-01.json').read_text())
assert campaign['status']=='COMPLETE' and campaign['active_pid'] is None and campaign['active_command'] is None
assert sha(root/'campaign-01.json')==data['campaign_sha256']
def verify(row):
 p=Path(row['path'])
 assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
for row in data['protected_files']:verify(row)
for row in data['targets']:
 verify(row);p=Path(row['path'])
 assert p.resolve()==p and all(not q.is_symlink() for q in p.parents)
 st=p.lstat()
 assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and st.st_blocks*512==row['allocated_bytes']
 assert row['byte_equal'] and row['generator_exit_code']==0 and row['generator_stdout_sha256']==row['sha256']
 assert sha(Path(row['generator_argv'][0]))==row['tool_sha256']
 assert sha(Path(row['generator_argv'][-1]))==row['elf_sha256']
own=set();pid=os.getpid()
while pid and pid not in own:
 own.add(pid)
 text=(Path('/proc')/str(pid)/'status').read_text()
 pid=int(next(l.split()[1] for l in text.splitlines() if l.startswith('PPid:')))
busy=[];unreadable=[];checked=0
prefixes=tuple(str(Path(p).parent) for p in expected)
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name) in own:continue
 try:
  status=(proc/'status').read_text()
  uid=int(next(l.split()[1] for l in status.splitlines() if l.startswith('Uid:')))
  if uid!=os.getuid():continue
  comm=(proc/'comm').read_text().strip()
  cmd=(proc/'cmdline').read_bytes()
  cwd=os.readlink(proc/'cwd')
  refs=[]
  for fd in (proc/'fd').iterdir():
   try:refs.append(os.readlink(fd))
   except FileNotFoundError:pass
  checked+=1
  if comm in ('emu','java','yosys','berkeley-abc','sta','cc1','cc1plus','verilator_bin') or any(cwd.startswith(p) or p.encode() in cmd or any(x.startswith(p) for x in refs) for p in prefixes):
   busy.append(dict(pid=int(proc.name),comm=comm))
 except FileNotFoundError:pass
 except PermissionError:
  if proc.exists():unreadable.append(int(proc.name))
assert not busy and not unreadable,dict(busy=busy,unreadable=unreadable)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
state=dict(status='RUNNING',operation_id=data['operation_id'],started=now(),proof_sha256=sha(proof),
 targets=[dict(**r,deleted=False) for r in data['targets']],processes_checked=checked,busy=busy,unreadable=unreadable,
 filesystem_before=dict(zip(('total','used','free'),shutil.disk_usage(root))),protected_file_count=len(data['protected_files']),
 windows_files_deleted=0,other_windows_cleanup_active=True)
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 for row in state['targets']:
  verify(row)
  Path(row['path']).unlink()
  row['deleted']=True;row['deleted_at']=now();save()
 for row in data['protected_files']:verify(row)
 assert all(not Path(r['path']).exists() for r in state['targets'])
 state.update(status='COMPLETE',finished=now(),filesystem_after=dict(zip(('total','used','free'),shutil.disk_usage(root))),
  deleted_logical_bytes=sum(r['bytes'] for r in state['targets']),deleted_allocated_bytes=sum(r['allocated_bytes'] for r in state['targets']),protected_files_unchanged=True)
 state['native_free_delta']=state['filesystem_after']['free']-state['filesystem_before']['free'];save()
except BaseException as exc:
 state.update(status='FAILED',error=repr(exc),finished=now());save();raise
win=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')/state_path.name
assert not win.exists();win.write_bytes(state_path.read_bytes())
print(json.dumps({k:state[k] for k in ('status','finished','deleted_logical_bytes','deleted_allocated_bytes','native_free_delta','protected_file_count','protected_files_unchanged','windows_files_deleted')},indent=2))
print('state_sha256',sha(state_path))
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$space=[ordered]@{recorded_at=[DateTime]::UtcNow.ToString('o');D_free_before=$windowsBefore;D_free_after=(Get-PSDrive D).Free;attributable_to_this_cleanup=$false;windows_files_deleted=0;reason='Another authorized Windows cleanup is active; WSL filesystem block release is measured separately, no VHDX compaction performed.'}
$target='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runtime-space-20261025-0510\windows-after-cache-cleanup.json'
if(Test-Path -LiteralPath $target){throw 'new measurement output required'}
[System.IO.File]::WriteAllText($target,($space|ConvertTo-Json)+[Environment]::NewLine,(New-Object System.Text.UTF8Encoding($false)))
$space|ConvertTo-Json