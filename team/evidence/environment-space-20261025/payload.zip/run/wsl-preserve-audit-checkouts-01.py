#!/usr/bin/env python3
"""Prepare, verify and restore-review seven audit checkout backups; NEVER removes originals."""
from pathlib import Path
if not __debug__:raise RuntimeError('Python optimization not allowed')
import base64,collections,concurrent.futures,datetime,hashlib,json,os,shutil,stat,subprocess,time,zipfile
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
DEST=WIN/'retained-audit-checkouts-01'
VERIFY=OUT/'audit-restore-validation-01'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def save(p,obj):
 data=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
 with Path(p).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return hashlib.sha256(data).hexdigest()
def require(v,msg):
 if not v:raise RuntimeError(msg)
def attrs(p):
 return {n:base64.b64encode(os.getxattr(p,n,follow_symlinks=False)).decode() for n in os.listxattr(p,follow_symlinks=False)}
def metadata(p,rel):
 s=p.lstat()
 require(s.st_uid==os.getuid() and s.st_gid==os.getgid(),'foreign owner/group requires separate handling: '+str(p))
 return dict(path=rel,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,xattrs=attrs(p))
def inventory(root):
 require(root.is_dir() and not root.is_symlink(),'source root is not an ordinary directory')
 rows=[dict(metadata(root,'.'),kind='directory')]
 for base,ds,fs in os.walk(root,followlinks=False):
  ds.sort();fs.sort()
  for name in ds+fs:
   p=Path(base)/name;s=p.lstat();rel=str(p.relative_to(root));r=metadata(p,rel)
   if stat.S_ISLNK(s.st_mode):r.update(kind='symlink',target=os.readlink(p))
   elif stat.S_ISDIR(s.st_mode):r.update(kind='directory')
   elif stat.S_ISREG(s.st_mode):
    require(s.st_nlink==1,'external or internal hardlink requires separate treatment: '+str(p))
    r.update(kind='file',bytes=s.st_size,allocated_bytes=s.st_blocks*512,device=s.st_dev,inode=s.st_ino)
   else:raise RuntimeError('special file: '+str(p))
   if '.git' in p.parts:
    require(not name.endswith('.lock'),'Git lock: '+str(p))
    require(not stat.S_ISLNK(s.st_mode),'Git metadata symlink: '+str(p))
   rows.append(r)
  ds[:]=[n for n in ds if not (Path(base)/n).is_symlink()]
 files=[r for r in rows if r['kind']=='file']
 def digest(r):return sha(root/r['path'])
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for row,d in zip(files,pool.map(digest,files)):row['sha256']=d
 return rows
def verify_tree(root,rows,physical=False):
 actual=inventory(root);a={r['path']:r for r in actual};b={r['path']:r for r in rows}
 require(set(a)==set(b),'path set differs: '+str(root))
 for path,old in b.items():
  keys=['kind','mode','uid','gid','xattrs','mtime_ns']
  if old['kind']=='file':keys+=['bytes','sha256','mtime_ns']
  if old['kind']=='symlink':keys+=['target']
  if physical and old['kind']=='file':keys+=['device','inode']
  for key in keys:require(a[path][key]==old[key],str(root/path)+' differs '+key)
 return len(actual)
def git(root,*args):
 e=os.environ.copy();e['GIT_OPTIONAL_LOCKS']='0'
 p=subprocess.run(['git','--no-optional-locks','-C',str(root),*args],env=e,capture_output=True)
 return dict(exit_code=p.returncode,stdout=p.stdout.decode(errors='replace'),stderr=p.stderr.decode(errors='replace'))
def independent_git(root):
 root=root.resolve(strict=True)
 for argv,expected in [(['rev-parse','--show-toplevel'],root),(['rev-parse','--absolute-git-dir'],root/'.git'),(['rev-parse','--path-format=absolute','--git-common-dir'],root/'.git')]:
  result=git(root,*argv)
  require(result['exit_code']==0 and Path(result['stdout'].strip()).resolve(strict=True)==expected,'external Git location: '+str(root)+' '+str(argv))
 require((root/'.git').is_dir() and not (root/'.git').is_symlink(),'Git directory identity')
 cw=git(root,'config','--get','core.worktree')
 require(cw['exit_code']==1 and not cw['stdout'],'core.worktree needs separate handling')
 require(not any((root/'.git').rglob('alternates')),'Git alternates appeared')
 worktrees=git(root,'worktree','list','--porcelain')
 require(worktrees['exit_code']==0 and worktrees['stdout'].count('worktree ')==1,'linked worktree dependency')
def restore(root,rows,z):
 require(not root.exists(),'restore root exists');root.mkdir()
 for r in rows:
  rel=Path(r['path'])
  require(not rel.is_absolute() and '..' not in rel.parts and (str(rel)!='.' or r['kind']=='directory'),'invalid restoration path')
 for r in sorted((x for x in rows if x['kind']=='directory'),key=lambda x:len(Path(x['path']).parts)):
  if r['path']!='.':(root/r['path']).mkdir()
 for r in rows:
  p=root/r['path']
  if r['kind']=='file':
   p.parent.mkdir(parents=True,exist_ok=True)
   with z.open('objects/'+r['sha256']) as src,p.open('xb') as dst:shutil.copyfileobj(src,dst,1048576)
   os.chmod(p,stat.S_IMODE(r['mode']));os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']))
  elif r['kind']=='symlink':
   os.symlink(r['target'],p);os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']),follow_symlinks=False)
 for r in rows:
  p=root/r['path']
  for n,v in r['xattrs'].items():os.setxattr(p,n,base64.b64decode(v),follow_symlinks=False)
 for r in sorted((x for x in rows if x['kind']=='directory'),key=lambda x:len(Path(x['path']).parts),reverse=True):
  p=root/r['path'];os.chmod(p,stat.S_IMODE(r['mode']));os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']))
os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:4]))
require(not any(os.environ.get(k) for k in ('GIT_DIR','GIT_COMMON_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_CONFIG','GIT_CONFIG_COUNT','GIT_CONFIG_PARAMETERS')),'Git location/config environment override')
pre=OUT/'audit-checkout-preflight-01.json'
require(sha(pre)=='9cf67c8d173eed1d15fc07f1788d7435480ed3b67239c3f00a9785acd90a1917','preflight pin')
config=json.loads(pre.read_text());candidates=config['candidates']
require(len(candidates)==7,'candidate count')
original_roots=[Path(c['path']).resolve(strict=True) for c in candidates]
require(len(set(original_roots))==7,'duplicate original roots')
for target in (DEST.resolve(),VERIFY.resolve()):
 require(all(not target.is_relative_to(source) and not source.is_relative_to(target) for source in original_roots),'output and original directories overlap')
require(not DEST.exists() and not VERIFY.exists(),'outputs already exist; no replay')
DEST.mkdir();VERIFY.mkdir()
save(OUT/'audit-backup-start-01.json',dict(recorded_at=now(),status='PREPARING_NO_ORIGINAL_DELETION',preflight_sha256=sha(pre),archive=str(DEST/'payload.zip'),source_paths=[x['path'] for x in candidates],script_sha256=sha(__file__)))
sources=[];objects={}
for i,c in enumerate(candidates):
 root=Path(c['path']);require(c['common_inside_source'] and c['alternates']==[],'non-independent Git')
 independent_git(root)
 require(c['records']['worktrees']['stdout'].count('worktree ')==1,'linked worktree dependent')
 require(git(root,'rev-parse','HEAD')['stdout']==c['records']['head']['stdout'],'HEAD changed')
 require(git(root,'status','--porcelain=v1','-uall')['stdout']==c['records']['status']['stdout'],'status changed')
 require(not any((root/'.git').rglob('alternates')),'alternates appeared')
 rows=inventory(root)
 for r in rows:
  if r['kind']=='file':objects.setdefault(r['sha256'],dict(path=str(root/r['path']),bytes=r['bytes']))
 sources.append(dict(id='source-'+str(i+1).zfill(2),original_path=str(root),preflight=c,entries=rows))
 print(json.dumps(dict(event='inventoried',source=i+1,entries=len(rows),unique_payload_members=len(objects))),flush=True)
require(shutil.disk_usage(DEST).free>sum(o['bytes'] for o in objects.values())+536870912,'insufficient Windows archive headroom')
require(shutil.disk_usage(VERIFY).free>max(sum(r.get('bytes',0) for r in s['entries']) for s in sources)+536870912,'insufficient Linux restore headroom')
manifest=dict(contract='audit-checkout-retention-preparation-v1',recorded_at=now(),originals_removed=False,source_count=7,sources=sources,unique_members=len(objects),unique_raw_bytes=sum(o['bytes'] for o in objects.values()),scope='All regular bytes, symlink targets, modes, xattrs and mtimes including complete .git directories. Original sources remain. Restoration creates independent ordinary files, not hardlinks.')
manifest_sha=save(DEST/'manifest.json',manifest)
archive=DEST/'payload.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
 for digest,row in sorted(objects.items()):z.write(row['path'],arcname='objects/'+digest)
with archive.open('rb') as f:os.fsync(f.fileno())
archive_sha=sha(archive)
save(OUT/'audit-backup-archive-01.json',dict(recorded_at=now(),archive=str(archive),archive_sha256=archive_sha,archive_bytes=archive.stat().st_size,manifest_sha256=manifest_sha,manifest_bytes=(DEST/'manifest.json').stat().st_size,unique_members=len(objects),unique_raw_bytes=manifest['unique_raw_bytes'],originals_removed=False))
print(json.dumps(dict(event='archive_written',bytes=archive.stat().st_size,members=len(objects))),flush=True)
with zipfile.ZipFile(archive) as z:
 require(len(z.namelist())==len(set(z.namelist()))==len(objects),'member set')
 require(set(z.namelist())=={'objects/'+h for h in objects},'member coverage')
 for digest,row in objects.items():
  d=hashlib.sha256();n=0
  with z.open('objects/'+digest) as f:
   for b in iter(lambda:f.read(1048576),b''):d.update(b);n+=len(b)
  require(d.hexdigest()==digest and n==row['bytes'],'archive member mismatch')
 results=[]
 for source in sources:
  root=VERIFY/source['id'];restore(root,source['entries'],z)
  checked=verify_tree(root,source['entries'])
  independent_git(root)
  c=source['preflight'];head=git(root,'rev-parse','HEAD');status=git(root,'status','--porcelain=v1','-uall');refs=git(root,'show-ref','--head');fsck=git(root,'fsck','--full')
  require(head['exit_code']==0 and head['stdout']==c['records']['head']['stdout'],'restored HEAD')
  require(status['exit_code']==0 and status['stdout']==c['records']['status']['stdout'],'restored status')
  require(refs['exit_code']==c['records']['refs']['exit_code'] and refs['stdout']==c['records']['refs']['stdout'],'restored refs')
  require(fsck['exit_code']==0,'restored fsck')
  original_checked=verify_tree(Path(source['original_path']),source['entries'],physical=True)
  proof=dict(recorded_at=now(),status='PASS_RESTORED_EXACT_SOURCE',id=source['id'],original_path=source['original_path'],temporary_restore_path=str(root),entries=checked,original_entries_unchanged=original_checked,head=head,git_status=status,refs=refs,fsck=fsck,manifest_sha256=manifest_sha,archive_sha256=archive_sha,originals_removed=False,qualification='Source and Git restoration only; no new performance, RTL or EMU qualification')
  save(OUT/('audit-restore-'+source['id']+'-01.json'),proof);results.append(proof)
  # Only delete this newly restored, successfully verified temporary copy.
  require(root.parent==VERIFY and VERIFY.resolve(strict=True)==VERIFY and root.resolve(strict=True)==root and root.name==source['id'] and not root.is_symlink(),'temporary root identity')
  require(all(not root.is_relative_to(original) and not original.is_relative_to(root) for original in original_roots),'temporary cleanup overlaps an original')
  shutil.rmtree(root)
  print(json.dumps(dict(event='restore_verified_and_temporary_removed',source=source['id'],entries=checked)),flush=True)
summary=dict(recorded_at=now(),status='READY_FOR_RETIREMENT_REVIEW_NOT_EXECUTED',source_count=7,source_allocated_bytes=sum(c['allocated_bytes'] for c in candidates),archive_bytes=archive.stat().st_size,manifest_bytes=(DEST/'manifest.json').stat().st_size,archive_sha256=archive_sha,manifest_sha256=manifest_sha,unique_members=len(objects),restored_sources=len(results),originals_removed=False,estimated_logical_space_basis='Source allocated size minus archive/manifest is only a planning figure across filesystems; no source cleanup performed',read_only_preflight_sha256=sha(pre),archive_windows_path='D:/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510/retained-audit-checkouts-01/payload.zip',source_paths=[c['path'] for c in candidates])
save(OUT/'audit-backup-preparation-result-01.json',summary)
for p in [OUT/'audit-backup-start-01.json',OUT/'audit-backup-archive-01.json',OUT/'audit-backup-preparation-result-01.json',*sorted(OUT.glob('audit-restore-source-*-01.json'))]:
 with (WIN/p.name).open('xb') as f:f.write(p.read_bytes())
print(json.dumps(summary,indent=2),flush=True)

