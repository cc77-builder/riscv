$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import json,subprocess,collections
base=Path('/home/lizufan/riscv-lab')
root=base/'r3-reduce-20261025-0202'
out=[]
for label in ('baseline','candidate'):
 repo=root/label
 rows=[]
 for p in sorted(repo.iterdir()):
  if not p.is_dir() or p.name in ('.git','team'):continue
  c=subprocess.check_output(['du','-s','-B1','--',str(p)],text=True)
  rows.append(dict(name=p.name,allocated_bytes=int(c.split()[0]),symlink=p.is_symlink()))
 cache=repo/'out'
 detail=[]
 if cache.is_dir():
  for p in sorted(cache.iterdir()):
   c=subprocess.check_output(['du','-s','-B1','--',str(p)],text=True)
   detail.append(dict(name=p.name,allocated_bytes=int(c.split()[0]),symlink=p.is_symlink()))
 out.append(dict(label=label,directories=rows,cache_children=detail))
h=base/'r2s3-hoisted-20261025-0326'
build=h/'build-h4-01'
files=[dict(path=str(p.relative_to(build)),bytes=p.stat().st_size) for p in sorted(build.rglob('*')) if p.is_file()]
selected={}
for name in ('build.json','make.log','stdout.log','commands.json','source/Makefile'):
 p=build/name
 if p.is_file():selected[name]=p.read_text()[:20000]
patterns=subprocess.run(['rg','-n','objects|vdot-perf.txt|exclude|skip','--',str(h/'source/team/optimizations/o2/r2-config-reuse/caller/evidence.py')],text=True,capture_output=True)
report=dict(r3=out,h4_build_files=files,selected_build_text=selected,archive_rule=patterns.stdout,archive_rule_exit=patterns.returncode)
p=base/'space-20261025-0510/cache-inspection-01.json';p.write_text(json.dumps(report,indent=2)+'\n')
target=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')/p.name
target.write_bytes(p.read_bytes())
print(json.dumps(dict(r3=out,h4_build_files=files,archive_rule=patterns.stdout,selected_names=list(selected)),indent=2))
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE