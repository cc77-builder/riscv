#!/usr/bin/env python3
"""Resume actual restoration checks from a fixed archive; only remove our own verified temporary copies."""
from pathlib import Path
import copy,hashlib,importlib.util,json,os,shutil,time,zipfile
if not __debug__:raise RuntimeError('Python optimization not allowed')
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
BACKUP=WIN/'retained-audit-checkouts-01'
HELPER=BACKUP/'restore.py'
HELPER_SHA='18746112a89a86fd0c8d0cd153d95ab893d08c2410895526f620c290cba5d1fd'
def require(v,msg):
 if not v:raise RuntimeError(msg)
require(hashlib.sha256(HELPER.read_bytes()).hexdigest()==HELPER_SHA,'restore helper pin')
spec=importlib.util.spec_from_file_location('audit_restore',HELPER);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.environment_gate()
manifest=m.verified_manifest(BACKUP/'manifest.json')
payload=m.verify_payload(BACKUP/'payload.zip',manifest)
roots=[Path(s['original_path']).resolve(strict=True) for s in manifest['sources']]
new=OUT/'audit-restore-validation-02'
require(not new.exists() and not new.is_symlink(),'new restoration validation output exists')
require(all(not new.resolve().is_relative_to(p) and not p.is_relative_to(new.resolve()) for p in roots),'temporary root overlap')
new.mkdir()
def save_both(name,obj):
 a=m.save(OUT/name,obj);b=m.save(WIN/name,obj);require(a==b,'cross-filesystem receipt bytes');return a
save_both('audit-restore-v2-start-01.json',dict(recorded_at=m.now(),contract='audit-checkout-restore-v2-pinned-csv-stat-exception',helper_sha256=HELPER_SHA,payload=payload,originals_removed=False,prior_strict_status_failure_preserved=True))
results=[];negative=[]
journal=(OUT/'audit-restore-v2-cleanup-journal-01.jsonl').open('x')
def event(obj):
 journal.write(json.dumps(obj)+'\n');journal.flush();os.fsync(journal.fileno())
with zipfile.ZipFile(BACKUP/'payload.zip') as z:
 for source in manifest['sources']:
  original=Path(source['original_path'])
  before=m.verify_tree(original,source['entries'],physical=True)
  if source['id']=='source-01':
   root=OUT/'audit-restore-validation-01/source-01'
   require(root.exists(),'prior actual restoration is absent')
   origin='v1 actual restoration reused after new read-only diagnosis'
  else:
   root=new/source['id'];m.restore(root,source['entries'],z);origin='new v2 actual restoration'
  identity=root.lstat()
  proof=m.verify_restored(root,source)
  if source['id']=='source-01':
   status=proof['git_status']
   require(proof['status_equivalence']['kind']=='EXACT_BYTES_WITH_EXPLICIT_CSV_STAT_CACHE_DIFFERENCE','expected diagnosed difference')
   for label in ('unknown-source','wrong-head','wrong-original-path','extra-unrelated-status','duplicate-status-entry'):
    badsource=copy.deepcopy(source);badstatus=copy.deepcopy(status)
    if label=='unknown-source':badsource['id']='source-unknown'
    elif label=='wrong-head':badsource['preflight']['records']['head']['stdout']='0'*40+'\n'
    elif label=='wrong-original-path':badsource['original_path']+='-unrelated'
    elif label=='extra-unrelated-status':badstatus['stdout']+=' M unrelated-file\n'
    elif label=='duplicate-status-entry':badstatus['stdout']+=' M '+m.CSV+'\n'
    try:m.status_equivalence(root,badsource,badstatus)
    except RuntimeError as e:negative.append(dict(case=label,status='REJECTED',reason=str(e)))
    else:raise RuntimeError('negative case accepted: '+label)
   save_both('audit-restore-v2-negatives-01.json',dict(recorded_at=m.now(),cases=negative,scope='Known status exception identity and delta guard; source/index/attributes untouched'))
  after=m.verify_tree(original,source['entries'],physical=True)
  original_status=m.git(original,'status','--porcelain=v1','-uall')
  require(original_status['exit_code']==0 and original_status['stdout']==source['preflight']['records']['status']['stdout'],'original status changed')
  proof.update(original_entries_before=before,original_entries_after=after,restoration_origin=origin,helper_sha256=HELPER_SHA,original_status_unchanged=True)
  proof_sha=save_both('audit-restore-v2-'+source['id']+'.json',proof)
  require(root.resolve(strict=True)==root and not root.is_symlink(),'temporary identity')
  require(root.parent in (OUT/'audit-restore-validation-01',new),'unexpected temporary parent')
  require(root.name==source['id'] and all(not root.is_relative_to(p) and not p.is_relative_to(root) for p in roots),'temporary overlaps original')
  current=root.lstat();require(current.st_dev==identity.st_dev and current.st_ino==identity.st_ino,'temporary inode changed')
  # Both the full archive and the original failed v1 receipts/diagnosis remain.
  # This is a newly materialized duplicate, now fully verified under the explicit v2 contract.
  event(dict(recorded_at=m.now(),action='remove_verified_temporary_copy_intent',path=str(root),proof_sha256=proof_sha,originals_removed=False))
  shutil.rmtree(root);require(not root.exists(),'temporary removal failed')
  event(dict(recorded_at=m.now(),action='removed_verified_temporary_copy',path=str(root),originals_removed=False))
  results.append(dict(id=source['id'],entries=proof['entries'],status=proof['status'],status_equivalence=proof['status_equivalence']['kind'],proof_sha256=proof_sha,temporary_removed=True))
  print(json.dumps(dict(event='restoration_v2_pass',source=source['id'],entries=proof['entries'],status_equivalence=proof['status_equivalence']['kind'],temporary_removed=True)),flush=True)
journal.close()
with (WIN/'audit-restore-v2-cleanup-journal-01.jsonl').open('xb') as f:f.write((OUT/'audit-restore-v2-cleanup-journal-01.jsonl').read_bytes())
summary=dict(recorded_at=m.now(),status='READY_FOR_RETIREMENT_REVIEW_NOT_EXECUTED',contract='audit-checkout-restore-v2-pinned-csv-stat-exception',source_count=7,restored_sources=len(results),sources=results,source_allocated_bytes=sum(s['preflight']['allocated_bytes'] for s in manifest['sources']),source_regular_logical_bytes=sum(r.get('bytes',0) for s in manifest['sources'] for r in s['entries']),archive_bytes=(BACKUP/'payload.zip').stat().st_size,manifest_bytes=(BACKUP/'manifest.json').stat().st_size,helper_bytes=HELPER.stat().st_size,archive_sha256=m.ARCHIVE_SHA,manifest_sha256=m.MANIFEST_SHA,helper_sha256=HELPER_SHA,unique_members=manifest['unique_members'],unique_raw_bytes=manifest['unique_raw_bytes'],originals_removed=False,all_originals_unchanged=True,temporary_copies_removed=7,negative_cases=negative,prior_strict_status_failure_preserved=True,source_paths=[s['original_path'] for s in manifest['sources']],qualification='Exact source/Git bytes, listed metadata and complete fsck; explicit per-source pinned historical CSV status difference. No new build/EMU qualification or permission to retire originals.')
save_both('audit-backup-preparation-result-02.json',summary)
print(json.dumps(summary,indent=2),flush=True)

