$ErrorActionPreference='Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$git='D:\Programs\Git\cmd\git.exe'
$base='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan'
$work=Join-Path $base 'working-r2s3-hoisted-20261025-0326'
$out=Join-Path $base 'runtime-space-20261025-0510'
if(Test-Path -LiteralPath $out){throw 'space output must be new'}
if((& $git -C $work rev-parse HEAD).Trim() -ne 'e301a360d21a0a942882921f8b481c81eff1e478'){throw 'unexpected starting commit'}
$dirty=@(& $git -C $work status --porcelain=v1 --untracked-files=all)
if($LASTEXITCODE -ne 0 -or $dirty.Count -ne 0){throw 'completed worktree not clean'}
& $git -C $work switch -c 'local/space-20261025-0510'
if($LASTEXITCODE -ne 0){throw 'new local branch failed'}
New-Item -ItemType Directory -Path $out|Out-Null
$repos=@('working-zufan-full-20261022','working-r2s3-caller-resume-20261025-0202','working-r3-reduce-20261025-0202','working-r2s3-hoisted-20261025-0326')
$rows=@();$common=@{}
foreach($name in $repos){
 $p=Join-Path $base $name
 if(-not(Test-Path -LiteralPath $p)){continue}
 $meta=@(& $git -C $p rev-parse --path-format=absolute --show-toplevel --git-dir --git-common-dir --git-path index)
 if($LASTEXITCODE -ne 0){throw ('git topology failed '+$name)}
 $status=@(& $git -C $p -c core.quotepath=false status --porcelain=v1 --untracked-files=normal)
 $submodules=@(& $git -C $p submodule status)
 $row=[ordered]@{path=$p;head=(& $git -C $p rev-parse HEAD).Trim();top=$meta[0];git_dir=$meta[1];common_dir=$meta[2];index=$meta[3];status=$status;submodules=$submodules}
 $rows+=$row
 if(-not $common.ContainsKey($meta[2])){
  $common[$meta[2]]=[ordered]@{count_objects=@(& $git -C $p count-objects -v);worktrees=@(& $git -C $p worktree list --porcelain)}
 }
}
$caches=@()
foreach($name in $repos[1..3]){
 foreach($relative in @('out','build','target','.bloop','__pycache__')){
  $p=Join-Path (Join-Path $base $name) $relative
  if(Test-Path -LiteralPath $p){$files=@(Get-ChildItem -LiteralPath $p -Recurse -File -Force);$sum=($files|Measure-Object Length -Sum).Sum;$caches+=[ordered]@{path=$p;files=$files.Count;logical_bytes=$sum}}
 }
}
$windows=[ordered]@{recorded_at=[DateTime]::UtcNow.ToString('o');git_version=(& $git --version);drive_D=[ordered]@{free_bytes=(Get-PSDrive D).Free;used_bytes=(Get-PSDrive D).Used};repositories=$rows;common_repositories=$common;top_level_names=@(Get-ChildItem -LiteralPath $base -Directory|Select-Object -ExpandProperty Name);own_top_level_cache_candidates=$caches}
[System.IO.File]::WriteAllText((Join-Path $out 'windows-before.json'),($windows|ConvertTo-Json -Depth 10)+[Environment]::NewLine,(New-Object System.Text.UTF8Encoding($false)))
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import os,json,subprocess,datetime,shutil
base=Path('/home/lizufan/riscv-lab')
out=base/'space-20261025-0510';assert not out.exists();out.mkdir()
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
roots=[base/'r2s3-hoisted-20261025-0326',base/'r3-reduce-20261025-0202']
repos=[roots[0]/'source',roots[1]/'baseline',roots[1]/'candidate']
def git(repo,*args):
 return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def size(path):
 p=subprocess.run(['du','-s','-B1','--',str(path)],text=True,capture_output=True)
 if p.returncode:return dict(path=str(path),error=p.stderr.strip())
 return dict(path=str(path),allocated_bytes=int(p.stdout.split()[0]))
topology=[];objects={};seen=set()
def donors(obj):
 obj=obj.resolve()
 if str(obj) in seen:return
 seen.add(str(obj));alt=obj/'info/alternates'
 refs=[]
 if alt.is_file():
  for line in alt.read_text().splitlines():
   p=Path(line);p=p if p.is_absolute() else obj/p
   refs.append(str(p.resolve()))
 objects[str(obj)]=dict(exists=obj.is_dir(),alternates=refs,allocation=size(obj) if obj.is_dir() else None)
 for value in refs:donors(Path(value))
for repo in repos:
 if not (repo/'.git').exists():continue
 common=Path(git(repo,'rev-parse','--path-format=absolute','--git-common-dir'))
 topology.append(dict(path=str(repo),head=git(repo,'rev-parse','HEAD'),git_dir=git(repo,'rev-parse','--absolute-git-dir'),common_dir=str(common),index=git(repo,'rev-parse','--path-format=absolute','--git-path','index'),status=git(repo,'status','--porcelain=v1','--untracked-files=normal').splitlines(),count_objects=git(repo,'count-objects','-v').splitlines(),submodules=git(repo,'submodule','status').splitlines()))
 donors(common/'objects')
inventories=[]
for root in roots:
 children=[]
 for p in sorted(root.iterdir()):
  if p.is_symlink():children.append(dict(path=str(p),symlink=os.readlink(p)));continue
  if p.is_dir():children.append(size(p))
  else:children.append(dict(path=str(p),bytes=p.stat().st_size))
 inventories.append(dict(root=str(root),children=children))
heavy=[];related=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  comm=(p/'comm').read_text().strip();cwd=os.readlink(p/'cwd')
  raw=(p/'cmdline').read_bytes()
 except (OSError,PermissionError):continue
 if comm in ('emu','java','yosys','berkeley-abc','sta','cc1','cc1plus','verilator_bin'):heavy.append(dict(pid=int(p.name),comm=comm))
 if any(str(r) in cwd or str(r).encode() in raw for r in roots):
  related.append(dict(pid=int(p.name),comm=comm,cwd=cwd))
state=json.loads((roots[0]/'campaign-01.json').read_text())
assert state['status']=='COMPLETE' and state['active_command'] is None and state['active_pid'] is None
result=dict(recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),git_version=subprocess.check_output(['git','--version'],text=True).strip(),filesystem=dict(zip(('total','used','free'),shutil.disk_usage(base))),git_alternate_environment=os.environ.get('GIT_ALTERNATE_OBJECT_DIRECTORIES'),repositories=topology,object_donors=objects,inventory=inventories,heavy_processes=heavy,related_processes=related,hoisted_campaign_status=state['status'])
path=out/'native-before.json';path.write_text(json.dumps(result,indent=2)+'\n')
windows=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
shutil.copyfile(path,windows/path.name)
print(json.dumps(dict(status='SPACE_READONLY_INVENTORY_COMPLETE',native_report=str(path),heavy_processes=heavy,related_processes=related,object_donors=list(objects),inventory=inventories),indent=2))
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE