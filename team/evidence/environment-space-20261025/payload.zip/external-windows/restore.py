"""Restore an archived checkout into a NEW directory; never overwrite a destination.
The restored repository uses the preserved object store as a read-only alternate.
Keep recovery.git, or run git repack -a in the restored checkout before relocating it.
"""
import argparse,json,zipfile,hashlib,os,datetime
os.environ['GIT_NO_LAZY_FETCH']='1'
from pathlib import Path
from preserve import OUT,long,cmd,save
def restore(name,destination):
 manifest=json.loads((OUT/(name+'-manifest.json')).read_text(encoding='utf8'))
 dst=Path(destination).absolute();assert not dst.exists(),'Destination already exists'
 assert dst.name!='.git';dst.mkdir(parents=True)
 cmd(['git','init',str(dst)])
 with zipfile.ZipFile(OUT/'files.zip') as z:
  for entry in manifest['files']:
   rel=entry['path'];kind=entry['kind']
   assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
   if kind=='common':continue
   if kind=='git' and rel in {'commondir','gitdir','config.worktree'}:continue
   f=long(dst)/('.git' if kind=='git' else '')/rel
   f.parent.mkdir(parents=True,exist_ok=True);data=z.read(entry['sha256'])
   assert hashlib.sha256(data).hexdigest()==entry['sha256'];f.write_bytes(data)
   os.utime(f,ns=(entry['mtime_ns'],entry['mtime_ns']))
  cfg=next(f for f in manifest['files'] if f['kind']=='common')
  (dst/'.git/config').write_bytes(z.read(cfg['sha256']))
 for d in manifest['dirs']:(long(dst)/d).mkdir(parents=True,exist_ok=True)
 (dst/'.git/objects/info').mkdir(parents=True,exist_ok=True)
 (dst/'.git/objects/info/alternates').write_bytes(((OUT/'recovery.git/objects').as_posix()+'\n').encode())
 cmd(['git','-C',str(dst),'config','core.worktree',str(dst)])
 cmd(['git','-C',str(dst),'config','core.longpaths','true'])
 for remote in cmd(['git','-C',str(dst),'remote']).decode().splitlines():
  cmd(['git','-C',str(dst),'config',f'remote.{remote}.promisor','false'])
 updates='\n'.join('update '+ref+' '+sha for sha,ref in (line.split() for line in manifest['refs'].splitlines()))+'\n'
 if manifest['shared']:cmd(['git','-C',str(dst),'update-ref','--stdin'],updates.encode())
 if manifest['branch']:cmd(['git','-C',str(dst),'symbolic-ref','HEAD','refs/heads/'+manifest['branch']])
 else:cmd(['git','-C',str(dst),'update-ref','--no-deref','HEAD',manifest['head']])
 verify(name,dst)
def verify(name,dst):
 dst=Path(dst);manifest=json.loads((OUT/(name+'-manifest.json')).read_text(encoding='utf8'))
 for e in manifest['files']:
  if e['kind']=='work':assert hashlib.sha256((long(dst)/e['path']).read_bytes()).hexdigest()==e['sha256']
 prefix=['git','--no-optional-locks','-C',str(dst)]
 head=cmd(prefix+['rev-parse','HEAD']).decode().strip();assert head==manifest['head']
 status=cmd(prefix+['status','--porcelain=v1','-uall']).decode('utf8','replace')
 expected=set(manifest['status'].splitlines());actual=set(status.splitlines());assert expected<=actual,(name,'Missing original changes')
 normalized=[]
 for line in actual-expected:
  assert line.startswith(' M '),(name,'Unexpected change',line)
  rel=line[3:];index=cmd(prefix+['ls-files','-s','--',rel]).decode().split()[1]
  raw=cmd(prefix+['hash-object','--no-filters','--',rel]).decode().strip()
  assert index==raw,(name,'Unexpected content change',rel)
  normalized.append(rel)
 excludes=['--','.']+[':(exclude)'+p for p in sorted(normalized)] if normalized else []
 for label,args in [('staged.patch',['diff','--binary','--cached']),('unstaged.patch',['diff','--binary']),('head.patch',['diff','--binary','HEAD'])]:
  assert cmd(prefix+args+excludes)==(OUT/(name+'-'+label)).read_bytes(),(name,label)
 original_index=next(e for e in manifest['files'] if e['kind']=='git' and e['path']=='index')
 # Git may refresh only stat-cache metadata. Compare stage, blob, mode and flags.
 index_copy=OUT/(name+'-original.index')
 with zipfile.ZipFile(OUT/'files.zip') as z:index_copy.write_bytes(z.read(original_index['sha256']))
 import subprocess
 for args in [['ls-files','--stage','-z'],['ls-files','-v','-z']]:
  expected_index=subprocess.run(prefix+args,env={**os.environ,'GIT_INDEX_FILE':str(index_copy)},capture_output=True,check=True).stdout
  assert cmd(prefix+args)==expected_index,(name,'Index contents differ')
 result={'name':name,'destination':str(dst),'at':datetime.datetime.now().astimezone().isoformat(),'head':head,'raw_files':sum(e['kind']=='work' for e in manifest['files']),'head_status_staged_unstaged_and_all_raw_bytes':'PASS','normalization_only_paths':normalized,'normalization_note':'Any newly visible dirty paths have raw bytes identical to original index blob; original cached status hid EOL/filter normalization. No content was normalized or discarded.'}
 save(OUT/(name+'-restore-verified.json'),result);print(json.dumps(result))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--name',required=True);a.add_argument('--destination',required=True);a.add_argument('--verify-existing',action='store_true');p=a.parse_args();(verify if p.verify_existing else restore)(p.name,p.destination)
