import json,pathlib,hashlib,datetime,shutil,subprocess
from audit import ROOT,OUT,git,walk
from preserve import save
plan=json.loads((OUT/'plan.json').read_text(encoding='utf8'));old={r['name']:r for r in json.loads((OUT/'audit.json').read_text(encoding='utf8'))['repos']}
deleted=[];kept=[]
for n in plan['remove']:
 assert not (ROOT/n).exists(),('Still exists',n)
 r=json.loads((OUT/(n+'-deleted.json')).read_text(encoding='utf-8-sig'));assert r['status']=='DELETED_AND_ABSENT';deleted.append(r)
 assert json.loads((OUT/(n+'-restore-verified.json')).read_text(encoding='utf8'))['head_status_staged_unstaged_and_all_raw_bytes']=='PASS'
for n,reason in plan['keep'].items():
 p=ROOT/n;assert p.is_dir()
 head=git(p,'rev-parse','HEAD').decode().strip();status=git(p,'status','--porcelain=v1','-uall').decode('utf8','replace')
 prior=json.loads((OUT/(n+'-inventory.json')).read_text(encoding='utf8'));files,links,dirs=walk(p)
 assert not links
 def work(fs):return {x[0]:(x[1],x[2]) for x in fs if x[0]!='.git' and not x[0].startswith('.git\\')}
 a,b=work(prior),work(files);changes=[k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)]
 wt=git(p,'worktree','list','--porcelain').decode()
 assert all((ROOT/n).as_posix() not in wt for n in plan['remove'])
 kept.append({'name':n,'reason':reason,'head':head,'branch':git(p,'branch','--show-current').decode().strip(),'status':status,'old_head':old[n]['head'],'changed_worktree_metadata':changes,'worktree_listing':wt})
actual=sorted(p.name for p in ROOT.iterdir() if (p/'.git').exists());assert actual==sorted(plan['keep']),('Unexpected repository set',actual)
for p in OUT.glob('restore-tests*'):
 assert not list(p.iterdir()),('Test copy remains',str(p))
recovery=OUT/'recovery.git'
fsck=subprocess.run(['git','--git-dir='+str(recovery),'fsck','--full'],capture_output=True);assert fsck.returncode==0,fsck.stderr
(OUT/'git-fsck-final.txt').write_bytes(fsck.stdout+fsck.stderr)
critical=[OUT/'files.zip',*OUT.glob('*-manifest.json'),*OUT.glob('*.patch'),*recovery.rglob('*')]
integrity={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in critical if p.is_file()}
save(OUT/'archive-integrity.json',integrity)
after=shutil.disk_usage(ROOT).free;backup=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file());original=sum(r['sourceBytes'] for r in deleted)
result={'at':datetime.datetime.now().astimezone().isoformat(),'deleted_count':len(deleted),'retained_count':len(kept),'source_logical_bytes':original,'backup_and_evidence_bytes':backup,'logical_net_reclaimed':original-backup,'free_before':plan['free_before'],'free_after':after,'observed_free_increase':after-plan['free_before'],'concurrent_activity_note':'Hoisted/space task advanced the retained shared repository to e301a360 and added runtime records during this cleanup; actual free-space delta includes concurrent system activity.','restore_tests_passed':len(deleted),'kept':kept,'deleted':[r['name'] for r in deleted],'integrity_entries':len(integrity),'git_fsck':'PASS'}
save(OUT/'final-validation.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in {'kept','deleted'}},ensure_ascii=False));print(json.dumps([{'name':r['name'],'changed_files':len(r['changed_worktree_metadata']),'head':r['head'],'status_lines':len(r['status'].splitlines())} for r in kept]))
