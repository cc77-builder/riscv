import os,json,subprocess,hashlib,zipfile,datetime,shutil
from pathlib import Path
from audit import ROOT,OUT,git,walk
KEEP={'working-zufan-full-20261022':'PPA configured entry and shared Git store',
 'working-r2s3-hoisted-20261025-0326':'open hoisted claim and latest unpublished work',
 'working-r2s3-caller-20261024-2025':'frozen parent caller and unpublished issue archive',
 'working-t17-clean-20261024-0854':'current fullcore baseline and independent commit',
 'working-r3-reduce-20261025-0202':'latest stable integrated checkout and reproduction entry'}
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
def long(p):return Path('\\\\?\\'+str(p)) if not str(p).startswith('\\\\?\\') else p
def cmd(args,data=None):
 r=subprocess.run(args,input=data,capture_output=True)
 if r.returncode:raise RuntimeError((args,r.stderr.decode('utf8','replace')))
 return r.stdout
def main():
 rows=json.loads((OUT/'audit.json').read_text())['repos']
 selected=[r for r in rows if r['name'] not in KEEP]
 plan={'at':datetime.datetime.now().astimezone().isoformat(),'free_before':shutil.disk_usage(ROOT).free,'keep':KEEP,'remove':[r['name'] for r in selected],'source_bytes':sum(r['bytes'] for r in selected)}
 save(OUT/'plan.json',plan)
 recovery=OUT/'recovery.git';cmd(['git','init','--bare',str(recovery)])
 cmd(['git','--git-dir='+str(recovery),'config','gc.auto','0'])
 cas=OUT/'files.zip';assert not cas.exists(),'Do not overwrite existing archive'
 object_seen=set();common_seen=set();blob_seen=set();summaries=[]
 with zipfile.ZipFile(cas,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=4,allowZip64=True) as z:
  for r in selected:
   p=Path(r['path']);name=r['name'];print('BEGIN '+name,flush=True)
   assert not r['links'] and not r['nested_git'] and not r['locks']
   assert all(x.startswith('-') for x in r['submodules'].splitlines()),'initialized submodule'
   assert git(p,'rev-parse','HEAD').decode().strip()==r['head']
   assert git(p,'status','--porcelain=v1','-uall').decode('utf8','replace')==r['status']
   common=Path(r['commondir']);gd=Path(r['gitdir'])
   if str(common) not in common_seen:
    objects=git(p,'cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)').decode().splitlines()
    new=[x.split()[0] for x in objects if x.split()[0] not in object_seen]
    if new:
     with (OUT/(name+'-pack.stderr')).open('wb') as err:
      pack=subprocess.Popen(['git','--no-optional-locks','-C',str(p),'pack-objects','--stdout'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
      index=subprocess.Popen(['git','--git-dir='+str(recovery),'index-pack','--stdin'],stdin=pack.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
      pack.stdout.close();pack.stdin.write(('\n'.join(new)+'\n').encode());pack.stdin.close()
      io,ie=index.communicate();code=pack.wait()
      assert code==0 and index.returncode==0,(code,ie)
    object_seen.update(x.split()[0] for x in objects);common_seen.add(str(common))
    save(OUT/(name+'-objects.json'),objects)
   refs=r['refs'].splitlines();updates=[]
   for line in refs:
    sha,ref=line.split();updates.append(f'update refs/preserved/{name}/{ref.removeprefix("refs/")} {sha}')
   updates.append(f'update refs/heads/saved/{name} {r["head"]}')
   cmd(['git','--git-dir='+str(recovery),'update-ref','--stdin'],('\n'.join(updates)+'\n').encode())
   manifest={'name':name,'original':str(p),'head':r['head'],'branch':r['branch'],'status':r['status'],'refs':r['refs'],'shared':r['gitdir']!=r['commondir'],'files':[],'dirs':[]}
   def add(f,kind,rel):
    s=f.stat();data=f.read_bytes();sha=hashlib.sha256(data).hexdigest()
    assert (f.stat().st_size,f.stat().st_mtime_ns)==(s.st_size,s.st_mtime_ns),'Source changed while reading'
    if sha not in blob_seen:z.writestr(sha,data);blob_seen.add(sha)
    manifest['files'].append({'kind':kind,'path':rel.replace('\\','/'),'sha256':sha,'bytes':len(data),'mtime_ns':s.st_mtime_ns,'attributes':s.st_file_attributes})
   files,links,dirs=walk(p);assert not links
   manifest['dirs']=[n.replace('\\','/') for n in dirs if n!='.git' and not n.startswith('.git\\')]
   for rel,size,mtime in files:
    if rel=='.git' or rel.startswith('.git\\'):continue
    add(long(p)/rel,'work',rel)
   mf,ml,md=walk(gd);assert not ml
   for rel,size,mtime in mf:
    if rel.startswith(('objects\\','worktrees\\')):continue
    add(long(gd)/rel,'git',rel)
   add(long(common)/'config','common','config')
   for label,args in [('staged.patch',['diff','--binary','--cached']),('unstaged.patch',['diff','--binary']),('head.patch',['diff','--binary','HEAD'])]:
    (OUT/(name+'-'+label)).write_bytes(git(p,*args))
   assert git(p,'status','--porcelain=v1','-uall').decode('utf8','replace')==r['status'],'Status changed during preservation'
   save(OUT/(name+'-manifest.json'),manifest)
   summary={'name':name,'files':len(manifest['files']),'head':r['head'],'bytes':sum(f['bytes'] for f in manifest['files']),'dirty':bool(r['status'])}
   summaries.append(summary);print(json.dumps(summary),flush=True)
 print('VERIFY all file contents',flush=True)
 with zipfile.ZipFile(cas) as z:
  for n in z.namelist():assert hashlib.sha256(z.read(n)).hexdigest()==n,n
 fsck=cmd(['git','--git-dir='+str(recovery),'fsck','--full','--no-reflogs'])
 (OUT/'git-fsck.txt').write_bytes(fsck)
 saved_objects=set(x.split()[0] for x in cmd(['git','--git-dir='+str(recovery),'cat-file','--batch-all-objects','--batch-check=%(objectname)']).decode().splitlines())
 assert object_seen<=saved_objects
 save(OUT/'preservation-verified.json',{'at':datetime.datetime.now().astimezone().isoformat(),'repos':summaries,'git_objects':len(object_seen),'raw_blobs':len(blob_seen),'file_archive_bytes':cas.stat().st_size,'git_object_and_raw_sha256_verification':'PASS'})
 print('PRESERVATION VERIFIED',flush=True)
if __name__=='__main__':main()
