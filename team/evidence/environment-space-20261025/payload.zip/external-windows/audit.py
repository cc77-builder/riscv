import os,sys,json,subprocess,datetime,stat
from pathlib import Path
ROOT=Path(r'D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan')
OUT=Path(__file__).resolve().parent
def git(p,*args):
 r=subprocess.run(['git','--no-optional-locks','-C',str(p),*args],capture_output=True)
 if r.returncode: raise RuntimeError((str(p),args,r.stderr.decode('utf8','replace')))
 return r.stdout
def walk(p):
 p=Path('\\\\?\\'+str(p)) if not str(p).startswith('\\\\?\\') else p
 files=[];links=[];dirs=[]
 def fail(e):raise e
 for base,ds,fs in os.walk(p,followlinks=False,onerror=fail):
  for n in ds[:]+fs:
   f=Path(base)/n;s=f.lstat()
   if s.st_file_attributes&0x400:
    links.append(str(f));
    if n in ds:ds.remove(n)
   elif f.is_dir():dirs.append(str(f.relative_to(p)))
   else:files.append((str(f.relative_to(p)),s.st_size,s.st_mtime_ns))
 return files,links,dirs
def main():
 rows=[]
 for p in sorted(ROOT.iterdir()):
  if not (p/'.git').exists():continue
  files,links,dirs=walk(p)
  row={'name':p.name,'path':str(p),'head':git(p,'rev-parse','HEAD').decode().strip(),
   'status':git(p,'status','--porcelain=v1','-uall').decode('utf8','replace'),
   'branch':git(p,'branch','--show-current').decode().strip(),
   'refs':git(p,'show-ref').decode(),'worktrees':git(p,'worktree','list','--porcelain').decode(),
   'gitdir':git(p,'rev-parse','--absolute-git-dir').decode().strip(),
   'commondir':git(p,'rev-parse','--path-format=absolute','--git-common-dir').decode().strip(),
   'submodules':git(p,'submodule','status','--recursive').decode(),
   'links':links,'nested_git':[n for n in dirs if n.endswith('\\.git')],
   'locks':[n for n,s,t in files if n.startswith('.git\\') and n.endswith('.lock')],
   'bytes':sum(s for n,s,t in files),'file_count':len(files),
   'git_bytes':sum(s for n,s,t in files if n.startswith('.git\\'))}
  (OUT/(p.name+'-inventory.json')).write_text(json.dumps(files),encoding='utf8')
  rows.append(row)
  print(json.dumps({k:row[k] for k in ['name','bytes','git_bytes','file_count','links','nested_git','locks','submodules']}),flush=True)
 (OUT/'audit.json').write_text(json.dumps({'at':datetime.datetime.now().astimezone().isoformat(),'repos':rows},ensure_ascii=False,indent=2),encoding='utf8')
if __name__=='__main__':main()
