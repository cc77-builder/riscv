#!/usr/bin/env python3
"""Verify or restore the pinned seven-source audit backup; never removes directories."""
from pathlib import Path
if not __debug__:raise RuntimeError('Python optimization not allowed')
import base64,collections,concurrent.futures,datetime,hashlib,json,os,shutil,stat,subprocess,time,zipfile
OUT=Path('/home/lizufan/riscv-lab/space-20261025-0510')
WIN=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-space-20261025-0510')
DEST=WIN/'retained-audit-checkouts-01'
VERIFY=OUT/'audit-restore-validation-01'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def save(p,obj):
 data=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
 with Path(p).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return hashlib.sha256(data).hexdigest()
def require(v,msg):
 if not v:raise RuntimeError(msg)
def attrs(p):
 return {n:base64.b64encode(os.getxattr(p,n,follow_symlinks=False)).decode() for n in os.listxattr(p,follow_symlinks=False)}
def metadata(p,rel):
 s=p.lstat()
 require(s.st_uid==os.getuid() and s.st_gid==os.getgid(),'foreign owner/group requires separate handling: '+str(p))
 return dict(path=rel,mode=s.st_mode,uid=s.st_uid,gid=s.st_gid,mtime_ns=s.st_mtime_ns,xattrs=attrs(p))
def inventory(root):
 require(root.is_dir() and not root.is_symlink(),'source root is not an ordinary directory')
 rows=[dict(metadata(root,'.'),kind='directory')]
 for base,ds,fs in os.walk(root,followlinks=False):
  ds.sort();fs.sort()
  for name in ds+fs:
   p=Path(base)/name;s=p.lstat();rel=str(p.relative_to(root));r=metadata(p,rel)
   if stat.S_ISLNK(s.st_mode):r.update(kind='symlink',target=os.readlink(p))
   elif stat.S_ISDIR(s.st_mode):r.update(kind='directory')
   elif stat.S_ISREG(s.st_mode):
    require(s.st_nlink==1,'external or internal hardlink requires separate treatment: '+str(p))
    r.update(kind='file',bytes=s.st_size,allocated_bytes=s.st_blocks*512,device=s.st_dev,inode=s.st_ino)
   else:raise RuntimeError('special file: '+str(p))
   if '.git' in p.parts:
    require(not name.endswith('.lock'),'Git lock: '+str(p))
    require(not stat.S_ISLNK(s.st_mode),'Git metadata symlink: '+str(p))
   rows.append(r)
  ds[:]=[n for n in ds if not (Path(base)/n).is_symlink()]
 files=[r for r in rows if r['kind']=='file']
 def digest(r):return sha(root/r['path'])
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for row,d in zip(files,pool.map(digest,files)):row['sha256']=d
 return rows
def verify_tree(root,rows,physical=False):
 actual=inventory(root);a={r['path']:r for r in actual};b={r['path']:r for r in rows}
 require(set(a)==set(b),'path set differs: '+str(root))
 for path,old in b.items():
  keys=['kind','mode','uid','gid','xattrs','mtime_ns']
  if old['kind']=='file':keys+=['bytes','sha256','mtime_ns']
  if old['kind']=='symlink':keys+=['target']
  if physical and old['kind']=='file':keys+=['device','inode']
  for key in keys:require(a[path][key]==old[key],str(root/path)+' differs '+key)
 return len(actual)
def git(root,*args):
 e=os.environ.copy();e['GIT_OPTIONAL_LOCKS']='0'
 p=subprocess.run(['git','--no-optional-locks','-C',str(root),*args],env=e,capture_output=True)
 return dict(exit_code=p.returncode,stdout=p.stdout.decode(errors='replace'),stderr=p.stderr.decode(errors='replace'))
def independent_git(root):
 root=root.resolve(strict=True)
 for argv,expected in [(['rev-parse','--show-toplevel'],root),(['rev-parse','--absolute-git-dir'],root/'.git'),(['rev-parse','--path-format=absolute','--git-common-dir'],root/'.git')]:
  result=git(root,*argv)
  require(result['exit_code']==0 and Path(result['stdout'].strip()).resolve(strict=True)==expected,'external Git location: '+str(root)+' '+str(argv))
 require((root/'.git').is_dir() and not (root/'.git').is_symlink(),'Git directory identity')
 cw=git(root,'config','--get','core.worktree')
 require(cw['exit_code']==1 and not cw['stdout'],'core.worktree needs separate handling')
 require(not any((root/'.git').rglob('alternates')),'Git alternates appeared')
 worktrees=git(root,'worktree','list','--porcelain')
 require(worktrees['exit_code']==0 and worktrees['stdout'].count('worktree ')==1,'linked worktree dependency')
def restore(root,rows,z):
 require(not root.exists(),'restore root exists');root.mkdir()
 for r in rows:
  rel=Path(r['path'])
  require(not rel.is_absolute() and '..' not in rel.parts and (str(rel)!='.' or r['kind']=='directory'),'invalid restoration path')
 for r in sorted((x for x in rows if x['kind']=='directory'),key=lambda x:len(Path(x['path']).parts)):
  if r['path']!='.':(root/r['path']).mkdir()
 for r in rows:
  p=root/r['path']
  if r['kind']=='file':
   p.parent.mkdir(parents=True,exist_ok=True)
   with z.open('objects/'+r['sha256']) as src,p.open('xb') as dst:shutil.copyfileobj(src,dst,1048576)
   os.chmod(p,stat.S_IMODE(r['mode']));os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']))
  elif r['kind']=='symlink':
   os.symlink(r['target'],p);os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']),follow_symlinks=False)
 for r in rows:
  p=root/r['path']
  for n,v in r['xattrs'].items():os.setxattr(p,n,base64.b64decode(v),follow_symlinks=False)
 for r in sorted((x for x in rows if x['kind']=='directory'),key=lambda x:len(Path(x['path']).parts),reverse=True):
  p=root/r['path'];os.chmod(p,stat.S_IMODE(r['mode']));os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']))

ARCHIVE_SHA='5d479fae7c94bf54fc27ce975a7a96098eb3f6bb2287812fd9e7bfd301ca901d'
MANIFEST_SHA='87311d16105e03cff7f839307b7caeb3b20f4ee72370a308f0f31d70fb689af4'
PROFILE_SHA='521323f64962642af0b397ac7cbd500687e82a9e5cf42f0c5b15f02acf8bd736'
def environment_gate():
 require(not any(os.environ.get(k) for k in ('GIT_DIR','GIT_COMMON_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_CONFIG','GIT_CONFIG_COUNT','GIT_CONFIG_PARAMETERS')),'Git location/config environment override')
 os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:4]))
def verified_manifest(path):
 require(sha(path)==MANIFEST_SHA,'manifest SHA')
 m=json.loads(Path(path).read_text())
 require(m['contract']=='audit-checkout-retention-preparation-v1' and m['source_count']==7,'manifest contract')
 require([s['id'] for s in m['sources']]==['source-'+str(i).zfill(2) for i in range(1,8)],'source IDs')
 return m
def verify_payload(archive,m):
 require(sha(archive)==ARCHIVE_SHA,'archive SHA')
 objects={}
 for s in m['sources']:
  require(len({r['path'] for r in s['entries']})==len(s['entries']),'duplicate source entry')
  for r in s['entries']:
   p=Path(r['path'])
   require(not p.is_absolute() and '..' not in p.parts,'invalid path')
   if r['kind']=='file':
    digest=r['sha256'];require(len(digest)==64 and set(digest)<=set('0123456789abcdef'),'invalid object SHA')
    require(digest not in objects or objects[digest]==r['bytes'],'conflicting member size')
    objects[digest]=r['bytes']
 require(len(objects)==m['unique_members']==14099,'unique payload count')
 with zipfile.ZipFile(archive) as z:
  require(len(z.namelist())==len(set(z.namelist()))==len(objects),'ZIP member uniqueness')
  require(set(z.namelist())=={'objects/'+d for d in objects},'ZIP coverage')
  for digest,n in objects.items():
   info=z.getinfo('objects/'+digest);require(not info.is_dir() and info.file_size==n,'ZIP size/type')
   d=hashlib.sha256();size=0
   with z.open(info) as f:
    for b in iter(lambda:f.read(1048576),b''):d.update(b);size+=len(b)
   require(d.hexdigest()==digest and size==n,'ZIP decompression mismatch')
 return dict(members=len(objects),raw_bytes=sum(objects.values()),archive_sha256=ARCHIVE_SHA,manifest_sha256=MANIFEST_SHA)
def verified_profile(path,manifest):
 require(sha(path)==PROFILE_SHA,'normalization profile SHA')
 p=json.loads(Path(path).read_text())
 require(p['contract']=='audit-normalization-profile-v1' and p['manifest_sha256']==MANIFEST_SHA,'profile contract')
 require(len(p['sources'])==7 and {s['id'] for s in p['sources']}=={s['id'] for s in manifest['sources']},'profile coverage')
 for s in manifest['sources']:
  row=next(x for x in p['sources'] if x['id']==s['id']);entries={r['path']:r for r in s['entries']}
  require(row['original_path']==s['original_path'] and row['head']==s['preflight']['records']['head']['stdout'].strip(),'profile source identity')
  require(row['index_sha256']==entries['.git/index']['sha256'],'profile index identity')
  require(len({x['path'] for x in row['candidates']})==len(row['candidates']),'profile duplicate candidates')
  for c in row['candidates']:
   require(c['raw_oid']==c['index_oid'] and c['filtered_oid']!=c['raw_oid'],'profile candidate relation')
   require(c['path'] in entries and c['raw_sha256']==entries[c['path']]['sha256'] and c['bytes']==entries[c['path']]['bytes'],'profile candidate bytes')
   require(c['attributes'].get('filter') in (None,'unset','unspecified') and c['cached_attributes'].get('filter') in (None,'unset','unspecified'),'external filter forbidden')
 return p
def path_attributes(root,path,cached=False):
 result=git(root,'check-attr',*(('--cached',) if cached else ()), '--all','-z','--',path)
 require(result['exit_code']==0,'check-attr failed')
 parts=result['stdout'].rstrip('\0').split('\0') if result['stdout'] else []
 require(len(parts)%3==0,'attribute tuple count')
 attributes={}
 for i in range(0,len(parts),3):
  require(parts[i]==path,'attribute path')
  attributes[parts[i+1]]=parts[i+2]
 return attributes
def status_equivalence(root,source,result,profile):
 expected=source['preflight']['records']['status']
 require(expected['exit_code']==0 and result['exit_code']==0,'Git status failed')
 if expected['stdout']==result['stdout']:return dict(kind='EXACT_PORCELAIN_MATCH',added_count=0,profile_sha256=PROFILE_SHA)
 matches=[x for x in profile['sources'] if x['id']==source['id']]
 require(len(matches)==1,'unregistered profile source');binding=matches[0]
 require(source['original_path']==binding['original_path'] and source['preflight']['records']['head']['stdout'].strip()==binding['head'],'profile source/HEAD binding')
 require(sha(root/'.git/index')==binding['index_sha256'],'profile whole-index binding')
 before=expected['stdout'].splitlines();after=result['stdout'].splitlines();before_set=set(before)
 candidates={' M '+r['path']:r for r in binding['candidates']}
 added=[line for line in after if line not in before_set]
 require(added and len(added)==len(set(added)) and all(line in candidates for line in added),'unregistered/duplicate/non-M Git status addition')
 require([line for line in after if line not in set(added)]==before,'existing Git status changed or disappeared')
 details=[]
 for line in added:
  row=candidates[line];rel=row['path'];p=root/rel
  require(p.stat().st_size==row['bytes'] and sha(p)==row['raw_sha256'],'profile raw file changed')
  # Check attributes BEFORE invoking Git's filtered hash path; external filters remain forbidden.
  attrs=path_attributes(root,rel);cached=path_attributes(root,rel,True)
  require(attrs==row['attributes'] and cached==row['cached_attributes'],'profile attributes changed')
  require(attrs.get('filter') in (None,'unset','unspecified') and cached.get('filter') in (None,'unset','unspecified'),'external filter forbidden')
  entry=git(root,'ls-files','--stage','--',rel)
  require(entry['exit_code']==0 and entry['stdout']==row['mode']+' '+row['index_oid']+' 0\t'+rel+'\n','profile index entry')
  raw=git(root,'hash-object','--no-filters',rel);filtered=git(root,'hash-object','--path='+rel,rel)
  require(raw['exit_code']==filtered['exit_code']==0 and raw['stdout'].strip()==row['raw_oid']==row['index_oid'] and filtered['stdout'].strip()==row['filtered_oid']!=row['index_oid'],'profile Git blob relation')
  details.append(dict(status_line=line,profile_entry=row))
 return dict(kind='EXACT_BYTES_WITH_PROFILED_GIT_STATUS_DIFFERENCES',added_count=len(added),added=details,profile_sha256=PROFILE_SHA,explanation='Only pre-profiled raw==index but filtered!=index paths newly report worktree M after stat-cache refresh; no source/index/attribute normalization was performed.')
def verify_restored(root,source,profile):
 checked=verify_tree(root,source['entries']);independent_git(root)
 c=source['preflight'];head=git(root,'rev-parse','HEAD');status=git(root,'status','--porcelain=v1','-uall');refs=git(root,'show-ref','--head');fsck=git(root,'fsck','--full')
 require(head['exit_code']==0 and head['stdout']==c['records']['head']['stdout'],'restored HEAD')
 require(refs['exit_code']==c['records']['refs']['exit_code'] and refs['stdout']==c['records']['refs']['stdout'],'restored refs')
 equivalence=status_equivalence(root,source,status,profile)
 require(fsck['exit_code']==0,'restored fsck')
 # Git read operations must not silently rewrite even the archived index/cache bytes.
 verify_tree(root,source['entries'])
 return dict(recorded_at=now(),status='PASS_EXACT_BYTES_AND_GIT_RESTORATION_V3',contract='audit-checkout-restore-v3-profiled-stat-differences',id=source['id'],original_path=source['original_path'],restored_path=str(root),entries=checked,head=head,git_status=status,status_equivalence=equivalence,refs=refs,fsck=fsck,archive_sha256=ARCHIVE_SHA,manifest_sha256=MANIFEST_SHA,originals_removed=False,qualification='Exact source/Git bytes and listed metadata; excludes original inode/ctime/atime and any new build, EMU or performance qualification')
def main():
 import argparse
 p=argparse.ArgumentParser(description='Verify the pinned seven-source backup or restore one source to a NEW Linux directory. Never removes a directory.')
 p.add_argument('--archive',type=Path,default=Path(__file__).parent/'payload.zip')
 p.add_argument('--manifest',type=Path,default=Path(__file__).parent/'manifest.json')
 p.add_argument('--profile',type=Path,default=Path(__file__).parent/'normalization-profile.json')
 p.add_argument('--source-id',choices=['source-'+str(i).zfill(2) for i in range(1,8)])
 p.add_argument('--restore-to',type=Path)
 p.add_argument('--receipt',type=Path,help='Optional new JSON receipt outside the restored tree')
 a=p.parse_args();environment_gate()
 require(bool(a.source_id)==bool(a.restore_to),'source-id and restore-to must be supplied together')
 m=verified_manifest(a.manifest);profile=verified_profile(a.profile,m);payload=verify_payload(a.archive,m)
 report=dict(recorded_at=now(),status='PASS_READ_ONLY_BACKUP_VERIFY',payload=payload,sources=[dict(id=s['id'],original_path=s['original_path']) for s in m['sources']])
 if a.restore_to is not None:
  target=a.restore_to.resolve();require(not target.exists() and not target.is_symlink(),'restore target exists')
  for s in m['sources']:
   original=Path(s['original_path']).resolve()
   require(not target.is_relative_to(original) and not original.is_relative_to(target),'restore target overlaps original')
  require(not a.archive.resolve().is_relative_to(target) and not a.manifest.resolve().is_relative_to(target),'target overlaps backup')
  source=next(s for s in m['sources'] if s['id']==a.source_id)
  with zipfile.ZipFile(a.archive) as z:restore(target,source['entries'],z)
  report=verify_restored(target,source,profile)
 if a.receipt is not None:
  require(a.restore_to is None or not a.receipt.resolve().is_relative_to(a.restore_to.resolve()),'receipt must be outside restored tree')
  require(all(not a.receipt.resolve().is_relative_to(Path(s['original_path']).resolve()) for s in m['sources']),'receipt must be outside all original source trees')
  save(a.receipt,report)
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()


