#!/usr/bin/env python3
"""Verify or restore the retained T17 generated C++ cache to a NEW directory."""
from pathlib import Path
import argparse,hashlib,json,os,stat,zipfile
ARCHIVE_SHA='d7027b4bf97082eaaa13baa295d712fe5d8c2dcf52ddf72254752978fcf501b8'
MANIFEST_SHA='30bc3521614873922d89d11aa96d9b06a0f538b7adacc382bdd7b0b9edff87d6'
def require(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def main():
 cli=argparse.ArgumentParser(description=__doc__)
 cli.add_argument('--archive',type=Path,default=Path(__file__).parent/'t17-generated-cpp-h.zip')
 cli.add_argument('--manifest',type=Path,default=Path(__file__).parent/'manifest.json')
 cli.add_argument('--restore-to',type=Path,help='new directory only; omitted means read-only verification')
 a=cli.parse_args()
 require(sha(a.manifest)==MANIFEST_SHA,'manifest SHA mismatch')
 m=json.loads(a.manifest.read_text());rows=m['members']
 require(m['status']=='PASS_LOSSLESS_CACHE_RETENTION' and len(rows)==324,'invalid retention manifest')
 require(sha(a.archive)==ARCHIVE_SHA==m['archive_sha256'],'archive SHA mismatch')
 require(len({x['name'] for x in rows})==324,'duplicate manifest members')
 require(all(Path(x['name']).name==x['name'] and x['name'] not in ('.','..') for x in rows),'invalid member path')
 if a.restore_to is not None:
  require(not a.restore_to.exists(),'restore target must not already exist')
  a.restore_to.mkdir(parents=False)
 restored=[];total=0
 with zipfile.ZipFile(a.archive) as z:
  names=z.namelist()
  require(len(names)==len(set(names))==324 and set(names)=={r['name'] for r in rows},'archive member set mismatch')
  for r in rows:
   member=z.getinfo(r['name']);require(not member.is_dir() and member.file_size==r['bytes'],'member size/type mismatch')
   d=hashlib.sha256();count=0
   dst=(a.restore_to/r['name']).open('xb') if a.restore_to is not None else None
   try:
    with z.open(member) as src:
     for b in iter(lambda:src.read(1048576),b''):
      d.update(b);count+=len(b)
      if dst is not None:dst.write(b)
   finally:
    if dst is not None:dst.close()
   require(d.hexdigest()==r['sha256'] and count==r['bytes'],'member content mismatch: '+r['name'])
   if a.restore_to is not None:
    p=a.restore_to/r['name']
    os.chmod(p,stat.S_IMODE(r['mode']));os.utime(p,ns=(r['mtime_ns'],r['mtime_ns']))
    require(sha(p)==r['sha256'],'restored file differs: '+r['name']);restored.append(r['name'])
   total+=count
 report=dict(status='PASS',mode='restore-to-new-directory' if a.restore_to is not None else 'read-only-verify',members=len(rows),raw_bytes=total,archive_sha256=ARCHIVE_SHA,restored_files=len(restored),scope='Generated C++/headers only; excludes object/PCH caches and does not grant build/EMU qualification')
 if a.restore_to is not None:
  with (a.restore_to/'restore-receipt.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()

