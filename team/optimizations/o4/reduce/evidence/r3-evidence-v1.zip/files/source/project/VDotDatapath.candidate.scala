package xiangshan.backend.fu.vector

import chisel3._
import chisel3.util._

/** Eight signed byte products for the vdot-s8x8-r32-v0.1 contract.
  * Lane 0 is bits 7:0; bits 127:64 of both operands are ignored.
  * This combinational module can precede the wrapper's product registers.
  */
class VDotProducts extends RawModule {
  val io = IO(new Bundle {
    val vs1 = Input(UInt(128.W))
    val vs2 = Input(UInt(128.W))
    val products = Output(Vec(8, SInt(16.W)))
  })

  for (lane <- 0 until 8) {
    val a = io.vs1(8 * lane + 7, 8 * lane).asSInt
    val b = io.vs2(8 * lane + 7, 8 * lane).asSInt
    io.products(lane) := a * b
  }
}

/** Carry-save reduction modulo 2^19, followed by one carry-propagating add.
  * Eight arbitrary signed 16-bit values fit exactly in a signed 19-bit result.
  * The public low-32 sign extension and high-96 zero contract is unchanged.
  */
class VDotReduce extends RawModule {
  val io = IO(new Bundle {
    val products = Input(Vec(8, SInt(16.W)))
    val result = Output(UInt(128.W))
  })

  private val width = 19
  private def compress(a: UInt, b: UInt, c: UInt): Seq[UInt] = {
    val sum = a ^ b ^ c
    val majority = (a & b) | (a & c) | (b & c)
    // The discarded carry is modulo 2^19, not a signed saturating operation.
    val carry = Cat(majority(width - 2, 0), 0.U(1.W))
    Seq(sum, carry)
  }
  private def layer(terms: Seq[UInt]): Seq[UInt] =
    terms.grouped(3).flatMap {
      case Seq(a, b, c) => compress(a, b, c)
      case remaining => remaining
    }.toSeq

  private val terms = io.products.map(x => x.pad(width).asUInt).toSeq
  private val six = layer(terms)
  private val four = layer(six)
  private val three = layer(four)
  private val two = layer(three)
  require(two.length == 2)
  private val sum19 = (two(0) + two(1))(width - 1, 0).asSInt
  private val result32 = Wire(SInt(32.W))
  result32 := sum19
  io.result := Cat(0.U(96.W), result32.asUInt)
}

/** Combinational arithmetic top for independent verification.
  * The future functional-unit wrapper instantiates the same two submodules
  * separately, with registers between them; this top has no cycle protocol.
  */
class VDotDatapath extends RawModule {
  val io = IO(new Bundle {
    val vs1 = Input(UInt(128.W))
    val vs2 = Input(UInt(128.W))
    val result = Output(UInt(128.W))
  })

  private val products = Module(new VDotProducts)
  private val reduce = Module(new VDotReduce)

  products.io.vs1 := io.vs1
  products.io.vs2 := io.vs2
  reduce.io.products := products.io.products
  io.result := reduce.io.result
}
