# P2：观察器语义与调用路径归因边界

结论：P1 的既有记录足以支持“额外差异集中在 split_full → leaf 间接调用触发预测纠正的到达区间”。不能把该区间的 8–10 拍差直接命名为某个 BTB 的固定恢复延迟，也不能用它预测修订后的加速比。本轮没有新仿真或 RTL 变更。

## 已完成的独立核对

- 11 个相关源文件与实际 clean-02 EMU 来源逐字节 SHA256 相同，见 observer-semantics.json。
- P1 normal/replay 的整个 stderr SHA256 相同（b4df356175d3dd69b53d49029f03de501961085f935b945b5818d65b6e6819aa），不是只比较均值。
- 全日志 11,425 对 ROB/VFEX4 重定向均为同一 ROB/self，父级恰晚一拍；没有把两个阶段重复算成两个纠错。
- 12 个正式 S-V 窗口首条最终退休 vdot 的 ENQUEUE→ACCEPT 均为 19 拍，PC 均为 0x80001644；快窗 CSR→ENQUEUE 为 77–79 拍，慢窗为 87 拍。因此主要新增差异已在首 vdot 到达 ROB 前出现，不能解释为该 vdot 在 FU 内多算了 9 拍。
- 原 segment.py 对本条完整轨迹未发现影响已报告结论的重要问题；其结果仍是区间定位，单凭它不能认定分支原因。

## 各事件到底表示什么

源路径均相对仓库或实际 EMU 来源根；具体摘录与 SHA 在配套 JSON。

| 事件 | 真正观测点 | 能说明与不能说明 |
| --- | --- | --- |
| T13_CSR_SAMPLE | NewCSR.scala:1041–1045，io.in.fire && ren，CSR c00/c02 | CSR 执行侧读数；不是该指令退休时间。周期差可与同钟 GTimer 差核对。 |
| T13_COUNTER_ENQUEUE | Rob.scala:1484–1488，canEnqueue 的 counter read | ROB 分配时 empty/waitForward/blockBackward；不是 counter issue/read。 |
| T13_RETIRE | Rob.scala:1491–1501，isCommit && commitValid | ROB 实际退休。count 可大于 1，压缩/融合组不能当单条指令；相邻退休间隔不是单指令执行或访存延迟。 |
| O2_ENQUEUE | Rob.scala:1552–1555，VDot 分配且 !redirect | 记录 ROB/FTQ/PC/word。身份必须加分配代次；ROB 值会重复。 |
| O2_ACCEPT | ExeUnit.scala:523–524，实际 elasticVDot.io.in.fire | FU 实际接收；seq 在所有 VFEX4 接收（含 DIV）时递增。 |
| O2_RESPONSE | ExeUnit.scala:538–539，实际 vdot.out.fire | 结果从 FU 进入父级输出接口；不是 ROB 退休。 |
| O2_REDIRECT | Rob.scala:1564–1565 | ROB 的 s1_s3_redirect；打印 ROB/FTQ/self，未打印原因、PC、预测/真实目标。 |
| O2_VFEX4_REDIRECT | ExeUnit.scala:519–521 | 真正到 VFEX4 的 flush；由 CtrlBlock.scala:121 的 RegNext，晚 ROB 一拍。 |

GTimer（utility/GTimer.scala:21–26）是各模块本地复位清零的 +1 计数器，不是一个共享全局寄存器。观察器禁止 ResetGen，VFEX4 观察器在不门控父时钟上；既有 schema 与全轨迹校验支持本次同周期比较。不能任意给不同模块再补偏移。

本次 leaf 入口后出现的 9/9/9 是相邻指定指令的**退休观察间隔**，不能写成三条 CSR/vset 指令固定各执行 9 拍；首个 leaf 退休 bundle 之前的区间同样混合供指、寄存器/上下文读取、调度与退休，不能统称纯前端延迟。

## 为何可以收紧到间接调用预测纠正

慢窗中的额外重定向要先通过独立动态绑定：origin 在相应 ROI 唯一后续同 ROB 正常退休、self=0、无中间杀死该 origin 的更老重定向；实际指令字 0x000700e7 对应 0x800015ac 的 jalr ra,0(a4)。本次从计时 CSR 至此退休不足 48 个 ROB 条目且无重复，可避免跨圈误配。不能在任意长日志里直接找最后一个同 ROB 的 PC。

源码支持链如下：

1. DecodeUnit.scala:202 把 JALR 送至 FuType.jmp，XSDecode.flushPipe 默认 false（:94–109）。
2. JumpUnit.scala:30–46 的纠错条件为 actualTarget != predictInfo.target || !predictInfo.taken；:37 固定为 flushAfter（self=0）。
3. CtrlBlock.scala:190–203 只把有效 EXU 重定向中的 isMisPred 或后端取指异常送入选择器；:211–216 的另一来源是内存违规重放。RedirectGenerator.scala:42–51、:70–74 选最老并寄存。
4. CtrlBlock.scala:103–112 还会优先选择 ROB flush。Rob.scala:609–615 中异常、中断和 replay 为 flush/self=1；普通 JALR 不要求 flushPipe。绑定的是正常退休 JALR，故本次 self=0 记录不能解释为访存违规、异常或 JALR 主动清流水线。

因此可写：“该额外记录是间接调用 JALR 的控制流预测纠正；差异位于它通向 leaf 的到达区间。”这是日志身份与源语义合并的归因，**不是日志直接打印了 isMisPred 原因位**。没有 predicted target、predTaken、表项 hit/miss、前端供指恢复时刻，无法进一步区分预测为不跳转和目标错，也不能指定 BTB/TAGE/RAS 表污染或 I-cache miss。

## 对修订 P1 的建议

有依据考虑一次最小、对称的软件调用层修订或干预，不需要据此改 vdot RTL。若去除共享可变目标调用点，应同时覆盖 packed/split 与全部 RVV 对照，保留输入准备、输出消费、计时边界和预设门槛；旧 P1 HOLD 永久保留，新版本另立身份。原记录只给出了修订方向，不能先验保证修订会减少完整窗口周期、锚点必过或自动扩大测试。

本文件不代替 trace 子任务的逐窗绑定和静态子任务的具体设计；本次没有重新授予 P1 性能采用资格。
