# P2 静态调用链与最小修订设计

本项只读核查 P1 的最终 ELF、冻结源和旧诊断，不运行 EMU/NEMU，不改变旧 P1 HOLD。调用链各条指令的反汇编已逐字与 ELF 可执行 PT_LOAD 内容交叉核验。

## 实际调用链

| 段 | 实际 PC | 内容 |
| --- | --- | --- |
| 开始周期 CSR | 0x80000a7c | rdcycle a6；计时器48B栈框已在窗外建立 |
| 计时器→完整包装 | 0x80000a80–0x80000a90 | fence、3个mv、jalr s4；s4只有packed_full/split_full两个目标 |
| split_full→leaf | 0x80001580–0x800015ac | 窗内32B栈框，保存s0/s1/ra，捕获A/x/y/slots/entry，jalr a4 |
| leaf起始 | 0x800015f0–0x80001640 | 参数重排；vstart/vcsr/vtype；4次x和4次A向量load |
| 首条vdot | 0x80001644 | 0x0388000b，读v16/v24 |

开始cycle读之后至首vdot之前共有38条静态指令（5＋12＋21）。这是指令条数，不能转换成38拍。首vdot只直接依赖v16/v24，不能把前面所有load的退休时间相加称为算术延迟。

steady packed在计时窗内复制32B变化x、A只在stream开头准备；split无输入复制。两者都计入完整调用与8个INT32提取，且验证128B全宽槽。

## conditioning 与历史

main.c:178–180 每次将conditioner的entry设为split_entries[4]（RVV3），然后调用同一split_full。最终机器码0x800067f0/0x800067f4生成RVV3地址0x80002250，0x80006824/0x80006828调用0x80001580；因而conditioner与计时split共享0x800015ac。main.c:211–214在condition之后才prepare并计时。

| seq | round / 顺序 / kind | 前一计时实现 | 首vdot接受前cycles |
| ---: | --- | --- | ---: |
| 0 | 0 / forward / 1 | NONE_WITHIN_TIMING_PHASE | 120 |
| 7 | 0 / forward / 0 | P-R4 | 112 |
| 13 | 0 / forward / 2 | S-R4 | 106 |
| 14 | 1 / reverse / 1 | S-V | 96 |
| 20 | 1 / reverse / 0 | S-R0 | 106 |
| 27 | 1 / reverse / 2 | P-V | 98 |
| 28 | 2 / forward / 1 | S-V | 97 |
| 35 | 2 / forward / 0 | P-R4 | 98 |
| 41 | 2 / forward / 2 | S-R4 | 106 |
| 42 | 3 / reverse / 1 | S-V | 96 |
| 48 | 3 / reverse / 0 | S-R0 | 106 |
| 55 | 3 / reverse / 2 | P-V | 97 |
| 56 | 4 / forward / 1 | S-V | 96 |
| 63 | 4 / forward / 0 | P-R4 | 97 |
| 69 | 4 / forward / 2 | S-R4 | 106 |
| 70 | 5 / reverse / 1 | S-V | 97 |
| 76 | 5 / reverse / 0 | S-R0 | 106 |
| 83 | 5 / reverse / 2 | P-V | 97 |

kind=0普通、1首锚、2尾锚；round0/1不用于正式统计。每一行在当前窗口之前都执行相同RVV3 conditioning，不只是上一计时实现。

正式慢窗41/48/69/76均106拍；但每个S-V的直接前一inner target都相同，因此不能用“直接前一个目标不同”解释。慢窗与较早的计时方法/控制流历史有关。forward普通S-V虽从packed的外层目标切到split，仍只97–98拍，简单外层切换解释也不成立。

结合动态ROB与redirect证据才能把相关性定位为内层间接调用控制流纠正；本静态结果单独不证明哪级预测器、错误目标内容或缓存原因。

## 仅建议一次修订：隔离conditioning调用点

选择A：仅为窗外conditioner增加独立generic wrapper，使其有自己的间接调用PC；保持相同RVV3、独立缓冲区、一次调用和结果检查。计时中的packed_full/split_full、两层间接调用、上下文读取、32B复制和结果提取全保留，所有12实现使用同一修改。

先冻结新合同/身份，再检验最终ELF：原计时函数和数据布局/字节尽量固定，新conditioning wrapper置于隔离追加段，仅窗外调用目标改变；若无法维持，必须明确布局混杂或另用有界同布局对照，不把跨布局周期差全归因调用点。它是测量设计干预，不是新生产API性能承诺。

沿用1%锚点、逐顺序3%收益和完整负控/正常/重放。最多这一轮有依据修订，steady-d0仍失败即停止扩大，不删样、不增加只利于vdot的预热。即使通过，也需在真实消费者固定调用历史下确认收益后才采用。

不选B作为本轮最小干预：12个算法固定full入口＋直接inner call可以对称实施，但改变P0泛型entry调用成本，外层timer可能由2目标变12目标，可能将问题转移到上层。应作为真实消费者一次选型的独立API合同，不与A混在同一试验。

## 复算

python3 -B analyze.py --out <新的输出目录>。仅读取冻结文件并生成该目录；不会修改原输入。result.json保存所有18个S-V窗口、38条指令及身份哈希。
