N source-only forward preparation, 2026-11-07. No compiler, reference or target guest was executed.
Original source snapshots, all generated controller files, binding, invocation, arguments and status are preserved.
External inputs remain identified by the original 94-pin binding; this archive is not a self-contained runtime image.
operation.json is the original ChatPC terminal receipt. execute.ps1 is the exact submitted shell wrapper.
