$ErrorActionPreference='Stop'
$entry='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runs\dot16-production-cost-20261107-main\integration-01\narrow-forward-prepare.py'
if((Get-FileHash -Algorithm SHA256 -LiteralPath $entry).Hash.ToLowerInvariant() -ne '2ce37effb4513e8b8a83cac31d1c8c77b9a3c135f08995c00bd3e5c29211769f'){throw 'Preparation wrapper identity changed'}
& wsl.exe -d Ubuntu-22.04 -- python3 -B /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-production-cost-20261107-main/integration-01/narrow-forward-prepare.py
if($LASTEXITCODE -ne 0){throw 'N source-only preparation did not pass'}
exit 0