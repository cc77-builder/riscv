# Four-arm reference preparation

GNU build and reference queue each use one coordinated CPU. Exactly four normal reference cases plus one DQ last-logit negative; each original reference owner retains 100M API calls / 600s internal / 630s external bounds. Whole-operation CPU, elapsed and output budgets must be frozen separately before execution. No target EMU entry script is included; no automatic launch or budget extension.
