"""One bounded source-only N controller preparation; no compiler/reference/EMU."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys,time,traceback
from datetime import datetime,timezone
from types import SimpleNamespace

def stamp():
    return datetime.now(timezone.utc).isoformat()
def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):
            h.update(b)
    return h.hexdigest()
def write(p,x):
    Path(p).write_text(json.dumps(x,indent=2)+'\n')
def need(ok,why):
    if not ok: raise ValueError(why)

need(sys.dont_write_bytecode,'-B required')
os.sched_setaffinity(0,{1});os.nice(5)
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole8-narrow-q288-20261107-main')
source=root/'forward-source-01'
output=root/'forward-controller-01'
audit=root/'forward-prepare-01'
public=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022/team/optimizations/o2/dot16/first-forward')
pins={
  "prepare.py": "e6f8149f2471d1ca3688583dcc64a3e5e0345552b6900fdad2c39832c9e595b7",
  "derive_extension.py": "b6aa50371a908573450f884e8fc43da33f226cb0f866228811cf6630cc62c0a1",
  "CONTRACT.md": "735df8d8053f6ff948135cd4f6b2188138d751b1f0ad9e1842ca59a44166ea59"
}
old_profile=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-first-forward-20261107-main/resource-01/profile.json')
profile_sha='b650534b8c14fe3ecb813232be47decc3a550e279352859c7ec4a1d4d4046d0b'
need(all(not p.exists() for p in (source,output,audit)),'all three outputs fresh')
need(digest(old_profile)==profile_sha,'original four-arm profile unchanged')
for name,pin in pins.items():
    need(digest(public/name)==pin,'reviewed public source '+name)
args=SimpleNamespace(
    paired_consumer=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/paired-consumer-source-01/paired-consumer'),
    base=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/paired-consumer-source-01/base'),
    config=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/paired-consumer-source-01/config.json'),
    quantize=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/attempt-02'),
    kernel_source=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole8-narrow-q288-20261107-main/image-01/source/fused.S'),
    kernel_elf=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole8-narrow-q288-20261107-main/image-01/paired16-target.elf'),
    hardware_result=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole2-q288-20261107-main/controller-01/hardware-result.json'),
    kernel='narrow',output=output)
started=stamp();tick=time.monotonic()
audit.mkdir();source.mkdir()
write(audit/'arguments.json',{k:str(v) for k,v in vars(args).items()})
(audit/'prepare_invocation.py').write_bytes(Path(__file__).read_bytes())
record=dict(status='PREPARING_SOURCE_ONLY',started=started,cpu_affinity=sorted(os.sched_getaffinity(0)),
            nice=os.getpriority(os.PRIO_PROCESS,0),public_source_pins=pins,
            source=str(source),output=str(output),old_profile=str(old_profile),
            old_profile_sha256=profile_sha,new_build_runs=0,reference_runs=0,target_emu_runs=0,
            performance_qualified=False)
write(audit/'status.json',record)
try:
    for name,pin in pins.items():
        (source/name).write_bytes((public/name).read_bytes())
        need(digest(source/name)==pin,'frozen copy '+name)
    spec=importlib.util.spec_from_file_location('narrow_first_forward_preparer',source/'prepare.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=module.prepare(args)
    need(result['status']=='FIRST_FORWARD_DOT16_CONTROLLER_BOUND_NOT_RUNTIME','source-only status')
    need(result['selected_dot16_kernel']['choice']=='narrow','explicit N')
    need(result['reference_runs']==0 and result['target_emu_runs']==0 and
         result['performance_qualified'] is False and result['target_cases']==[] and
         result['target_entry_scripts_included'] is False,'no runtime qualification')
    need(not (output/'run.py').exists() and not (output/'audit.py').exists(),'no target entries')
    generated={str(p.relative_to(output)):digest(p) for p in output.rglob('*')
               if p.is_file() and p.name!='binding.json'}
    need(generated==result['generated_files'],'all generated files read back')
    for name,pin in pins.items():
        need(digest(public/name)==pin and digest(source/name)==pin,'sources unchanged '+name)
    need(digest(old_profile)==profile_sha,'original four-arm profile still unchanged')
    record.update(status=result['status'],selected_dot16_kernel=result['selected_dot16_kernel'],
                  binding_sha256=digest(output/'binding.json'),
                  binding_bytes=(output/'binding.json').stat().st_size,
                  input_files_count=len(result['input_files']),
                  generated_files_count=len(generated),generated_files_sha256=generated,
                  reference_cases=result['reference_cases'],target_cases=result['target_cases'],
                  target_entry_scripts_included=False,source_unchanged=True,old_profile_unchanged=True)
except BaseException as error:
    record.update(status='NARROW_SOURCE_PREPARATION_FAILED',error=repr(error))
    (audit/'failure.txt').write_text(traceback.format_exc())
    raise
finally:
    record.update(finished=stamp(),elapsed_seconds=time.monotonic()-tick)
    write(audit/'status.json',record)
print(json.dumps({k:v for k,v in record.items() if k!='generated_files_sha256'},indent=2),flush=True)
