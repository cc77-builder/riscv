#!/usr/bin/env python3
"""Verify copied terminal records and exact integer UART observations.

This does not run a checker/guest or qualify a retirement/performance window.
Original target images/profile stay in the original closed run and full archive.
"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
EXPECTED = {
    'target-01/results.json': '13c45f846a8a26ad27996c6cd41faabd942da541131282f024c09dd5bb7e38f0',
    'target-01/state.json': '10f2a7a4d09ecfcecdec77cabbd8bb2b96cf3a08214c03e3a43479bc8b90f79c',
    'owner-01/state.json': '0c179518076d6b23cbf4b77926a1a7f3161a63a1929fd05b47714be7ef5bab4c',
    'original-host-receipt.json': 'f22c6f0776a9609063b042c439fd155d09f2fad173ec02cb23b7a3fa758e9d08',
}
OP = '49cbde030e5643f0cccfca5cec8a79c1.ed135ec164a525ededcc42c31676ba4a'
LOGICAL = '3eaaab12-1f79-42b3-86d9-586bdebd642c'
CASES = ('paired16', 'paired16_quantize', 'dot16', 'dot16_quantize')


def read(name):
    return json.loads((ROOT / name).read_bytes())


def pin(name):
    b = (ROOT / name).read_bytes()
    return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def main():
    for name, digest in EXPECTED.items():
        assert pin(name)['sha256'] == digest, name
    results = read('target-01/results.json')
    state = read('target-01/state.json')
    owner = read('owner-01/state.json')
    host = read('original-host-receipt.json')
    assert host['operation_id'] == host['shell']['operation_id'] == OP
    assert host['status'] == host['shell']['status'] == 'succeeded'
    receipt = host['shell']['result']
    assert receipt['exit_code'] == 0 and receipt['cleanup_complete'] is True
    assert receipt['cancelled'] is False and receipt['timed_out'] is False
    assert owner['operation_id'] == state['operation_id'] == LOGICAL
    assert owner['campaign_state_sha256'] == EXPECTED['target-01/state.json']
    assert owner['results_sha256'] == EXPECTED['target-01/results.json']
    assert not owner['changed_inputs'] and owner['cpu_release_verified'] is True
    assert owner['case_cleanup']['cleanup_verified'] is True
    assert not owner['case_cleanup']['unknown']
    assert len(owner['case_cleanup']['cases']) == 4
    assert all(c['cleanup_verified'] and not c['emu_group_present'] and
               not c['launcher_group_present'] for c in owner['case_cleanup']['cases'])
    command = read('owner-01/campaign.command.json')
    assert pin('owner-01/campaign.command.json')['sha256'] == owner['campaign_command_sha256']
    assert command['status'] == 'exited' and command['exit_code'] == 0
    assert command['direct_child_reaped'] and command['process_group_absent_after_exit']
    assert not command['cleanup_errors']
    assert results['records'] == state['records']
    assert results['new_emu_runs'] == state['new_emu_runs'] == state['known_started_emu_runs'] == 4
    assert tuple(state['launched_cases']) == CASES and set(state['completed']) == set(CASES)
    assert all(not state[k] for k in ('active', 'cleanup_unknown', 'cleanup_errors', 'launch_state_unknown'))
    for obj in (results, state, owner):
        assert obj['status'] == 'FIRST_FORWARD_W2NP_TARGET_OBSERVATIONS_COMPLETE'
        assert obj['target_correctness_qualified'] is True and obj['performance_qualified'] is False
    records = {r['name']: r for r in results['records']}
    observed = {}
    for name in CASES:
        record = records[name]
        val_path = 'target-01/' + name + '/validation.json'
        raw_path = 'target-01/' + name + '/stdout.log'
        validation = read(val_path)
        assert validation == results['validations'][name]
        assert pin(val_path)['sha256'] == record['validation_sha256']
        assert pin(raw_path) == dict(bytes=record['raw_bytes']['stdout.log'], sha256=record['raw_sha256']['stdout.log'])
        assert record['raw_bytes']['stderr.log'] == 0
        assert record['raw_sha256']['stderr.log'] == hashlib.sha256(b'').hexdigest()
        raw = (ROOT / raw_path).read_text()
        lines = [line for line in raw.splitlines() if line.startswith('CONSUMER_')]
        assert lines == validation['transcript'] and len(lines) == 3
        assert lines[0] == 'CONSUMER_BEGIN token=1 position=0'
        assert lines[2] == 'CONSUMER_PASS bytes=3691424 flags=1'
        match = re.fullmatch(r'CONSUMER_COUNTERS ([0-9]+) ((?:[0-9a-f]{16} ){3}[0-9a-f]{16})', lines[1])
        assert match and int(match[1]) == record['method'] == validation['method']
        words = match[2].split()
        values = [int(word, 16) for word in words]
        sample = dict(cycles=values[3] - values[0], instret=values[2] - values[1])
        assert values == validation['counter_values'] and words == validation['counter_hex']
        assert validation['samples'] == [sample] == validation['counter_audit']['samples']
        assert validation['counter_audit']['counter_values'] == values
        assert validation['counter_audit']['counter_hex'] == words
        assert 0 < sample['cycles'] < record['max_cycles'] and 0 < sample['instret'] < 2**32
        assert validation['flags'] == 1 and validation['trap_pc'] == '0x8000013c'
        assert 'HIT GOOD TRAP at pc = 0x8000013c' in raw and 'Difftest enabled.' in raw
        assert validation['counter_retirement_verified'] is False
        assert validation['full_retirement_window_audited'] is False
        assert validation['performance_qualified'] is False
        observed[name] = dict(**sample, guest_total_cycles=validation['guest_cycles'],
                              counter_hex=words, validation=pin(val_path), stdout=pin(raw_path))
    p, pq, n, nq = [observed[k]['cycles'] for k in CASES]
    assert pq < p and nq < n
    report = dict(status='CLOSED_SUMMARY_BYTES_AND_UART_INTEGER_DIFFERENCES_VERIFIED',
                  scope='Read-only terminal record audit; no new target run or expanded qualification.',
                  inputs={k: pin(k) for k in EXPECTED}, original_operation=OP,
                  original_logical_operation=LOGICAL, original_started=host['shell']['started_at'],
                  original_finished=host['shell']['updated_at'], observations=observed,
                  comparison=dict(faster_rvv='paired16_quantize', faster_dot16='dot16_quantize',
                                  cycle_ratio_numerator=pq, cycle_ratio_denominator=nq,
                                  cycle_ratio=pq/nq, cycle_reduction_percent=100*(1-nq/pq)),
                  target_correctness_qualified=True, performance_qualified=False,
                  full_retirement_window_audited=False,
                  original_images_rehashed_in_this_audit=False, new_emu_runs=0,
                  transport_note='Initial shell text copy was redacted at the literal test token=1 and failed SHA. '
                                 'These exact files were exported from the closed run, then read with the dedicated '
                                 'binary file tool and verified against full original SHA256; the initial copy is retained separately.')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
