static void complete_compare(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    const unsigned words=R2_CONSUMER_STATE_BYTES/8;
    unsigned i=0,suspect=words;
    for(;i+8<=words;i+=8) {
        alias_word difference=(actual[i]^gold[i])|(actual[i+1]^gold[i+1])|
            (actual[i+2]^gold[i+2])|(actual[i+3]^gold[i+3])|
            (actual[i+4]^gold[i+4])|(actual[i+5]^gold[i+5])|
            (actual[i+6]^gold[i+6])|(actual[i+7]^gold[i+7]);
        if(difference) {suspect=i;break;}
    }
    for(;i<words;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    if(suspect!=words)reject(95,suspect*8);
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}
