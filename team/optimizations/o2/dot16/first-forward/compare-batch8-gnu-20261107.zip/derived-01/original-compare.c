static void complete_compare(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    for(unsigned i=0;i<R2_CONSUMER_STATE_BYTES/8;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}
