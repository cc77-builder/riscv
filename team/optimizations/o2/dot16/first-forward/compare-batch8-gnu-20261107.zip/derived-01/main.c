/* First full forward: method load and dispatch are included; validation/UART are outside. */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <klib.h>
#include "consumer_w2.h"
extern float *r2_w2_gs32_forward(struct r2_consumer_state *,int,int);
extern float *r2_w2_paired16_forward(struct r2_consumer_state *,int,int);
extern float *r2_w2_paired16_quantize_forward(struct r2_consumer_state *,int,int);
extern float *r2_w2_dot16_forward(struct r2_consumer_state *,int,int);
extern float *r2_w2_dot16_quantize_forward(struct r2_consumer_state *,int,int);

extern unsigned char fixture_w2_packed[],fixture_w2_packed_end[];
extern unsigned char fixture_weights[],fixture_weights_end[],fixture_embedding[],fixture_embedding_end[];
extern unsigned char fixture_packed[],fixture_packed_end[],fixture_tail_scales[],fixture_tail_scales_end[],fixture_gold[];
__thread int errno;
uintptr_t __stack_chk_guard=UINT64_C(0x9157a6c2d384ef09);
unsigned char team_tls_area[96] __attribute__((aligned(16)));
/* Private experiment selector, application negative, UART; old public enum is unchanged. */
volatile uint32_t target_control[3] __attribute__((section(".data"),used))={3,0,1};
volatile uint64_t target_report[64];
struct target_guarded_state { uint64_t before[2]; struct r2_consumer_state state; uint64_t after[2]; };
struct target_guarded_state target_guarded __attribute__((aligned(16)));
_Static_assert(offsetof(struct target_guarded_state,state)==16 && sizeof(struct target_guarded_state)==R2_CONSUMER_STATE_BYTES+32,"exact state guard layout");
#define target_state target_guarded.state
#define TARGET_GUARD UINT64_C(0xb5e9c13f6a0742d8)
static unsigned uart,method,negative;
typedef uint64_t alias_word __attribute__((may_alias));

__attribute__((noreturn,noinline,noclone)) static void reject(unsigned code,unsigned byte) {
    target_report[3]=code;target_report[9]=byte;
    if(uart)printf("CONSUMER_REJECT code=%u byte=%u\n",code,byte);
    __asm__ volatile("mv a0,%0\n.word 0x0005006b"::"r"((uintptr_t)code):"a0","memory");
    for(;;) {}
}
__attribute__((noreturn)) void __stack_chk_fail(void) {reject(90,0);}
static void check(int ok,unsigned code) {if(!ok)reject(code,0);}
static unsigned fcsr(void) {unsigned value;__asm__ volatile("csrr %0,fcsr":"=r"(value));return value;}
static uint64_t cycle(void) {uint64_t v;__asm__ volatile("fence iorw,iorw\nrdcycle %0\nfence iorw,iorw":"=r"(v)::"memory");return v;}
static uint64_t instret(void) {uint64_t v;__asm__ volatile("fence iorw,iorw\nrdinstret %0\nfence iorw,iorw":"=r"(v)::"memory");return v;}
static void tls_check(void) {
    uintptr_t tp,address;__asm__ volatile("mv %0,tp":"=r"(tp));
    __asm__ volatile("mv %0,%1":"=r"(address):"r"(&errno));
    check(tp==(uintptr_t)(team_tls_area+16) && address==tp+FULL_ERRNO_OFFSET,80);
    for(unsigned i=0;i<16;++i)check(team_tls_area[i]==0x6b && team_tls_area[80+i]==0xa7,81);
}
static void complete_compare(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    const unsigned words=R2_CONSUMER_STATE_BYTES/8;
    unsigned i=0,suspect=words;
    for(;i+8<=words;i+=8) {
        alias_word difference=(actual[i]^gold[i])|(actual[i+1]^gold[i+1])|
            (actual[i+2]^gold[i+2])|(actual[i+3]^gold[i+3])|
            (actual[i+4]^gold[i+4])|(actual[i+5]^gold[i+5])|
            (actual[i+6]^gold[i+6])|(actual[i+7]^gold[i+7]);
        if(difference) {suspect=i;break;}
    }
    for(;i<words;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    if(suspect!=words)reject(95,suspect*8);
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}
/* Method load, validation and dispatch are entirely inside the measured call. */
__attribute__((noinline,noclone)) static float *first_forward_dispatch(void) {
    method=target_control[0];
    switch(method) {
        case 3u: return r2_w2_forward(&target_state,R2_FR_CACHE,1,0);
        case 0x47533332u: return r2_w2_gs32_forward(&target_state,1,0);
        case 0x50313631u: return r2_w2_paired16_forward(&target_state,1,0);
        case 0x50535131u: return r2_w2_paired16_quantize_forward(&target_state,1,0);
        case 0x44313631u: return r2_w2_dot16_forward(&target_state,1,0);
        case 0x44313651u: return r2_w2_dot16_quantize_forward(&target_state,1,0);
        default: reject(88,0);
    }
}
int team_forward_main(void) {
    negative=target_control[1];uart=target_control[2];
    target_report[0]=UINT64_C(0x5233443136465731);target_report[1]=1;target_report[2]=0;target_report[3]=1;
    target_report[4]=1;target_report[5]=negative;target_report[6]=uart;
    check(negative<=1 && uart<=1,82);
    uintptr_t status,vlenb;__asm__ volatile("csrr %0,mstatus\ncsrr %1,vlenb":"=r"(status),"=r"(vlenb));
    check((status&0x6000)!=0 && (status&0x600)!=0 && vlenb==16 && errno==0,83);
    target_report[10]=status;target_report[11]=vlenb;
    for(unsigned i=0;i<16;++i){team_tls_area[i]=0x6b;team_tls_area[80+i]=0xa7;}tls_check();
    for(unsigned i=0;i<2;++i)target_guarded.before[i]=target_guarded.after[i]=TARGET_GUARD;
    check(r2_w2_init(fixture_weights,fixture_weights_end-fixture_weights,
        fixture_embedding,fixture_embedding_end-fixture_embedding,fixture_packed,fixture_packed_end-fixture_packed,
        fixture_tail_scales,fixture_tail_scales_end-fixture_tail_scales,
        fixture_w2_packed,fixture_w2_packed_end-fixture_w2_packed)==0,84);
    if(uart)printf("CONSUMER_BEGIN token=1 position=0\n");
    errno=12345;__asm__ volatile("csrwi fcsr,0":::"memory");
    uint64_t c0=cycle(),i0=instret();
    __asm__ volatile(".global first_forward_call_begin\nfirst_forward_call_begin:":::"memory");
    float *logits=first_forward_dispatch();
    __asm__ volatile(".global first_forward_call_end\nfirst_forward_call_end:":::"memory");
    uint64_t i1=instret(),c1=cycle();unsigned flags=fcsr();
    target_report[2]=method;target_report[16]=c0;target_report[17]=i0;target_report[18]=i1;target_report[19]=c1;target_report[20]=flags;
    check(logits==target_state.logits && errno==12345 && flags==1,85);tls_check();
    check(c1>c0 && i1>i0 && c1-c0<UINT32_MAX && i1-i0<UINT32_MAX,86);target_report[7]=1;
    for(unsigned i=0;i<2;++i)check(target_guarded.before[i]==TARGET_GUARD && target_guarded.after[i]==TARGET_GUARD,87);
    target_report[21]=1;
    if(uart) {
        printf("CONSUMER_COUNTERS %u %08x%08x %08x%08x %08x%08x %08x%08x\n",method,
            (unsigned)(c0>>32),(unsigned)c0,(unsigned)(i0>>32),(unsigned)i0,
            (unsigned)(i1>>32),(unsigned)i1,(unsigned)(c1>>32),(unsigned)c1);
    }
    if(negative)((unsigned char*)&target_state.logits[31999])[0]^=1;
    complete_compare();
    if(uart)printf("CONSUMER_PASS bytes=%u flags=%u\n",R2_CONSUMER_STATE_BYTES,flags);
    target_report[3]=0;return 0;
}
