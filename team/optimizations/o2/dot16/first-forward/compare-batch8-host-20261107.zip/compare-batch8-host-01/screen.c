#define _GNU_SOURCE
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <sys/mman.h>
#include <unistd.h>
typedef uint64_t alias_word __attribute__((may_alias));
static unsigned char *actual_base,*fixture_gold;
#define target_state (*actual_base)
static volatile uint64_t target_report[64];
static volatile unsigned trap_code,trap_byte;
static jmp_buf trap;
__attribute__((noreturn,noinline,noclone)) static void reject(unsigned c,unsigned b) {
    trap_code=c;trap_byte=b;longjmp(trap,1);
}

#define R2_CONSUMER_STATE_BYTES 160u
__attribute__((noinline,noclone)) static void old_small(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    for(unsigned i=0;i<R2_CONSUMER_STATE_BYTES/8;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}
__attribute__((noinline,noclone)) static void new_small(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    const unsigned words=R2_CONSUMER_STATE_BYTES/8;
    unsigned i=0,suspect=words;
    for(;i+8<=words;i+=8) {
        alias_word difference=(actual[i]^gold[i])|(actual[i+1]^gold[i+1])|
            (actual[i+2]^gold[i+2])|(actual[i+3]^gold[i+3])|
            (actual[i+4]^gold[i+4])|(actual[i+5]^gold[i+5])|
            (actual[i+6]^gold[i+6])|(actual[i+7]^gold[i+7]);
        if(difference) {suspect=i;break;}
    }
    for(;i<words;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    if(suspect!=words)reject(95,suspect*8);
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}

#undef R2_CONSUMER_STATE_BYTES

#define R2_CONSUMER_STATE_BYTES 3691424u
__attribute__((noinline,noclone)) static void old_full(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    for(unsigned i=0;i<R2_CONSUMER_STATE_BYTES/8;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}
__attribute__((noinline,noclone)) static void new_full(void) {
    _Static_assert(R2_CONSUMER_STATE_BYTES%8==0,"complete word comparison");
    const alias_word *actual=(const alias_word*)&target_state,*gold=(const alias_word*)fixture_gold;
    const unsigned words=R2_CONSUMER_STATE_BYTES/8;
    unsigned i=0,suspect=words;
    for(;i+8<=words;i+=8) {
        alias_word difference=(actual[i]^gold[i])|(actual[i+1]^gold[i+1])|
            (actual[i+2]^gold[i+2])|(actual[i+3]^gold[i+3])|
            (actual[i+4]^gold[i+4])|(actual[i+5]^gold[i+5])|
            (actual[i+6]^gold[i+6])|(actual[i+7]^gold[i+7]);
        if(difference) {suspect=i;break;}
    }
    for(;i<words;++i)if(actual[i]!=gold[i]) {
        const unsigned char *a=(const unsigned char*)&target_state;
        for(unsigned j=i*8;j<i*8+8;++j)if(a[j]!=fixture_gold[j])reject(94,j);
        reject(95,i*8);
    }
    if(suspect!=words)reject(95,suspect*8);
    target_report[8]=R2_CONSUMER_STATE_BYTES;
}

#undef R2_CONSUMER_STATE_BYTES

static unsigned long cases;
struct region {void *mapping;size_t bytes;unsigned char *data;};
static struct region guarded(unsigned n) {
    size_t page=(size_t)sysconf(_SC_PAGESIZE),rounded=(n+page-1)/page*page,total=rounded+page;
    void *p=mmap(NULL,total,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(p==MAP_FAILED || mprotect((char*)p+rounded,page,PROT_NONE))exit(10);
    struct region r={p,total,(unsigned char*)p+rounded-n};return r;
}
static void one(void (*f)(void),unsigned n,unsigned expected) {
    trap_code=trap_byte=0;target_report[8]=0;
    if(setjmp(trap)==0)f();
    if(expected==n) {
        if(trap_code || target_report[8]!=n) {fprintf(stderr,"false_reject %u %u\n",trap_code,trap_byte);exit(11);}
    } else if(trap_code!=94 || trap_byte!=expected || target_report[8]) {
        fprintf(stderr,"bad_reject expected=%u got=%u/%u reported=%llu\n",expected,trap_code,trap_byte,(unsigned long long)target_report[8]);exit(12);
    }
}
static void pair(void (*old)(void),void (*newer)(void),unsigned n) {
    unsigned first=0;while(first<n && actual_base[first]==fixture_gold[first])++first;
    one(old,n,first);one(newer,n,first);++cases;
}
static uint32_t random_word=0x6b1d2947;
static uint32_t random32(void) {uint32_t x=random_word;x^=x<<13;x^=x>>17;x^=x<<5;return random_word=x;}
static void exercise(unsigned n,void (*old)(void),void (*newer)(void),int exhaustive) {
    struct region a=guarded(n),g=guarded(n);actual_base=a.data;fixture_gold=g.data;
    for(unsigned i=0;i<n;++i)actual_base[i]=fixture_gold[i]=(unsigned char)random32();
    pair(old,newer,n);
    if(exhaustive)for(unsigned b=0;b<n;++b)for(unsigned bit=0;bit<8;++bit) {
        actual_base[b]^=(unsigned char)(1u<<bit);pair(old,newer,n);actual_base[b]^=(unsigned char)(1u<<bit);
    }
    unsigned boundary[]={0,7,8,15,16,31,32,55,56,63,64,65,127,128,n-65,n-64,n-33,n-32,n-31,n-8,n-7,n-1};
    for(unsigned i=0;i<sizeof boundary/sizeof boundary[0];++i) {
        unsigned b=boundary[i];if(b>=n)continue;
        actual_base[b]^=0x80;pair(old,newer,n);actual_base[b]^=0x80;
    }
    /* Same XOR masks must not cancel; include the high half of every word. */
    for(unsigned slot=1;slot<8;++slot) {
        actual_base[7]^=0x80;actual_base[slot*8+7]^=0x80;
        pair(old,newer,n);actual_base[7]^=0x80;actual_base[slot*8+7]^=0x80;
    }
    for(unsigned b=n-32;b<n;++b) {
        actual_base[b]^=1;pair(old,newer,n);actual_base[b]^=1;
    }
    if(n>152476) {actual_base[152476]^=1;pair(old,newer,n);actual_base[152476]^=1;}
    for(unsigned k=0;k<128;++k) {
        unsigned b=random32()%n,c=random32()%n;if(b==c)c=(c+1)%n;
        actual_base[b]^=0x42;actual_base[c]^=0x81;
        pair(old,newer,n);actual_base[b]^=0x42;actual_base[c]^=0x81;
    }
    if(munmap(a.mapping,a.bytes)||munmap(g.mapping,g.bytes))exit(13);
}
int main(void) {
    exercise(160,old_small,new_small,1);
    exercise(3691424,old_full,new_full,0);
    printf("{\"status\":\"COMPARE_BATCH8_HOST_C_PASS\",\"cases\":%lu,\"state_bytes\":3691424,\"small_bytes\":160,\"guard_page_at_logical_end\":true}\n",cases);
    return 0;
}
