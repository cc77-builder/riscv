"""Offline re-audit of one immutable completed Q288 run; starts no guest."""
from pathlib import Path
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
import shutil
import sys

PROFILE_SHA = "bb6c3be58e5c3992302952cb6684722494c501078b5d38fe419198cc27766c2a"
OLD_SHA = "745337dfc8759bfd9ff28e06ed907693a1d68a7009cf6a7420de2c6a039eb772"
NEW_SHA = "79c58eb8bc2821d82f4b0daf74f0ac9f6f9f8a35a25cde35373607e48bda396b"
RAW_PINS = {
    "status.json": "a1e65a5a4eba9b2cd377ec349fb6dba3592bf1d047d7996aaf71b3634caa0c85",
    "stdout.log": "11f0408f2f50686a85ea16d272c33fa44bc29f6fd21d2f55a786fc0bde6c30dc",
    "stderr.log": "63955f99a4c567167f6f6e528558b2d2805af50cfdae18cba7eeba93b885895d",
}
GATE_SHA = "172551fb537e93f33937819b1a7625e39986726c039266750adadb73e8ccc05c"
OLD_SELECTOR = '    lines = [line for line in plain.splitlines() if "Q_" in line or line.startswith("QW")]\n'
NEW_SELECTOR = '    lines = [line for line in plain.splitlines() if line.startswith(("Q_", "QW"))]\n'
OPERATION = "0844a5921b2fa4d9e47903bfc930fdee.b9e59cdda838f6aab491673b143c9389"


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def process_check():
    try:
        os.killpg(5697, 0)
        absent = False
    except ProcessLookupError:
        absent = True
    return dict(original_pgid=5697, process_group_absent=absent,
                original_pid_absent=not Path("/proc/5697").exists())


def audit(root, output):
    need(sys.dont_write_bytecode, "run with -B")
    need(not output.exists(), "fresh offline output")
    here = Path(__file__).resolve().parent
    target = root / "target-01"
    profile_path = root / "preflight-02/profile.json"
    old_path = root / "preflight-02/inputs/run.py"
    new_path = here / "run.py"
    proof_path = here / "derivation.json"
    host_path = here / "host-final-receipt.json"
    need(digest(profile_path) == PROFILE_SHA and digest(old_path) == OLD_SHA
         and digest(new_path) == NEW_SHA, "fixed profile and actual auditor sources")
    profile = json.loads(profile_path.read_text())
    need(len(profile["pins"]) == 80 and profile["runtime_sha256"] == OLD_SHA,
         "original eighty-pin runtime profile")
    old_text, new_text = old_path.read_text(), new_path.read_text()
    need(old_text.count(OLD_SELECTOR) == new_text.count(NEW_SELECTOR) == 1
         and new_text == old_text.replace(OLD_SELECTOR, NEW_SELECTOR)
         and new_text.replace(NEW_SELECTOR, OLD_SELECTOR) == old_text,
         "one selector edit and whole-file exact inverse")
    proof = json.loads(proof_path.read_text())
    need(proof["old_sha256"] == OLD_SHA and proof["new_sha256"] == NEW_SHA
         and proof["before"] == OLD_SELECTOR and proof["after"] == NEW_SELECTOR
         and proof["whole_file_inverse_equal"] is True, "frozen exact derivation record")
    host = json.loads(host_path.read_text())
    need(host["operation_id"] == OPERATION and host["status"] == "failed",
         "original failed host operation")
    shell = host["shell"]
    need(shell["operation_id"] == OPERATION and shell["status"] == "failed"
         and shell["result"]["exit_code"] == 1 and shell["result"]["cleanup_complete"] is True
         and not shell["result"]["cancelled"] and not shell["result"]["timed_out"],
         "original host failed and closed, not silently rewritten")
    pins = dict(profile["pins"])
    pins[str(profile_path)] = PROFILE_SHA
    for name, sha in RAW_PINS.items():
        pins[str(target / name)] = sha
    for path in (new_path, proof_path, host_path, Path(__file__)):
        pins[str(path)] = digest(path)
    old = module(old_path, "q288_original_runtime_for_offline_audit")
    new = module(new_path, "q288_anchored_runtime_for_offline_audit")
    old.check_pins(pins)
    gate = old.module(profile["gate"], "q288_frozen_generic_gate_for_offline_audit", GATE_SHA)
    original_status = json.loads((target / "status.json").read_text())
    need(original_status["status"] == "FAILED"
         and original_status["error"] == "ValueError('complete ordered guest inventory')"
         and original_status["target_runtime_qualified"] is False,
         "preserve exact original audit failure")
    need(original_status["process_started"] is True and original_status["exit_code"] == 0
         and original_status["pid"] == original_status["pgid"] == 5697
         and original_status["process_reaped"] is True
         and original_status["process_group_absent"] is True
         and original_status["changed_inputs"] == []
         and original_status["input_identities_unchanged"] is True
         and original_status["signals"] == {"first": None, "count": 0}
         and not original_status.get("timed_out") and not original_status.get("cancelled"),
         "actual original EMU successful exit and cleanup")
    closure_before = process_check()
    need(all(closure_before[k] for k in ("process_group_absent", "original_pid_absent")),
         "original process and group absent before offline audit")
    output.mkdir(parents=True)
    (output / "inputs").mkdir()
    (output / "original").mkdir()
    for name in RAW_PINS:
        shutil.copyfile(target / name, output / "original" / name)
    for path, name in ((old_path, "original-run.py"), (new_path, "anchored-run.py"),
                       (profile_path, "profile.json"), (proof_path, "derivation.json"),
                       (host_path, "host-final-receipt.json"), (Path(__file__), "audit.py"),
                       (Path(profile["gate"]), "runtime_gate.py")):
        shutil.copyfile(path, output / "inputs" / name)
    save(output / "input-pins.json", pins)
    result = dict(schema=1, contract="r3-dot16-q288-consumer-v1",
        status="RUNNING", started=stamp(), original_operation=OPERATION,
        original_host_status="failed", original_host_exit_code=1,
        original_runtime_status="FAILED", original_emu_exit_code=0,
        original_runtime_status_rewritten=False, new_guest_runs=0, new_builds=0,
        process_check_before=closure_before, original_profile_sha256=PROFILE_SHA,
        original_auditor_sha256=OLD_SHA, anchored_auditor_sha256=NEW_SHA,
        whole_file_inverse_equal=True, profile_pin_count=80,
        target_runtime_qualified=False, performance_qualified=False,
        full_retirement_window_audited=False, asic_ppa_qualified=False)
    save(output / "result.json", result)
    try:
        stdout = (target / "stdout.log").read_bytes()
        stderr = (target / "stderr.log").read_bytes()
        raw = stderr + stdout
        plain = gate.normalize_console(raw.decode("utf-8", errors="strict"))
        old_lines = [line for line in plain.splitlines() if "Q_" in line or line.startswith("QW")]
        new_lines = [line for line in plain.splitlines() if line.startswith(("Q_", "QW"))]
        extras = [line for line in old_lines if not line.startswith(("Q_", "QW"))]
        need(len(old_lines) == 45 and len(new_lines) == 43 and len(extras) == 2
             and all("chosenQ_cancel" in line and line.startswith("[PERF ") for line in extras),
             "exact observed two PERF false positives")
        old_error = None
        try:
            old.guest_check(raw, profile["reference"], profile, gate)
        except ValueError as error:
            old_error = str(error)
        need(old_error == "complete ordered guest inventory", "exact original failure reproduced first")
        result["original_failure_reproduced"] = dict(error=old_error, selected_lines=45,
            protocol_lines=43, first_selected=old_lines[0], expected_first=new_lines[0], extras=extras)
        checked = new.guest_check(raw, profile["reference"], profile, gate)
        save(output / "checks.json", checked)
        result["checks_sha256"] = digest(output / "checks.json")
        lines = stdout.splitlines(keepends=True)
        call = next(line for line in lines if line.startswith(b"Q_CALL "))
        qw = [line for line in lines if line.startswith(b"QW ")]
        end = next(line for line in lines if line.startswith(b"Q_END "))
        need(stdout.count(call) == stdout.count(qw[1]) == stdout.count(end) == 1,
             "unique raw protocol mutation locations")
        controls = [
            ("missing-q-call", stdout.replace(call, b"", 1),
             "complete ordered guest inventory", 42,
             "delete one complete actual Q_CALL line"),
            ("duplicate-qw-index", stdout.replace(qw[1], qw[0], 1),
             "QW order or counter range", 43,
             "replace QW1 with actual QW0; count stays43, index0 duplicated and index1 missing"),
            ("unknown-q-line", stdout.replace(end, b"Q_UNKNOWN inventory_probe\r\n" + end, 1),
             "complete ordered guest inventory", 44,
             "insert an unknown protocol-prefix line before Q_END"),
        ]
        negatives = []
        for name, changed_stdout, expected_error, count, change in controls:
            need(changed_stdout != stdout, "actual negative mutation")
            dest = output / name
            dest.mkdir()
            (dest / "stdout.log").write_bytes(changed_stdout)
            found = None
            try:
                new.guest_check(stderr + changed_stdout, profile["reference"], profile, gate)
            except ValueError as error:
                found = str(error)
            need(found == expected_error, "specific semantic negative rejection: " + name)
            selected = [line for line in gate.normalize_console(changed_stdout.decode()).splitlines()
                        if line.startswith(("Q_", "QW"))]
            need(len(selected) == count, "specific negative inventory count")
            row = dict(name=name, status="EXPECTED_REJECTION", change=change,
                error=found, selected_lines=count, stdout_sha256=digest(dest / "stdout.log"),
                unchanged_stderr_sha256=RAW_PINS["stderr.log"], new_guest_runs=0)
            save(dest / "result.json", row)
            negatives.append(row)
        result["negative_controls"] = negatives
        old.check_pins(pins)
        closure_after = process_check()
        need(all(closure_after[k] for k in ("process_group_absent", "original_pid_absent")),
             "original process and group absent after offline audit")
        result.update(status="DOT16_Q288_OFFLINE_AUDIT_PASS",
            process_check_after=closure_after, input_identities_unchanged=True,
            raw_output_identities_unchanged=True, target_runtime_qualified=True,
            qualification="offline re-audit of this fixed original complete-Q288 AM run; correctness and CSR observations only")
    except BaseException as error:
        result.update(status="FAILED", error=repr(error), target_runtime_qualified=False)
        raise
    finally:
        changes = []
        for path, expected in pins.items():
            try:
                actual = digest(path)
                if actual != expected:
                    changes.append(dict(path=path, expected=expected, actual=actual))
            except OSError as error:
                changes.append(dict(path=path, error=repr(error)))
        result["changed_inputs"] = changes
        result["input_identities_unchanged"] = not changes
        if changes:
            result.update(status="FAILED", target_runtime_qualified=False)
        result["finished"] = stamp()
        save(output / "result.json", result)
    need(result["status"] == "DOT16_Q288_OFFLINE_AUDIT_PASS", "offline final integrity")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    audit(args.root.resolve(), args.output.resolve())
