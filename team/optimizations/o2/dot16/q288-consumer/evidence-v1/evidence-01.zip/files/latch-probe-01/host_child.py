import os,signal,time
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
signal.signal(signal.SIGINT,signal.SIG_IGN)
Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-q288-20261106-pro3/latch-probe-01/child-ready').write_text(str(os.getpid()))
while True: time.sleep(1)
