#!/usr/bin/env python3
"""One real host-only probe at Popen handoff plus repeated TERM during cleanup."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
from types import SimpleNamespace

ROOT = Path("/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-q288-20261106-pro3")
SOURCE = Path("/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-q288-20261106-pro3/controller-02/run.py")
SOURCE_SHA = "745337dfc8759bfd9ff28e06ed907693a1d68a7009cf6a7420de2c6a039eb772"
def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok, message):
    if not ok: raise ValueError(message)
os.sched_setaffinity(0, {1})
need(digest(SOURCE) == SOURCE_SHA, "actual runtime source differs")
compile(SOURCE.read_bytes(), str(SOURCE), "exec")
out = ROOT / "latch-probe-01"
need(not out.exists(), "fresh host probe output")
out.mkdir()
ready = out / "child-ready"
child = out / "host_child.py"
child.write_text("import os,signal,time\nfrom pathlib import Path\n"
                 "signal.signal(signal.SIGTERM,signal.SIG_IGN)\n"
                 "signal.signal(signal.SIGINT,signal.SIG_IGN)\n"
                 "Path(" + repr(str(ready)) + ").write_text(str(os.getpid()))\n"
                 "while True: time.sleep(1)\n")
spec = importlib.util.spec_from_file_location("dot16_actual_runtime_latch_probe", SOURCE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
helper = ROOT / "image-01/inputs/process_helper.py"
gate = ROOT / "preflight-01/inputs/runtime_gate.py"
profile = dict(contract=mod.CONTRACT, status="FROZEN_BEFORE_EMU",
    host_only_diagnostic=True, target_qualification_allowed=False,
    runtime_sha256=SOURCE_SHA, helper=str(helper), gate=str(gate), cpu=1,
    emu=sys.executable, image=str(child), flash=str(child), reference="HOST_ONLY_NO_NEMU",
    max_cycles=1, budget_seconds=60, stream_limit_bytes=8388608,
    pins={str(p): digest(p) for p in (SOURCE, helper, gate, child, Path(sys.executable).resolve())})
profile_path = out / "host-only-profile.json"
profile_path.write_text(json.dumps(profile, indent=2) + "\n")
real_popen = subprocess.Popen
held = []
timers = []
injections = []
def boundary(*args, **kwargs):
    proc = real_popen(*args, **kwargs)
    held.append(proc)
    until = time.monotonic() + 5
    while not ready.exists() and time.monotonic() < until:
        time.sleep(0.01)
    need(ready.exists() and int(ready.read_text()) == proc.pid, "actual child readiness")
    injections.append(dict(point="child started; caller proc assignment has not occurred", signal="TERM"))
    os.kill(os.getpid(), signal.SIGTERM)
    timer = threading.Timer(0.75, lambda: os.kill(os.getpid(), signal.SIGTERM))
    timer.start()
    timers.append(timer)
    return proc
old_handlers = {s: signal.getsignal(s) for s in (signal.SIGTERM, signal.SIGINT)}
started = time.monotonic()
error = None
try:
    mod.subprocess.Popen = boundary
    try:
        mod.run(SimpleNamespace(profile=profile_path, profile_sha256=digest(profile_path),
                                output=out / "receipt"))
    except InterruptedError as exc:
        error = repr(exc)
    need(error is not None and len(held) == 1, "cancel is required to fail after actual spawn")
    r = json.loads((out / "receipt/status.json").read_text())
    need(r["status"] == "FAILED" and r["target_runtime_qualified"] is False
         and r["cancelled"] is True and r["signals"] == dict(first=15, count=2)
         and r["pid"] == held[0].pid and r["exit_code"] == -9
         and r["cleanup_requested"] is True and r["cleanup_complete"] is True
         and r["process_reaped"] is True and r["process_group_absent"] is True
         and r["input_identities_unchanged"] is True, "real handoff/cancellation closure differs")
    try:
        os.killpg(held[0].pid, 0)
        absent = False
    except ProcessLookupError:
        absent = True
    need(absent and held[0].poll() == -9, "independent actual child/group cleanup check")
    result = dict(status="DOT16_HOST_LATCH_HANDOFF_AND_REPEAT_TERM_PASS", new_emu_runs=0,
        source_sha256=SOURCE_SHA, actual_child=held[0].pid, first_signal_before_proc_assignment=True,
        repeated_signal_during_original_stop_group=True, process_reaped=True, process_group_absent=True,
        cancellation_remained_failed=True, elapsed_seconds=time.monotonic()-started,
        actual_runtime_receipt_sha256=digest(out / "receipt/status.json"), injections=injections)
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
finally:
    mod.subprocess.Popen = real_popen
    for timer in timers: timer.join(timeout=2)
    for proc in held:
        try:
            os.killpg(proc.pid, 0)
        except ProcessLookupError:
            continue
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=10)
    for sig, handler in old_handlers.items(): signal.signal(sig, handler)
