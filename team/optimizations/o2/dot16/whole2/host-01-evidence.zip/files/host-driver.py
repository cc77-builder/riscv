"""One bounded CPU2 whole2 host screen from an immutable 18-file thin input view."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

WINDOWS_REPO = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022')
RUN = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole2-20261106-pro6')
FUSED = Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused')
Q = FUSED.parent
OLD = Path('team/optimizations/o2/dot16')
LEAF = OLD / 'whole2'
PINS = {
    str(OLD / 'candidate.py'): 'ad6de7c872f2695297d91a0ed6cb88cb2d71169c7093cf05ff993b87c419e363',
    str(OLD / 'screen.py'): 'c53224cfaeb990fd11f2e71a5201988de00ff86f5a9651083baa89b6c3c81006',
    str(OLD / 'CONTRACT.md'): '425a67aa3eb083609b284737c435c56314662363b32736cd562b0283f87c66bf',
    str(LEAF / 'generate.py'): '553459635da18319493f1027329da23e0aeb94ee560861e34abdc512a295f9e9',
    str(LEAF / 'screen.py'): 'c5d12b55a7b835d605d175977ebb24ecf9c05b92ce101edb9096f7db3bdd2f7f',
    str(LEAF / 'CONTRACT.md'): '25dcbe2a65474c74fc55f49a14bcc3e0ec37551b84b2e0fe4496e98d633640ac',
}
SOURCES = [Q / name for name in ('generate.py', 'oracle.c', 'q288.h')]
SOURCES += [Q.parent / 'caller.h', Q.parent / 'split/split.h',
            Path('team/optimizations/o2/r2-config-reuse/public/gemv.S'),
            Path('team/optimizations/o2/r2-safe-tail/machine_model.py')]
SOURCES += [FUSED / name for name in
            ('generate.py', 'model.py', 'screen.py', 'phased/candidate.py', 'phased/tail/candidate.py')]
SOURCES += [OLD / name for name in ('candidate.py', 'screen.py', 'CONTRACT.md')]
SOURCES += [LEAF / name for name in ('generate.py', 'screen.py', 'CONTRACT.md')]


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert not RUN.exists(), 'fresh run root; inspect any prior attempt instead of replay'
    assert sorted(os.sched_getaffinity(0)) == [2], 'exact CPU2 single-core budget'
    assert len(SOURCES) == len(set(SOURCES)) == 18
    RUN.mkdir()
    (RUN / 'host-driver.py').write_bytes(Path(__file__).read_bytes())
    state = dict(status='PREPARING', started=now(), source_head_observed=sys.argv[1],
                 cpu_affinity=sorted(os.sched_getaffinity(0)), new_emu_runs=0)
    save(RUN / 'state.json', state)
    try:
        frozen = RUN / 'inputs-01/source'
        records = []
        for rel in SOURCES:
            raw = (WINDOWS_REPO / rel).read_bytes()
            digest = sha(raw)
            if str(rel) in PINS:
                assert digest == PINS[str(rel)], 'explicit source pin ' + str(rel)
            target = frozen / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            assert target.read_bytes() == raw
            records.append(dict(path=str(rel), bytes=len(raw), sha256=digest))
        assert all(sha((WINDOWS_REPO / r['path']).read_bytes()) == r['sha256'] for r in records)
        save(RUN / 'inputs-01/manifest.json', dict(source_root=str(WINDOWS_REPO),
             source_head_observed=sys.argv[1], files=records, count=len(records), frozen_source=str(frozen)))
        argv = ['/usr/bin/python3', '-B', str(frozen / LEAF / 'screen.py'), '--repo', str(frozen),
                '--output', str(RUN / 'host-01')]
        receipt = dict(argv=argv, cwd=str(RUN), started=now(), timeout_seconds=120,
                       cpu_affinity=sorted(os.sched_getaffinity(0)), process_started=False, timed_out=False)
        start = time.monotonic()
        with (RUN / 'stdout.log').open('wb') as stdout, (RUN / 'stderr.log').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=RUN, stdout=stdout, stderr=stderr, start_new_session=True)
            receipt.update(process_started=True, pid=process.pid)
            save(RUN / 'runtime.json', receipt)
            try:
                process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                receipt['timed_out'] = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
            finally:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
                receipt.update(exit_code=process.returncode, finished=now(),
                               elapsed_seconds=time.monotonic() - start, direct_child_reaped=True)
                try:
                    os.killpg(process.pid, 0)
                except ProcessLookupError:
                    receipt['process_group_absent'] = True
                else:
                    receipt['process_group_absent'] = False
                save(RUN / 'runtime.json', receipt)
        assert receipt['exit_code'] == 0 and not receipt['timed_out'] and receipt['process_group_absent'], receipt
        result = json.loads((RUN / 'host-01/result.json').read_text())
        assert result['status'] == 'WHOLE2_ACTUAL_ELF_SCREEN_PASS'
        assert result['numeric_cases'] == 8 and result['rejected_mutants'] == 3
        assert result['new_emu_runs'] == 0 and not result['performance_qualified']
        assert all(sha((WINDOWS_REPO / r['path']).read_bytes()) == r['sha256'] and
                   sha((frozen / r['path']).read_bytes()) == r['sha256'] for r in records)
        state.update(status='WHOLE2_HOST_DRIVER_PASS', sources_unchanged=True,
                     source_files=len(records), runtime=receipt, result=result,
                     result_sha256=sha((RUN / 'host-01/result.json').read_bytes()))
    except BaseException as error:
        state.update(status='FAILED', error=repr(error))
        raise
    finally:
        state['finished'] = now()
        save(RUN / 'state.json', state)
    print(json.dumps(state, indent=2))


if __name__ == '__main__':
    main()
