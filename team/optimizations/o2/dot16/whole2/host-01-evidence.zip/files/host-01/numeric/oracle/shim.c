
#include <stdint.h>
#include <fenv.h>
#include <math.h>
typedef union { uint32_t u; float f; } bits;
int host_rne(void) { return fesetround(FE_TONEAREST); }
uint32_t host_mul(uint32_t a, uint32_t b) { bits x={.u=a},y={.u=b},z; z.f=x.f*y.f;return z.u; }
uint32_t host_add(uint32_t a, uint32_t b) { bits x={.u=a},y={.u=b},z; z.f=x.f+y.f;return z.u; }
uint32_t host_convert(int32_t a) { bits z; z.f=(float)a;return z.u; }
uint32_t host_fma_witness(void) {
    volatile uint32_t v[4]={0x3d000000,0x3d000000,0x3d000001,0x3cfffffe};
    bits a={.u=v[0]},b={.u=v[1]},c={.u=v[2]},d={.u=v[3]},z;
    float first=(-1.0f*a.f)*b.f;z.f=fmaf(c.f,d.f,first);return z.u;
}
