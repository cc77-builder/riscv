import os,sys,json,hashlib,importlib.util,re,collections,datetime
from pathlib import Path
os.sched_setaffinity(0,{1});os.nice(5);sys.dont_write_bytecode=True
root=Path("/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole8-narrow-q288-20261107-main")
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
profile_path=root/'preflight-01/profile.json'
assert sha(profile_path)=='eca5b81200085c54635cf35495b15c90191e1d66c49d11a4db8fd1f6337daef0'
profile=json.loads(profile_path.read_bytes())
assert len(profile['pins'])==85
verified=[]
for path,pin in sorted(profile['pins'].items()):
 actual=sha(path)
 assert actual==pin,path
 verified.append({'path':path,'sha256':actual})
runpath=root/'preflight-01/inputs/run.py'
assert sha(runpath)=='a2888116ad76c064b3390900718d894ef16fc5edb0dba5c0874e5f84b514b4b6'
spec=importlib.util.spec_from_file_location('narrow_terminal_readonly_runner',runpath)
run=importlib.util.module_from_spec(spec);sys.modules[spec.name]=run;spec.loader.exec_module(run)
gate=run.module(profile['gate'],'narrow_terminal_readonly_gate',run.GATE_SHA)
raw=(root/'target-01/stderr.log').read_bytes()+(root/'target-01/stdout.log').read_bytes()
recomputed=run.guest_check(raw,profile['reference'],profile,gate)
status=json.loads((root/'target-01/status.json').read_bytes())
checks=json.loads((root/'target-01/checks.json').read_bytes())
assert recomputed==checks
assert sha(root/'target-01/status.json')=='6eaa57167fd2ea019d73ebfb97067968e4cfa9221fa199d9cd9d453be7da8109'
assert sha(root/'target-01/checks.json')==status['checks_sha256']=='117e43b39701f08dc1b238bfda7a172bf9b68e93303b657d3c5e758fc269d045'
for name,row in status['raw_logs'].items():
 p=root/'target-01'/name
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name
assert status['status']=='DOT16_WHOLE8_NARROW_Q288_FULLCORE_PASS'
assert status['exit_code']==0 and status['input_identities_unchanged'] and status['changed_inputs']==[]
assert status['process_reaped'] and status['process_group_absent']
assert not status['performance_qualified'] and not status['full_retirement_window_audited'] and not status['asic_ppa_qualified']
plain=gate.normalize_console(raw.decode('utf-8'))
qlines=[x for x in plain.splitlines() if x.startswith(('Q_','QW'))]
assert len(qlines)==43
actual_calls=[]
for line in qlines:
 m=re.fullmatch(r'Q_CALL (\d+) (\d+) (\d+) (\d+)',line)
 if m:
  idx,stage,arm,dataset=map(int,m.groups());assert idx==len(actual_calls)
  actual_calls.append(dict(stage=stage,arm=arm,dataset=dataset))
order=[3,0,1,2,3,3,2,1,0,3]
expected=[dict(stage=0,arm=a,dataset=d) for d in [1,2] for a in range(4)]
expected.append(dict(stage=0,arm=2,dataset=3))
for a in order:
 expected += [dict(stage=1,arm=a,dataset=0),dict(stage=2,arm=a,dataset=0)]
assert actual_calls==expected==profile['call_plan']
assert profile['order']==order and checks['outputs_checked']==29*288
assert dict(collections.Counter(x['arm'] for x in actual_calls))=={0:6,1:6,2:7,3:10}
assert checks['judge_fault_controls']==5 and checks['fullmin_arm']==2
assert not Path('/proc/2292').exists() and not Path('/proc/2293').exists()
groups=[]
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  try:
   s=(p/'stat').read_text();v=s[s.rfind(')')+2:].split()
   if int(v[2])==2293:groups.append(int(p.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert groups==[]
print(json.dumps({'status':'NARROW_Q288_TERMINAL_READBACK_VERIFIED','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only':True,'new_builds':0,'new_guest_runs':0,'profile_sha256':sha(profile_path),'pins_verified':len(verified),'pins_manifest_sha256':hashlib.sha256(json.dumps(verified,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'original_guest_parser_recomputed_equal':True,'independent_exact_call_sequence':True,'protocol_lines':len(qlines),'calls_by_arm':dict(collections.Counter(x['arm'] for x in actual_calls)),'q_calls':29,'outputs_checked':8352,'warmups':10,'measured_windows':10,'judge_fault_controls':5,'fullmin_arm':2,'fullmin_measured':False,'exit_code':status['exit_code'],'process_reaped':True,'process_group_absent':True,'runtime_processes_absent':True,'checks_sha256':sha(root/'target-01/checks.json'),'status_sha256':sha(root/'target-01/status.json'),'samples':checks['samples'],'scope':'fixed complete Q288 correctness and CSR observations; not full application or full retirement audit'}))

