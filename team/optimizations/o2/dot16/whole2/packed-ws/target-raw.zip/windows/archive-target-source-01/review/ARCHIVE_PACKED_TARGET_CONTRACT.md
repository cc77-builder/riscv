# Packed K288 target 闭合证据运输合同

## 目的与边界

本助手只运输已闭合的 `target-k288-01`、其冻结 preflight 和来源文件，并从原 stdout 的八条 `PWS_SAMPLE` 复算已有整数观测。它不调用原 checker、官方验证器、GNU、EMU、NEMU、EDA 或子进程，不重新确认功能通过，也不改变原资格。

原 target 的有限运行结论为 `PACKED_WS_EIGHT_WINDOW_TARGET_PASS`；原 `target_runtime_qualified=true` 仅按原 `qualification` 字段保存。`performance_qualified`、`application_performance_qualified`、`full_retirement_window_audited`、`retired_custom_count_verified` 仍为 false。prepare 在测量窗外；总 guest cycles 不作为内核或应用指标。八个窗口仅有每方法两次顺序观测，不产生统计置信度结论。

## 固定输入、命名空间与输出

WSL 根：

`/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-packed-ws-20261107-main`

Windows 根在 WSL 的挂载路径：

`/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main`

完整读取以下五个互不重叠、无符号链接的目录；不遍历整个 runs，也不排除任何文件或 `.o/.a`。

| 输入根 | ZIP 内命名空间 | 内容 |
|---|---|---|
| WSL `target-k288-01` | `wsl/target-k288-01/` | 全部 status、checks、stdout、完整 stderr 和 cwd，包括空目录 |
| WSL `preflight-k288-01` | `wsl/preflight-k288-01/` | profile、result、全部冻结 executable snapshots |
| Windows `target-source-01` | `windows/target-source-01/` | 原 controller、合同、派生记录、source manifest 和其验证附件 |
| Windows `target-launch-01` | `windows/target-launch-01/` | 原启动材料全部原件；不猜测未读文件名或赋予新的执行身份 |
| Windows `archive-target-source-01` | `windows/archive-target-source-01/` | 本助手、原回执/摘取/派生分析、审查附件 |

`archive-target-source-01` 执行前至少放入下列原字节文件：

- `archive_packed_target.py`，必须是实际被执行的助手路径。
- `captured-files.json`：7939 B，SHA256 `de76b908ec7f1e4013b39c64bb508fe8c08bd57801dfa0d333ae29aaca4ad677`。
- `host-receipt.json`：3909 B，SHA256 `473c8f15b0869ea9dae165451284afa9a6226ee6fb9b56d883f403cd564ce6c3`。
- `cycle-analysis.json`：1115 B，SHA256 `cb0acfc6c876080c6915f1c126fc194158e373b7c25577e50a5c2590bbca0854`。

本合同、REVIEW、自检源码/结果可一并放入该目录；它们是辅助资料，不是 guest 或历史工具执行资格。程序对全部选中内容记录运输 hash，但历史执行身份仅来自原 profile/status；source manifest 与捕获文件用于来源核对。

输出必须是全新的 Windows `archive-target-01`，不能存在、位于输入根内或覆盖输入。成功仅生成 `raw.zip` 和 `audit.json`；ZIP 另含 `ARCHIVE-MANIFEST.json`，保存完整路径命名空间、成员长度/SHA、空目录、原资格、精确有理数观测和外部依赖身份。失败保留已产生的 ZIP/文件并写 `archive-failure.json`，不删除任何原件。

## 固定闭合身份与依赖

助手硬绑定以下原件完整长度与 SHA256；对闭合记录的字节检查先于语义读取。

| WSL 相对文件 | 长度 | SHA256 |
|---|---:|---|
| `target-k288-01/status.json` | 2219 | `e0011666c36625a40538100e201f2cda2cad75c8f48557255b89361981b71775` |
| `target-k288-01/checks.json` | 2654 | `66b30e06cb5a39f57e3790210dc3b2aa741d7a01a8230857c8d556d164e7bb4d` |
| `target-k288-01/stdout.log` | 1733 | `166e024ec76c515e39cc2b6910a101ca8b686a6dce446fd441133470433094b0` |
| `target-k288-01/stderr.log` | 3065676 | `9af09d53a803fcfb1788ab2fd77339645f13d24f346099ac1ac04381ac24020f` |
| `preflight-k288-01/profile.json` | 88784 | `b48e4dfd3f6d1bc13c741f6cacc00b9097c946844abeb24c3ffd52d0a1100181` |
| `preflight-k288-01/result.json` | 373 | `d6942d424b675d553b874e70cf3ef62e9c8196dd118406a17bc5d6e7b62c1154` |

原 host operation 固定为 `0250d6044ba18f5fd71831ae3131d2ce.be44a4d254afc57af4be96e78c6f3a08`。使用既有 succeeded/exit0/cleanup_complete 回执及原 terminal status；不重查 PID，不重放原操作。

profile 的 432 项 pin 分为归档范围内 7 项、外部 425 项。连同固定原件和 source manifest，共 25 个去重后的归档内 pin、10 个固定长度。内部必须实际匹配，外部只按原字符串路径与 SHA 记录，不打开、复制或 rehash；外部 `include/../` 拼写保留。任何原路径或词法正规化路径落入内部范围时，都必须走严格内部 pin 检查。

镜像和 ELF 实际仍位于外部 `reference-02`：

- `k288/images/normal-0/real-w2.bin`，SHA256 `5efdb3f53786490fd2752b44e0ec48053bbfab98ce829a82ec7fcc8b5db2a756`。
- `k288/packed-screen.elf`，SHA256 `7b164fd3a6e08840f1bcc5824f48295e310e4d19544d41000740a8742fd58426`。

它们未假定已复制进 target，而由既有 `reference-raw.zip` 覆盖：11059275 B，SHA256 `20598d3ee465ce7fab91180d1172efc7d83680b04a6ac75c39dbefe3ee77a0b1`。已发布入口为 `team/optimizations/o2/dot16/whole2/packed-ws/reference-raw.zip`；对应成员为 `wsl/reference-02/` 下上述路径。本助手不重新打开该 ZIP。EMU、reference SO、flash、工具与旧 reference 原树同样仅保留原 profile 的外部 pin。

## 整数复算与运输完整性

从完整原 stdout 解码并严格匹配八条 sample，按 Python 整数解析 cycles、instret、flags，FNV 保留 16 位十六进制字符串。顺序必须与原件相同：P、N、packedP、packedN、packedN、packedP、N、P。全部字段逐项匹配原 checks 和 profile；均值、次序配对、较快 RVV/自定义对照用 `Fraction` 计算。输出的分子/分母为十进制字符串，另附 Decimal 展示值。

本助手不把 stderr 文字、GOOD trap 或 DiffTest 搜索结果加为新功能判据。stderr 原字节完整运输并做 SHA/CRC；原 `cycle-analysis.json` 也按固定字节保存，不用其中浮点百分比替代新精确有理数记录。

沿成熟助手逐字复用：流式 SHA、全根扫描、ZIP 成员全集/重名检查、每个文件完整 CRC/SHA 读回、空目录读回、原树 after-scan 和全部原文件长度/SHA 复核。成功意味着这些运输检查实际完成。仅云端元数据自检不能提前声称 ZIP 或原树检查通过。

## 运行资源与计划 CLI

单 Python 进程、CPU affinity `{1}`、absolute nice `5`，设置后立即核实。归档处理由 300 s SIGALRM/deadline 限定，SIGINT/SIGTERM 进入失败保留路径。无子进程、无额外辅助 worker；不与主端安排的 prefix 等辅助工程抢占同一 worker。调度由主端负责，本助手不暂停或修改其他作业。

资源声明只需五个输入根 read、全新 `archive-target-01` write，以及既有 Python/标准库运行环境 read。Windows 原路径为 `D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runs\dot16-packed-ws-20261107-main`；WSL 两根使用 `Ubuntu-22.04:` 加上述绝对路径。不要因 profile 列出外部依赖就申明或执行外部读取。

计划 CLI（此处未执行）：

```bash
python3 -B /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main/archive-target-source-01/archive_packed_target.py \
  --runs /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-packed-ws-20261107-main \
  --sources /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main \
  --output /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main/archive-target-01
```

实际来源文件原路径及 SHA 在此固定；它不是任意路径参数化的重放框架。主端冻结/读回 helper 与上述捕获资料后再执行。原功能资格、归档完整性和后续发布身份分别保留。
