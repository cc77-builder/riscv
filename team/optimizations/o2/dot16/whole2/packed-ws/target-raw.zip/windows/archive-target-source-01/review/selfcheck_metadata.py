#!/usr/bin/env python3
"""Finite cloud-only metadata/static checks; no PC, archive main, scan or ZIP."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
HELPER = ROOT / 'verification/archive_packed_target.py'
BASE = ROOT / 'verification/archive_packed_reference.py'
DATA = ROOT / 'source-review/packed-ws-20261107'
CAPTURE = ROOT / 'verification/packed-target-closed-review'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    raw = HELPER.read_bytes(); source = raw.decode(); tree = ast.parse(source)
    original = BASE.read_text(); old_tree = ast.parse(original)
    assert digest(BASE.read_bytes()) == '5c66e38e98ae219e8a218898d7cdd780d73c9342ee21bcae5872e3c94e2ed943'
    spec = importlib.util.spec_from_file_location('packed_target_archive_review', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    local = {
        'preflight-k288-01/profile.json': DATA / 'actual-target-preflight/profile.json',
        'preflight-k288-01/result.json': DATA / 'actual-target-preflight/result.json',
        'target-source-01/source-manifest.json': DATA / 'target-source-01/source-manifest.json',
        **{'archive-target-source-01/' + name: CAPTURE / name for name in
           ('captured-files.json', 'host-receipt.json', 'cycle-analysis.json')},
    }
    observed = {}
    values = {}
    for name, path in local.items():
        data = path.read_bytes(); values[name] = json.loads(data)
        observed[name] = dict(bytes=len(data), sha256=digest(data))
        size, sha = (helper.FIXED_WSL | helper.FIXED_WINDOWS)[name]
        assert observed[name] == dict(bytes=size, sha256=sha), name
    captured = values['archive-target-source-01/captured-files.json']
    files = {item['name']: item for item in captured['files']}
    for name, item in files.items():
        assert (item['bytes'], item['sha256']) == helper.FIXED_WSL['target-k288-01/' + name]
        if 'text' in item:
            data = item['text'].encode('utf-8')
            assert len(data) == item['bytes'] and digest(data) == item['sha256'], name
    inputs = [json.loads(files['status.json']['text']), json.loads(files['checks.json']['text']),
        values['preflight-k288-01/profile.json'], values['preflight-k288-01/result.json'],
        values['target-source-01/source-manifest.json'], captured,
        values['archive-target-source-01/host-receipt.json'], files['stdout.log']['text'].encode('utf-8')]

    def check(args):
        return helper.evidence_metadata(helper.RUNS, helper.SOURCES, *args)

    pins, sizes, groups, external, evidence, windows = check(inputs)
    assert len(pins) == 25 and len(sizes) == 10 and len(external) == 425
    assert {k: len(v) for k, v in groups.items()} == dict(fixed_closed_records=6,
        fixed_source_bundle_and_captures=4, original_profile_internal_pins=7, source_bundle_pins=10)
    assert [windows['mean_cycles'][str(k)]['decimal'] for k in range(1, 5)] == [
        '45639.5', '27353.5', '45047.5', '25655.5']
    assert windows['mean_n']['cycles_saved']['numerator'] == '1698'
    assert windows['mean_p']['cycles_saved']['numerator'] == '592'
    assert [[r['original_index'], r['packed_index']] for r in windows['paired_order_comparisons']['N']] == [[1, 3], [6, 4]]
    assert [[r['original_index'], r['packed_index']] for r in windows['paired_order_comparisons']['P']] == [[0, 2], [7, 5]]
    roots = helper.input_roots(helper.RUNS, helper.SOURCES)
    assert len(roots) == len(set(roots.values())) == 5
    assert all('reference-' not in p.name for p in roots.values())
    assert inputs[2]['image'] in external and inputs[2]['elf'] in external
    archive_raw = (DATA / 'archive-audit.json').read_bytes()
    assert len(archive_raw) == 12287 and digest(archive_raw) == '1dbe6e7ff0791fe60e77c714e88b0cbd8fdd8e60a8604273ef9c77283d4bc6ee'
    prior_archive = json.loads(archive_raw)
    assert prior_archive['archive_bytes'] == helper.REFERENCE_ARCHIVE['bytes']
    assert prior_archive['archive_sha256'] == helper.REFERENCE_ARCHIVE['sha256']

    negative_results = []
    for label in ('missing-recorded-window', 'changed-recorded-counter', 'wrong-mean',
                  'false-performance-qualification', 'unclosed-host-receipt', 'local-parent-traversal'):
        bad = copy.deepcopy(inputs)
        observation_only = label in ('missing-recorded-window', 'changed-recorded-counter', 'wrong-mean')
        if label == 'missing-recorded-window':
            bad[7] = b'\n'.join(line for line in bad[7].splitlines() if not line.startswith(b'PWS_SAMPLE 7 '))
        elif label == 'changed-recorded-counter':
            bad[7] = bad[7].replace(b'PWS_SAMPLE 0 1 45669 ', b'PWS_SAMPLE 0 1 45668 ', 1)
        elif label == 'wrong-mean':
            bad[1]['mean_cycles']['4'] += 1
        elif label == 'false-performance-qualification':
            bad[0]['performance_qualified'] = True
        elif label == 'unclosed-host-receipt':
            bad[6]['shell']['result']['cleanup_complete'] = False
        elif label == 'local-parent-traversal':
            path = next(iter(external))
            bad[2]['pins'][str(helper.SOURCES / 'target-source-01/../target-source-01/foreign.py')] = bad[2]['pins'].pop(path)
        try:
            if observation_only:
                helper.observe_windows(bad[7], bad[1], bad[2])
            else:
                check(bad)
        except ValueError as error:
            negative_results.append(dict(case=label, status='REJECTED', reason=str(error)))
        else:
            raise AssertionError('negative was not rejected: ' + label)

    helpers = {}
    for name in ('need', 'stamp', 'stream_sha', 'sha', 'read', 'encoded', 'scan'):
        new_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        old_node = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        new = ast.get_source_segment(source, new_node); old = ast.get_source_segment(original, old_node)
        assert new == old, name
        helpers[name] = digest(new.encode())
    start, end = '        raw_manifest = encoded(manifest)\n', '        audit = dict(status='
    transport = source[source.index(start):source.index(end)]
    assert transport == original[original.index(start):original.index(end)]
    start, end = '    started, deadline = stamp(), time.monotonic() + ', '        signal.setitimer(signal.ITIMER_REAL, '
    timer = source[source.index(start):source.index(end) + len(end) + len('300)\n')]
    old_timer = original[original.index(start):original.index(end) + len(end) + len('600)\n')]
    assert timer == old_timer.replace('600', '300')
    start, end = '    except BaseException as error:\n', "\n\nif __name__ == '__main__':"
    assert source[source.index(start):source.index(end)] == original[original.index(start):original.index(end)]
    imports = {alias.name for n in tree.body if isinstance(n, ast.Import) for alias in n.names}
    assert 'subprocess' not in imports and 'importlib' not in imports
    report = dict(status='STATIC_AND_CAPTURED_METADATA_CHECK_PASS', helper_bytes=len(raw), helper_sha256=digest(raw),
        actual_cloud_records=observed, captured_original_records={name: {key: item[key] for key in ('bytes', 'sha256')}
            for name, item in files.items()}, original_stderr_loaded=False, previous_archive_audit_checked=True,
        fixed_input_roots=5, local_pins=len(pins), size_pins=len(sizes), external_dependencies=len(external),
        recorded_pin_counts={k: len(v) for k, v in groups.items()}, eight_exact_observations=windows,
        negative_controls=negative_results, unchanged_helpers=helpers,
        unchanged_zip_readback_after_sha256=digest(transport.encode()),
        timer_only_budget_change='600 to 300 seconds', failure_tail_unchanged=True,
        archive_main_called=False, scan_called=False, zip_created=False, native_pc_accessed=False,
        new_guest_runs=0, new_builds=0, new_eda_runs=0,
        scope='Cloud metadata and source comparison only. No actual five-tree inventory, ZIP or new runtime qualification.')
    (OUT / 'selfcheck.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'helper_bytes', 'helper_sha256', 'local_pins',
        'size_pins', 'external_dependencies', 'zip_created')}, indent=2))


if __name__ == '__main__':
    main()
