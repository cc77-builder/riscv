# Packed K288 target 归档助手审查

## 交付与结论

已创建 `verification/archive_packed_target.py`：27626 B，SHA256 `b8ae9a93334fffbd1978f39c00c96190e8212c420313f5b04721d906538d85cc`。基于实际闭合云端原件的有限元数据/静态自检通过，未发现需扩大运行资格的理由。它只归档证据并复算已有计数；尚未执行真实归档。

基底为 `verification/archive_packed_reference.py`：28224 B，SHA256 `5c66e38e98ae219e8a218898d7cdd780d73c9342ee21bcae5872e3c94e2ed943`。七个基础函数（含 scan）及 ZIP 成员完整读回、原树 after-scan/逐文件 SHA 区块逐字相同；失败保留尾部逐字相同。有限计时段仅把 600 s 收为 300 s。仍为单 Python 进程 CPU1、absolute nice5，无 subprocess，无 guest/build/EDA。

## 真实记录绑定

只读取五个闭合输入根：WSL `target-k288-01`、`preflight-k288-01`；Windows `target-source-01`、`target-launch-01`、`archive-target-source-01`。统一命名空间后全量归档，包括完整 stderr 和空 cwd，不省略文件，不遍历整个 runs。输出为新的 Windows `archive-target-01`，失败保留产物与全部原件。

实际 status/checks/stdout/stderr/profile/preflight-result 均有固定长度及完整 SHA。profile 的 432 项执行 pin 中 7 项在归档内、425 项外部；连同固定捕获与十项 source manifest，共 25 个去重内部 pin、10 个长度 pin。source manifest 证明来源，未将其附件提升为历史执行输入。

镜像和 ELF 确实属于 `reference-02/k288`，不假定 target 含镜像。外部原路径/SHA 原样记录，不打开或 rehash；既有 11059275 B、SHA256 `20598d3ee465ce7fab91180d1172efc7d83680b04a6ac75c39dbefe3ee77a0b1` 的 `reference-raw.zip` 为其已发布入口。该 ZIP 身份来自既有 archive audit，当前不重验旧 ZIP。

原 host receipt 对应唯一 operation `.be44a4d254afc57af4be96e78c6f3a08`；回执的 terminal status 与保存的 status 一致。它们作为原闭合证据读取，不重查 PID、不重放原操作。stderr 只做运输完整性检查，不扫描文字添加新功能门槛。

## 精确计数复算

原 stdout 捕获文本重新编码后与完整原字节的长度/SHA 一致，包括 CRLF/ANSI；只从八条完整 `PWS_SAMPLE` 提取数据。cycles、instret、flags 用 Python 整数，FNV 保留 hex；均值/配对用 Fraction，分子分母以字符串输出。

| 方法 | 平均 cycles |
|---|---:|
| P | 45639.5 |
| N | 27353.5 |
| packed P | 45047.5 |
| packed N | 25655.5 |

N 均值节约 1698 cycles，精确比例为 `54707/51311`；P 均值节约 592 cycles，比例为 `2467/2435`。P 配对索引为 `(0,2)`、`(7,5)`，N 为 `(1,3)`、`(6,4)`；全部原整数、次序、均值及原展示 ratios 与 checks/profile 一致。父端 `cycle-analysis.json` 另按原字节保留，其浮点百分比末位差异不作为新门槛。

prepare 仍在测量窗外。以上是每方法两次的局部运行观测，`performance_qualified`、`application_performance_qualified`、retirement audit 等 false 保留；不授予统计结论、整应用收益或 PPA 资格。

## 有限自检与实际执行前边界

`selfcheck_metadata.py` / `selfcheck.json` 已完成 AST、真实捕获字节、原 metadata 正例和六项针对性负控：缺窗、改 counter、错均值、性能资格升格、host 未闭合、内部 `../` 路径。全部正例通过、变异拒绝。基底 helper/运输区块/失败尾部精确比较也通过。自检未调用 main、scan、ZIP，也未访问本机。

`/root/whole2_code_review` 已针对同一 `b8ae9a…` 做有限只读复核：未见五根范围、内外 pin、八窗 Fraction、原资格保留或完整读回/after-scan 的具体阻塞；该复核未执行 helper、自检或本机任务，不是额外运行资格。

主端还需把本 helper 与原 `captured-files.json`、`host-receipt.json`、`cycle-analysis.json` 放入固定 `archive-target-source-01`，冻结/读回后执行；合同给出 CLI 和 read/write 根。target-launch 全根会运输，但没有依据云端猜测该目录的成员名或为其添加虚假执行 pin。

本次不掌握本机五树最终成员数，未读完整原 stderr；真实全树存在/无链接、全部 pin、ZIP CRC/SHA、原树未变及 300 s 完成，仅由主端随后运行的 audit 证明。实际输入不足或改变时失败保留，不能把本静态自检替代真实归档回执。
