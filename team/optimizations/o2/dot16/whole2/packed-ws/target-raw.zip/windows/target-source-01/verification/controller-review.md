# Packed-Ws 目标控制器有限独立审查

## 结论与已修问题

**修正 cycle 极值后，未发现会阻止计划中 freeze/preflight 的具体接口问题。** 本次最终审查版本为 `source-review/packed-ws-20261107/target-source-01/run.py`，21707B，SHA256：

`df95f6a05dbf3ffdf4314de38ecd8bce13ff3a7b63ef2583bb99d00f77e29655`

原21703B版本 `68cddae6…` 的唯一已发现问题：`guest_check()` 使用 `0 < cycles < (1<<32)`，会接纳4294967295；固定guest实际要求差值小于UINT32_MAX，最大合法值为4294967294。root已经改为 `0 < cycles < (1<<32)-1`，同步派生记录。该修复只收紧单个错误边界，不改变guest或原进程所有权实现。

本次没有执行preflight、编译、host oracle、NEMU或EMU，没有访问本机、读取活跃作业或修改来源。除只读静态核对，唯一代码执行为有限离线格式检查：把同一EMU曾真实产生的原stdout送入固定console normalizer，检查新GOOD-PC/aggregate表达式可匹配实际格式；没有重复root的小组PWS变异测试。

## Preflight 与真实 v2 产物

实际读取的 `actual-eight/result.json` 为166147B/SHA `65de4aca20b86d7faaed7c11863297930d571ee2c97b2ad54bb15bdd4c72e4d0`，不是按摘要构造字段。状态、contract、十例reference、前置九窗口result、全部输入不变和进程闭合字段与新preflight相符。

- 21条实际command是19次exit0和两个 `*-negative` exit2，均direct child reaped、process group absent；新第90行的后缀判断正好匹配实际label，没有把合法负例当构建失败。
- 独立子审查核对三组清单共423个唯一pin，无冲突；前置scalar参考的 `cec287…` result也在original_inputs中。preflight会重新读原件计算这些pin，本次cloud审查没有替它执行本机全量核验。
- `inputs/{screen.py,main.c,model.py,process_helper.py}`，每K的 `packed-screen.elf`，默认 `images/{normal-0|normal}/real-w2.bin`，以及 `reference/{normal-0|normal}/image.bin` 路径与实际记录相符。两种normal BIN的SHA均等于对应原编译BIN，能够与原ELF含BSS完整比较；不是拿非default fixture的patched镜像与原ELF误比。
- 原冻结 `screen.inspect(elf,raw,kernels,scalar)` 接口与四参数调用一致，返回值为可直接比较的dict/list/int，未见tuple/list导致的误拒。actual/static/campaign三者身份相等检查合适。
- UART=1目标镜像对UART=0参考image做完整字节比较，只允许既定8B control范围内的明确差异。引用的参考image另被加入新pin；原ELF、fixture和函数不修改。

实际静态与正常样本接口：

| 项 | K288 | K768 |
| --- | --- | --- |
| static SHA | `9883493045580c3c30f95616e671a2343726e8f04f9bd4b449f5647633d1c3ba` | `b3696cc418c12faf83a049adc1d83c1fbdc8646f8bad004393e6ec6ef63e4226` |
| 正常case | normal-0 | normal |
| 整guest reference retired | 731770 | 1566414 |
| 原/packed P 窗口instret | 22173 | 58458 |
| 原/packed N 窗口instret | 13025 | 34085 |
| expected flags / final FCSR | 1 / 1 | 1 / 1 |
| gold FNV | `f4481cc0f931d2d5` | `f909c47ea8f72842` |
| success PC | `0x8000013c` | `0x8000013c` |

两K的normal与replay完整validation确实相等。profile的八个期望instret来自各实际样本 `row[3]-row[2]`，按 `[1,2,3,4,4,3,2,1]` 排列，没有错用cycle、全guest retired或旧ELF函数指令数。硬件/ABI检查使用固定EMU、REF、flash、gate及原1400B布局和编译flags；不依赖当前源码自述。

## UART 解析和资格

BEGIN、八条SAMPLE、PASS的完整10行与已编译main协议一致；方法顺序、精确instret、flags、完整16位FNV以及修正后的cycle范围均有检查。各方法恰两样本，均值和比值使用同一次完整记录，保留较快合格RVV及自定义方法的比较，没有借旧镜像分母。

原失败gate在控制台归一化后仍有效，另拒绝PWS_REJECT；精确image/reference加载、唯一真实DiffTest启用、唯一GOOD TRAP及冻结success PC均被绑定。原同EMU stdout完整SHA `c66766f203a152f7681c3251d36ec4d5378e9742a0737ac61fad5b4506208a95` 实际含ANSI颜色和CRLF；经固定gate归一化后，新格式表达式正确识别其 `0x80003a5a` GOOD TRAP及900166/1510313聚合诊断，未见ANSI或行首约定引起的误拒。这个旧PC只用于格式检查，没有填入新profile。

聚合计数只存诊断，不用作应用收益或内核分母。`guest_all_slots_guards_csrs_checked` 等字段表达的是冻结guest验收路径完成；代码同时明确 `full_target_memory_dump=false`、prepare在窗外、没有完整退休审计。target负例和target回放均记为false，不把参考负控或回放升级成新target执行。

完整状态名只在正常EMU退出、完整协议解析及输入/profile复核之后设置；最终清理、信号或输入变化可以撤销成功。`performance_qualified`、application performance及ASIC资格保持false。

## 进程回收与外层职责

独立按 `source-derivation.json` 的六项变换逆向恢复了完整旧 `run()`；六个helper也逐字相同，SHA符合记录。只改资源绑定、状态名和资格范围。CPU1、绝对nice5均实际回读；子进程使用独立session/PGID、每流16MiB限制、0.25s信号/截止检查。固定helper的TERM等待、必要KILL、wait回收有界。

正常路径要求exit0且group absent；最终再次poll/reap并检查group。回收异常、残留组、取消、profile或任一pin变化都会置FAILED并撤销target资格，不自动启动第二K、重放或延期。失败原流和终态继续保存。

9000s内层EMU截止由本脚本执行；9600s外层operation限制、外层operation/owner身份和调用回执属于root的ChatPC启动层，并非本脚本另有一个外层watchdog。启动层应按既有合同保存其实际回执；最终只有原operation和脚本终态都闭合，才可宣称资源释放完成。此职责划分不要求新增owner框架或额外guest。

## 审查范围

本报告覆盖最终 `df95f6a0…` 版本的源码和当前cloud实际元数据接口，未执行本机preflight，因此没有声称423个原路径已由本次审查重新读回，也没有授予target PASS。新preflight和实际EMU结果仍由root使用该固定版本产生。无需因本次审查额外增加target负控、回放或TRACE门槛。
