#!/usr/bin/env python3
"""Transport the fixed CLOSED K288 target/preflight, without running a checker.

Adapted from archive_packed_reference.py: streaming hashes, whole ZIP readback,
original-tree after-scan, CPU1/nice5, finite timer and failure retention.
Five exact roots; no omissions, external dependency reads, guest or subprocess.
"""
import argparse
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import stat
import sys
import time
import zipfile

RUNS = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-packed-ws-20261107-main')
SOURCES = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main')
CONTRACT = 'r3-packed-ws-eight-window-target-v1'
TARGET_STATUS = 'PACKED_WS_EIGHT_WINDOW_TARGET_PASS'
PROFILE_SHA = 'b48e4dfd3f6d1bc13c741f6cacc00b9097c946844abeb24c3ffd52d0a1100181'
REFERENCE_RESULT_SHA = '65de4aca20b86d7faaed7c11863297930d571ee2c97b2ad54bb15bdd4c72e4d0'
REFERENCE_ARCHIVE = dict(name='reference-raw.zip', bytes=11059275,
    sha256='20598d3ee465ce7fab91180d1172efc7d83680b04a6ac75c39dbefe3ee77a0b1',
    publication_path='team/optimizations/o2/dot16/whole2/packed-ws/reference-raw.zip',
    original_path=str(SOURCES / 'archive-reference-01/raw.zip'),
    read_or_rehashed=False)
HOST_OPERATION = '0250d6044ba18f5fd71831ae3131d2ce.be44a4d254afc57af4be96e78c6f3a08'
FIXED_WSL = {
    'target-k288-01/status.json': (2219, 'e0011666c36625a40538100e201f2cda2cad75c8f48557255b89361981b71775'),
    'target-k288-01/checks.json': (2654, '66b30e06cb5a39f57e3790210dc3b2aa741d7a01a8230857c8d556d164e7bb4d'),
    'target-k288-01/stdout.log': (1733, '166e024ec76c515e39cc2b6910a101ca8b686a6dce446fd441133470433094b0'),
    'target-k288-01/stderr.log': (3065676, '9af09d53a803fcfb1788ab2fd77339645f13d24f346099ac1ac04381ac24020f'),
    'preflight-k288-01/profile.json': (88784, PROFILE_SHA),
    'preflight-k288-01/result.json': (373, 'd6942d424b675d553b874e70cf3ef62e9c8196dd118406a17bc5d6e7b62c1154'),
}
SOURCE_PINS = {
    'run.py': 'df95f6a05dbf3ffdf4314de38ecd8bce13ff3a7b63ef2583bb99d00f77e29655',
    'TARGET_CONTRACT.md': '6a9e64f4f813daa8ab385d619b06d325c1762f6f158176eb141cf9683e33633d',
    'source-derivation.json': '2c78bae2293cb331d4d88a98457f275fd33881077658048f19b977764b74e10f',
}
FIXED_WINDOWS = {
    'target-source-01/source-manifest.json': (1104, '45b74d8a10bf4f053076fa2d1cc252069254ead979412cc94811abe218c1f9eb'),
    'archive-target-source-01/captured-files.json': (7939, 'de76b908ec7f1e4013b39c64bb508fe8c08bd57801dfa0d333ae29aaca4ad677'),
    'archive-target-source-01/host-receipt.json': (3909, '473c8f15b0869ea9dae165451284afa9a6226ee6fb9b56d883f403cd564ce6c3'),
    'archive-target-source-01/cycle-analysis.json': (1115, 'cb0acfc6c876080c6915f1c126fc194158e373b7c25577e50a5c2590bbca0854'),
}
ORDER = (1, 2, 3, 4, 4, 3, 2, 1)
STATUS_FALSE = ('performance_qualified', 'application_performance_qualified',
                'full_retirement_window_audited', 'asic_ppa_qualified', 'full_target_memory_dump')
CHECKS_FALSE = ('performance_qualified', 'application_performance_qualified',
    'full_retirement_window_audited', 'retired_custom_count_verified', 'target_replay_performed',
    'target_negative_performed', 'full_target_memory_dump', 'prepare_inside_measurement',
    'aggregate_is_kernel_or_application_metric')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def input_roots(runs, sources):
    return {**{'wsl/' + n: runs / n for n in ('target-k288-01', 'preflight-k288-01')},
            **{'windows/' + n: sources / n for n in
               ('target-source-01', 'target-launch-01', 'archive-target-source-01')}}


def fraction_record(value):
    value = Fraction(value)
    with localcontext() as context:
        context.prec = 28
        decimal = str(Decimal(value.numerator) / Decimal(value.denominator))
    return dict(numerator=str(value.numerator), denominator=str(value.denominator), decimal=decimal)


def compare_cycles(original, candidate):
    original, candidate = Fraction(original), Fraction(candidate)
    need(original > 0 and candidate > 0, 'positive recorded cycle observations')
    return dict(original_cycles=fraction_record(original), candidate_cycles=fraction_record(candidate),
        cycles_saved=fraction_record(original-candidate),
        speedup=fraction_record(original/candidate),
        cycle_reduction_pct=fraction_record(100*(original-candidate)/original))


def observe_windows(raw, checks, profile):
    """Recompute recorded numbers only; no GOOD-trap, DiffTest or stderr gate."""
    pattern = re.compile(r'PWS_SAMPLE ([0-9]+) ([1-4]) ([0-9]+) ([0-9]+) ([0-9]+) ([0-9a-f]{16})')
    lines = [line for line in raw.decode('utf-8', errors='strict').splitlines() if line.startswith('PWS_SAMPLE')]
    need(len(lines) == 8, 'exact eight recorded sample lines')
    samples = []
    for index, line in enumerate(lines):
        match = pattern.fullmatch(line)
        need(match is not None, 'complete original sample syntax')
        number, method, cycles, instructions, flags = map(int, match.groups()[:5])
        need(number == index and method == ORDER[index], 'original paired order and indices')
        samples.append(dict(index=number, method=method, cycles=cycles, instructions=instructions,
                            flags=flags, golden_fnv=match[6]))
    need(samples == checks['samples'], 'all exact stdout integers and hexadecimal hashes equal original checks')
    need(tuple(profile['order']) == ORDER and profile['sample_count'] == 8 and
         [x['instructions'] for x in samples] == profile['expected_window_instret'] and
         all(x['flags'] == profile['expected_flags'] and x['golden_fnv'] == profile['golden_fnv'] for x in samples),
         'recorded sample fields refer to the frozen profile')
    values = {method: [row['cycles'] for row in samples if row['method'] == method] for method in range(1, 5)}
    need(all(len(v) == 2 for v in values.values()), 'two recorded observations per method')
    means = {method: Fraction(sum(v), 2) for method, v in values.items()}
    need(set(checks['mean_cycles']) == {'1', '2', '3', '4'} and
         all(Fraction(str(checks['mean_cycles'][str(method)])) == mean for method, mean in means.items()),
         'exact arithmetic means equal original checks')
    ratios = dict(original_n_over_packed_n=means[2]/means[4],
        original_p_over_packed_p=means[1]/means[3], original_p_over_original_n=means[1]/means[2],
        packed_p_over_packed_n=means[3]/means[4],
        fastest_observed_rvv_over_fastest_observed_custom=min(means[1], means[3])/min(means[2], means[4]))
    need(set(checks['ratios_from_means']) == set(ratios) and
         all(checks['ratios_from_means'][key] == float(value) for key, value in ratios.items()),
         'original displayed ratios agree with exact rational means')
    pairs = {}
    for name, selections in {'P': ((0, 2), (7, 5)), 'N': ((1, 3), (6, 4))}.items():
        pairs[name] = [dict(order=order, original_index=left, packed_index=right,
            **compare_cycles(samples[left]['cycles'], samples[right]['cycles']))
            for order, (left, right) in zip(('forward', 'reverse'), selections)]
    fastest_rvv = min((1, 3), key=means.get); fastest_custom = min((2, 4), key=means.get)
    return dict(scope='Arithmetic recomputation of eight already-qualified local observations; no checker rerun or new qualification.',
        samples=samples, method_names={'1': 'P', '2': 'N', '3': 'packedP', '4': 'packedN'},
        mean_cycles={str(k): fraction_record(v) for k, v in means.items()}, paired_order_comparisons=pairs,
        mean_p=compare_cycles(means[1], means[3]), mean_n=compare_cycles(means[2], means[4]),
        fastest_observed=dict(rvv_method=fastest_rvv, custom_method=fastest_custom,
            **compare_cycles(means[fastest_rvv], means[fastest_custom])),
        exact_rational_ratios={k: fraction_record(v) for k, v in ratios.items()},
        prepare_inside_measurement=False, performance_qualified=False, application_performance_qualified=False,
        full_retirement_window_audited=False, retired_custom_count_verified=False,
        statistical_confidence_claimed=False, checks_samples_and_means_matched=True)


def evidence_metadata(runs, sources, status, checks, profile, preflight, source_manifest, captured, host, stdout):
    """Read-only captured metadata binding; caller transports all original bytes."""
    roots = input_roots(runs, sources)
    target, pre = runs / 'target-k288-01', runs / 'preflight-k288-01'
    pins, sizes, groups, external = {}, {}, {}, {}

    def pin(path, digest, group, size=None):
        path = Path(path)
        need(path.is_absolute() and '..' not in path.parts and
             any(path.is_relative_to(root) for root in roots.values()), 'pin inside one selected closed tree')
        need(re.fullmatch('[0-9a-f]{64}', digest) is not None, 'recorded SHA256')
        need(path not in pins or pins[path] == digest, 'consistent recorded pin')
        pins[path] = digest; groups.setdefault(group, set()).add(path)
        if size is not None:
            need(type(size) is int and size >= 0 and (path not in sizes or sizes[path] == size), 'consistent original size')
            sizes[path] = size

    for name, (size, digest) in FIXED_WSL.items():
        pin(runs / name, digest, 'fixed_closed_records', size)
    for name, (size, digest) in FIXED_WINDOWS.items():
        pin(sources / name, digest, 'fixed_source_bundle_and_captures', size)
    need(status['schema'] == 1 and status['contract'] == CONTRACT and status['status'] == TARGET_STATUS and
         status['finished'] and status['process_started'] is True and status['exit_code'] == 0 and
         status['process_reaped'] is True and status['process_group_absent'] is True and
         status['input_identities_unchanged'] is True and status['changed_inputs'] == [] and
         status['signals'] == dict(first=None, count=0) and status['target_runtime_qualified'] is True,
         'recorded target closure and original limited runtime qualification')
    need(all(status[key] is False for key in STATUS_FALSE) and all(checks[key] is False for key in CHECKS_FALSE),
         'no original performance/application/retirement qualification promoted')
    need(status['cpu_affinity'] == [1] and status['nice'] == 5 and status['k'] == 288 and
         status['budget_seconds'] == 9000 and status['stream_limit_bytes'] == 16777216 and
         status['profile'] == str(pre / 'profile.json') and status['profile_sha256'] == PROFILE_SHA and
         status['checks_sha256'] == FIXED_WSL['target-k288-01/checks.json'][1] and status['cwd'] == str(target / 'cwd'),
         'exact original target resources and record bindings')
    need(profile['contract'] == CONTRACT and profile['status'] == 'FROZEN_BEFORE_EMU' and
         profile['k'] == checks['k'] == 288 and profile['fixture_kind'] == checks['fixture_kind'] == 'normal-0' and
         profile['cpu'] == 1 and profile['nice'] == 5 and profile['max_cycles'] == 4000000 and
         profile['budget_seconds'] == 9000 and profile['stream_limit_bytes'] == 16777216 and
         profile['target_runtime_qualified'] is False and profile['new_emu_runs'] == 0 and
         profile['prepare_inside_measurement'] is False, 'retain frozen preflight state and exact original profile')
    need(preflight['status'] == 'PACKED_WS_EIGHT_WINDOW_PREFLIGHT_PASS' and
         preflight['profile'] == str(pre / 'profile.json') and preflight['profile_sha256'] == PROFILE_SHA and
         preflight['k'] == 288 and preflight['input_files'] == len(profile['pins']) == 432 and
         preflight['new_emu_runs'] == preflight['new_builds'] == preflight['new_abi_probes'] == 0,
         'original preflight remains a zero-execution record')
    need(profile['reference_build'] == str(runs / 'reference-02') and
         profile['reference_result_sha256'] == REFERENCE_RESULT_SHA and
         profile['image'] == str(runs / 'reference-02/k288/images/normal-0/real-w2.bin') and
         profile['elf'] == str(runs / 'reference-02/k288/packed-screen.elf') and
         profile['pins'][profile['image']] == profile['image_sha256'] and
         profile['pins'][profile['elf']] == profile['elf_sha256'], 'image and ELF are external reference-02 inputs, not target copies')
    expected_command = [profile['emu'], '-i', profile['image'], '--flash=' + profile['flash'],
                        '--ram-size=128MB', '--diff=' + profile['reference'], '--max-cycles=4000000', '--seed=1']
    need(status['command'] == expected_command and checks['loaded_reference'] == profile['reference'] and
         checks['success_pc'] == profile['success_pc'], 'recorded command/checks belong to the exact profile')
    for path, digest in profile['pins'].items():
        p = Path(path); normalized = Path(os.path.normpath(p))
        need(p.is_absolute() and re.fullmatch('[0-9a-f]{64}', digest) is not None, 'original profile dependency identity')
        if any(p.is_relative_to(root) or normalized.is_relative_to(root) for root in roots.values()):
            pin(p, digest, 'original_profile_internal_pins')
        else:
            external[path] = digest  # Preserve external include/../ spellings; never open them.
    need(len(groups['original_profile_internal_pins']) == 7 and len(external) == 425,
         'complete original profile pin partition')
    for key, filename in (('gate', 'runtime_gate.py'), ('helper', 'process_helper.py'), ('runtime_source', 'run.py')):
        need(profile[key] == str(pre / 'inputs' / filename) and Path(profile[key]) in pins, 'original preflight executable snapshot')
    need(profile['runtime_sha256'] == SOURCE_PINS['run.py'], 'actual target controller identity')
    need(len(source_manifest) == 10, 'complete original source bundle manifest')
    for name, digest in source_manifest.items():
        rel = PurePosixPath(name)
        need(str(rel) == name and not rel.is_absolute() and '..' not in rel.parts and rel.parts, 'safe source bundle name')
        pin(sources / 'target-source-01' / rel, digest, 'source_bundle_pins')
    need(all(source_manifest.get(name) == digest for name, digest in SOURCE_PINS.items()), 'three fixed delivered target sources')
    need(captured['path'] == str(target) and len(captured['files']) == 4 and
         {x['name'] for x in captured['files']} == {'status.json', 'checks.json', 'stdout.log', 'stderr.log'},
         'complete original captured target-file identities')
    for item in captured['files']:
        need((item['bytes'], item['sha256']) == FIXED_WSL['target-k288-01/' + item['name']], 'captured original byte identity')
        if 'text' in item:
            raw = item['text'].encode('utf-8')
            need(len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], 'captured text is exact original bytes')
            if item['name'] == 'status.json':
                need(json.loads(raw) == status, 'captured original status')
            elif item['name'] == 'checks.json':
                need(json.loads(raw) == checks, 'captured original checks')
            elif item['name'] == 'stdout.log':
                need(raw == stdout, 'captured original stdout including CRLF and ANSI bytes')
    for name in ('stdout.log', 'stderr.log'):
        size, digest = FIXED_WSL['target-k288-01/' + name]
        need(status['raw_logs'][name] == dict(bytes=size, sha256=digest), 'full raw stream identity from closed status')
    need(host['operation_id'] == HOST_OPERATION and host['status'] == 'succeeded' and
         host['shell']['operation_id'] == HOST_OPERATION and host['shell']['status'] == 'succeeded' and
         host['shell']['result']['exit_code'] == 0 and host['shell']['result']['cleanup_complete'] is True and
         host['shell']['result']['timed_out'] is False and host['shell']['result']['cancelled'] is False,
         'same recorded successful host operation; no live process inquiry')
    host_lines = host['shell']['result']['stdout'].splitlines()
    need(len(host_lines) == 2 and json.loads(host_lines[1]) == status, 'original host stdout contains this exact terminal status')
    observations = observe_windows(stdout, checks, profile)
    evidence = dict(original_status=status['status'], original_contract=CONTRACT,
        original_runtime_qualification=status['target_runtime_qualified'],
        original_qualification_scope=status['qualification'],
        original_false_qualifications={k: status[k] for k in STATUS_FALSE},
        original_checks_false_qualifications={k: checks[k] for k in CHECKS_FALSE},
        original_pid=status['pid'], original_pgid=status['pgid'],
        recorded_child_closed=True, host_operation_id=HOST_OPERATION,
        original_started=status['started'], original_finished=status['finished'],
        host_started=host['shell']['started_at'], host_finished=host['shell']['updated_at'],
        original_profile_pin_count=432, archived_profile_pin_count=7, external_profile_pin_count=425,
        external_image=dict(path=profile['image'], sha256=profile['image_sha256'],
            reference_archive_member='wsl/reference-02/k288/images/normal-0/real-w2.bin'),
        external_elf=dict(path=profile['elf'], sha256=profile['elf_sha256'],
            reference_archive_member='wsl/reference-02/k288/packed-screen.elf'),
        reference_archive=dict(REFERENCE_ARCHIVE),
        raw_logs=status['raw_logs'], stderr_read_as_diagnostic_or_error_gate=False,
        pin_scope='Profile pins are historical execution inputs; source bundle/capture pins are provenance. Other files receive transport hashes only.')
    return pins, sizes, groups, external, evidence, observations


def recorded_evidence(runs, sources):
    for root, fixed in ((runs, FIXED_WSL), (sources, FIXED_WINDOWS)):
        for name, (size, digest) in fixed.items():
            path = root / name
            need(path.stat().st_size == size and sha(path) == digest, 'fixed original record bytes: ' + name)
    target, pre, archive_source = runs / 'target-k288-01', runs / 'preflight-k288-01', sources / 'archive-target-source-01'
    return evidence_metadata(runs, sources, read(target / 'status.json'), read(target / 'checks.json'),
        read(pre / 'profile.json'), read(pre / 'result.json'), read(sources / 'target-source-01/source-manifest.json'),
        read(archive_source / 'captured-files.json'), read(archive_source / 'host-receipt.json'),
        (target / 'stdout.log').read_bytes())


def scan(roots, pinned):
    # Same real-file/link policy as archive_prefix; no .o/.a or other exclusions.
    kept, omitted, directories = {}, {}, set()
    for namespace, root in roots.items():
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        directories.update((namespace.split('/')[0] + '/', namespace + '/'))
        for path in sorted(root.rglob('*')):
            mode = path.lstat().st_mode
            need(not stat.S_ISLNK(mode), 'archive tree contains a link: ' + str(path))
            name = namespace + '/' + path.relative_to(root).as_posix()
            if stat.S_ISDIR(mode):
                directories.add(name + '/')
                continue
            need(stat.S_ISREG(mode), 'regular archive input: ' + str(path))
            need(name not in kept, 'unique archive name')
            kept[name] = path
    return kept, omitted, directories


def main(a):
    need(sys.dont_write_bytecode, '-B required; frozen source inputs stay read-only')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(os.sched_getaffinity(0) == {1} and os.getpriority(os.PRIO_PROCESS, 0) == 5,
         'actual archive CPU1 and absolute nice5')
    need(a.runs == RUNS and a.sources == SOURCES and a.output == SOURCES / 'archive-target-01', 'fixed evidence roots and output')
    need(all(p.is_absolute() and p == p.resolve() for p in (a.runs, a.sources, a.output)), 'canonical absolute paths')
    runs, sources, out = a.runs, a.sources, a.output
    roots = input_roots(runs, sources)
    archive_source = sources / 'archive-target-source-01'
    need(all(p.is_dir() and not p.is_symlink() and p == p.resolve() for p in roots.values()), 'five canonical closed input trees')
    values = list(roots.values())
    need(all(not p.is_relative_to(q) and not q.is_relative_to(p)
             for i, p in enumerate(values) for q in values[i+1:]), 'disjoint input roots')
    need(not out.exists() and all(not out.is_relative_to(p) and not p.is_relative_to(out) for p in values),
         'fresh output separate from all input trees')
    need(Path(__file__).resolve() == archive_source / 'archive_packed_target.py', 'actual helper included in archive source')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone archive owns its finite timer')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 300
    handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM)}
    def interrupted(sig, _frame):
        raise InterruptedError('archive signal/deadline ' + str(sig))
    try:
        for sig in handlers:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 300)
        files, omitted, directories = scan(roots, {})
        pinned, sizes, groups, external, evidence, observations = recorded_evidence(runs, sources)
        inventory = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
        by_path = {path: inventory[name] for name, path in files.items()}
        need(not omitted and len(by_path) == len(files), 'no omitted file or overlapping namespace')
        need('wsl/target-k288-01/cwd/' in directories, 'original cwd directory retained, including when empty')
        need(all(p in by_path and by_path[p]['sha256'] == digest for p, digest in pinned.items()), 'all recorded local pins retained unchanged')
        need(all(by_path[p]['bytes'] == size for p, size in sizes.items()), 'all original complete file spans')
        manifest = dict(schema=1, evidence=evidence, cycle_observations=observations,
            input_roots={name: str(path) for name, path in roots.items()},
            recorded_pin_counts={key: len(value) for key, value in groups.items()},
            files=inventory, directories=sorted(directories), omitted=omitted,
            omissions_deleted=False, all_selected_closed_tree_files_included=True,
            external_dependencies=dict(profile_path_sha256_pins=external, reference_archive=dict(REFERENCE_ARCHIVE),
                policy='External ELF/BIN/EMU/reference/source/tool/cache files and the older archive are not opened, copied or rehashed.'),
            receipts='windows/archive-target-source-01/host-receipt.json retained verbatim; original success is not rerun.',
            auxiliary_analysis='windows/archive-target-source-01/cycle-analysis.json retained as the original derived analysis; exact rational observations above are separately recomputed from stdout.',
            scope='ZIP transport and recorded-counter arithmetic only; no new correctness, performance, retirement, application or PPA qualification.',
            cpu_affinity=[1], nice=5, budget_seconds=300)
        raw_manifest = encoded(manifest)
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in sorted(directories):
                z.writestr(name, b'')
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            expected = set(files) | directories | {'ARCHIVE-MANIFEST.json'}
            need(len(z.namelist()) == len(expected) and set(z.namelist()) == expected, 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name in directories:
                need(z.getinfo(name).is_dir() and z.getinfo(name).file_size == 0 and z.read(name) == b'', 'exact directory member')
            for name, record in inventory.items():
                need(not z.getinfo(name).is_dir() and z.getinfo(name).file_size == record['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == record['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted, after_directories = scan(roots, pinned)
        need(after == files and after_omitted == omitted and after_directories == directories, 'closed tree inventory unchanged')
        need(all(path.stat().st_size == inventory[name]['bytes'] and sha(path) == inventory[name]['sha256']
                 for name, path in after.items()), 'all retained source bytes unchanged')
        audit = dict(status='PACKED_TARGET_RAW_ARCHIVE_VERIFIED', started=started, finished=stamp(),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive), files=len(files),
            members=len(expected), directories=len(directories), raw_kept_bytes=sum(x['bytes'] for x in inventory.values()),
            recorded_pins_verified=len(pinned), recorded_pin_counts=manifest['recorded_pin_counts'],
            omitted_files=0, omitted_bytes=0, member_crc_and_sha_verified=True, empty_directories_retained=True,
            retained_files_unchanged=True, source_membership_unchanged=True, original_files_deleted=False,
            original_recorded_child_closures_checked=True, live_processes_requeried=False,
            external_dependencies_rehashed=False, original_validators_rerun=False, stderr_used_as_new_gate=False,
            new_builds=0, new_eda_runs=0, new_guest_runs=0, source_evidence=evidence,
            cycle_observations=observations, input_roots=manifest['input_roots'], external_dependency_count=len(external),
            qualification='Transport integrity and exact recorded arithmetic only; original target scope retained without promotion.')
        need(time.monotonic() < deadline, 'complete archive within total budget')
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error),
            started=started, finished=stamp(), original_files_retained=True, new_guest_runs=0, new_eda_runs=0)))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('runs', 'sources', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    main(parser.parse_args())
