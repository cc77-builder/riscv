"""Two offline synthetic UINT32_MAX boundary checks. No preflight or guest."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path('/workspace/scratch/f9116701fd09')
OUT = Path(__file__).resolve().parent
BASE = ROOT/'source-review/packed-ws-20261107'
PINS = {
    BASE/'target-source-01/run.py': 'df95f6a05dbf3ffdf4314de38ecd8bce13ff3a7b63ef2583bb99d00f77e29655',
    BASE/'target-inputs/runtime_gate.py': '172551fb537e93f33937819b1a7625e39986726c039266750adadb73e8ccc05c',
    BASE/'actual-eight/result.json': '65de4aca20b86d7faaed7c11863297930d571ee2c97b2ad54bb15bdd4c72e4d0',
    BASE/'actual-eight/k288/static.json': '9883493045580c3c30f95616e671a2343726e8f04f9bd4b449f5647633d1c3ba',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def save(name, value):
    path = OUT/name
    assert not path.exists(), 'fresh output only'
    path.write_text(json.dumps(value, indent=2) + '\n')


for path, pin in PINS.items():
    assert digest(path) == pin, str(path)
runtime = load(BASE/'target-source-01/run.py', 'offline_boundary_runtime')
gate = load(BASE/'target-inputs/runtime_gate.py', 'offline_boundary_gate')
result = json.loads((BASE/'actual-eight/result.json').read_bytes())
static = json.loads((BASE/'actual-eight/k288/static.json').read_bytes())
normal = result['campaigns']['288']['validations']['normal-0']
record = static['records']['normal-0']
images = [p for p in result['generated_inputs']
          if p.endswith('/k288/images/normal-0/real-w2.bin')]
assert len(images) == 1 and static['inspection'] == result['campaigns']['288']['inspection']
profile = dict(k=288, fixture_kind='normal-0', image=images[0],
    order=[row[0] for row in normal['samples']],
    expected_window_instret=[row[3]-row[2] for row in normal['samples']],
    expected_flags=record['expected_flags'], golden_fnv=record['golden_fnv'],
    prepared_payload_bytes=10368, success_pc=static['inspection']['success_pc'])
assert profile['order'] == runtime.ORDER and len(profile['order']) == 8
save('synthetic-profile.json', profile)
outcomes = []
for cycles, should_accept in ((4294967294, True), (4294967295, False)):
    lines = ['OFFLINE SYNTHETIC BOUNDARY INPUT; NOT A TARGET RUN',
        'The image is ' + profile['image'],
        'The reference model is ' + static['reference'],
        'The first instruction of core 0 has commited. Difftest enabled.',
        'PWS_BEGIN k=288 rows=288 groups=9 control=0']
    for i, method in enumerate(profile['order']):
        count = cycles if i == 0 else 30000
        lines.append(f'PWS_SAMPLE {i} {method} {count} '
            f'{profile["expected_window_instret"][i]} {profile["expected_flags"]} {profile["golden_fnv"]}')
    lines += ['PWS_PASS k=288 samples=8 full_comparisons=16 prepared_bytes=10368',
        f'Core 0: HIT GOOD TRAP at pc = {profile["success_pc"]:#x}',
        f'Core-0 instrCnt = {normal["retired"]}, cycleCnt = 4295967295, IPC = 0.000170']
    raw = ('\n'.join(lines)+'\n').encode()
    name = f'cycles-{cycles}.synthetic.log'
    assert not (OUT/name).exists()
    (OUT/name).write_bytes(raw)
    try:
        checked = runtime.guest_check(raw, static['reference'], profile, gate)
    except ValueError as exc:
        assert not should_accept, repr(exc)
        assert str(exc) == 'method/order/complete value hash/exact flags/actual expected window instret'
        outcome = dict(cycles=cycles, outcome='REJECTED', exception=str(exc))
    else:
        assert should_accept and checked['samples'][0]['cycles'] == cycles
        outcome = dict(cycles=cycles, outcome='ACCEPTED')
    outcome.update(synthetic_log=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    outcomes.append(outcome)
assert all(digest(path) == pin for path, pin in PINS.items())
receipt = dict(status='OFFLINE_UINT32_MAX_BOUNDARY_CHECK_PASS',
    scope='Only two synthetic parser boundary checks; no target qualification.',
    cases=outcomes, input_pins={str(p): h for p, h in PINS.items()},
    helper_sha256=digest(Path(__file__)), candidate_inputs_unchanged=True,
    prior_13_mutations_rerun=False, preflight_runs=0, guest_runs=0,
    target_runtime_qualified=False, performance_qualified=False)
save('result.json', receipt)
print(json.dumps(receipt, indent=2))
