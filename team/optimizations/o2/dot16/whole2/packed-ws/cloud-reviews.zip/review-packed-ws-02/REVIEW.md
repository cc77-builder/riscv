# Packed-Ws N/P 四内核有限独立审查

## 结论

**有限 GO：未发现当前独立 `packed.S`、typed ABI 或 `pack.c` 的实质阻塞。** 完整源码差分符合固定布局变换；实际、未修改的 `pack.c` 已在 x86-64 host 上通过 ASan/UBSan 边界与逐字节验证。本结论不授予 RV64 编译、NEMU/EMU、target、完整应用或性能 PASS。

输入根目录为 `/workspace/scratch/f9116701fd09/source-review/packed-ws-20261107`。10 个完整输入的长度与 SHA256 见 `static-review-evidence.json`，host 回执也固定同一组 SHA。关键输入：

| 输入 | 字节数 | SHA256 |
|---|---:|---|
| `candidate/packed.S` | 17064 | `445ff9a47f182e8f876caf1dcd89eac2d13a25ebccd3ceb91d21a194d31edb15` |
| `pack.c` | 1162 | `7cca44cca9766762b46af4afbbab82a89fafaa4b329c6954558defeb93a55237` |
| `packed_ws.h` | 3685 | `0c2bf40d4339f59a973595435838486e0cb536a07b395a8bc9ac664a2da97bfd` |

## 源码与数值语义

独立脚本没有执行候选 `derive.py`：它自行列出三个冻结父文件的固定变换及次数，逐个逆向恢复完整父文件，再要求三块拼接与实际 `packed.S` 全字节相等，并核对候选记录。结果成立；当前文件 36 个标签互不重名。

除公开函数及其 guard/fast/fallback 前缀改名外，仅六处 `vlse32.v v12,(a4),t3` 改为 `vle32.v v12,(a4)`、六处组步进 `+4` 改为 `+32`、六处 tile 尾步进 `+252/+672` 改为 `+0`。N 每种 K 一条路径，P 每种 K 的 fast/fallback 两条路径都已改。保留的 `t3=36/96` 与 `addi a4,a4,0` 是冗余指令，不改变结果。

新布局每个输出 word 对应 `tile/group/lane`，来源是 `Ws[(tile*8+lane)*G+group]`，其中 G 为 9 或 24。所有六处载入前均为 `vl=8,e32,m2`；在 VLEN128 下恰好将同一八行 scale 放入 v12/v13。每组消耗 32B，每 tile 消耗 `G*32`，无需额外 tile 跳步；最后一组完整落在 10368B/27648B 对象内，最终指针仅到 one-past。

既有 `cast(dot) → multiply Ws → multiply Xs → left-fold add` 的指令、顺序及分组次序逐字保留，未引入 FMA。P guard 仍完整扫描 9/24 个 32B X 分组，检测 `X<-127`，即 signed8 的 -128；发现后进入原 fallback。guard 没有消费或扰动 Ws 指针，两个分支均从 context 重新载入 Ws。guard、分支、W/X/Xs/y 步进及 CSR 序列都未改。

最终八个 128bit slot 的写出源码完整保留。N 保留父指令的 low32 dot/zero-high96 合同；P fast 的初始化与 tail-undisturbed reduction、fallback 的逐组清零和 reduction 也完整保留。本审查确认没有新破坏，未在 target 上重新执行这一合同。

## Typed ABI 与集成边界

新 scales 类型与两种 context 类型分开，prepare 和四个函数原型对应；context 大小 56B、字段偏移 0/8/16/24/32/40/48 与汇编载入相符。scale 对象精确 10368B/27648B、64B 对齐；slot 16B 大小/对齐。host 编译通过了头文件布局断言和独立 `_Generic` 原型断言；RV64 编译仍由主端验证。

**一个有条件的集成注意点：** 内部 `.Ltile_*`、`.Lgroup_*` 仍使用父文件名字。当前 packed 文件内部无冲突；如果与旧父源码直接拼进同一个 `.S`，会出现重复标签。与旧内核同时链接时将 `packed.S` 单独汇编成对象即可，无需为了当前独立文件修改候选。

## 实际 host 验证

使用 GCC 14.2.0，以 `-O2 -fstrict-aliasing -fno-fast-math -ffp-contract=off -fsanitize=address,undefined -fno-sanitize-recover=all` 编译实际 `pack.c` 和独立 `test_pack.c`。编译、执行均 exit0 并回收；全部 10 个输入 SHA 在执行前后相同。

每种尺寸各 5 组位模式，逐个覆盖全部 2592/6912 个 word：唯一普通位编码、唯一 qNaN payload、唯一负 sNaN payload、IEEE 边界值含正负零及 tile 交界、任意 uint32 位排列。共比较 47520 word / 190080B。唯一编码额外从实际复制结果反解三个坐标，检查完整索引双射；其余案例逐 word 比较原始四个字节。全部 36 tiles、35 个跨 tile 边界及所有组/行位置均包含在逐索引检查中。

输入和输出前后各 64B guard 在调用期间由 ASan poison，调用后检查 guard 字节；输入全体字节保持不变。初始化及 oracle 都通过 `memcpy`/字符访问操作表示，不求值 float，未用浮点相等代替 NaN/负零位保留。实际 packer 同样只读写 unsigned char。

首次 `review-packed-ws-01` 编译成功，运行遇到 LeakSanitizer 明确报告 ptrace 环境不支持，故保留为失败证据。第二次仅把 `detect_leaks=1` 改为 `0`，测试 C 字节完全相同，ASan/UBSan 与 poisoned guard 保留。没有丢弃或覆盖首次日志。

## 证据

| 文件 | SHA256 |
|---|---|
| `host-test-result.json` | `6642417399863387a8aab19731d11f1978b7e154237664b512405ed2a8e1e4d8` |
| `static-review-evidence.json` | `9fd7b9da67e3d78680b78134d37c6f30b736e09be6d045abd499935f94408e9a` |
| `execute.log` | `ceb38a4bf1627d6650cfd54c0662758a4ca28ba9285f159bbbf3db856ebffa8e` |
| `test_pack.c` | `98e8c70fd5db51db44557ab608df1f3db9d9df350dd6c4a86b8667cd11add4f5` |
| `../review-packed-ws-01/host-test-result.json` | `19c77e7780f27c281214382e247dc685f8bf72161ed3fef1cfaf9bd28420bab4` |

主端的 GNU 完整机器体差分与后续受控 target 验证仍独立负责；此处不把 unit-stride 的静态变化或 host packer 正确性解释为 cycle、完整应用或硬件性能改善。
