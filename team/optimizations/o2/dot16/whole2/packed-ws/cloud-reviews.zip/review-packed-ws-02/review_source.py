#!/usr/bin/env python3
"""Record a fixed, independently enumerated full-source diff; run no candidate code."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/f9116701fd09/source-review/packed-ws-20261107')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def need(condition, detail):
    if not condition:
        raise ValueError(detail)

def main():
    host = json.loads((HERE / 'host-test-result.json').read_text())
    inputs = {}
    for name, expected in host['input_sha256'].items():
        raw = (SOURCE / name).read_bytes()
        need(sha(raw) == expected, 'input identity: ' + name)
        inputs[name] = dict(bytes=len(raw), sha256=sha(raw))
    # Counts and transform contents are fixed here, not supplied by the
    # candidate deriver or its JSON. Public P prefixes include guard labels.
    plans = [
        ('dot16.S', [('q288_dot16_whole8_narrow', 5)], 252, 1),
        ('paired16.S', [('q288_paired16_rvv', 17)], 252, 2),
        ('w2_np.S', [('q768_dot16_whole8_narrow', 5),
                     ('q768_paired16_rvv', 17)], 672, 3),
    ]
    blocks, records = [], []
    derivation = json.loads((SOURCE / 'candidate/source-derivation.json').read_text())
    for name, symbols, tail, count in plans:
        parent = (SOURCE / 'parent' / name).read_bytes()
        edits = [(old.encode(), (old + '_packed_ws').encode(), n)
                 for old, n in symbols]
        edits += [
            (b'  vlse32.v v12, (a4), t3\n', b'  vle32.v v12, (a4)\n', count),
            (b'  addi a4, a4, 4\n', b'  addi a4, a4, 32\n', count),
            (f'  addi a4, a4, {tail}\n'.encode(), b'  addi a4, a4, 0\n', count),
        ]
        actual = parent
        for before, after, expected_count in edits:
            need(actual.count(before) == expected_count, 'forward anchor: ' + name)
            actual = actual.replace(before, after)
        inverse = actual
        for before, after, expected_count in reversed(edits):
            need(inverse.count(after) == expected_count, 'inverse anchor: ' + name)
            inverse = inverse.replace(after, before)
        need(inverse == parent, 'full inverse: ' + name)
        declared = derivation['sources'][name]
        need(declared['parent_sha256'] == sha(parent), 'manifest parent: ' + name)
        need(declared['derived_sha256'] == sha(actual), 'manifest derived: ' + name)
        need(declared['edits'] == [dict(before=a.decode(), after=b.decode(), count=n)
                                  for a, b, n in edits], 'manifest changes: ' + name)
        blocks.append(actual)
        records.append(dict(parent=name, parent_sha256=sha(parent),
                            derived_sha256=sha(actual), full_parent_inverse=True,
                            weight_scale_load_sites=count, group_step_sites=count,
                            tile_tail_sites=count))
    packed = (SOURCE / 'candidate/packed.S').read_bytes()
    need(b'\n'.join(blocks) == packed, 'entire concatenated candidate byte identity')
    labels = re.findall(rb'^([A-Za-z_.$][A-Za-z0-9_.$]*):', packed, re.M)
    need(len(labels) == len(set(labels)) == 36, 'standalone label uniqueness')
    old_run = HERE.parent / 'review-packed-ws-01'
    old_runner = (old_run / 'run_host.py').read_bytes()
    new_runner = (HERE / 'run_host.py').read_bytes()
    need(old_runner.replace(b'detect_leaks=1', b'detect_leaks=0') == new_runner,
         'bounded host environment retry difference')
    need((old_run / 'test_pack.c').read_bytes() == (HERE / 'test_pack.c').read_bytes(),
         'host test source unchanged on retry')
    evidence = dict(
        status='LIMITED_STATIC_GO_AND_HOST_PACK_PASS',
        input_root=str(SOURCE), input_identity=inputs,
        full_diff=records, exact_candidate_bytes=True, unique_standalone_labels=36,
        scale_load_sites=6, group_step_sites=6, tile_tail_sites=6,
        only_instruction_changes='Ws strided load to unit load; group +4 to +32; tile tail +252/+672 to +0',
        static_review=dict(fp_order_unchanged=True, guard_and_dispatch_unchanged=True,
                           fast_and_fallback_both_adapted=True, final_slots_unchanged=True,
                           csr_sequences_unchanged=True, typed_context_offsets_unchanged=True),
        conditional_integration_note='Parent .L labels are retained. Compile packed.S separately if parent objects coexist; do not concatenate old and new assembly into one translation unit.',
        host_attempts=[
            dict(result=str(old_run / 'host-test-result.json'),
                 result_sha256=sha((old_run / 'host-test-result.json').read_bytes()),
                 status='FAILED_UNSUPPORTED_LEAKSANITIZER_UNDER_PTRACE'),
            dict(result=str(HERE / 'host-test-result.json'),
                 result_sha256=sha((HERE / 'host-test-result.json').read_bytes()),
                 status=host['status'], summary=host['summary'])],
        host_retry_change='Only detect_leaks=1 -> 0; AddressSanitizer and UBSan retained',
        candidate_modified=False, rv64_compile_performed_by_this_review=False,
        rv64_kernel_executed=False, target_qualified=False, performance_qualified=False)
    output = HERE / 'static-review-evidence.json'
    need(not output.exists(), 'fresh static evidence output')
    output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(status=evidence['status'], evidence_sha256=sha(output.read_bytes()),
                          input_files=len(inputs), unique_labels=len(labels))))

if __name__ == '__main__':
    main()
