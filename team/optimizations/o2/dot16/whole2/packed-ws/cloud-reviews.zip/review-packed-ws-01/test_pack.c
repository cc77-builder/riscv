#include "packed_ws.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sanitizer/asan_interface.h>

#ifndef __SANITIZE_ADDRESS__
#error "This bounded host verification requires AddressSanitizer"
#endif

#define REQUIRE(c, message) do { if (!(c)) { \
    fprintf(stderr, "FAIL: %s at %s:%d\n", message, __FILE__, __LINE__); \
    exit(1); \
} } while (0)

#define CHECK_ABI(K) \
    _Static_assert(_Generic(&q##K##_prepare_packed_ws, \
        void (*)(struct q##K##_packed_ws_scales *, const float *): 1, default: 0), "prepare signature"); \
    _Static_assert(_Generic(&q##K##_dot16_whole8_narrow_packed_ws, \
        void (*)(const struct q##K##_packed_ws_context *): 1, default: 0), "N signature"); \
    _Static_assert(_Generic(&q##K##_paired16_rvv_packed_ws, \
        void (*)(const struct q##K##_packed_ws_context *): 1, default: 0), "P signature")
CHECK_ABI(288);
CHECK_ABI(768);
_Static_assert(_Alignof(struct packed_ws_slot) == 16, "slot alignment");

static const char *const pattern_names[] = {
    "unique_normal_bits", "unique_qnan_payloads", "unique_negative_snan_payloads",
    "ieee_edges_and_tile_boundaries", "arbitrary_u32_bijection"
};

static uint32_t pattern(unsigned profile, unsigned index, unsigned groups) {
    static const uint32_t edge[] = {
        UINT32_C(0x00000000), UINT32_C(0x80000000),
        UINT32_C(0x7f800000), UINT32_C(0xff800000),
        UINT32_C(0x7fc12345), UINT32_C(0xffc54321),
        UINT32_C(0x7f800001), UINT32_C(0xff800001),
        UINT32_C(0x00000001), UINT32_C(0x80000001),
        UINT32_C(0x007fffff), UINT32_C(0x807fffff),
        UINT32_C(0x00800000), UINT32_C(0x80800000),
        UINT32_C(0x7f7fffff), UINT32_C(0xff7fffff)
    };
    switch (profile) {
    case 0: return UINT32_C(0x3f000000) + index;
    case 1: return UINT32_C(0x7fc00000) | index;
    case 2: return UINT32_C(0xff800001) + index;
    case 3:
        if ((index / groups) % 8 == 7 && index % groups == groups - 1)
            return UINT32_C(0x80000000);
        if ((index / groups) % 8 == 0 && index % groups == 0)
            return UINT32_C(0x7f801234);
        return edge[index % (sizeof(edge) / sizeof(edge[0]))];
    default: return (UINT32_C(0x9e3779b9) * index) ^ UINT32_C(0xa5a5a5a5);
    }
}

static void check_guard(const unsigned char *p, unsigned char expected) {
    for (unsigned i = 0; i < 64; ++i) REQUIRE(p[i] == expected, "guard modified");
}

/* Decode the output stream's coordinates, then check original row-major bytes.
 * The unique-normal case additionally decodes the original index from the
 * actual result and checks its three coordinates plus a complete bijection.
 * No float lvalue is evaluated anywhere in the oracle or initialization.
 */
static void check_words(unsigned k, unsigned groups, unsigned profile,
                        const unsigned char *saved, const unsigned char *got) {
    unsigned char seen[288 * 24] = {0};
    unsigned count = 288 * groups;
    for (unsigned out_index = 0; out_index < count; ++out_index) {
        unsigned lane = out_index % 8;
        unsigned group = (out_index / 8) % groups;
        unsigned tile = out_index / (8 * groups);
        unsigned original = (tile * 8 + lane) * groups + group;
        REQUIRE(original < count, "oracle source index range");
        if (memcmp(got + 4 * out_index, saved + 4 * original, 4) != 0) {
            uint32_t a, b;
            memcpy(&a, got + 4 * out_index, 4);
            memcpy(&b, saved + 4 * original, 4);
            fprintf(stderr, "K%u profile%u output%u source%u got=%08" PRIx32
                    " expected=%08" PRIx32 "\n", k, profile, out_index, original, a, b);
            exit(1);
        }
        if (profile == 0) {
            uint32_t word;
            memcpy(&word, got + 4 * out_index, 4);
            REQUIRE(word >= UINT32_C(0x3f000000), "decoded lower bound");
            unsigned source_index = word - UINT32_C(0x3f000000);
            REQUIRE(source_index < count, "decoded upper bound");
            REQUIRE(source_index / groups / 8 == tile, "actual tile coordinate");
            REQUIRE(source_index / groups % 8 == lane, "actual row coordinate");
            REQUIRE(source_index % groups == group, "actual group coordinate");
            REQUIRE(seen[source_index]++ == 0, "actual source index duplicated");
        }
    }
    if (profile == 0)
        for (unsigned i = 0; i < count; ++i) REQUIRE(seen[i] == 1, "actual source index missing");
    printf("{\"case\":\"K%u\",\"groups\":%u,\"pattern\":\"%s\","
           "\"compared_words\":%u,\"compared_bytes\":%u,\"tiles\":36,"
           "\"tile_boundaries\":35,\"all_index_bijection\":%s,\"passed\":true}\n",
           k, groups, pattern_names[profile], count, 4 * count,
           profile == 0 ? "true" : "false");
}

#define DEFINE_CASE(K, GROUPS) \
    static struct source_##K { \
        _Alignas(64) unsigned char pre[64]; \
        float values[288 * GROUPS]; \
        unsigned char post[64]; \
    } input_##K; \
    static struct destination_##K { \
        unsigned char pre[64]; \
        struct q##K##_packed_ws_scales values; \
        unsigned char post[64]; \
    } output_##K; \
    _Static_assert(offsetof(struct source_##K, values) == 64, "source guard adjacency"); \
    _Static_assert(offsetof(struct source_##K, post) == 64 + 288 * GROUPS * 4, "source tail adjacency"); \
    _Static_assert(offsetof(struct destination_##K, values) == 64, "destination alignment and guard"); \
    _Static_assert(offsetof(struct destination_##K, post) == 64 + 288 * GROUPS * 4, "destination tail adjacency"); \
    static void run_##K(unsigned profile) { \
        unsigned char saved[288 * GROUPS * 4]; \
        memset(input_##K.pre, 0x31, 64); memset(input_##K.post, 0x73, 64); \
        memset(output_##K.pre, 0xd7, 64); memset(output_##K.post, 0x9b, 64); \
        memset(&output_##K.values, 0xa6, sizeof(output_##K.values)); \
        REQUIRE((uintptr_t)&output_##K.values % 64 == 0, "actual output alignment"); \
        REQUIRE((uintptr_t)input_##K.values % 4 == 0, "actual input alignment"); \
        for (unsigned i = 0; i < 288 * GROUPS; ++i) { \
            uint32_t bits = pattern(profile, i, GROUPS); \
            memcpy(&input_##K.values[i], &bits, sizeof(bits)); \
        } \
        memcpy(saved, input_##K.values, sizeof(saved)); \
        __asan_poison_memory_region(input_##K.pre, 64); \
        __asan_poison_memory_region(input_##K.post, 64); \
        __asan_poison_memory_region(output_##K.pre, 64); \
        __asan_poison_memory_region(output_##K.post, 64); \
        q##K##_prepare_packed_ws(&output_##K.values, input_##K.values); \
        __asan_unpoison_memory_region(input_##K.pre, 64); \
        __asan_unpoison_memory_region(input_##K.post, 64); \
        __asan_unpoison_memory_region(output_##K.pre, 64); \
        __asan_unpoison_memory_region(output_##K.post, 64); \
        check_guard(input_##K.pre, 0x31); check_guard(input_##K.post, 0x73); \
        check_guard(output_##K.pre, 0xd7); check_guard(output_##K.post, 0x9b); \
        REQUIRE(memcmp(saved, input_##K.values, sizeof(saved)) == 0, "input representation modified"); \
        check_words(K, GROUPS, profile, saved, (const unsigned char *)&output_##K.values); \
    }
DEFINE_CASE(288, 9)
DEFINE_CASE(768, 24)

int main(void) {
    for (unsigned profile = 0; profile < 5; ++profile) {
        run_288(profile);
        run_768(profile);
    }
    printf("{\"status\":\"HOST_PACK_COPY_PASS\",\"cases\":10,"
           "\"compared_words\":47520,\"compared_bytes\":190080,"
           "\"asan_poisoned_input_output_guards\":true,"
           "\"input_unchanged\":true,\"header_abi_static_assertions\":true,"
           "\"rv64_kernels_executed\":false}\n");
    return 0;
}
