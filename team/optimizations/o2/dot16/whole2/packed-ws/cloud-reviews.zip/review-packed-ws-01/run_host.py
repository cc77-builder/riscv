#!/usr/bin/env python3
"""One bounded host verification of the actual, unmodified pack.c."""
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/f9116701fd09/source-review/packed-ws-20261107')
PINS = {
    'candidate/packed.S': '445ff9a47f182e8f876caf1dcd89eac2d13a25ebccd3ceb91d21a194d31edb15',
    'candidate/source-derivation.json': '137800f4596cc9187adb471a7fbdedb886a3cd32b995f4a3c3c55b68fcffeef8',
    'derive.py': 'd03bab8fec1863597ccfc2ec74d9f6e75af1c8f7207cf22ad81a940f7d47fd19',
    'pack.c': '7cca44cca9766762b46af4afbbab82a89fafaa4b329c6954558defeb93a55237',
    'packed_ws.h': '0c2bf40d4339f59a973595435838486e0cb536a07b395a8bc9ac664a2da97bfd',
    'parent/dot16.S': '40d263b68ead735b84cb626086674463fbb81154ed9898eb8a340f95f102d671',
    'parent/paired16.S': '452ecab3ae3122dd8ea3d5ae05140197a10bb14a9a5ab76437f7591b00b29caf',
    'parent/w2_np.S': 'fbe3a93f642ec3468da92ae776e1b547c29c527d4dffc30456191b437d1272c5',
    'parent/q288.h': 'f8e4df00dba860487c168f6990edbf2dc8814291b825d30762c7ecad61821cc2',
    'parent/w2.h': '605a28aef27442e6ea15cae94f2350cdd7ac69ed40af7ea501f9650d6606544e',
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def check_inputs():
    for rel, expected in PINS.items():
        if sha(SOURCE / rel) != expected:
            raise ValueError('changed review input: ' + rel)

def run(label, argv, env, timeout):
    start = time.monotonic()
    with (HERE / (label + '.log')).open('wb') as stream:
        proc = subprocess.Popen(argv, cwd=HERE, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=timeout)
        except BaseException:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait(timeout=3)
            except ProcessLookupError:
                proc.wait()
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=3)
            raise
    return dict(label=label, argv=list(map(str, argv)), exit_code=code,
                seconds=time.monotonic() - start, reaped=proc.poll() is not None,
                log_sha256=sha(HERE / (label + '.log')))

def main():
    check_inputs()
    result = dict(status='RUNNING', host_machine=platform.machine(),
                  source_root=str(SOURCE), input_sha256=PINS, commands=[],
                  candidate_modified=False, rv64_kernel_executed=False,
                  target_qualified=False, performance_qualified=False)
    output = HERE / 'host-test-result.json'
    if output.exists() or (HERE / 'host_pack_test').exists():
        raise ValueError('this evidence output must be fresh')
    cc = '/usr/bin/gcc'
    env = dict(os.environ, LC_ALL='C', ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key in ('CPATH', 'C_INCLUDE_PATH', 'CPLUS_INCLUDE_PATH', 'LIBRARY_PATH',
                'LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT'):
        env.pop(key, None)
    result['compiler'] = dict(path=cc, realpath=str(Path(cc).resolve()), sha256=sha(cc),
                             version=subprocess.check_output([cc, '--version'], text=True).splitlines()[0])
    result['test_source_sha256'] = sha(HERE / 'test_pack.c')
    result['runner_sha256'] = sha(__file__)
    argv = [cc, '-std=c11', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
            '-fstrict-aliasing', '-fno-fast-math', '-ffp-contract=off',
            '-fsanitize=address,undefined', '-fno-sanitize-recover=all',
            '-fno-omit-frame-pointer', '-I', str(SOURCE), str(SOURCE / 'pack.c'),
            str(HERE / 'test_pack.c'), '-o', str(HERE / 'host_pack_test')]
    try:
        rec = run('compile', argv, env, 60)
        result['commands'].append(rec)
        if rec['exit_code'] != 0:
            raise ValueError('host compilation failed')
        result['binary_sha256'] = sha(HERE / 'host_pack_test')
        rec = run('execute', [str(HERE / 'host_pack_test')], env, 30)
        result['commands'].append(rec)
        if rec['exit_code'] != 0:
            raise ValueError('host verification failed')
        rows = [json.loads(line) for line in (HERE / 'execute.log').read_text().splitlines()]
        if len(rows) != 11 or rows[-1]['status'] != 'HOST_PACK_COPY_PASS':
            raise ValueError('incomplete host report')
        if len(rows[:-1]) != 10 or not all(row['passed'] for row in rows[:-1]):
            raise ValueError('incomplete cases')
        result['cases'], result['summary'] = rows[:-1], rows[-1]
        check_inputs()
        result.update(status='HOST_PACK_COPY_PASS', inputs_unchanged=True,
                      asan_ubsan_enabled=True, all_children_reaped=True)
    except BaseException as exc:
        result.update(status='FAILED', error=repr(exc))
        raise
    finally:
        output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'inputs_unchanged', 'summary')}))

if __name__ == '__main__':
    main()
