# Packed-Ws 固定 K 五臂 screen 源码审查

## 结论与版本

当前源码层未发现需要阻止计划中 GNU 构建或参考运行的具体错误。没有修改 screen 源码、运行编译器、执行 host oracle/NEMU/EMU，未读取本机或任何活跃 target/owner。新参考控制器还在 root 编写，本报告不对未见控制器或未来生成的 ELF 授予资格。

审查版本：

| 文件 | 字节 | SHA256 |
| --- | ---: | --- |
| `screen/main.c` | 8187 | `3bb643c350b6b676766c14fd49d0642fc7a4631b95787b6bf1693ee0acea58be` |
| `screen/flags_host.c` | 2141 | `619bfcd30fe8112280cd449eb7bfb1e2c5b6972daf75cd11d29c844e6909a477` |

上述相对路径位于 `/workspace/scratch/f9116701fd09/source-review/packed-ws-20261107/`。其余实际读过的输入及完整 SHA 见同目录 `inputs.json`。以下行号指本表版本。

## 固定几何、调度与类型

`main.c` 第8行和第19行分别选择 K288/K768，其他 K 在编译期拒绝。每个 K 需要独立 ELF，但每个 ELF 内同时保留五臂。各自的 fixture、gold、flags 和打包长度应由对应 K 的实际固定来源绑定，不能跨 K 混用。源码固定 M288、GS32、36个完整8行tile；不涵盖分类器行尾或其他尺寸。

| method | 入口与 Ws 布局 | 活跃槽 | 每个正常 guest 的调用数 |
| ---: | --- | --- | ---: |
| 0 | 原 `q288_oracle` / `w2_scalar`，row-major Ws | 两套槽均不写 | 2 |
| 1 | 原 P，row-major Ws | `RowSlot` | 4 |
| 2 | 原 N，row-major Ws | `RowSlot` | 4 |
| 3 | packed P，`PackedScales` | `packed_ws_slot` | 4 |
| 4 | packed N，`PackedScales` | `packed_ws_slot` | 4 |

第131行 ORDER 为 `0,1,2,3,4,4,3,2,1`，每个样本一遍 warm、一遍 measured，共9窗口/18调用。第108–113行分别构造旧、新具名 context，未转换不兼容结构或函数指针；旧 q288 的 `split_leaf entry` 用合法零指针初始化，新 context 的 `uintptr_t reserved` 为0。K288 的 `caller_slot` 与 K768 的 `w2_slot` 均是16B，独立新槽也为16B。各个槽 payload 从64B对齐对象的偏移16开始，满足16B对齐；旧、新槽没有共享存储或别名。

`compare()` 第85行完整比较1152B输出；旧槽仅 method1/2 比对128B slot-gold，其他臂要求完整A5；新槽仅 method3/4 比对slot-gold，其他臂要求完整A5。两套槽和输出各有16B前后guard。

## Prepare 与独立期望

第52–57行的 prepared object 是64B前guard、完整 `PackedScales`、64B后guard，payload自身64B对齐且无额外尾部padding：

| K | payload | 完整 prepared object |
| ---: | ---: | ---: |
| 288 | 10368B | 10496B |
| 768 | 27648B | 27776B |

第128–129行先填A5，再实际调用 `PREPARE(&prepared.data,w2_scales)`，随后逐字节比较完整外部 `w2_packed_scales` 并核全部guard。实际 `pack.c` 第9–15行按 `[row][group] → [tile][group][lane]` 拷贝四字节对象，未把 Ws 转成 host float 后重写。外部 packed-scales 必须来自先冻结的独立字节排列；不能用本次 DUT prepare 产物反过来作为期望。

正常结束前第144行再次比较 prepared 全payload和guards。每次结果比较还检查 prepared guards；这里证明的是开始/正常结束时的payload相等，不声称逐调用中间时刻的payload都已另行dump。负例在尾部全量检查前拒绝，已有 NEMU 内存导出能力可通过终态完整 prepared dump 核验。

本审查不假定 target 有任意内存导出能力。target 可依照既定计划复用 guest 全字节比较、负控和 DiffTest；如增加窗外UART诊断，应按实际输出范围描述。此项不改变在途完整 forward 的验收。

## 负控与新 dump 的精确终态

第133行负例固定 method2；warm 正常通过后，measured 返回并取完计数器/FCSR，第136行只翻 `((unsigned char*)output.data)[287*4]` 的一个bit。第87行按字节递增比较，因而预期拒绝偏移1148、code91。拒绝发生在样本写入之前，故继续保留原判据：warm计数1、已接受样本0、sample0、所有576B samples为0、精确最后输出bit变化；不能把任意非零退出当成负控成功。

**正常 ORDER 的最后一臂为 method1；负例为 method2。两种终态均应是旧槽=slot-gold，新槽=128B A5。** 新槽前后仍各是16B guard。不能在最终 dump 中把新槽期望写成gold；它在之前 method3/4 的结果已由每次 guest 比较覆盖。

原 `inspection-w2/inputs/original-reference.py` 的 `validate()` 第52行起可继续复用完整原判据，集成时对应变更有明确边界：

- ORDER 改为五臂九窗口；flags 从固定1改为本case绑定的精确值。
- 原不可变fixture列表加入 `expected-flags` 与 `packed-scales`；新dump加入160B packed-slots和上述完整prepared对象。原输出、旧槽、报告、样本、原输入的全量比较保留。
- 正常/负例原report形状仍适用；K由独立ELF和fixture身份绑定，原report magic本身不区分K。
- 保留原 `qualify_np.py` 第307–310行位于 validator 外的实际trap PC、`pc=halt_pc+4`、mcause/mepc/mtval为0检查，以及原adapter的精确退出和进程回收检查。新编译后的reject地址由实际ELF检查取得，不能搬旧地址。
- 完整1400B寄存器、32768B CSR dump和正常/replay完整验证相等仍依原接口保存。原dump存在不等于所有CSR都在guest中逐项比较；guest明确检查的是下节所列状态。

这些是新五臂 harness 与原验证接口的对应变化，不是对当前旧作业追加要求。

## FCSR、CSR 与窗口

第83行每次调用前设置 `vl=8/vtype=0/vstart=0/vcsr=7/fcsr=0`。第96–97行每次输出成功后检查四项向量状态；原标量 TU 应继续使用既有禁自动向量化编译选项，以免标量参考自身改变VL/vtype。

warm 的完整FCSR在 `compare()` 后读取；当前compare只有字节/整数/CSR操作，不引入浮点异常。measured 的完整FCSR在第135行 `i1/c1` 后立即读取，早于翻bit、compare、digest和printf。与低五位精确flags比较同时要求FRM为0，没有沿用旧K288只查FRM的较弱条件。

PREPARE及其首轮全字节检查位于所有窗口之外。restore在c0之前；窗口保留原 `c0 → i0 → apply → i1 → c1` 和fence；比较、hash、UART和末尾prepared检查均在窗外。窗口包含common harness的apply分支/context构造和函数调用开销，不是裸内核单独计数。此screen不测准备时间、权重打包、量化或完整forward；不能把窗口收益直接称为应用收益或忽略将来实际准备成本。

## Host flags 检查

`flags_host.c` 第25–29行读取完整固定 W/X/Ws/Xs/gold；第30行设置RNE并清异常；第31行的参数顺序与未修改 `q288_oracle` 声明/定义完全一致；第32行先取异常，之后才逐字节比较全部1152B输出。五类异常到 RISC-V NX/UF/OF/DZ/NV 的映射正确，输出固定四字节小端flags，不假定结果为1。新输出以exclusive-create打开，不覆盖已有文件。

编译入口须把严格FP选项施加到**两个翻译单元**：wrapper内的 `FENV_ACCESS` pragma不能跨TU约束原oracle。保留 `-ffp-contract=off`、禁fast-math；host固定受控binary32执行环境（本项目x86_64/SSE，避免x87扩展精度），使用 `-frounding-math` 并链接 `-lm`。目标端继续原禁自动向量化配置。实际命令、编译器身份及后续结果属于controller证据，本次未见其终态。

`K288_HOST_ORACLE_FLAGS_PASS` 仅是该host构建的固定数据完整值/异常观察。RISC-V精确flags仍由 root 已计划的原oracle NEMU交叉确定；旧K288 FRM检查不能继承为精确FCSR资格。独立子审查对这一接口、取样位置和编译边界得出同一结论，但未执行host或guest。

## 本次验证范围

已做完整相关源码阅读、实际文件SHA、旧参考接口和类型/布局/控制流推理；没有新增参考算法、测试矩阵或运行器。没有编译或执行本次screen，因此报告仅授予这两个源码版本的只读审查结论，所有运行/性能资格仍未定。
