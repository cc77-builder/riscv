# Packed-Ws reference controller 有限独立审查

## 结论

对审阅版本 `screen.py`（31329B，SHA256 `cadd154b2c04960f02651c0f3ce50a65e8e63441e71922c87886281d1be6095a`），未发现需要阻断冻结的具体启动错误或误 PASS 路径。此结论仅针对控制器静态实现及已提供的实际 W2/GNU 元数据；不是构建、NEMU、目标 EMU 或性能 PASS。

未修改 screen 目录，未导入或执行控制器，未运行本机、编译、guest 或 EDA。只在本审查目录写报告及证据索引。main.c/flags_host.c 的核心实现由另一位审查者负责；此处只核对 host validator 所依赖的公开接口和路线。

## 已核实的入口与身份

| 已读原件 | 实际身份 | 控制器读取点 |
|---|---|---|
| `source-review/packed-ws-20261107/inspection-w2/result.json` | 48270B / `7d46f70b4cb105bd468577815e21c97fe9fa249fb447eeec3c977d9236e3b8c1` | `original_inputs`、闭合 W2 资格与 source pins |
| `source-review/packed-ws-20261107/inspection-w2/static.json` | 11930B / `b498a43984c64707d28861505275fb0aff0e23e64778ba68d92350873e5bc448` | `records.normal/edge.fixtures`，各8个原 fixture |
| `source-review/packed-ws-20261107/inspection/result.json` | 18710B / `369307b6a392df26e1e34f5a643feb2cadb96f84ada8006214625ba6e27ebb8e` | `functions` 的4个 packed 与各自 parent 全函数身份 |
| `inspection-w2/inputs/original-reference.py` | 10130B / `9bc23d73550f0de16b2816fc732031f53dd81f6c9a483ce233ac2d2c4a7f41fa` | 提取唯一完整 `validate()`，不调用旧8af参考的 frozen/runtime入口 |

实际 W2 `original_inputs` 恰含一个 `/Makefile.app` 和一个 `/tools.json`，可据现有键唯一恢复 AM 与 GNU工具记录；引用层级没有把 `result.static_inspection` 错当 `static.inspection` 或把 fixtures 错放在 result 下。新 W2 固定 normal 的 expected_flags=1，edge=0，与已读原件一致。

K288 的四 case/file 字段与 `verification/q288-fixture-extract/extract.py` 的实际生产代码一致：normal-0/1/2、fullmin，各8个规范化文件，expected_flags=None，`exact_flags_resolved=false`。本审查未取得本机 extraction manifest/result 原始字节，不独立宣称其 runtime 身份已核；screen 自身以固定 manifest SHA、完成状态、文件 SHA/字节数核对该输入，字段接口未见不匹配。

## 生命周期与资源

`command()`（审阅版245行起）、`interrupt()`、`check()` 与 `source-review/w2-harness/qualify_np.py` 逐字节相同。保留 TERM/INT 首次 latch、0.25s 有限 wait 安全点、每子进程独立组、失败/超时回收、direct_child_reaped、group_absent、residual 与逐 guest 回执。没有重放未知操作或新增长期后台进程。

计划数核算：host flags 编译1次+四次 host flags=5；每 K 的 build/readelf/objdump=3，共6；K288 的 negative/default/replay/其余3例=6个 guest，K768 的 negative/normal/replay/edge=4个 guest。因此完整路径为 **21命令、10独立 reference进程**。代码明确要求 reference_runs=10 才授予最终 PASS，没有把 host flags 当 guest计数。

实际 affinity={1}、absolute nice5 在设置后读回；子进程继承、构建 -j1，线程环境固定。默认总预算1200s，CLI接受300..1800s；每命令受总剩余时间裁剪。guest使用100M API步/180s内部预算、210s外层命令预算；日志/单文件32MiB cap。外部工具调用仍需为成熟 stop_group 留有限回收余量。总预算是上限，不能把21项各自最大时限相加当作预计耗时；无需增加新的同机稳定性或机械命令数门。

## 输入、复制与 GNU 资格

source-manifest限定4个固定 basename，逐项固定 SHA 后复制；每次 copy 均回查原 pin，再导入 model/process helper。既有 GNU source快照、W2 source、AM、工具、运行时 NEMU、adapter和支持源的路径均只读，输出树与所有输入根分离。

每 K 保持独立完整ELF/BIN与fixture视图。`inspect()` 校验整个 ELF/BIN/BSS、静态入口、RAM/stack/heap边界、无动态/TLS/活跃重定位、trap机器字及计数器边界。每 K 从固定 GNU结果提取两个packed+两个parent，**每个完整函数的长度/SHA和RX PT_LOAD归属**都须与固定结果相同；没有用函数名或局部指令匹配代替全体字节，也没有将旧 GNU阶段的 runtime=false变为新reference PASS。

Makefile仅两项声明的替换并完整逆回旧文本。原scalar、entry、头文件、N/P与packed汇编、pack.c保持固定字节复制；新核心main作为新团队harness明确区分。host flags 编译使用固定GCC、禁fast-math/融合/向量化并启用frounding，四次输出均需4字节flags、0..31范围、准确gold/fenv成功标志；这些flags再进入对应完整fixture和guest终态检查。

## Fixture、validator与反例闭合

K288每例9个新image fixture包含原8文件及新expected-flags；K768同样由旧8文件加独立packed-scales排列构成。所有长度固定，packed scales按[tile][group][lane]完整四字节置换，K288另与已提取packed-scales逐字节相等。默认链接image逐段验证完整fixture字节与符号extent；变体只改声明的互不重叠fixture范围，guest只再改原2×u32负控/UART控制。

原完整 `validate()` 只改immutable fixture列表与flags来源，完整逆回成立；外部 ORDER 明确设为 `[0,1,2,3,4,4,3,2,1]`。保留原独立adapter状态/ABI/retired/API上限/无异常/无stderr、完整dump inventory与尺寸、所有288输出、8个完整128bit slots、guards、9个sample与CSR/register原始dump。新增prepared/packed-slots在dump-plan中，因而也进入原validator的完整尺寸/raw_sha映射和normal/replay整体比较；其内容与guard另有逐字节条件。全部9个不可变fixture在guest结束后核SHA；final-registers的完整FCSR值须等于该例expected_flags。

**负控的实际范围：**main当前 negative选择method2（原N），随后精确翻转最终输出byte1148。host要求固定code91/BAD trap、合法reject PC和PC+4、warm完成1/测量完成0、零samples、且全输出恰为gold仅该bit变化。它证明共享完整输出比较器拒绝该腐坏；不应称为packed-N专属负控。此路线使negative最终旧slots=gold、packed_slots=A5与当前host判据一致；无需仅为名称对齐修改它。

## 两点交付时的表述/归档边界

1. `reference_qualified=true` 只能在本次10例全部完成后成立；NEMU计数/host flags不能解释成香山目标周期或性能。`target_runtime_qualified`、`performance_qualified`、`application_performance_qualified` 三个资格标志保持false，target_emu_runs=0，新结果状态清楚。
2. `inputs.json`在初始inputs快照后保存，后续host和两K source复制继续增加同一 `snapshots` 字典；最终 **result.snapshots + result.generated_inputs** 才包含完整后续材料。代码每例都对这个完整活字典审计，未见资格漏洞。后续归档应使用最终这两张表和原始目录，不能误将早期inputs.json的snapshots当作全部后续快照清单。这是现有布局说明，不要求为此增加新框架或执行门。

没有建议扩展试验矩阵或重跑旧资格。待首席与main/flags审查者整合后，以真实新GNU/NEMU结果裁决。
