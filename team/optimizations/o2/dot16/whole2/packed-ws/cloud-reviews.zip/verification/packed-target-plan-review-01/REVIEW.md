# Packed-Ws 目标小试：有限方案审查

## 决策

**赞成采用新独立八窗口 v2，完成其参考验证后，只先启动 K288 normal-0 的一次目标运行。不要直接跑含 scalar 的九窗口旧 ELF，也不要同时预订 K768 长仿真。** 这是依据实际执行成本缩小重复工作；原九窗口、scalar 交叉和十例参考证据保留。新版本不继承旧 target PASS。

本次只读 cloud 副本并做有限静态核对，没有修改来源、实现控制器、读取本机或启动任何编译/测试。root 后续提供的八窗口修改已纳入本报告；截至审查，其新构建/参考/目标终态未在本次核验。

## 改变选择的实际证据

已完整读取 `source-review/packed-ws-20261107/actual-reference-result.json`，实际142366B，SHA256 `cec287cff44cdda1070539515a3d426fd81e6a4025e0a84ac6bcb632ef7f1f5a`。其中两K、十例均完成，全部子进程闭合、输入不变，target运行数为0。记录起止21:03:13.513577–21:03:30.610171Z，整个既有构建/host/十例参考阶段用时17.096594s。

| 正常参考 case | 全guest retired | measured scalar instret | 两次scalar调用的量级估算 |
| --- | ---: | ---: | ---: |
| K288 normal-0 | 2,032,427 | 636,520 | 约1,273,040，约占62.6% |
| K768 normal | 5,057,095 | 1,731,532 | 约3,463,064，约占68.5% |

最后一列只用两倍 measured scalar 窗口说明重复工作的量级，warm边界没有单独计时；它不是精确可删除指令数。直接相减的0.759M/1.594M也不是新 v2 的实测 retired。不能用这些参考计数宣称新目标周期或确定墙钟。

`source-review/narrow-terminal-review.json` 保存的原目标 stdout 则确有 `instrCnt=900166`、`cycleCnt=1510313`、`Host time spent: 6133536ms`，并有正常退出、reaped/group absent终态；其整文件SHA为 `39dbdf4b4b7ead4848a31818e476f518ce3749b541fa7877257c5d4268bee94f`。对应 `team/optimizations/o2/dot16/whole2/NARROW_Q288_RESULT.md` 记录 CPU0/nice4、共享四核资源、4M cycles/9000s预算。新的CPU1/nice5调度不同，不保证同速，但足以说明继续在目标上重复大标量窗口可能占用数小时。

删除 scalar 计时并不删除待比较四函数的任何调用：仍保留原P/N与packedP/N，各两个相反顺序样本，每个样本前完整warm，并执行原gold、双槽、guards和状态检查。固定独立gold、精确flags已由旧scalar及NEMU交叉，随后新 v2 的四函数还会在原NEMU上完整检查。该方案的工程成本与预期节省相比合理。

## v2 的窄接口核对

实际审查目录：`source-review/packed-ws-20261107/screen-eight-v2/`。

| 文件 | 字节 / SHA256 |
| --- | --- |
| main.c | 8185 / `6933f5a75a9b61b4b6ee96cdaae1f2e4649312ef0ef726272c7d521c08bc2b4d` |
| screen.py | 32611 / `41907943f78825afb3accde2ead8f9952e01b60770fe76cec8e2b6436b4ea76e` |
| source-manifest.json | `aaa8ed4e724069f79344ac3ce97d21dc408456b84f110b495a2e973031c394e3` |
| source-derivation.json | `3175d74d4ac4bf2415c6892e53de7636c262efd7dae039b472b4e447e2826cce` |

未发现具体启动阻塞：

- 独立按派生记录正向、反向替换，main四项修改及controller全部修改均恢复完整原字节；manifest实际SHA逐项相符。
- ORDER为 `[1,2,3,4,4,3,2,1]`；`w2_samples[8][8]` 与512B dump一致，正常report两计数均8，成功UART为8窗口/16次完整比较。负例仍只做一次warm+一次measured，sample全512B为0；方法2与翻byte1148判据不变。
- 原完整validator只有三项可逆编辑；第三项准确将正常report的两个9改为8，其余report/输出/槽/guards/负例和回放主体保留。512B样本库存与8项ORDER共同约束全部样本，没有遗留第9项访问。
- `command/interrupt/check/inspect/pack_scale_bytes` 的源码逐字保持；没有改变子进程、回收或实际ELF检查实现。
- v1 result固定为 `cec287…`，并pin其全部snapshots/generated_inputs。实际v1正常两K的scalar样本、九样本、prepared/packed-slot完整检查及最终flags=1均与新前置检查相符。重新观测host flags须等于v1完整字典；K288 normal-2的0也保留，未把所有case误设为1。
- 原scalar函数和来源仍在，但本轮正常调用顺序不再经过它；不得写成“新目标已执行scalar”。正常末方法1、负例方法2的终态仍是旧槽gold、新槽全A5。

## 最小目标范围与身份

第一笔目标实验只选择新 v2 K288 `images/normal-0/real-w2.bin`，不改变fixture或四函数，控制字固定为 `(negative=0, UART=1)`。同K选中view的完整ELF/BIN、static、record、全部函数体SHA、fixture/flags和新参考资格均按其新身份绑定；旧v1的PC、完整ELF SHA和PASS不能搬来充当新输入证明。若当前选中bin控制本已0/1，目标image可以全字节相同复制；任何控制写入都限定在已检查的8B范围。

复用实际EMU `f14918658fcd2f19c9fb6c1d493025d98f727ac985ea73129edc58270fa6977d`、REF `cc768488944941d59442727a96e0a19206e24872dcefed0052cf6cb3694a3fae`、flash `a3360212cf7bb784119c1719c9258362f8567803601b2359aee2c104864fa994`。原1400B ABI及已编译D16/O2/T14=1、O1 handoff/各trace=0身份从原硬件结果/物理输入绑定，不能用运行时设置环境变量替代这项身份。

已有Q288启动形式可复用：EMU `-i <new image> --flash=<fixed flash> --ram-size=128MB --diff=<fixed reference> --max-cycles=<frozen cap> --seed=1`。只一个EMU worker，CPU1、绝对nice5并核实际值，独立新cwd/stdout/stderr/receipt/profile；在途四臂的owner、输入、affinity、预算均不改。

`q288-consumer/run.py` 的单进程、0.25s截止/信号检查、固定helper进程组清理及最后pin复核适合这一工作。`w2-target-candidate/launch_target.py` 写死完整forward四case、tag、profile域和runtime PASS，**不宜直接复用成这次screen的launcher**；只能借鉴其外层预算留余量、回执、终态和CPU释放原则，避免为两个串行可选case引入四臂调度器。

## UART 足以证明的范围

借用原 `runtime_gate` 的控制台归一化和失败标记检查，针对新PWS协议做有界完整解析，保留原始两条流及各自SHA：

1. 实际EMU正常exit0，精确加载固定reference，出现一次真实DiffTest enabled；没有PWS_REJECT、DiffTest/运行失败、超时或取消。
2. 仅一条精确 `PWS_BEGIN k=288 rows=288 groups=9 control=0`，随后8条完整PWS_SAMPLE，index依次0..7、method严格等于新ORDER；最后一条精确 `PWS_PASS k=288 samples=8 full_comparisons=16 prepared_bytes=10368`。拒绝重复、缺失或多余PWS记录。
3. 每样本 cycles/instret 均为正且小于UINT32_MAX，flags等于该case实际冻结record，16位十六进制FNV等于该casegold的冻结FNV。当前v1 normal-0实际flags=1、FNV=`f4481cc0f931d2d5`，新v2仍应从实际record读取；K768 normal的现有FNV为`f909c47ea8f72842`，不得跨case套用。
4. 只有一条GOOD TRAP，其实际PC等于新 `inspection.success_pc`。原Q288 `guest_check()` 仅计GOOD TRAP条数，没有这个PC相等检查；不能直接当成已具备。v1两K的PC虽实际是`0x8000013c`，新版本仍按新ELF绑定。
5. 终态须完成输入/profile前后SHA、direct child reaped、group absent；只有UART PASS而尚未闭合不能授予成功。

在冻结源码/ELF与完整控制流绑定下，完整PWS成功证明本case的16次调用通过guest全部1152B输出、活动/非活动完整128B槽、guards、VL/vtype/vstart/vcsr与精确FCSR检查；首尾prepared完整字节检查也已走完。这是固定guest验收逻辑的目标执行证据。UART只有结果hash和窗口差值，**不是目标内存dump、原始全部输出导出、完整CSR导出或退休链**。末态prepared数据没有从target独立读回，不应套用NEMU的内存导出描述。

v1已有两个参考负控验证共享比较器，不能写成packed-N专属负控，更不能转为新target负控PASS。本次不自动追加target负控、重放或TRACE作为启动/通过门槛。

## 四函数比较与资格

各方法保留两条原始目标窗口，分别报告原P、原N、packedP、packedN的cycles和instret。可给同方向样本比较、两次均值及原始范围；不删第一样本、不借旧镜像分母、不用host墙钟作性能。

分别计算 `1-C(packedN)/C(N)` 与 `1-C(packedP)/C(P)`，说明Ws布局对两条路线各自的收益。相对RVV时同时保留P与packedP中较快的合格结果；不可只选择较慢原P来放大packedN加速。均值比只属于同一新ELF、同一normal fixture下的完整GEMV调用窗口，仍含apply/context/调用开销。

prepare、权重packing、量化和完整forward均不在这些窗口里。因此结果只能支持下一步工程选择；`performance_qualified=false`、`application_performance_qualified=false`、`full_retirement_window_audited=false` 和 `retired_custom_count_verified=false`保持。固定case成功可单独记录 `target_runtime_qualified=true`，不扩大到所有K/fixtures、整应用或ASIC。

## 预算与是否继续 K768

K288先复用已真实使用过的有限停止边界：**4,000,000 guest cycles、9,000s内层wall、每流16MiB、外层9,600s并包含清理余量**。这是一次明确有上限的投入，不是保证足够的完成预测；CPU1/nice5与旧CPU0/nice4不同。新v2实际reference retired可供计划复核，但仍不能当作目标cycle上界。失败或到预算即保留原件、闭合进程，不自动加时或重放。

K768先不启动、不承诺完成预算。K288若收益明确，或有具体K768特有的访存布局理由，再结合实际K288目标wall/cycles、新K768 reference规模与当时资源决定。K288无明显收益不能证明K768必然无益，但不足以自动占用另一段长仿真。原run允许最高12M cycles/14400s只是已有接口资源上限，也不能拿来宣称K768需要或必能在该时间完成。

这比立即跑两份含scalar的旧ELF更直接回答当前问题：packed-Ws是否能让四个实际候选窗口变快。若小试改善不足，停止该分支并保留已有正确性成果即可，无需扩大验证来填满时间。
