def validate(build,dest,record,receipt,negative):
    need(receipt.get('process_started') is True and receipt.get('process_group_absent_after_exit') is True and not receipt.get('residual_process_group')
         and not receipt.get('timed_out') and receipt['exit_code']==(2 if negative else 0),'owned reference terminal receipt')
    result=read(dest/'reference-result.json');abi=read(dest/'abi.json')
    need(abi['register_bytes']==abi['header_span']==1400 and abi['initial_pc']==0x10000000 and abi['initial_mode']==3,'original reset/ABI')
    need(result['state']==2 and result['reason']==('bad_trap' if negative else 'good_trap') and result['halt_ret']==(91 if negative else 0)
         and 0<result['retired']<=result['api_calls']<=100000000 and result['memory_dumps']==len(record['dump_plan']) and result['xiangshan_cycles_measured'] is False,'actual terminal state')
    text=(dest/'stdout.log').read_text();need(not (dest/'stderr.log').read_bytes() and not any(s in text.lower() for s in ('pma check failed','critical error','reference_adapter_reject','abort')),'no unexplained reference failure')
    sizes={n:s for n,_,s in record['dump_plan']};sizes.update({'initial-registers.bin':1400,'final-registers.bin':1400,'initial-csrs.bin':32768,'final-csrs.bin':32768})
    need({p.name for p in dest.glob('*.bin')}==set(sizes)|{'image.bin'},'exact dump inventory')
    for n,size in sizes.items():need((dest/n).stat().st_size==size,'complete dump '+n)
    expected=bytearray((build/'real-w2.bin').read_bytes());expected[record['control_offset']:record['control_offset']+8]=struct.pack('<2I',int(negative),0)
    need((dest/'image.bin').read_bytes()==expected,'only explicit negative/UART controls differ')
    for name in ('input','input-scales','weight','packed','scales','gold','slot-gold','expected-flags','packed-scales'):
        need(digest(dest/(name+'-after.bin'))==record['fixtures'][name+'.bin'],'entire immutable fixture unchanged '+name)
    report=struct.unpack('<64Q',(dest/'report.bin').read_bytes())
    need(report[:10]==(0x5232573254473031,1,int(negative),91 if negative else 0,0,1 if negative else 8,0 if negative else 8,0,0,1148 if negative else 0), 'exact actual report/progress/rejection')
    need(report[10]&0x6000 and report[10]&0x600 and report[11]==16 and not any(report[12:]),'FS/VS and complete report extent')
    guard=struct.pack('<2Q',*[0x5a1d8c2976e340bf]*2);gold=(build/'fixture/gold.bin').read_bytes();actual=(dest/'output.bin').read_bytes()
    good=guard+gold+guard
    if negative:
        need(actual!=good,'normal complete comparator rejects actual negative')
        bad=bytearray(good);bad[16+1148]^=1;need(actual==bad,'exact last output bit corruption')
    else:need(actual==good,'all 288 actual outputs and guards equal original')
    need((dest/'slots.bin').read_bytes()==guard+(build/'fixture/slot-gold.bin').read_bytes()+guard,'all 8 full128 slots and guards')
    samples=list(struct.iter_unpack('<8Q',(dest/'samples.bin').read_bytes()))
    if negative:need(not any(any(x) for x in samples),'no negative measurement admitted')
    else:
        for index,row in enumerate(samples):
            method,c0,i0,i1,c1,flags,fnv,reserved=row
            need(method==ORDER[index] and c1>c0 and i1>i0 and flags==record['expected_flags'] and fnv==int(record['golden_fnv'],16) and reserved==0,'actual method/order/full result/flags/counters')
    return dict(status='EXPECTED_W2_REFERENCE_REJECTION' if negative else 'W2_REFERENCE_PASS',negative=negative,
                api_calls=result['api_calls'],retired=result['retired'],report=list(report),samples=[list(x) for x in samples],
                raw_sha256={n:digest(dest/n) for n in sizes},target_emu_runs=0,performance_qualified=False)
