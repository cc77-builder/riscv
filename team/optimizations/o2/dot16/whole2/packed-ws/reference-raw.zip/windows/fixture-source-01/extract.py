#!/usr/bin/env python3
"""Extract only the fixed, closed K288 narrow ELF fixtures; no guest execution."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import struct
import sys
import time

ELF_SHA = '82281d6fab843190321cdb21189f2feae848e2c1220e6a1ad0ec8bd883011b91'
MODEL_SHA = '703667b537c652b22a7dd82f8e3d3a7a42e965d7b5df7d4627b78e0d7358cc82'
SOURCE_PINS = {
    'main.c': 'd4df1b76da77b4b288e2cf9309d4dce075d6acc0d2b01fca654f5548b00c7346',
    'q288.c': 'f0c557cb837ac05ff713b0eaadb7949b3ba623ae54fe1c02aedcd4220f5bf8d1',
    'oracle.c': '6e72ed5b4e6b4ea804d34212e9e84d9001207eea076a26a8a835f2a1c29f9dec',
}
SYMBOLS = {
    'q_weights': (82944, '33b83f1b813223a0d00cb1ceae782ba1f23ff07fdfcb9e9361aa4c55b3014850'),
    'q_packed': (82976, '19267742fe86a5939bd26df1714c6d69b09b07bc23bedf17381953f805c1bb9a'),
    'q_inputs': (864, 'cb63d3348e2907347dec3dc9e86dbface623e2eb81983a9b5288f3f5db8c88ef'),
    'q_weight_scale': (10368, '0b2e27a91a3bced06fa246d1d6d3317a984437eaa72d9dc8e431730a1d1edb3a'),
    'q_input_scale': (108, 'c1fc01352589526ed0db08fdec52ee7397605910024307a77656cb7f73f0d406'),
    'q_golden': (3456, '1153c660a94deafa8e0a31e361115906baf70d88a44be36c1fa54f72eae3169f'),
    'q_min_packed': (82976, 'e6bbbc79928c1373997eb59bb22c741fc6f93ab1d77ceed9b3265e8c2b2360e7'),
    'q_min_x': (320, '9428da8bec2a4213f6c5b9801c6f11e5a2f7cc072c54cc8ebe9fab9f9f18a864'),
    'q_min_golden': (1152, '66c4c3af41f5c15c3228ce31c1bfc1be67e438e566d1def9499e6daa6b96e525'),
}
SIZES = {'weight.bin': 82944, 'packed.bin': 82944, 'input.bin': 288,
         'scales.bin': 10368, 'input-scales.bin': 36, 'gold.bin': 1152,
         'slot-gold.bin': 128, 'packed-scales.bin': 10368}
GUARD = 0xd15ea5e5cafebabe
GUARD_BYTES = struct.pack('<2Q', GUARD, GUARD)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def unguard(raw, size):
    need(len(raw) == size + 32 and raw[:16] == raw[-16:] == GUARD_BYTES,
         'complete original 16-byte head/tail guards')
    return raw[16:16 + size]


def pack_weight(weight):
    need(len(weight) == 82944, 'whole row-major K288 weight')
    return b''.join(weight[(8*t+r)*288+32*g:(8*t+r)*288+32*g+32]
                    for t in range(36) for g in range(9) for r in range(8))


def unpack_weight(packed):
    need(len(packed) == 82944, 'whole packed K288 weight')
    weight = bytearray(82944)
    written = set()
    for t in range(36):
        for g in range(9):
            for r in range(8):
                source = ((t*9+g)*8+r)*32
                target = (8*t+r)*288+32*g
                need(target not in written and target + 32 <= len(weight), 'exact inverse pack coverage')
                written.add(target)
                weight[target:target+32] = packed[source:source+32]
    need(written == set(range(0, 82944, 32)) and pack_weight(weight) == packed,
         'complete inverse weight packing and round trip')
    return bytes(weight)


def packed_scales(scales):
    need(len(scales) == 10368, 'complete original FP32 object representation')
    # Copy complete four-byte objects; do not load/evaluate host float values.
    order = [(8*t+r)*9+g for t in range(36) for g in range(9) for r in range(8)]
    need(sorted(order) == list(range(2592)), 'complete scale-word permutation')
    return b''.join(scales[4*i:4*i+4] for i in order)


def integer_and_value_reference(weight, x, ws, xs, model):
    need((len(weight), len(x), len(ws), len(xs)) == (82944, 288, 10368, 36), 'fixed complete reference spans')
    w, xv = struct.unpack('<82944b', weight), struct.unpack('<288b', x)
    sw, sx = struct.unpack('<2592I', ws), struct.unpack('<9I', xs)
    outputs, final_dots = [], []
    for row in range(288):
        total = 0  # binary32 +0, represented as bits
        for group in range(9):
            begin = group*32
            dot = sum(w[row*288+begin+k] * xv[begin+k] for k in range(32))
            need(-524288 <= dot <= 524288, 'exact signed-byte dot32 range')
            term = model.round_binary32(dot, 0)
            term = model.multiply(term, sw[row*9+group])
            term = model.multiply(term, sx[group])
            total = model.add(total, term)
            if row >= 280 and group == 8:
                final_dots.append(dot)
        outputs.append(total)
    need(len(final_dots) == 8, 'all final tile/group slots')
    slots = b''.join(struct.pack('<4I', value & 0xffffffff, 0, 0, 0) for value in final_dots)
    return struct.pack('<288I', *outputs), slots, final_dots


def run(a):
    need(sys.dont_write_bytecode, 'python3 -B is required')
    os.sched_setaffinity(0, {1})
    os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(os.sched_getaffinity(0) == {1} and os.getpriority(os.PRIO_PROCESS, 0) == 5,
         'actual CPU1 affinity and absolute nice5')
    need(all(p.is_absolute() and p == p.resolve() for p in (a.image_build, a.model, a.output)),
         'canonical absolute input/output paths')
    build, out = a.image_build, a.output
    helper = Path(__file__).resolve()
    contract = helper.with_name('CONTRACT.md')
    inputs = [build/'paired16-target.elf', build/'status.json', build/'elf-check.json',
              *(build/'source'/name for name in SOURCE_PINS), a.model, helper, contract]
    need(len(set(inputs)) == len(inputs) and all(p.is_file() and not p.is_symlink() for p in inputs),
         'nine distinct real input files')
    need(not out.exists() and not out.is_relative_to(build) and not build.is_relative_to(out) and
         all(not p.is_relative_to(out) for p in inputs), 'fresh isolated output, old build untouched')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone finite extractor')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 120
    handlers = {s: signal.getsignal(s) for s in (signal.SIGALRM, signal.SIGINT, signal.SIGTERM)}
    def interrupted(sig, _frame):
        raise InterruptedError('extraction signal/deadline ' + str(sig))
    status = dict(status='EXTRACTING', started=started, cpu_affinity=[1], nice=5, budget_seconds=120,
                  source_inputs_written=False, prepare_function_executed=False, scalar_c_oracle_executed=False,
                  target_emu_runs=0, reference_runs=0, reference_qualified=False,
                  target_runtime_qualified=False, performance_qualified=False, expected_flags_resolved=False)
    emitted = {}
    def write(name, raw):
        p = out/name
        need(name not in emitted and not p.exists(), 'one fresh output: ' + name)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
        record = dict(bytes=len(raw), sha256=sha(raw))
        need(p.stat().st_size == record['bytes'] and digest(p) == record['sha256'], 'complete output readback')
        emitted[name] = record
        return record
    try:
        for s in handlers:
            signal.signal(s, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 120)
        before = {str(p): dict(bytes=p.stat().st_size, sha256=digest(p)) for p in inputs}
        need(before[str(inputs[0])]['sha256'] == ELF_SHA and before[str(a.model)]['sha256'] == MODEL_SHA,
             'fixed actual narrow ELF and frozen model')
        for name, pin in SOURCE_PINS.items():
            need(before[str(build/'source'/name)]['sha256'] == pin, 'fixed source layout/order: ' + name)
        receipt = json.loads((build/'status.json').read_bytes())
        need(receipt['contract'] == 'r3-dot16-whole8-narrow-q288-v1' and
             receipt['status'] == 'DOT16_WHOLE8_NARROW_Q288_IMAGE_STATIC_PASS' and
             receipt['elf'] == str(inputs[0]) and receipt['elf_sha256'] == ELF_SHA and
             all(receipt[k] is True for k in ('inputs_unchanged', 'generated_inputs_unchanged',
                                             'last_process_reaped', 'last_process_group_absent')),
             'closed actual source image identity')
        inspection = json.loads((build/'elf-check.json').read_bytes())
        need(inspection['unchanged_fixtures'] == {name: dict(bytes=size, sha256=pin)
             for name, (size, pin) in SYMBOLS.items()}, 'the actual nine complete fixture symbols')
        snapshot_names = [(build/'status.json', 'status.json'), (build/'elf-check.json', 'elf-check.json'),
                          *((build/'source'/name, name) for name in SOURCE_PINS),
                          (a.model, 'model.py'), (helper, 'extract.py'), (contract, 'CONTRACT.md')]
        for source, name in snapshot_names:
            need(write('inputs/'+name, source.read_bytes()) == before[str(source)], 'exact input snapshot')
        spec = importlib.util.spec_from_file_location('fixed_q288_fixture_model', out/'inputs/model.py')
        model = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(model)
        elf_raw = inputs[0].read_bytes()
        need(sha(elf_raw) == ELF_SHA, 'actual read ELF identity')
        elf = model.ELF(elf_raw)
        raw_symbols, symbol_records, intervals = {}, {}, []
        for name, (size, pin) in SYMBOLS.items():
            need(name in elf.symbols, 'actual defined fixture symbol: ' + name)
            address, extent, offset = elf.symbols[name]
            need(extent == size and 0 <= offset <= offset+size <= len(elf_raw) and
                 0x80000000 <= address < address+size <= 0x88000000, 'complete file/RAM symbol span: ' + name)
            need(any(s[1] == 1 and s[2] & 2 and s[3] <= address and address+size <= s[3]+s[5] and
                     s[4]+address-s[3] == offset for s in elf.sections), 'whole symbol in one allocated PROGBITS section')
            raw = elf.symbol_data(name)
            need(len(raw) == size and sha(raw) == pin, 'whole actual fixture bytes: ' + name)
            raw_symbols[name] = raw
            record = write('source-symbols/'+name+'.bin', raw)
            symbol_records[name] = dict(**record, address=hex(address), elf_file_offset=offset)
            intervals.append((address, address+size, name))
        intervals.sort()
        need(all(a[1] <= b[0] for a, b in zip(intervals, intervals[1:])), 'distinct complete source symbol spans')
        ordinary_packed = unguard(raw_symbols['q_packed'], 82944)
        minimum_packed = unguard(raw_symbols['q_min_packed'], 82944)
        minimum_x = unguard(raw_symbols['q_min_x'], 288)
        need(pack_weight(raw_symbols['q_weights']) == ordinary_packed, 'all normal W bytes obey the original pack formula')
        minimum_weight = unpack_weight(minimum_packed)
        need(minimum_weight == bytes([128])*82944 and minimum_x == bytes([128])*288,
             'observed fullmin weight/input are entirely signed -128')
        scale_expectation = packed_scales(raw_symbols['q_weight_scale'])
        cases = {}
        for case, dataset in [('normal-0', 0), ('normal-1', 1), ('normal-2', 2), ('fullmin', None)]:
            minimum = dataset is None
            d = 0 if minimum else dataset
            weight = minimum_weight if minimum else raw_symbols['q_weights']
            packed = minimum_packed if minimum else ordinary_packed
            x = minimum_x if minimum else raw_symbols['q_inputs'][d*288:(d+1)*288]
            ws = raw_symbols['q_weight_scale']
            xs = raw_symbols['q_input_scale'][d*36:(d+1)*36]
            gold = raw_symbols['q_min_golden'] if minimum else raw_symbols['q_golden'][d*1152:(d+1)*1152]
            value_gold, slot_gold, last_dots = integer_and_value_reference(weight, x, ws, xs, model)
            need(value_gold == gold, 'pure integer RNE binary32 value check equals fixed whole gold: ' + case)
            need(not minimum or last_dots == [524288]*8, 'independent fullmin final eight dot32 values')
            values = {'weight.bin': weight, 'packed.bin': packed, 'input.bin': x, 'scales.bin': ws,
                      'input-scales.bin': xs, 'gold.bin': gold, 'slot-gold.bin': slot_gold,
                      'packed-scales.bin': scale_expectation}
            need({name: len(raw) for name, raw in values.items()} == SIZES, 'all complete normalized case spans')
            files = {name: write('cases/'+case+'/fixture/'+name, raw) for name, raw in values.items()}
            def span(name, offset=0, length=None):
                n = len(raw_symbols[name]) if length is None else length
                need(0 <= offset <= offset+n <= len(raw_symbols[name]), 'normalized source slice')
                return dict(symbol=name, offset=offset, bytes=n,
                            address=hex(int(symbol_records[name]['address'], 16)+offset))
            sources = dict(weight=span('q_min_packed', 16, 82944) if minimum else span('q_weights'),
                weight_derivation='inverse of original tile/group/row/byte packing' if minimum else 'original full symbol',
                packed=span('q_min_packed' if minimum else 'q_packed', 16, 82944),
                input=span('q_min_x', 16, 288) if minimum else span('q_inputs', d*288, 288),
                scales=span('q_weight_scale'), input_scales=span('q_input_scale', d*36, 36),
                gold=span('q_min_golden') if minimum else span('q_golden', d*1152, 1152))
            record = dict(case=case, ordinary_dataset=dataset, source_elf_sha256=ELF_SHA,
                geometry=dict(rows=288, k=288, group_size=32, groups=9, tiles=36, rows_per_tile=8),
                sources=sources, files=files, last_slot_dots=last_dots,
                output_gold='Original ELF bytes; independently matched by the pinned finite binary32 value model.',
                slot_gold='Exact signed integer dot32 at rows280..287/group8, low32 plus zero high96.',
                packed_scales='Four-byte object permutation [row][group] to [tile][group][lane]; no float evaluation.',
                packed_scale_required_alignment=64, expected_frm=0, expected_flags=None,
                expected_flags_status='UNRESOLVED: old main checks FRM only; host/NEMU cross-check is separate.',
                binary32_value_check_passed=True, flags_modelled=False, reference_qualified=False,
                target_runtime_qualified=False, performance_qualified=False)
            write('cases/'+case+'/record.json', encoded(record))
            cases[case] = record
        need(all(p.stat().st_size == before[str(p)]['bytes'] and digest(p) == before[str(p)]['sha256']
                 for p in inputs), 'all original input bytes unchanged')
        need(all((out/name).stat().st_size == rec['bytes'] and digest(out/name) == rec['sha256']
                 for name, rec in emitted.items()), 'all complete extracted outputs unchanged')
        manifest = dict(schema=1, contract='fixed-k288-fixture-extraction-v1', input_files=before,
            source_fixture_symbol_count=9, symbol_records=symbol_records,
            guard=dict(word_hex=hex(GUARD), head_bytes=16, tail_bytes=16,
                checked_symbols=['q_packed', 'q_min_packed', 'q_min_x']),
            cases=cases, files=dict(emitted), exact_flags_resolved=False,
            model_scope='Pinned ELF reader plus finite RNE binary32 integer value primitives only; no instruction/CSR/flag model executed.',
            qualification='Static extraction and bitwise value check only; no DUT, NEMU, C-oracle or prepare execution.')
        manifest_record = write('manifest.json', encoded(manifest))
        need(time.monotonic() < deadline, 'complete fixed extraction within finite budget')
        status.update(status='K288_FIXED_FIXTURES_EXTRACTED_AND_VALUE_CHECKED', finished=stamp(),
            source_elf_sha256=ELF_SHA, source_fixture_symbols=9, normalized_cases=list(cases),
            complete_case_files=32, inputs_unchanged=True, outputs_readback_verified=True,
            expected_flags=None, manifest=manifest_record, output_files_before_receipt=len(emitted))
        (out/'result.json').write_bytes(encoded(status))
        print(json.dumps(status, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        status.update(status='FAILED', error=repr(error), finished=stamp(), partial_outputs_preserved=True)
        (out/'result.json').write_bytes(encoded(status))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for s, handler in handlers.items():
            signal.signal(s, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('image-build', 'model', 'output'):
        parser.add_argument('--'+name, type=Path, required=True)
    run(parser.parse_args())
