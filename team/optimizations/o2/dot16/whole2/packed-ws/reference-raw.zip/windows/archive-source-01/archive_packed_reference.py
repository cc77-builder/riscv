#!/usr/bin/env python3
"""Transport fixed CLOSED packed GNU/fixture/reference evidence; run no guest/tool.

Ten exact input roots, distinct Windows/WSL namespaces, no omissions or deletion.
Streaming hashes, whole ZIP readback, after-scan, finite timer and failure retention
reuse archive_prefix.py. Original qualification is recorded, never recomputed.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import sys
import time
import zipfile

RUNS = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-packed-ws-20261107-main')
SOURCES = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main')
FIXED = {
    'gnu-01/result.json': (18710, '369307b6a392df26e1e34f5a643feb2cadb96f84ada8006214625ba6e27ebb8e'),
    'q288-fixtures-01/manifest.json': (26147, '13d05882e6f1876993a6e6b63c8d5041c1067bdfb73ba061adf41f91d66f2bd1'),
    'q288-fixtures-01/result.json': (1021, '2486b659f58c29fe6012a2d9d4efdbd182127bbe7bcc682341fbd3b9e7b200fc'),
    'reference-01/result.json': (142366, 'cec287cff44cdda1070539515a3d426fd81e6a4025e0a84ac6bcb632ef7f1f5a'),
    'reference-02/result.json': (166147, '65de4aca20b86d7faaed7c11863297930d571ee2c97b2ad54bb15bdd4c72e4d0'),
    'reference-02/k288/static.json': (24695, '9883493045580c3c30f95616e671a2343726e8f04f9bd4b449f5647633d1c3ba'),
    'reference-02/k768/static.json': (15282, 'b3696cc418c12faf83a049adc1d83c1fbdc8646f8bad004393e6ec6ef63e4226'),
}
FIXTURE_RESULT_SHA = '2486b659f58c29fe6012a2d9d4efdbd182127bbe7bcc682341fbd3b9e7b200fc'
REFS = {
    'reference-01': ('r3-packed-ws-two-geometry-reference-v1', 'PACKED_WS_BOTH_GEOMETRIES_REFERENCE_PASS', 172, 40),
    'reference-02': ('r3-packed-ws-eight-window-reference-v2', 'PACKED_WS_EIGHT_WINDOWS_REFERENCE_PASS', 298, 41),
}
CASES = {288: ('negative', 'normal-0', 'replay', 'normal-1', 'normal-2', 'fullmin'),
         768: ('negative', 'normal', 'replay', 'edge')}
KINDS = {288: ('normal-0', 'normal-1', 'normal-2', 'fullmin'), 768: ('normal', 'edge')}
GNU_LABELS = ('parents-assemble', 'parents-link', 'parents-nm', 'parents-disassembly',
              'packed-assemble', 'packed-link', 'packed-nm', 'packed-disassembly', 'pack-compile', 'pack-disassembly')
OUT_OF_SCOPE = ('target_runtime_qualified', 'performance_qualified', 'application_performance_qualified',
                'production_routes_modified')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def input_roots(runs, sources):
    return {**{'wsl/' + n: runs / n for n in
        ('gnu-01', 'q288-fixtures-01', 'reference-01', 'reference-02', 'source-01')},
        **{'windows/' + n: sources / n for n in
        ('source-01', 'fixture-source-01', 'screen-source-01', 'screen-source-02', 'archive-source-01')}}


def reference_labels():
    result = ['host-flags-build'] + ['host-flags-' + n for n in KINDS[288]]
    for k in (288, 768):
        result += [f'k{k}-' + n for n in ('build', 'metadata', 'disassembly', *CASES[k])]
    return result


def evidence_metadata(runs, sources, gnu, fixture, fixture_result, refs, statics):
    """Pure captured-metadata checks and pin collection; no I/O or validator import."""
    roots = input_roots(runs, sources)
    pins, sizes, groups, required, json_records, external = {}, {}, {}, set(), {}, {}

    def path_ok(path):
        p = Path(path)
        need(p.is_absolute() and '..' not in p.parts, 'absolute recorded path without traversal')
        return p

    def digest_ok(digest):
        need(isinstance(digest, str) and len(digest) == 64 and
             all(c in '0123456789abcdef' for c in digest), 'recorded SHA256')

    def pin(path, digest, group, size=None):
        p = path_ok(path); digest_ok(digest)
        need(any(p.is_relative_to(root) for root in roots.values()), 'pin belongs to one selected closed root: ' + str(p))
        need(p not in pins or pins[p] == digest, 'consistent recorded pin: ' + str(p))
        pins[p] = digest; groups.setdefault(group, set()).add(p)
        if size is not None:
            need(type(size) is int and size >= 0 and (p not in sizes or sizes[p] == size), 'consistent recorded size')
            sizes[p] = size

    def original(path, digest, group, size=None):
        p = Path(path); digest_ok(digest)
        need(p.is_absolute(), 'absolute original dependency path')
        # Two original external include paths contain ../. Preserve their exact
        # recorded spelling without reading/resolving them or allowing local escape.
        normalized = Path(os.path.normpath(p))
        if any(normalized.is_relative_to(root) or p.is_relative_to(root) for root in roots.values()):
            pin(p, digest, group, size)
        else:
            need(str(p) not in external or external[str(p)]['sha256'] == digest, 'consistent external dependency pin')
            rec = external.setdefault(str(p), dict(sha256=digest, recorded_by=[]))
            if group not in rec['recorded_by']:
                rec['recorded_by'].append(group)
            if size is not None:
                need(type(size) is int and size >= 0 and rec.get('bytes', size) == size, 'external recorded size')
                rec['bytes'] = size

    def relative(path):
        p = PurePosixPath(path)
        need(str(p) == path and not p.is_absolute() and '..' not in p.parts and p.parts, 'safe recorded relative path')
        return p

    for name, (size, digest) in FIXED.items():
        pin(runs / name, digest, 'fixed_records', size)
    pin(runs / 'q288-fixtures-01/result.json', FIXTURE_RESULT_SHA, 'fixed_records')
    need(gnu['contract'] == 'r3-dot16-np-packed-ws-v1' and
         gnu['status'] == 'PACKED_WS_FOUR_KERNEL_GNU_IDENTITY_PASS' and gnu['finished'], 'closed fixed GNU identity result')
    need(gnu['target_emu_runs'] == gnu['reference_runs'] == 0 and gnu['reference_qualified'] is False and
         all(gnu[n] is False for n in ('target_runtime_qualified', 'performance_qualified', 'production_routes_modified')),
         'GNU identity alone has no runtime/performance qualification')
    need(all(gnu[n] is True for n in ('all_pins_unchanged', 'all_children_reaped', 'gnu_built')) and
         gnu['cpu_affinity'] == [1] and gnu['nice'] == 5 and gnu['budget_seconds'] == 180, 'original GNU closure/profile')
    need(tuple(c['label'] for c in gnu['commands']) == GNU_LABELS and
         (len(gnu['inputs']), len(gnu['snapshots']), len(gnu['artifacts'])) == (20, 13, 20), 'complete GNU metadata')
    for command in gnu['commands']:
        need(type(command['exit_code']) is int and command['exit_code'] == 0 and command['reaped'] is True and
             command['group_absent'] is True and command['finished'], 'recorded closed GNU command')
        required.add(runs / 'gnu-01' / (command['label'] + '.log'))
    for path, digest in gnu['inputs'].items():
        original(path, digest, 'gnu_originals')
    for path, digest in gnu['snapshots'].items():
        need(Path(path).is_relative_to(runs / 'gnu-01/inputs'), 'GNU snapshot under its original run')
        pin(path, digest, 'gnu_snapshots')
    for name, digest in gnu['artifacts'].items():
        pin(runs / 'gnu-01' / relative(name), digest, 'gnu_artifacts')
    need(len(gnu['functions']) == 4 and all(v['frozen_common_elf_parent_equal'] is True and
         v['all_other_machine_words_equal'] is True for v in gnu['functions'].values()), 'recorded four complete machine identities')
    # Windows source-01 is a byte-matched transfer mirror, not the GNU execution path.
    mirror = {}
    for path, digest in gnu['inputs'].items():
        p = Path(path)
        if p.is_relative_to(runs / 'source-01'):
            rel = p.relative_to(runs / 'source-01')
            need(len(rel.parts) == 1 and gnu['snapshots'].get(str(runs / 'gnu-01/inputs' / rel)) == digest,
                 'executed GNU source equals complete input snapshot')
            pin(sources / 'source-01' / rel, digest, 'windows_gnu_source_mirror')
            mirror[rel.as_posix()] = digest
    need(len(mirror) == 10, 'all nine GNU source files plus manifest mirrored')

    need(fixture['contract'] == 'fixed-k288-fixture-extraction-v1' and fixture['exact_flags_resolved'] is False and
         fixture_result['status'] == 'K288_FIXED_FIXTURES_EXTRACTED_AND_VALUE_CHECKED' and fixture_result['finished'],
         'closed original fixture extraction with unresolved flags')
    need(fixture_result['inputs_unchanged'] is True and fixture_result['outputs_readback_verified'] is True and
         fixture_result['manifest'] == dict(bytes=FIXED['q288-fixtures-01/manifest.json'][0],
             sha256=FIXED['q288-fixtures-01/manifest.json'][1]), 'original complete fixture manifest')
    need(fixture_result['target_emu_runs'] == fixture_result['reference_runs'] == 0 and
         all(fixture_result[n] is False for n in ('reference_qualified', 'target_runtime_qualified',
             'performance_qualified', 'expected_flags_resolved')), 'extraction qualification is not promoted')
    for path, rec in fixture['input_files'].items():
        original(path, rec['sha256'], 'fixture_originals', rec['bytes'])
    for name, rec in fixture['files'].items():
        pin(runs / 'q288-fixtures-01' / relative(name), rec['sha256'], 'fixture_outputs', rec['bytes'])
    need(set(fixture['cases']) == set(KINDS[288]), 'all four original normalized K288 cases')
    for kind, record in fixture['cases'].items():
        need(record['expected_flags'] is None and record['binary32_value_check_passed'] is True and
             len(record['files']) == 8, 'original eight full fixture files, flags unresolved')
        for name, rec in record['files'].items():
            path = runs / 'q288-fixtures-01/cases' / kind / 'fixture' / relative(name)
            need(pins.get(path) == rec['sha256'] and sizes.get(path) == rec['bytes'], 'case coverage in full fixture manifest')

    need(set(refs) == set(REFS) and set(statics) == set(REFS), 'both original reference generations')
    for run_name, result in refs.items():
        run = runs / run_name
        contract, status, count_original, count_snapshots = REFS[run_name]
        need(result['contract'] == contract and result['status'] == status and result['finished'] and
             result['reference_qualified'] is True and result['reference_runs'] == 10 and result['target_emu_runs'] == 0 and
             all(result[n] is False for n in OUT_OF_SCOPE), 'original reference-only qualification boundary')
        need(result['all_inputs_unchanged'] is True and result['all_children_reaped'] is True and
             result['cpu_affinity'] == [1] and result['nice'] == 5 and result['budget_seconds'] == 1200,
             'original reference closure/profile')
        need((len(result['original_inputs']), len(result['snapshots']), len(result['generated_inputs'])) ==
             (count_original, count_snapshots, 111), 'complete final input/snapshot/generated maps, not initial inputs.json')
        need([c['label'] for c in result['commands']] == reference_labels(), 'all 21 original command labels and order')
        commands = {row['label']: row for row in result['commands']}
        for row in result['commands']:
            need(row['process_started'] is True and row['direct_child_reaped'] is True and
                 row['process_group_absent_after_exit'] is True and row['residual_process_group'] is False and row['finished'],
                 'recorded reference child closure')
            need(type(row['exit_code']) is int and row['exit_code'] == (2 if row['label'].endswith('-negative') else 0),
                 'original two expected negative exits, other commands exit0')
            cwd = Path(row['cwd'])
            if cwd == run:
                required.update((run / (row['label'] + '.log'), run / (row['label'] + '.stderr.log')))
        for path, digest in result['original_inputs'].items():
            original(path, digest, run_name + '_originals')
        for field in ('snapshots', 'generated_inputs'):
            for path, digest in result[field].items():
                need(Path(path).is_relative_to(run), 'final map belongs to its own reference run')
                pin(path, digest, run_name + '_' + field)
        required.update((run / 'inputs.json', run / 'derivation.json'))
        need(set(result['campaigns']) == {'288', '768'} and set(statics[run_name]) == {288, 768}, 'both fixed K campaigns')
        for k in (288, 768):
            campaign, static = result['campaigns'][str(k)], statics[run_name][k]
            work = run / f'k{k}'
            pin(work / 'static.json', campaign['static_sha256'], run_name + '_static')
            need(static['contract'] == contract and static['k'] == k and
                 static['status'] == 'PACKED_WS_FOUR_ARM_STATIC_PASS_NOT_RUNTIME' and
                 static['inspection'] == campaign['inspection'] and static['target_emu_runs'] == 0 and
                 static['performance_qualified'] is False, 'original static is not runtime qualification')
            need(static['abi']['bytes'] == 1400 and set(static['records']) == set(KINDS[k]) and
                 tuple(campaign['validations']) == CASES[k], 'complete fixed cases and original ABI')
            need(result['original_inputs'].get(static['reference']) == static['reference_sha256'], 'original NEMU dependency pin')
            for path, digest in static['source_identity'].items():
                need(Path(path).is_relative_to(work) and result['generated_inputs'].get(path) == digest,
                     'static complete source/ELF/BIN/fixture identity appears in final generated map')
                pin(path, digest, run_name + '_static_sources')
            for kind, record in static['records'].items():
                need(record['contract'] == contract and record['k'] == k and record['fixture_kind'] == kind and
                     len(record['fixtures']) == 9, 'original nine-file reference fixture record')
                for name, digest in record['fixtures'].items():
                    path = work / 'images' / kind / 'fixture' / relative(name)
                    need(result['generated_inputs'].get(str(path)) == digest, 'fixture binding to final generated inputs')
                    pin(path, digest, run_name + '_fixtures')
                json_records[work / 'images' / kind / 'record.json'] = record
            for case, validation in campaign['validations'].items():
                negative = case == 'negative'
                kind = KINDS[k][0] if case in ('negative', 'replay') else case
                record = static['records'][kind]
                dest = work / 'reference' / case
                row = commands[f'k{k}-{case}']
                need(Path(row['cwd']) == dest, 'original guest output stays in its selected case')
                need(validation['contract'] == contract and validation['k'] == k and validation['fixture_kind'] == kind and
                     validation['negative'] is negative and validation['status'] ==
                     ('EXPECTED_PACKED_WS_REFERENCE_REJECTION' if negative else 'PACKED_WS_REFERENCE_PASS') and
                     validation['target_emu_runs'] == 0 and validation['performance_qualified'] is False,
                     'recorded numerical positive/negative scope')
                dumps = {name: size for name, _address, size in record['dump_plan']}
                need(len(dumps) == len(record['dump_plan']) == 15, 'all original dump plan spans distinct')
                dumps.update({'initial-registers.bin': 1400, 'final-registers.bin': 1400,
                              'initial-csrs.bin': 32768, 'final-csrs.bin': 32768})
                need(set(validation['raw_sha256']) == set(dumps), 'all nineteen complete original memory/register/CSR dumps')
                for name, digest in validation['raw_sha256'].items():
                    pin(dest / relative(name), digest, run_name + '_raw_dumps', dumps[name])
                required.update(dest / name for name in ('image.bin', 'stdout.log', 'stderr.log',
                    'result.json', 'reference-result.json', 'abi.json', 'validation.json'))
                json_records[dest / 'result.json'] = row
                json_records[dest / 'validation.json'] = validation
    need(refs['reference-02']['prior_reference_result_sha256'] == FIXED['reference-01/result.json'][1],
         'second generation explicitly binds the retained first result')
    required |= set(pins) | set(json_records)
    evidence = dict(gnu=dict(status=gnu['status'], commands=10, functions=gnu['functions'],
            reference_qualified=False, target_runtime_qualified=False, performance_qualified=False),
        fixtures=dict(status=fixture_result['status'], complete_case_files=fixture_result['complete_case_files'],
            expected_flags_resolved=False, reference_qualified=False, performance_qualified=False),
        references={name: dict(status=r['status'], contract=r['contract'], commands=21, reference_runs=10,
            exit_histogram=dict(Counter(str(c['exit_code']) for c in r['commands'])),
            original_inputs=len(r['original_inputs']), final_snapshots=len(r['snapshots']),
            final_generated_inputs=len(r['generated_inputs']), raw_dump_files=190,
            reference_qualified=r['reference_qualified'], target_emu_runs=0,
            original_qualification={n: r[n] for n in OUT_OF_SCOPE},
            static_sha256={k: c['static_sha256'] for k, c in r['campaigns'].items()}) for name, r in refs.items()},
        fixed_records={name: dict(bytes=size, sha256=digest) for name, (size, digest) in FIXED.items()},
        fixture_result_sha256=FIXTURE_RESULT_SHA,
        windows_gnu_source_mirror=dict(files=mirror, scope='Byte identity to executed WSL source and input snapshot only; not a second execution.'))
    return pins, sizes, groups, required, json_records, external, evidence


def recorded_evidence(runs, sources):
    for name, (size, digest) in FIXED.items():
        path = runs / name
        need(path.stat().st_size == size and sha(path) == digest, 'fixed actual record bytes: ' + name)
    need(sha(runs / 'q288-fixtures-01/result.json') == FIXTURE_RESULT_SHA, 'actual fixture result used by both reference generations')
    refs = {name: read(runs / name / 'result.json') for name in REFS}
    statics = {}
    for name, result in refs.items():
        statics[name] = {}
        for k in (288, 768):
            path = runs / name / f'k{k}/static.json'
            need(sha(path) == result['campaigns'][str(k)]['static_sha256'], 'actual original campaign static bytes')
            statics[name][k] = read(path)
    return evidence_metadata(runs, sources, read(runs / 'gnu-01/result.json'),
        read(runs / 'q288-fixtures-01/manifest.json'), read(runs / 'q288-fixtures-01/result.json'), refs, statics)


def scan(roots, pinned):
    # Same real-file/link policy as archive_prefix; no .o/.a or other exclusions.
    kept, omitted, directories = {}, {}, set()
    for namespace, root in roots.items():
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        directories.update((namespace.split('/')[0] + '/', namespace + '/'))
        for path in sorted(root.rglob('*')):
            mode = path.lstat().st_mode
            need(not stat.S_ISLNK(mode), 'archive tree contains a link: ' + str(path))
            name = namespace + '/' + path.relative_to(root).as_posix()
            if stat.S_ISDIR(mode):
                directories.add(name + '/')
                continue
            need(stat.S_ISREG(mode), 'regular archive input: ' + str(path))
            need(name not in kept, 'unique archive name')
            kept[name] = path
    return kept, omitted, directories


def main(a):
    need(sys.dont_write_bytecode, '-B required; frozen source inputs stay read-only')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(os.sched_getaffinity(0) == {1} and os.getpriority(os.PRIO_PROCESS, 0) == 5,
         'actual archive CPU1 and absolute nice5')
    need(a.runs == RUNS and a.sources == SOURCES and a.output == SOURCES / 'archive-reference-01', 'fixed evidence roots and output')
    need(all(p.is_absolute() and p == p.resolve() for p in (a.runs, a.sources, a.output)), 'canonical absolute paths')
    runs, sources, out = a.runs, a.sources, a.output
    roots = input_roots(runs, sources)
    archive_source = sources / 'archive-source-01'
    need(all(p.is_dir() and not p.is_symlink() and p == p.resolve() for p in roots.values()), 'ten canonical closed input trees')
    values = list(roots.values())
    need(all(not p.is_relative_to(q) and not q.is_relative_to(p)
             for i, p in enumerate(values) for q in values[i+1:]), 'disjoint input roots')
    need(not out.exists() and all(not out.is_relative_to(p) and not p.is_relative_to(out) for p in values),
         'fresh output separate from all input trees')
    need(Path(__file__).resolve() == archive_source / 'archive_packed_reference.py', 'actual helper included in archive source')
    need((archive_source / 'receipts.json').is_file() and (archive_source / 'receipts.json').stat().st_size > 0,
         'complete original host receipt bytes supplied by caller; no receipt schema guessed')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone archive owns its finite timer')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 600
    handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM)}
    def interrupted(sig, _frame):
        raise InterruptedError('archive signal/deadline ' + str(sig))
    try:
        for sig in handlers:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 600)
        # Inspect the ten exact trees for links before opening any record file.
        files, omitted, directories = scan(roots, {})
        pinned, sizes, groups, required, json_records, external, evidence = recorded_evidence(runs, sources)
        inventory = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
        by_path = {path: inventory[name] for name, path in files.items()}
        need(not omitted and len(by_path) == len(files), 'no omitted file or overlapping namespace')
        need(required <= set(by_path), 'all source/binary/fixture/guest raw and closure files retained')
        need(all(by_path[p]['sha256'] == digest for p, digest in pinned.items()), 'every original recorded pin included unchanged')
        need(all(by_path[p]['bytes'] == size for p, size in sizes.items()), 'all recorded complete file spans')
        need(all(read(p) == value for p, value in json_records.items()), 'original per-case records equal exact final result metadata')
        manifest = dict(schema=1, evidence=evidence,
            input_roots={name: str(path) for name, path in roots.items()},
            recorded_pin_counts={key: len(value) for key, value in groups.items()},
            files=inventory, directories=sorted(directories), omitted=omitted,
            omissions_deleted=False, all_selected_closed_tree_files_included=True,
            external_dependencies=dict(original_path_sha256_pins=external,
                policy='Recorded dependency identities only; external tools, AM, NEMU, adapter, old ELF and caches are not read/copied/rehashed.'),
            receipts='windows/archive-source-01/receipts.json retained verbatim; host receipt schema not reinterpreted.',
            pin_policy='Final result snapshots/generated/artifacts and full raw dump pins checked. Other files receive transport hashes; no historical pin is invented.',
            scope='ZIP transport integrity only. Original GNU/static/reference scopes retained; no new target, application or performance qualification.',
            cpu_affinity=[1], nice=5, budget_seconds=600)
        # The ZIP/readback/after-scan block below is copied verbatim from archive_prefix.py.
        raw_manifest = encoded(manifest)
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in sorted(directories):
                z.writestr(name, b'')
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            expected = set(files) | directories | {'ARCHIVE-MANIFEST.json'}
            need(len(z.namelist()) == len(expected) and set(z.namelist()) == expected, 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name in directories:
                need(z.getinfo(name).is_dir() and z.getinfo(name).file_size == 0 and z.read(name) == b'', 'exact directory member')
            for name, record in inventory.items():
                need(not z.getinfo(name).is_dir() and z.getinfo(name).file_size == record['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == record['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted, after_directories = scan(roots, pinned)
        need(after == files and after_omitted == omitted and after_directories == directories, 'closed tree inventory unchanged')
        need(all(path.stat().st_size == inventory[name]['bytes'] and sha(path) == inventory[name]['sha256']
                 for name, path in after.items()), 'all retained source bytes unchanged')
        audit = dict(status='PACKED_REFERENCE_RAW_ARCHIVE_VERIFIED', started=started, finished=stamp(),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive), files=len(files),
            members=len(expected), directories=len(directories), raw_kept_bytes=sum(x['bytes'] for x in inventory.values()),
            recorded_pins_verified=len(pinned), recorded_pin_counts=manifest['recorded_pin_counts'],
            omitted_files=0, omitted_bytes=0, member_crc_and_sha_verified=True,
            retained_files_unchanged=True, source_membership_unchanged=True, original_files_deleted=False,
            original_recorded_child_closures_checked=True, live_processes_requeried=False,
            external_dependencies_rehashed=False, original_validators_rerun=False,
            new_builds=0, new_eda_runs=0, new_guest_runs=0, source_evidence=evidence,
            input_roots=manifest['input_roots'], external_dependency_count=len(external),
            qualification='Transport integrity only; original extraction, GNU and reference-only qualifications preserved.')
        need(time.monotonic() < deadline, 'complete archive within total budget')
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error),
            started=started, finished=stamp(), original_files_retained=True, new_guest_runs=0, new_eda_runs=0)))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('runs', 'sources', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    main(parser.parse_args())
