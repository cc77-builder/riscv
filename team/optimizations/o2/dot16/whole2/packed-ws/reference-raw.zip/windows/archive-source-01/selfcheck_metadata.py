#!/usr/bin/env python3
"""Cloud-only static/metadata checks. Never calls archive main(), scan(), or ZIP."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
HELPER = ROOT / 'verification/archive_packed_reference.py'
BASE = ROOT / 'verification/archive_prefix.py'
DATA = ROOT / 'source-review/packed-ws-20261107'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    raw = HELPER.read_bytes(); source = raw.decode(); tree = ast.parse(source)
    original = BASE.read_text(); old_tree = ast.parse(original)
    spec = importlib.util.spec_from_file_location('packed_archive_static_review', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    local = {
        'gnu-01/result.json': DATA / 'inspection/result.json',
        'reference-01/result.json': DATA / 'actual-reference-result.json',
        'reference-02/result.json': DATA / 'actual-eight/result.json',
        'q288-fixtures-01/manifest.json': DATA / 'actual-closed-archive-inputs/q288-fixtures-01/manifest.json',
        'q288-fixtures-01/result.json': DATA / 'actual-closed-archive-inputs/q288-fixtures-01/result.json',
    }
    for number in (1, 2):
        for k in (288, 768):
            local[f'reference-0{number}/k{k}/static.json'] = DATA / (
                f'actual-closed-archive-inputs/reference-01/k{k}/static.json' if number == 1 else f'actual-eight/k{k}/static.json')
    values = {name: json.loads(path.read_bytes()) for name, path in local.items()}
    observed = {name: dict(bytes=path.stat().st_size, sha256=digest(path.read_bytes())) for name, path in local.items()}
    for name, (size, pin) in helper.FIXED.items():
        assert observed[name] == dict(bytes=size, sha256=pin), name
    for name in ('reference-01', 'reference-02'):
        for k in (288, 768):
            assert observed[f'{name}/k{k}/static.json']['sha256'] == values[f'{name}/result.json']['campaigns'][str(k)]['static_sha256']
    refs = {name: values[name + '/result.json'] for name in helper.REFS}
    statics = {name: {k: values[f'{name}/k{k}/static.json'] for k in (288, 768)} for name in helper.REFS}
    inputs = [values['gnu-01/result.json'], values['q288-fixtures-01/manifest.json'],
              values['q288-fixtures-01/result.json'], refs, statics]

    def check(args):
        return helper.evidence_metadata(helper.RUNS, helper.SOURCES, *args)

    pins, sizes, groups, required, pairs, external, evidence = check(inputs)
    assert len(pins) == 753 and len(required) == 941 and len(pairs) == 52
    assert sum(len(v) for k, v in groups.items() if k.endswith('_raw_dumps')) == 380
    assert all(len(evidence['references'][name]['static_sha256']) == 2 for name in refs)
    assert len(external) == 137 and sum('../' in p for p in external) == 2
    roots = helper.input_roots(helper.RUNS, helper.SOURCES)
    assert len(roots) == len(set(roots.values())) == 10
    assert roots['wsl/source-01'] != roots['windows/source-01']
    assert all('target' not in p.name and 'preflight' not in p.name for p in roots.values())

    negative_results = []
    for label in ('lost-late-snapshot', 'missing-final-csr-dump', 'wrong-negative-exit',
                  'generated-path-escapes-run', 'false-performance-qualification',
                  'conflicting-original-pin', 'missing-gold-fixture-pin', 'local-parent-traversal'):
        bad = copy.deepcopy(inputs)
        if label == 'lost-late-snapshot':
            mapping = bad[3]['reference-02']['snapshots']
            del mapping[next(p for p in mapping if '/k768/source/' in p)]
        elif label == 'missing-final-csr-dump':
            del bad[3]['reference-02']['campaigns']['288']['validations']['normal-0']['raw_sha256']['final-csrs.bin']
        elif label == 'wrong-negative-exit':
            next(c for c in bad[3]['reference-01']['commands'] if c['label'] == 'k288-negative')['exit_code'] = 0
        elif label == 'generated-path-escapes-run':
            mapping = bad[3]['reference-02']['generated_inputs']; path = next(iter(mapping))
            mapping[str(helper.RUNS / 'future-target-01/foreign.py')] = mapping.pop(path)
        elif label == 'false-performance-qualification':
            bad[3]['reference-02']['performance_qualified'] = True
        elif label == 'conflicting-original-pin':
            bad[3]['reference-01']['original_inputs'][str(helper.RUNS / 'gnu-01/result.json')] = '0' * 64
        elif label == 'missing-gold-fixture-pin':
            del bad[1]['files']['cases/normal-0/fixture/gold.bin']
        elif label == 'local-parent-traversal':
            mapping = bad[3]['reference-02']['original_inputs']; path = next(iter(mapping))
            mapping[str(helper.SOURCES / 'screen-source-02/../screen-source-02/source-manifest.json')] = mapping.pop(path)
        try:
            check(bad)
        except ValueError as error:
            negative_results.append(dict(case=label, status='REJECTED', reason=str(error)))
        else:
            raise AssertionError('negative was not rejected: ' + label)

    helpers = {}
    for name in ('need', 'stamp', 'stream_sha', 'sha', 'read', 'encoded'):
        new_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        old_node = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        new = ast.get_source_segment(source, new_node); old = ast.get_source_segment(original, old_node)
        assert new == old, name
        helpers[name] = digest(new.encode())
    a, b = '        raw_manifest = encoded(manifest)\n', '        audit = dict(status='
    transport = source[source.index(a):source.index(b)]
    old_transport = original[original.index(a):original.index(b)]
    assert transport == old_transport
    for start, end in (
        ('    started, deadline = stamp(), time.monotonic() + 600\n', '        signal.setitimer(signal.ITIMER_REAL, 600)\n'),
        ('    except BaseException as error:\n', "\n\nif __name__ == '__main__':"),
    ):
        assert source[source.index(start):source.index(end) + len(end)] == original[original.index(start):original.index(end) + len(end)]
    imports = {alias.name for n in tree.body if isinstance(n, ast.Import) for alias in n.names}
    assert 'subprocess' not in imports and 'importlib' not in imports
    report = dict(status='STATIC_AND_CAPTURED_METADATA_CHECK_PASS', helper_bytes=len(raw), helper_sha256=digest(raw),
        actual_captured_records=observed, fixed_input_roots=10, pins=len(pins), recorded_sizes=len(sizes),
        required_files=len(required), semantic_record_pairs=len(pairs), external_dependencies=len(external),
        raw_dump_files=380, final_snapshots=[40, 41], final_generated_inputs=[111, 111],
        recorded_pin_counts={k: len(v) for k, v in groups.items()}, negative_controls=negative_results,
        unchanged_basic_helpers=helpers, unchanged_zip_readback_after_sha256=digest(transport.encode()),
        timer_and_failure_tail_unchanged=True, archive_main_called=False, scan_called=False, zip_created=False,
        native_pc_accessed=False, new_guest_runs=0, new_builds=0, new_eda_runs=0,
        scope='Cloud captured-metadata/static checks only; no original tree inventory, ZIP or local execution qualification.')
    (OUT / 'selfcheck.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'helper_bytes', 'helper_sha256', 'pins', 'required_files',
        'raw_dump_files', 'external_dependencies', 'zip_created')}, indent=2))


if __name__ == '__main__':
    main()
