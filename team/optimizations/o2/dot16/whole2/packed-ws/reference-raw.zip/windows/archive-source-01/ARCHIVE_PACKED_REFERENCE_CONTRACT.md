# Packed GNU 与两代 reference 原始证据运输合同

## 目的与边界

仅运输 `dot16-packed-ws-20261107-main` 下已经闭合的 GNU 身份检查、K288 fixture 提取、reference-01 和 reference-02。不启动 guest、GNU、NEMU、EDA、validator 或任何子进程，不读取后续 target/preflight，也不读取其他项目归档。归档成功只表示选中原件的运输完整性；不增加 target、应用或性能资格。

本助手只在云端编写及做静态／已捕获元数据检查。实际 Windows/WSL 归档由 root 审核后单独执行。原件不删除、不移动、不重写；不省略 `.o`、`.a` 或任何其他文件。

## 固定输入与命名空间

WSL 父目录：

`/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-packed-ws-20261107-main`

Windows 父目录：

`D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runs\dot16-packed-ws-20261107-main`

其 WSL 挂载路径是 `/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main`。

| 原件目录 | ZIP 目录 | 用途 |
|---|---|---|
| WSL `gnu-01` | `wsl/gnu-01/` | GNU 全体函数机器码、ELF、对象、日志及输入快照 |
| WSL `q288-fixtures-01` | `wsl/q288-fixtures-01/` | 四例完整 fixture、原始符号、manifest/result、输入快照 |
| WSL `reference-01` | `wsl/reference-01/` | 第一代双 K 的完整 GNU/NEMU 与比较器证据 |
| WSL `reference-02` | `wsl/reference-02/` | 第二代八窗口双 K 的完整证据 |
| WSL `source-01` | `wsl/source-01/` | 实际 GNU 执行源 |
| Windows `source-01` | `windows/source-01/` | 上述 GNU 源的逐字节匹配镜像 |
| Windows `fixture-source-01` | `windows/fixture-source-01/` | fixture 提取器及合同 |
| Windows `screen-source-01` | `windows/screen-source-01/` | 第一代 reference 源、合同及 manifest |
| Windows `screen-source-02` | `windows/screen-source-02/` | 第二代源、合同、manifest 与 derivation |
| Windows `archive-source-01` | `windows/archive-source-01/` | 本 helper、合同、审查、自检、原始 host receipts |

只递归这十个目录，不扫描父 `runs`；根之间必须独立，拒绝符号链接及非普通文件。Windows/WSL 的 `source-01` 具有不同 ZIP 名称。Windows 镜像只记字节一致性，不冒称它是 GNU 执行路径。所有额外存在的普通文件也一并保存，并获得运输时的完整长度和 SHA。

## 固定证据身份

| 原件（相对 WSL 父目录） | bytes | SHA256 |
|---|---:|---|
| `gnu-01/result.json` | 18710 | `369307b6a392df26e1e34f5a643feb2cadb96f84ada8006214625ba6e27ebb8e` |
| `q288-fixtures-01/manifest.json` | 26147 | `13d05882e6f1876993a6e6b63c8d5041c1067bdfb73ba061adf41f91d66f2bd1` |
| `q288-fixtures-01/result.json` | 1021 | `2486b659f58c29fe6012a2d9d4efdbd182127bbe7bcc682341fbd3b9e7b200fc` |
| `reference-01/result.json` | 142366 | `cec287cff44cdda1070539515a3d426fd81e6a4025e0a84ac6bcb632ef7f1f5a` |
| `reference-02/result.json` | 166147 | `65de4aca20b86d7faaed7c11863297930d571ee2c97b2ad54bb15bdd4c72e4d0` |
| `reference-02/k288/static.json` | 24695 | `9883493045580c3c30f95616e671a2343726e8f04f9bd4b449f5647633d1c3ba` |
| `reference-02/k768/static.json` | 15282 | `b3696cc418c12faf83a049adc1d83c1fbdc8646f8bad004393e6ec6ef63e4226` |

第一代两个 static 的 SHA 从其已固定结果读取：K288 `e7b87e57257debbf86b326498ee998a113d5bbac5b6149980e52ba63f0c5fa38`；K768 `4b8cacbeb6763b571a11b8866bbf8bc39e5b2a18e2564ef17a865a18355f386c`。两份云端原字节的长度分别为 24695、15282，已在静态自检核对。JSON 只用于检查原元数据关系；ZIP 保存完整原字节，不重新序列化原始工程 JSON。

## pin 与原始资格

GNU 原结果的 20 个 inputs、13 个 snapshots、20 个 artifacts 全量参与覆盖检查。10 条实际命令必须保留原 exit0/reaped/group_absent 记录。四个完整机器体与原父体的已有检查结果只被保留，不重新反汇编或运行。

reference-01/02 使用**最终 result.json** 的 40/41 份 snapshots、各 111 份 generated_inputs，并保存初版 inputs.json。每代 21 条原命令、10 次 guest 的闭合记录均保留：两次负控 exit2，其余 19 条命令 exit0。每代两种 K 共 10 例，每例按自己的原 dump_plan 保留 15 份完整内存 dump，加初／末 registers 两份 1400 B、初／末 CSR 两份 32768 B，共 19 份；两代合计 380 份都有原 SHA 和完整长度。两代 sample 大小不同，使用各自记录，不能统一套旧值。

每例还保留 image、stdout/stderr、result、reference-result、abi、validation。每例 result 与顶层 command、validation 与顶层 validation、image record 与 static record 做完整 JSON 对象一致性核对，Python 整数不经浮点或 JavaScript 中转。这个检查不执行比较器、不重新判定数值正确性。

提取阶段 `expected_flags_resolved=false` 保持不变；两个 reference 的已有 `reference_qualified=true` 分别保留。所有 target/performance/application 相关 false 不变。第二代仍明确引用第一代结果的原 SHA，不能用第二代结果覆盖第一代。

对已捕获实际九份元数据的静态检查得到：753 个去重内部 pin、442 个有记录长度的 pin、941 个至少必须存在的文件、52 对原 JSON 对象关系、137 项外部依赖。实际目录可能有更多文件，全部运输；这些数量不是完整目录文件数的估计。

外部工具、AM、NEMU、adapter、旧 ELF、旧参考和缓存只记录原 path/SHA（及原记录已有的 bytes），不读取、不复制、不重新 hash。两个原外部 include 路径含 `include/../`，精确保留其拼写；若原路径或词法规范化路径落到选中目录，仍必须通过内部 pin 的禁止 `..` 检查。不会通过外部路径逃逸去打开文件。

## 运行资源、CLI 与输出

helper 本身放入 Windows `archive-source-01/archive_packed_reference.py`；同目录由 root 注入 `receipts.json`，包含 GNU、fixture、两代 reference 的原始 host structuredContent。运输器保存 receipts 原字节，不猜测外层协议字段。合同、review、自检也放入该目录；这些仅为辅助资料，不计为原运行 PASS。

```bash
python3 -B /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main/archive-source-01/archive_packed_reference.py \
  --runs /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-packed-ws-20261107-main \
  --sources /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main \
  --output /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-packed-ws-20261107-main/archive-reference-01
```

单进程固定 CPU1、absolute nice5；自身设定并读回，最长 600 秒，INT/TERM/ALRM 进入失败保留路径。没有后台 worker 和子进程。调用方按其现有有限 host operation 运行，归档闭合后才启动计划中的 target guest。

需声明的读取资源是上述五个明确 WSL 子目录和五个明确 Windows 子目录，以及 Python 标准运行时（例如 `/usr`、`/lib`）；唯一写资源是全新的 Windows `archive-reference-01`。不需要声明跨根工程依赖的读取权，因为 helper 不打开它们。不需要 target/preflight 的读写权。

输出：

- `archive-reference-01/raw.zip`：十个命名空间中的所有原件，加 `ARCHIVE-MANIFEST.json`。
- `archive-reference-01/audit.json`：只有全体成员 CRC/完整 SHA、精确成员集合、源目录 after-scan/全 SHA、总预算均通过后才写；`status=PACKED_REFERENCE_RAW_ARCHIVE_VERIFIED`。
- 失败时写 `archive-failure.json` 并保留部分 raw.zip，不重试、不删原件、不覆盖已有输出。

manifest `schema=1`，包含固定结果身份、源证据原 scope、十根目录映射、所有成员长度/SHA、目录、分组 pin 数、完整外部依赖身份和空 `omitted`。audit 给出 raw.zip 长度/SHA、完整成员／文件／目录数量、实际保留字节数、pin 数、原件未变与运输验证标志；`new_guest_runs/new_builds/new_eda_runs=0`，`original_validators_rerun=false`。在真正运行前，不能声称这些运输检查已完成。

## 实现复用与已做检查

stream hash 六个基础 helper、ZIP 全成员读取与 after-scan 块、600 秒 timer/失败保留尾段逐字节复用现有 `archive_prefix.py`。scan 仅增加固定 Windows/WSL namespace 并取消所有省略。metadata 打开前先扫描十根拒绝链接，避免记录路径经链接指向选中范围外。

`selfcheck_metadata.py` 在云端仅解析 Python AST、核对九份已捕获原始 JSON 字节、调用无 I/O 的 evidence_metadata，检查八个定向错误会被拒绝，并比对以上复用代码。未调用 main、scan、ZIP，没有本机访问、guest、EDA 或新构建。它的 PASS 只代表静态及元数据检查。
