# 固定 K288 narrow ELF fixture 抽取合同 v1

此工具只读指定闭合image，写全新隔离输出。没有本机、DUT/NEMU、C oracle、pack.c或构建执行资格。本文件与helper应一起冻结，helper会将二者及实际支持输入原字节快照到新输出。当前尚未执行实际ELF抽取。

```text
python3 -B extract.py
  --image-build /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole8-narrow-q288-20261107-main/image-01
  --model /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-whole8-narrow-q288-20261107-main/image-01/inputs/model.py
  --output <fresh isolated q288-fixture directory>
```

固定CPU1、绝对nice5、总120秒，仅Python标准库与固定model，没有子进程。输入包括image下的paired16-target.elf/status.json/elf-check.json、source的main.c/q288.c/oracle.c、model和helper/本合同。只读这些具体文件，不遍历运行目录、不读任何活跃target/owner；输出不在旧image内。失败保留partial文件和FAILED result，不删旧源。

## 固定来源与范围

整个ELF SHA固定为 `82281d6fab843190321cdb21189f2feae848e2c1220e6a1ad0ec8bd883011b91`，model固定为 `703667b537c652b22a7dd82f8e3d3a7a42e965d7b5df7d4627b78e0d7358cc82`。三份源按既有SOURCE_PINS固定；status须是已闭合静态image，ELF路径/身份相符。status和elf-check的原字节分别记录实际SHA并快照，不把Chat副本的尾部换行当作原文件身份。

实际elf-check的unchanged_fixtures只有**9**个完整符号，并非10个：q_weights、q_packed、q_inputs、q_weight_scale、q_input_scale、q_golden、q_min_packed、q_min_x、q_min_golden。工具将九个完整长度/SHA常量与清单和实际ELF同时核对；记录RAM地址、文件偏移，要求整个符号处于同一已分配PROGBITS节、文件/RAM边界内，符号跨度不重叠。完整符号原件保存到source-symbols，不仅保存剥离后的payload。

q_packed/q_min_packed/q_min_x均按实际main给出的16B前/后guard剥离，四个uint64必须全为0xd15ea5e5cafebabe。先按原公式验证普通q_weights完整重打包等于q_packed payload。fullmin的row-major W由实际min packed逆恢复，完整round-trip后再检查全部W和X字节确实为0x80，不预设输入。

## 四组独立完整fixture

输出 `cases/normal-0`、`normal-1`、`normal-2` 和 `cases/fullmin`，各含record.json和fixture目录。

| 每个case的文件 | 字节 | 来源 |
| --- | ---: | --- |
| weight.bin / packed.bin | 各82944 | 共享普通W/实际packed；fullmin为逆恢复W与实际min packed |
| input.bin | 288 | q_inputs的对应dataset；fullmin为实际min X |
| scales.bin | 10368 | 全部原q_weight_scale |
| input-scales.bin | 36 | 对应dataset；fullmin明确使用dataset0 |
| gold.bin | 1152 | 对应q_golden原字节；fullmin为原q_min_golden |
| slot-gold.bin | 128 | 独立整数dot32最后tile/group，8槽低32+零高96 |
| packed-scales.bin | 10368 | 原Ws的完整4字节对象排列，[row][group]→[tile][group][lane] |

普通三个dataset共享W/Ws；各取完整X/Xs/gold片段。每个record记录原symbol、offset、长度、地址和每文件SHA；fullmin不是scale全1，它复用原Ws与dataset0的Xs，遵循实际min_judge和main的prepare路径。

slot期望直接对原W/X按有符号字节做精确整数和，不运行候选；fullmin八槽必须全为524288。packed-Ws检查2592个四字节对象恰各使用一次，保持全部对象位表示，不调用float转换或pack.c。

另外只调用固定model的ELF读取与 `round_binary32/multiply/add` 纯整数原语，按每行group0..8的cast→乘Ws→乘Xs→左折叠加复算全部输出，并与每case原gold逐字节相等。它只核固定有限二态数值的RNE结果，不模拟guest指令、X/Z、FCSR或异常。

## 精确flags明确未定

旧main的judge/min_judge仅检查FRM=0，没有检查精确FCSR。所有case记录 `expected_flags: null` 和未解决状态，**不生成expected-flags.bin，不填1或0**。纯数值模型同样不计算fflags。本工具的位值校对不能替代root后续基于完整原oracle的有界host/NEMU交叉验证。

manifest保留完整输入pin、九符号身份、guards、四case来源与所有导出文件SHA。结束时核原输入前后身份及全部输出readback；result只能标记静态fixture抽取/位值检查，reference/target/performance资格仍false。

## 交付前检查范围

云端副本已完成AST、实际三C/model及九符号清单pin核对；合成数据验证了82944B打包逆映射、2592个四字节scale对象排列、32个guard字节逐一损坏拒绝，以及scale全1的合成fullmin精确输出/槽位。独立只读审查核过输入目录、来源切片、数值次序和资格边界，未发现具体阻塞。上述检查未读取实际ELF，不表示四组真实fixture已抽取，也未解析或推定实际FCSR。

CLI所列model路径来自既有image生成器的 `inputs/model.py` 落盘入口；实际执行仍须通过完整固定SHA。读资源只需上述9个明确输入文件；写资源仅新输出根。没有子进程、工具链、Git或EMU目录写入。
