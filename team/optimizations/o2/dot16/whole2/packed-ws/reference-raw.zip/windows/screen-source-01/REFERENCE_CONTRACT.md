# Packed-Ws 两种固定几何参考验证 v1

合同 `r3-packed-ws-two-geometry-reference-v1`。本次只编译两个固定K镜像并使用既有、未修改的独立NEMU参考检查；不运行目标EMU，不授予性能、整应用或新RTL资格。源码和全部输出位于隔离runs，官方AM、上游标量源、NEMU及旧证据只读。

## 输入身份与几何

K288与K768分别构建一个ELF，均M288、GS32、VLEN128、RV64/lp64d；没有运行时K分派。每个ELF共有scalar、原P、原N、packedP、packedN五种方法。四个选中汇编函数必须在最终ELF中按完整函数体长度/SHA与已闭合GNU阶段相同，而不只检查局部opcode。

GNU入口为 `gnu-01/result.json` 18710B，SHA `369307b6a392df26e1e34f5a643feb2cadb96f84ada8006214625ba6e27ebb8e`。候选packed.S为17064B/`445ff9a47f182e8f876caf1dcd89eac2d13a25ebccd3ceb91d21a194d31edb15`，pack.c及typed header沿用该阶段完整固定输入。旧/新汇编保持不同编译对象，避免同名局部标签冲突。

K288使用已闭合ELF82281d6f…的固定提取结果，manifest 26147B/`13d05882e6f1876993a6e6b63c8d5041c1067bdfb73ba061adf41f91d66f2bd1`。normal-0/1/2、fullmin每例原W/X/Ws/Xs/gold与独立dot32最后八槽完整保留；fullmin仍为原Ws及dataset0的Xs。该提取没有精确flags资格。本次先将完整未修改q288 oracle与flags_host.c一起以固定x86_64 GCC11、O2、禁fast-math/FMA/自动向量化、frounding-math、标准精度编译，逐例核全部1152B原gold并采集实际五位异常映射。此结果作为待交叉的期望；后续实际NEMU中scalar和四种汇编均须满足精确FCSR，才完成RISC-V交叉。

K768复用闭合W2 N/P reference-01的normal和edge完整fixtures及原flags，result SHA `7d46f70b4cb105bd468577815e21c97fe9fa249fb447eeec3c977d9236e3b8c1`，static SHA `b498a43984c64707d28861505275fb0aff0e23e64778ba68d92350873e5bc448`。上游runq.c和原scalar.c逐字节复制，既有资格不自动转移到新ELF。

新的packed-scales期望按原Ws四字节对象排列为[tile][group][lane]，完整索引置换，不求值FP、不运行候选preparer来生成期望。K288还与独立提取期望全字节相等。其余fixture和控制字均记录精确ELF位置、长度、非重叠关系。新case镜像只替换声明的fixture范围；负控/UART仅原8B控制范围。

## 实际guest检查与计数边界

main.c为团队新固定几何harness；原标量、四种叶函数及ABI不修改。RowContext、PackedContext和两套slot使用不同类型，没有不兼容结构指针强转。

进入后启用FS/VS、检查VLEN16B；实际PREPARE写独立64B对齐对象，并与外部完整期望逐字节比较。prepared由64B头guard+10368/27648B数据+64B尾guard构成，完整10496/27776B。准备及其首尾完整检查均不在测量窗口内。

顺序固定为 `[0,1,2,3,4,4,3,2,1]`。每窗口先warm一次、再实测一次，总18次调用。每次恢复输出和两套槽为A5，固定VL8/e8/m1、vstart0、vcsr7、FCSR0。每次比较全部288输出；活动槽全部128B对gold、非活动槽全部A5，并检查16B前后guards和VL/vtype/vstart/vcsr。完整FCSR必须等于独立期望，因而同时约束FRM0。

四处实际CSR采样顺序为cycle/instret/instret/cycle，各自两侧均为IORW fence。实测FCSR在结束计数器之后、比较/hash/UART之前取样。窗口包含harness实际apply调用与选择开销；不减猜测常量。参考样本的计数不是香山目标周期或最终性能指标。

负控固定method2，在实测结果第1148字节翻一位后立即完整比较，必须code91、warm=1、接受样本0、全部samples为0。不能为接纳负例修改官方参考。正常末次method1和负例method2的终态都为原槽gold、新packed槽整A5。

## 完整参考判据

复用原团队W2完整validate函数，仅两项可逆文字替换：不可变fixtures清单加expected-flags/packed-scales，样本flags从常数改为record值；ORDER由本合同固定。原终态、负控、raw inventory、1400B寄存器及32768B CSR dump、512B报告、576B样本、1152B结果和原槽/guards判据保留。另比较新packed槽160B、完整prepared对象及末态FCSR，且全部fixture终态SHA与各自原始字节相同。

实际ELF/BIN包括BSS必须完全等价，静态RV64入口、RAM/节/栈界限、四个完整函数体、实际成功/失败trap、counter fence逐项绑定。reject完整函数允许编译器产生1或2处trap，但每一处都必须是完整li-a0-91+rs1-a0退出指令；实际负例只能停于这些地址。

K288按negative、normal-0、独立replay、normal-1、normal-2、fullmin共6例；K768按negative、normal、独立replay、edge共4例。两种default均要求完整validation对象逐字节意义相等重放。总10次参考运行，不启动目标EMU。每例原adapter100M步/180s，外层210s上限且受总预算限制，任何异常、超时、反例或身份变化立即失败并保留原件。

## 资源及回收

CPU1、绝对nice5、单worker，make -j1；总工程预算1200s（CLI仅允许300..1800s），外层保留有限回收余量。21条计划命令：host编译1+host4例+两组build/metadata/disassembly共6+参考10。不是并行21作业。原成熟command进程组/信号/最终回收逻辑完整复用；所有子进程必须reaped且group absent。日志/单文件上限32MiB。

唯一写树为fresh output，包含host、两组source/objects/images/reference及证据。所有原源、既有闭合GNU/K288提取/W2参考/硬件ABI/adapter、工具链、AM库与脚本及相应只读Git元数据完整声明；仅沿明确闭合入口读取，不遍历活跃target/owner。不修改AM库、不改官方工具，不重复原整应用仿真。输入、源码快照及生成输入在每例后完整复核，失败不自动重放。

成功状态只为 `PACKED_WS_BOTH_GEOMETRIES_REFERENCE_PASS`。`target_emu_runs=0`、`target_runtime_qualified=false`、`performance_qualified=false`、`application_performance_qualified=false` 保持明确。目标小规模验证须另立合同与结果；生产接入、准备成本和完整应用收益均不由本次参考PASS替代。
