# packed 原始证据运输辅助器审查

## 结论

可交 root 审阅后运行一次。这里没有执行归档；没有读取本机或任何活动输出。实现限定已有闭合 GNU、fixture、两代 reference 的十根目录，保留完整原件、失败负控与原资格边界。

helper：`verification/archive_packed_reference.py`，28224 B，SHA256 `5c66e38e98ae219e8a218898d7cdd780d73c9342ee21bcae5872e3c94e2ed943`。

## 核对依据

- root 逐字节导入的 GNU result、两个 reference result、两个 fixture manifest/result、四个 static，共九份 JSON。
- 实际执行的团队 screen.py 与 check_gnu.py 中路径、guest 结果持久化、stdout/stderr、最终 snapshots/generated_inputs 的写入逻辑。
- 成熟 `archive_prefix.py` 的 stream hash、全 ZIP readback、after-scan、600 秒 timer 和失败保留段。

全部已捕获 JSON 通过原 SHA；纯元数据函数通过，得到内部 pin 753、完整 raw dumps 380、必要文件 941、原 JSON 对象关系 52、外部依赖 137。第一代 40 与第二代 41 个最终 snapshots 都保留，各 111 个 generated_inputs 都保留；没有用运行初期的 inputs.json 代替最终清单。

八个定向负控仅变更捕获的内存对象：丢后补 snapshot、丢 final CSR dump、负控 exit2 改0、生成路径逃出本 run、虚增 performance 资格、冲突原 pin、丢 gold fixture pin、内部路径含 `..`；全部被拒绝。没有制造或执行任何 guest 反例。

## 实际修正

初稿对所有原路径禁止 `..`，会误拒两个真实外部 NEMU `include/../...` 依赖。现只将这两个外部路径按原拼写记录且不读取；内部 pin 或词法规范化后落入选中树的路径仍严格禁止遍历。外部原路径没有被偷偷替换为新的身份。

metadata 读取前先做十根 scan 拒绝链接。不会因 JSON 是普通文件名而先跟随一个尚未检查的链接。十根全部读完后的第二次 scan 与全文件 SHA 复核仍保留。

Windows/WSL source-01 分 namespace 保存。Windows 的十个 GNU 文件与实际 WSL originals/snapshots 比较，明确标为 mirror，不把没有执行过的路径标成执行来源。

## 独立复核及局限

whole2_code_review 已完成初稿 28148 B / `baf82ffcd34d39d0ce02763bb431e97b65735a677771ce7efbd8208b0e5cfa11` 的有限只读接口审查，核对九份实际元数据、source mirror、完整 raw pin、21 命令闭合、每例 JSON 持久化和 namespace，无新增实质阻塞。之后的唯一 helper 修改是将现有 scan 前移到 metadata 读取前；最终版重新通过全部纯元数据与静态检查。独立审查不替代 root 最终审核或实际归档。

未取得本机十根实时目录 inventory，未执行 ZIP，因此当前不能报告真实 raw.zip SHA、字节数、成员数或原件 after-scan 已通过。helper 会在受限实际执行时生成这些结果。目录完整性失败会保留部分产物并报错，不再扩实验、不重建源码、不重新执行 validator。

详见同目录合同和 `selfcheck.json`；实际运行 CLI、输入资源、输出 schema 均在合同中。
