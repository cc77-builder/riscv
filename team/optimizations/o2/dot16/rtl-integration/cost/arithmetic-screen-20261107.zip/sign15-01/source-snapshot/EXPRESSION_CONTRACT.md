# Signed product expression screen, v2

This is a separately identified continuation of the signed8 v1 screen. Its input
generation/cost receipts, complete FU boundary, unchanged wrapper/reducer, same
mapping/STA templates, library, and tools remain the v1 inputs. The original v1
screen and its failure/lifecycle limitations are retained unchanged.

`signed8` is the prior explicit signed-byte product expression. `sign15` keeps
the exact low 15 product bits and obtains bit15 as:

```
(a[7] XOR b[7]) AND (a != 0) AND (b != 0)
```

The signed-byte product is in [-16256,16384], so the high bit is exactly the
nonzero product sign. Neither -128 nor zero requires a special numerical domain
restriction. There is no change to rounding, saturation, lane order or width.
The implementation is accepted as equivalent only after the same unconstrained
all-eight-lane, full-16-bit Yosys SAT miter succeeds. The exact original module
must be reconstructible from the edit list. This remains an isolated generated
RTL input experiment, not a production source or guest qualification.

The complete 1,870 state bits, full IO, two elastic slots, E2 earliest response,
and unstalled II1 remain structurally untouched. The normal protocol, clock/reset
and flush behavior are not traded for area. No clock-gating or test-enable change
is part of this experiment. The new 20,000 library-area budget is evaluated in
the unchanged CommonFuCostTop scope. Existing negative setup slack is retained.

One worker remains on CPU1/nice5; original four EMUs keep their existing core
assignments. Total 420s, proof 120s, synthesis180s, STA60s, and bounded process-group
cleanup. v2 additionally latches TERM/INT into the same cleanup path and rejects
an output that contains or is contained in either frozen generation or nominal
input tree. A failed or interrupted command does not gain PASS. No automatic
retry, production checkout edit, extra guest, or extra CPU is authorized here.
