# Explicit signed-byte multiplication expression screen, v1

This bounded experiment changes only eight assignments in a separate copy of the
team-owned generated `VDotProducts.sv`. The original source, generated RTL, prior
evidence, resident cache, and all active forward inputs stay unchanged. It is a
new synthesis-input candidate, not a replacement of the authoritative design.

For each lane, the original expression sign-extends two signed bytes to 16-bit
bit patterns before an unsigned 16-bit modular product. The candidate writes the
same 16-bit product using two explicit `$signed` byte slices. A Yosys SAT miter
proves all eight complete outputs equal for every pair of 128-bit source inputs
before synthesis. Each edit has an exact inverse. No width, lane, or ignored-high
operand rule changes. The clock, reset, flush, p/r slots, complete control/perf
identity, 128-bit public result, earliest E2 response, and unstalled II1 are
preserved structurally because `VDotElastic.sv` and the complete top are unchanged.

The existing feature1 CommonFuCostTop source quartet comes from generation receipt
`7b45921ee1b5ff564113daa61403c4e52ecb598305aad6c093f4ab5768fe0a09`.
The original cost receipt is
`8c9a22771594565bfaa812309f68c84de4e8a213b02b9aba03440373f61e2e51`.
Mapping and STA scripts are reused with path-only reversible relocation, along
with the exact fixed Nangate45 library and installed tool identities. Full ports
and all 1,870 functional DFFs must remain. The same five timing path classes and
constant-only setup warnings are checked. The existing 24,017.406 area point is
the comparator; the new soft budget is 20,000 in that same library-area scope.

One worker uses CPU1, nice5, one thread. Total budget 420 seconds; individual
limits are 120s proof, 180s mapping, 60s STA, with process-group cleanup. The four
original EMUs continue on their existing CPU0..3 assignments. No guest, new
core elaboration, official checker change, or additional core is requested.

This screen cannot establish core timing, power, forward speed, or a production
implementation qualification. If promising, a maintainable source-level route
and its own validation are required before adoption. Failure evidence is retained;
timeouts or a missing proof never become equivalence PASS.
