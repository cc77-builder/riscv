# FA 映射网表的单次格式续接

合同 `dot16-fa-netlist-serialization-v1`。原FA实验local-01、源码和FAILED状态全部保留。唯一实际映射已经完成，954FA/4770pin/两完整CSA实例、1678DFF和原接口已通过；OpenSTA2.0.17对输出Verilog的concat-LHS报语法错误，因此原时序报告无资格。不得忽略这些错误或回写原结果。

此续接只使用原mapped.json，调用同一Yosys的官方splitnets默认模式（不使用-ports），然后write_verilog -noattr -norename。不运行proc/synth/opt/ABC/dfflibmap，不替换单元，不修改官方工具。前置help记录安装版本实际支持；输出仍含concat-LHS即停止。所有输出只写新serialization-01，原输入逐项冻结并前后核SHA。

先比较原JSON与split JSON，再在同一完整Liberty下重新解析导出的Verilog，比较完整电路终端连接图。比较所有顶层port的名字、方向、位宽、offset/upto/signed；每个cell的原名字、type、全部parameters、port方向/位宽；每个电网的全部cell/port逐位终端集合及0/1/x/z常量标签。不以临时bit编号或别名命名作连接身份；无初始化属性才允许忽略纯显示/源位置属性和不连接电路的别名。该校验证明序列化前后电路图相同，不称为原RTL到完整映射网表的等价证明。

原TCL仅替换输入/输出目录，完整inverse必须恢复原文件；1ns、所有时序与负载/线负载约束完全不改。原同库area重新从实际cell求和，保留954FA与1678DFF、220ports/2888bits边界；原D1000是对照，五类路径均须存在，任何STA Error/不完整结果仍拒绝。无FU/core/应用/PPA资格转授，不切换生产默认。

CPU2单核nice5，内部总120s；help≤10s、serialize≤30s、reparse≤30s、STA≤30s，外层180s含有限清理。全部子进程独立组并回收，失败保留，不自动重试/加时或改原门禁。新映射/ABC运行数为0。这是同一个映射点的格式兼容处理，不增加PPA扫描点。
