# Prefix parent 归档适配器审查

## 交付

`verification/archive_prefix_parent.py`：**26816 B，SHA256 `84a27ca933ce8014505f5a627ca66e3ad7fda42606591a64c51535f9450c82eb`**。

来源基底为 `verification/archive_packed_target.py`：SHA256 `b8ae9a93334fffbd1978f39c00c96190e8212c420313f5b04721d906538d85cc`。七个基础函数（含 scan）、完整 ZIP 读回与原树 after-scan 区块、失败保留尾部逐字相同；计时段仅按主端同意从 300 s 改为 600 s。无 subprocess，也不导入原工程 checker/controller。

只读三根：WSL parent-01、Windows parent-source-01、新 archive-parent-source-01。曾发现旧 prefix local 已使用同根 archive-source-01，主端已确认另用新名字，避免污染旧冻结输入。输出仍为新的 archive-parent-01；零省略、原件不删，含两 binary、全部生成源码/RTL/classes、正例和40项注错 raw、checker 和 `.o/.a`。

## 实际绑定

直接读取本次云端原件，未沿用旧 675/21 等计数。实际为：893 originals＝3 个归档内 Windows 执行源＋890 外部记录；22 snapshots；177 final artifacts。两个 generated manifest 各58项，并与 final 逐项一致；5个 harness class 和2份 binary 也在 final 内。metadata-audit 给出四份 raw log 的 stored SHA/完整长度，coverage 引用同一原件。归档共214个去重pin、231个原长度约束。

两份正例日志共40,131,032 B、两份 metadata.log 共23,889,848 B；这只是已知四日志体量，不冒充整树总量。census提供顶层103文件/5目录；递归体量和所有成员由实际归档扫描形成。classpath-before、runtime-classpath、observed-input-pins以及harness class清单只运输当前parent内部原件，不展开外部原路径或缓存。

原 result固定SHA为`03eb17ce008ab0be25b9d46ddf53a237daa2ee912c817be801ba8a80c6deaa8d`，host为`.e40fda7c58fb6656b3580c4529f40a2f`。原96命令均closed/reaped/group_absent，56×exit0和40×注错exit1保留原语义；host launch的3个源pin、输出路径和terminal摘要与result吻合。不重查进程，不重跑原checker。

`source_evidence.host_finished`只是原host `updated_at`（闭合回执更新时间），不声称独立进程停止时刻。inner原started/finished、host原started_at/updated_at以及outer duration=852131 ms有不同来源语义，合同已分别列明；helper行为未因此改变。

`parent_qualified=true`是原功能结论；归档仅保存它。fullcore/application/cost/core-cost/performance均false，旧乘法miter仍`UNKNOWN_EXTERNAL_TIMEOUT`。运输成功不提升任何这些资格，也不把parent运行的cost=false解释为撤销上游独立local成本证据。

## 有限自检和独立复核

`selfcheck_metadata.py` / `selfcheck.json` 已完成AST、14份可用云端原字节的长度/SHA、实际metadata正例和6项有限变异：未回收child、binary pin与result冲突、source/snapshot冲突、generated路径越界、fullcore资格升格、乘法UNKNOWN改为PASS。正例通过，六项均拒绝。七个基础函数、ZIP读回/after-scan及失败尾部的精确源码比较通过。

四份未提供云端完整字节的内部清单（classpath-before、observed-input-pins、parent-harness-classes、runtime-classpath）本次只与原census中的长度/SHA核对，明确记录在selfcheck的`identities_only_from_original_census`；主端实际运行时，helper会读取这些内部原文件并核完整长度/SHA。

`/root/whole2_code_review`对同一`84a27ca9…`完成只读复核，未见具体漏pin、路径误拒或资格误升，确认三根范围、原命令语义及原终态绑定。该复核没有执行helper、自检、ZIP、guest或本机操作。

本子任务仅创建云端verification文件。未调用归档main/scan/ZIP，未操作PC；真实全树可读/无链接、全成员CRC/SHA、600 s内完成和原树未变仍待主端实际运行。执行前按合同放入helper与原census、host receipt并冻结读回；没有新增工程验收门槛。
