# Prefix 外置整核六例差分冒烟衔接 v1.1（source-02）

本入口仅准备将**实际成功完成的外置 prefix 新 EMU**连接到已有六例合法 AM 镜像和原判定函数。准备阶段没有运行新 EMU；默认只生成计划。人工于2026-11-08 01:53 UTC解除录制保护；执行仍受原资源与运行保护约束。实际执行须在资源条件允许时使用新输出目录，原四臂和官方程序保持原样。

## 对原合同的复用和必要变化

复用 `dot16/rtl-integration/fullcore/CONTRACT.md` 的六例规格、固定 feature1 NEMU、boot flash、128 MB RAM、seed=1、300000 guest cycle和600秒 EMU墙钟保护。六例仍为两条dot8、四条dot16，覆盖原有vd别名、v0、signed8极值与完整高96bit零检查；不新增或删减任何通过条件。

包内 `legacy-smoke.py` 是原 `smoke.py` 的逐字节副本，SHA256 `363725f7a54ed367c7302108bc73f70266c68674a25a72587aaa04bc80e9e755`，没有修改。仅导入其 `audit_elf`、`architectural_blocks`、`runtime_gate` 和固定常量，不调用其 `main`。原通用runtime gate也按原SHA读取，不修改。实际目标日志仍必须满足原始BEGIN、六例PASS、最终唯一PASS、DiffTest启动、正确reference路径、GOOD TRAP及完整失败标记检查。

原入口把生成头固定在 `REPO/build/generated-src`，并读取旧build schema。本入口改为读取新 `core-build-NN/result.json`、`input-lock.json`、`generated-files.json`，从新外置 `cwd/build` 选择EMU和生成头。不会复制或改名旧构建状态来冒充新构建。限定的当前builder SHA为 `77f0d609f732a54c6376759ea2db1ed4b988945c93d8255bf1221774b8c81081`，输入锁SHA为 `01ebfe385c649d14e02f0f1a880dd60f5971cbb92c8219bc4a3a211b198d8ce4`。

## 实际执行的前提和绑定

必须显式提供已读到的真实成功core result SHA、本入口源码SHA和本合同SHA。完整core记录须为 `PREFIX_CORE_BUILD_COMPLETE`，七个原构建阶段均退出0并回收，输入未变；新EMU与生成头按该结果和输出清单核验。失败、中断或仅准备状态不能运行smoke。

原六例镜像直接复用，不再编译。原 `image-01/status.json` SHA `dac699b691bf75063af179059b5220e67e07d32feaeecb117fad74d8fb5836c7`，BIN SHA `6f800620b3ed6e504691ef1a060e701d781f2c888765d006a04cf0a4cfce3a49`，flash SHA `a3360212cf7bb784119c1719c9258362f8567803601b2359aee2c104864fa994`。所有原镜像产物按该status逐项校验，并用原ELF反汇编检查函数重新核对实际六条编码。不会把原镜像PASS迁移成新EMU运行PASS。

新生成头必须与固定reference头的八类架构字段类型/顺序/数组长度一致。`abi_probe.cpp`逐字节复用，SHA `709fd1d0a130b905da505a6fc1defa660a5c6006ec4572f5384c45d9befd2bdf`；用原native记录的真实Clang编译器和新生成头构建轻量布局探针，测得完整1400B布局后才启动唯一一次目标EMU。reference代码、三参调用声明与两参库导出均保持原样。

在ABI/EMU前后，通过新core冻结builder的 `verify_inputs` 执行同一受监管输入核验；该函数只校验原硬件、依赖、classpath、overlay和工具身份，不启动构建。另核对新EMU、头、结果、manifest、镜像、reference、判定器和本入口源码在整个smoke期间未变。读取和执行不构成通用沙箱，实际PowerShell资源声明必须包含这些真实输入与Git元数据。

## 输出、资源和失败处理

仅允许在原prefix runs根下新建 `core-smoke-NN`，不复用、清理或覆盖既有目录。输入core必须为同根的 `core-build-NN`。输出包括源码快照、原始命令与时间、分离stdout/stderr、ABI类型与布局、runtime inputs和最终result。所有官方文件、原镜像和core输出只读。

CPU1、nice5、单线程EMU，总墙钟默认1200秒且必须指定带时区的绝对deadline；输入检查每次最多300秒、ABI编译120秒、ABI运行30秒、EMU600秒，所有阶段同时受总deadline限制。外层进程也应先绑定CPU1/低优先级。每条命令单独进程组，异常、超时和中断执行原进程helper的有限TERM/KILL/wait，保存回收结果，绝不自动重试或延长保护上限。原helper的有限清理宽限可延伸到deadline之后。

成功只设置 `fullcore_smoke_qualified=true`，范围明确为这一个固定六例合法镜像。`fullcore_qualified`、应用性能和PPA资格保持false；不能称为完整G3、非法trap、随机/取消/竞争矩阵或应用性能验证。当前准备成果不包含虚构的core result SHA，也不提供一条可误启动旧EMU的已填参数命令。

## source-02 的最小版本更新

仅把烟测源码中的 `BUILDER_SHA` 和 `LOCK_SHA` 绑定到已审查的构建 source-02；源码逆替换这两项后与 source-01 逐字节一致。构建器的变化是 generation PATH 纳入仓库已有 Espresso，不修改烟测EMU环境。原烟测source-01、core-build-01失败证据和原ABI/镜像/判定逻辑全部保留。新 `core-build-02` 只有实际成功闭合后才可提供其结果SHA，使用独立 `core-smoke-02`；准备记录不代表构建或烟测成功。
