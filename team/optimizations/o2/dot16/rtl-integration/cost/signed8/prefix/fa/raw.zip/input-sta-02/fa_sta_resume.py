#!/usr/bin/env python3
"""One STA continuation of a frozen mapped circuit under an explicit name bijection."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main')
OLD = ROOT/'local-01'
SERIAL = ROOT/'serialization-01'
OUT = ROOT/'sta-resume-01'
PREFIX = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main/local-01')
LIB = Path('/home/lizufan/riscv-tools/nangate45/NangateOpenCellLibrary_typical.lib')
CONTROLLER = ROOT/'input-serial-01/fa_serialization.py'
CONTRACT = 'dot16-fa-explicit-bijection-sta-resume-v1'
EXPECTED = {'/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/input-serial-01/fa_serialization.py': '82738e4ca6c0d84de04cb8a77e9143ab2d646bc025e087dddc3ff62a12109a8a', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/local-01/mapped.json': '7117718b7d29be886b948d70d7a0486a472f341e1ffcf1bec827728b8cc8f53c', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/local-01/result.json': '476d893ba770a9faf323a61b7f1403c5999f4f00569b68d95b4620ff9b61a473', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/local-01/timing.tcl': '20940006f35eb6c0b445bd2f38ed102336f78617542d832d52336bb3b0be44b0', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/inputs.json': '340ed65c097b5f6bcb751f6f32bc19314154c32933121ce635ce1cf16cd36212', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/mapped.v': 'b1557c027795810779995e60032c3493fcb53d3f194a2cce76e516bad01d8e23', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/reparse.log': 'a2f13097e5970e2cfa0d83907807b73fc038074e83da613aebc7a80c348e3dad', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/reparse.ys': '80dce93b9c48603bcd00c35f51145177a58567aa1f83d1009313fcb9ffa06560', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/reparsed.json': 'dca75effeb69eccf2c406ba7436c607b82af36558465bfb491f2fa61fb416ce3', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/result.json': '861ccfa472deb1e08057fa57bec36fe245bd4ebfdcf51f13767fb7c06bc19d8f', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/serialize.log': '1fcb4312a6f8bb12e45ac0a431dc65a5f009ab5dcdd871b13b01bfdd6eea51c6', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/serialize.ys': '2a55ea6793e3c8ad822f1298c8b91771fcee8b3638a0e749a3204e4f74e2f27b', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/split.json': 'f391cf3a7185582c19ca11750c25124dceae0c09aa7190884df90e85c6fc2283', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/splitnets-help.log': '4afc8c69c6dd5aa46ad34a38db6c0a8a45471c2e75ee627129b90bc14eab5dfd', '/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main/serialization-01/timing.tcl': '76da63506203f149af24309b5af4cd5af27e7ef4f73bdb2a32f923be5d08ab76'}


def need(ok, message):
    if not ok: raise ValueError(message)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value): Path(path).write_text(json.dumps(value, indent=2)+'\n')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec);sys.modules[name] = obj;spec.loader.exec_module(obj)
    return obj


def object_sha(obj): return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()


def main(execute):
    need(sys.dont_write_bytecode, 'invoke with -B')
    overall_started = time.monotonic()
    deadline = overall_started+60 if execute else None
    os.sched_setaffinity(0, {3});os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(not OUT.exists() and not OUT.is_symlink(), 'fresh continuation output')
    pins = dict(EXPECTED)
    for path, h in pins.items(): need(sha(path) == h, 'fixed closed input changed: '+path)
    old_inputs = json.loads((SERIAL/'inputs.json').read_bytes())
    for section in ('originals', 'generated'):
        for path, h in old_inputs[section].items():
            need(path not in pins or pins[path] == h, 'inconsistent inherited pin')
            pins[path] = h
    for path in (Path(__file__).resolve(), Path(__file__).resolve().with_name('STA_RESUME_CONTRACT.md')):
        pins[str(path)] = sha(path)
    for path, h in pins.items(): need(sha(path) == h, 'inherited input changed: '+path)
    need(pins[str(PREFIX/'source-snapshot/process_helper.py')] == 'db8fc437041c9b3580126ef8498085212313510ce96eb483f21a8c04e17479b3', 'fixed process helper')
    need(pins[str(PREFIX/'source-snapshot/cost_helpers.py')] == 'bee29ddcfb0b1b6281dd8e05637bd9a032587a7b5ec18abaf85e08dda26be209', 'fixed cost helper')
    exact = module(CONTROLLER, 'existing_strict_fa_circuit')
    util = module(PREFIX/'source-snapshot/process_helper.py', 'fa_resume_process')
    helper = module(PREFIX/'source-snapshot/cost_helpers.py', 'fa_resume_cost')
    prior = json.loads((OLD/'result.json').read_bytes())
    serial = json.loads((SERIAL/'result.json').read_bytes())
    need(prior['status'] == 'FAILED' and prior['error'] == "ValueError('incomplete STA')", 'original failure preserved')
    need(serial['status'] == 'FAILED' and serial['error'] == "ValueError('serialized Verilog changed complete circuit graph')", 'serialization failure preserved')
    need(len(prior['commands']) == 2 and [c['label'] for c in serial['commands']] == ['splitnets-help', 'serialize', 'reparse'], 'closed exact prior commands')
    need(all(c['exit_code'] == 0 and c['reaped'] and c['group_absent'] for c in prior['commands']+serial['commands']), 'prior child closure')
    for pid in [31999, 32075]+[c['pid'] for c in prior['commands']+serial['commands']]:
        need(not util.group_exists(pid), 'prior group remains')
    need(serial['commands'][1]['argv'] == ['/usr/bin/yosys', '-T', '-s', str(SERIAL/'serialize.ys')]
         and serial['commands'][2]['argv'] == ['/usr/bin/yosys', '-T', '-s', str(SERIAL/'reparse.ys')], 'actual serialized readback lineage')
    original = json.loads((OLD/'mapped.json').read_bytes())['modules']['CommonFuCostTop']
    split = json.loads((SERIAL/'split.json').read_bytes())['modules']['CommonFuCostTop']
    reparsed = json.loads((SERIAL/'reparsed.json').read_bytes())['modules']['CommonFuCostTop']
    graph = exact.circuit(original)
    need(exact.circuit(split) == graph, 'unmodified strict split graph')
    mapping = {n: ('\\'+n if n.startswith('$') else n) for n in original['cells']}
    need(len(mapping) == 6150 and len(set(mapping.values())) == len(mapping)
         and set(mapping.values()) == set(reparsed['cells']), 'complete collision-free cell-name bijection')
    inverse = {v:k for k,v in mapping.items()}
    renamed = dict(reparsed);renamed['cells'] = {inverse[k]:v for k,v in reparsed['cells'].items()}
    need(exact.circuit(renamed) == graph, 'same strict complete graph after explicit inverse names')
    need(object_sha(graph) == '4bf4c350e4a464e4e875a4f32cb9b7e44f207f80b62bfe3fd0519de24ba32acd', 'independently reviewed graph identity')
    need(object_sha(sorted(mapping.items())) == '9d8441a6457bb230eee9404f9c131e0c906aae00738ac2bb53d6ef49c04c41d7', 'independently reviewed full mapping identity')
    changed = sum(k != v for k,v in mapping.items());need(changed == 5196, 'exact changed names')
    mapped = (SERIAL/'mapped.v').read_bytes()
    need(not re.search(rb'(?m)^\s*assign\s*\{', mapped), 'concat LHS remains')
    oldsta = (OLD/'timing.tcl').read_bytes().decode()
    need(oldsta.count(str(OLD)) == 7, 'one netlist and six report path substitutions')
    sta = oldsta.replace(str(OLD), str(OUT))
    need(sta.replace(str(OUT), str(OLD)) == oldsta, 'original complete STA constraints path-only inverse')
    graph_audit = dict(status='EXACT_TERMINAL_GRAPH_MATCH_UNDER_EXPLICIT_CELL_NAME_BIJECTION',
        original_json_sha256=sha(OLD/'mapped.json'), split_json_sha256=sha(SERIAL/'split.json'),
        reparsed_json_sha256=sha(SERIAL/'reparsed.json'), actual_mapped_verilog_sha256=sha(SERIAL/'mapped.v'),
        original_graph_sha256=object_sha(graph), raw_reparsed_graph_sha256=object_sha(exact.circuit(reparsed)),
        inverse_renamed_graph_sha256=object_sha(exact.circuit(renamed)), mapping_sha256=object_sha(sorted(mapping.items())),
        rule='Only an original dollar-prefixed cell name receives one leading literal backslash; every other cell name is unchanged.',
        complete_bijection=True, changed_cell_names=changed, unchanged_cell_names=6150-changed,
        ports=len(graph['ports']), cells=len(graph['cells']), nets=len(graph['nets']),
        terminal_count=sum(len(n['terminals']) for n in graph['nets']),
        compared='Original circuit() unchanged: cell types/parameters/all pins, port direction/width/offset/upto/signed, full endpoint graph and constants; no init attributes.',
        rtl_to_mapped_equivalence_claimed=False)
    counts = Counter(c['type'] for c in reparsed['cells'].values());areas = helper.library_areas(LIB)
    need(not set(counts)-set(areas), 'unmapped cell')
    area = sum(areas[k]*v for k,v in counts.items())
    need(counts['FA_X1'] == 954 and sum(v for k,v in counts.items() if k.startswith('DFF')) == 1678, 'same actual FA and register counts')
    baseline = prior['baseline_cost']
    ports = {n:dict(direction=p['direction'], width=len(p['bits']), offset=p.get('offset', 0)) for n,p in reparsed['ports'].items()}
    need(ports == baseline['ports'], 'complete original boundary')
    if not execute:
        print(json.dumps(dict(status='PLAN_ONLY', contract=CONTRACT, output=str(OUT), original_pins=pins,
            sta_script=sta, graph_audit=graph_audit, cell_area=area, cell_count=sum(counts.values()),
            cpu_affinity=[3], nice=5, budget_seconds=60, sta_seconds=30,
            new_yosys_runs=0, new_mapping_runs=0, new_fu_runs=0, new_core_runs=0), indent=2));return
    need(time.monotonic() < deadline, 'total budget including preflight')
    OUT.mkdir();(OUT/'tmp').mkdir();snap = OUT/'source-snapshot';snap.mkdir()
    for name in ('fa_sta_resume.py', 'STA_RESUME_CONTRACT.md'):
        (snap/name).write_bytes(Path(__file__).with_name(name).read_bytes())
    (OUT/'mapped.v').write_bytes(mapped);(OUT/'timing.tcl').write_text(sta)
    generated = {str(p):sha(p) for p in [*snap.iterdir(), OUT/'mapped.v', OUT/'timing.tcl']}
    need(sha(OUT/'mapped.v') == pins[str(SERIAL/'mapped.v')], 'identical existing mapped Verilog copy')
    save(OUT/'inputs.json', dict(originals=pins, generated=generated));save(OUT/'graph-audit.json', graph_audit)
    result = dict(contract=CONTRACT, status='RUNNING', started=util.stamp(), prior_statuses_preserved=['FAILED','FAILED'],
        cpu_affinity=[3], nice=5, budget_seconds=60, commands=[], new_yosys_runs=0, new_mapping_runs=0,
        new_fu_runs=0, new_core_runs=0, mapped_netlist_equivalence_tested=False,
        application_performance_qualified=False, core_cost_qualified=False, production_default_changed=False)
    save(OUT/'result.json', result);pending = [None]
    def interrupted(sig, frame): pending[0] = sig
    handlers = {sig:signal.signal(sig, interrupted) for sig in (signal.SIGTERM, signal.SIGINT)}
    def check():
        if pending[0] is not None: raise InterruptedError(str(pending[0]))
        need(time.monotonic() < deadline, 'total budget')
    env = dict(PATH='/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(OUT/'tmp'),
        OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    def command(label, argv, limit):
        check();row = dict(label=label, argv=list(map(str, argv)), started=util.stamp(), budget_seconds=min(limit, deadline-time.monotonic()))
        result['commands'].append(row);proc = None
        until = min(deadline, time.monotonic()+row['budget_seconds'])
        try:
            with (OUT/(label+'.log')).open('wb') as log:
                proc = subprocess.Popen(row['argv'], cwd=OUT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                row['pid'] = proc.pid;save(OUT/'result.json', result)
                while proc.poll() is None:
                    check();left = until-time.monotonic()
                    if left <= 0: raise subprocess.TimeoutExpired(row['argv'], row['budget_seconds'])
                    try: proc.wait(timeout=min(.25, left))
                    except subprocess.TimeoutExpired: pass
                row['exit_code'] = proc.returncode
            check();need(time.monotonic() <= until and proc.returncode == 0, label+' failed or exceeded budget')
            need(not util.group_exists(proc.pid), label+' remaining group')
        finally:
            if proc is not None:
                if util.group_exists(proc.pid): row['cleanup_complete'] = util.stop_group(proc)
                row['reaped'] = proc.poll() is not None;row['group_absent'] = not util.group_exists(proc.pid)
            row['finished'] = util.stamp();save(OUT/'result.json', result)
        return (OUT/(label+'.log')).read_text(errors='replace')
    try:
        log = command('sta', ['/usr/bin/sta', '-no_init', '-exit', OUT/'timing.tcl'], 30)
        need(not re.search(r'(?m)^.*\bError:', log) and 'not found' not in log
             and log.splitlines().count('DOT16_GENERATED_FU_STA_COMPLETE') == 1, 'complete error-free actual STA')
        paths = {n:helper.parse_path((OUT/(n+'.rpt')).read_text()) for n in ('r2r','i2r','r2o','i2o','ready')}
        need(all(p['exists'] for p in paths.values()), 'all five path classes')
        constants = helper.constant_warnings((OUT/'setup-checks.rpt').read_text(), reparsed)
        for p,h in {**pins, **generated}.items(): check();need(sha(p) == h, 'input changed: '+p)
        result.update(status='PREFIX_FA_BIJECTION_STA_COMPLETE', terminal_graph_preserved_under_explicit_bijection=True,
            graph_audit=graph_audit, cell_area=area, cell_count=sum(counts.values()), cell_histogram=dict(sorted(counts.items())),
            dff_cells=1678, ports=ports, timing=paths, reviewed_constant_endpoints=constants,
            nominal_setup_met=all(p['slack_ns'] >= 0 for p in paths.values()),
            delta_from_D1000=dict(cell_area=area-baseline['cell_area'], timing={n:{k:paths[n][k]-baseline['timing'][n][k] for k in ('arrival_ns','slack_ns')} for n in paths}),
            mapped_sha256=sha(OUT/'mapped.v'), inputs_unchanged=True,
            all_children_reaped=all(c['reaped'] and c['group_absent'] for c in result['commands']))
        check()
    except BaseException as exc:
        result.update(status='FAILED', error=repr(exc));raise
    finally:
        changed_inputs = []
        for p,h in {**pins, **generated}.items():
            try:
                if sha(p) != h: changed_inputs.append(p)
            except OSError: changed_inputs.append(p)
        result['changed_inputs'] = changed_inputs;result['inputs_unchanged'] = not changed_inputs
        if changed_inputs: result.update(status='FAILED', error='input changed or unreadable after STA')
        result['elapsed_seconds'] = time.monotonic()-overall_started
        result['total_budget_exceeded'] = time.monotonic() >= deadline
        if result['total_budget_exceeded']: result.update(status='FAILED', error='total budget including final input verification')
        if pending[0] is not None: result.update(status='FAILED', error='latched signal '+str(pending[0]))
        result['finished'] = util.stamp();save(OUT/'result.json', result)
        for sig,h in handlers.items(): signal.signal(sig,h)
    if time.monotonic() >= deadline:
        result.update(status='FAILED', total_budget_exceeded=True, error='total budget after final result persistence')
        save(OUT/'result.json', result)
    need(result['status'] == 'PREFIX_FA_BIJECTION_STA_COMPLETE', 'final input, cleanup or budget failure')
    print(json.dumps({k:v for k,v in result.items() if k not in ('ports','cell_histogram')}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute', action='store_true')
    main(parser.parse_args().execute)
