# 原 prefix feature1 的 FA_X1 单点映射对照

合同：`dot16-prefix-feature1-fa-x1-v1`。本次只回答一个问题：在已冻结 prefix 的同一 FUCommon 成本边界和约束下，将 carry-save 模块中的原完整全加器式显式映射到 Nangate45 FA_X1，能否改善实际面积或关键输入路径。原 D1000 是冻结对照；不扫描排列、目标频率、驱动强度或其他库单元。

## 规格与改动

原 feature1 的四件生成 SV、结果、完整产物 pin、工具及库逐项核 SHA。原 CSA 为108563 B / `68227036423ff34235b275546dc7d2341fb5e890857e1b9098f4bc070f9545f6`。只派生这一件映射输入 SV；原文件不改，其余三个 RTL 输入逐字节沿用。原477对 FA 的三个输入按原 XOR 书写顺序接 A、B、CI；原 sum 接 S、carry 接 CO。17个 HA、全部部分积、补偿常量、结果位、声明及其余字节保持，完整反替换必须恢复原 SHA。两路 products/highProducts 展开预期为954个 FA_X1。

时钟、复位、事务接口、流水级和数据位宽均不改。原 prefix 合同约定上升沿 E0 接收、E1 P→R、E2 最早响应、无阻塞 II=1；P/R 两槽、同步高有效 valid reset，数据/metadata不新增复位。架构输入/输出128位，低/高64位各8个signed8乘积；每半区P保存两行19位，feature1结果状态20位。该约定来自原候选，不把此次映射筛查写成新增整核或周期资格。

## 功能依据与真实绑定

复用现有严格 CSA 解析器解析整个原模块，核其512部分积、477 FA、17 HA、补偿和完整无环连接；它证明的二值算术域为全部2^128输入。读取原完整库，固定SHA `8d540a4d4cf6d09d27c87ad067857a9c0c2eeb023ab7a56e058cd3113db4e9b1`，提取唯一完整FA_X1 cell（88961 B / `375af4ef4d5ebea75126fe0180c84007c5bb3645c3f8da4a18bb8d72a223439b`）。完整解析实际CO/S布尔式和五个命名信号端口；对477对原式分别核八种输入与实际库函数一致，并逐字节反还原。常量1若出现仍按独立局部输入枚举，实际常量是其子集。

综合只 `read_liberty -lib` 加真实库叶单元，不能载入功能模型将FA再次展开。实际mapped.json须有954个FA_X1、两个完整CSA实例集合；全部4770个引脚连接与同实例原信号一一对应，每个CO/S互异且都被使用。记录DFF数、全接口与实际cell histogram；DFF须仍为1678，完整220端口/2888位与冻结基线相符。

以上是局部二值替换等价及实际映射绑定检查，不声称四态X/Z等价或完整映射网表等价；`mapped_netlist_equivalence_tested=false`。旧乘法SAT的UNKNOWN不改写；原FU/父级/六例core结果不转授到本映射网表。

## 公平成本条件及执行边界

Yosys0.9、ABC、OpenSTA、Nangate45 TT 1.1V/25C的原固定SHA和原完整map/STA脚本均核对。map脚本仅换一件CSA输入和输出位置；ABC仍D1000，BUF_X1驱动与5fF输出载荷不变。STA仍1ns、0.05ns uncertainty/transition、0.1ns输入/输出delay及原wire-load-model，完整逆替换应恢复原脚本。五类R2R/I2R/R2O/I2O/ready全部报告；库面积只用library area units，不推定μm²。FA必须由同一真实Liberty参与面积和STA，不允许零延迟黑盒估计。

默认仅plan-only。显式execute才在独立native `runs/dot16-prefix-fa-20261108-main/local-01`执行一次映射和一次STA；CPU2单核nice5，map≤300s、STA≤60s、总≤420s，外层额外有限清理。每个子进程独立进程组，失败/信号/超时均回收并保存原失败；不重跑或自动加时。所有冻结输入及派生输入前后核SHA。无Chisel生成、FU、EMU、Git变更或生产默认切换。

若没有足以支持后续工作的实际I2R/面积收益，停止本分支；不能用理论门数、局部cell延迟、寄存器间单一路径或综合面积代替应用加速、完整PPA、P&R或功耗结论。
