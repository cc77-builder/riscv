#!/usr/bin/env python3
"""Finite cloud metadata/static checks; no main, scan, ZIP, PC or checker."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
HELPER = ROOT / 'verification/archive_prefix_parent.py'
BASE = ROOT / 'verification/archive_packed_target.py'
DATA = ROOT / 'verification/prefix-parent-closed-01'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    raw = HELPER.read_bytes(); source = raw.decode(); tree = ast.parse(source)
    original = BASE.read_text(); old_tree = ast.parse(original)
    assert digest(BASE.read_bytes()) == 'b8ae9a93334fffbd1978f39c00c96190e8212c420313f5b04721d906538d85cc'
    spec = importlib.util.spec_from_file_location('prefix_parent_archive_static_review', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    read = lambda name: json.loads((DATA / name).read_bytes())
    census = read('archive-census.json'); records = {r['name']: r for r in census['records']}
    observed, census_only = {}, {}
    for name, (size, pin) in helper.FIXED_PARENT.items():
        path = DATA / name
        if path.exists():
            data = path.read_bytes(); observed[name] = dict(bytes=len(data), sha256=digest(data))
            assert observed[name] == dict(bytes=size, sha256=pin), name
        else:
            assert (records[name]['bytes'], records[name]['sha256']) == (size, pin), name
            census_only[name] = dict(bytes=size, sha256=pin, raw_cloud_bytes_available=False)
    for name, (size, pin) in helper.FIXED_ARCHIVE_SOURCE.items():
        data = (DATA / name).read_bytes(); observed['archive-source/' + name] = dict(bytes=len(data), sha256=digest(data))
        assert observed['archive-source/' + name] == dict(bytes=size, sha256=pin), name
    features = {f: {name: read(f'feature{f}/{name}') for name in
        ('generated-files.json', 'additional-coverage.json', 'metadata-audit.json', 'generation-boundary.json')}
        for f in (0, 1)}
    inputs = [read('result.json'), read('inputs.json'), read('final-artifact-pins.json'), census,
              read('host-receipt.json'), features]

    def check(args):
        return helper.evidence_metadata(helper.RUNS, helper.SOURCES, *args)

    pins, sizes, groups, external, directories, evidence = check(inputs)
    assert len(pins) == 214 and len(sizes) == 231 and len(external) == 890 and len(directories) == 5
    assert {k: len(v) for k, v in groups.items()} == dict(fixed_parent_records=16, fixed_captures=2,
        archived_original_inputs=3, snapshots=22, final_artifacts=177, generated_files=116,
        coverage_raw_logs=4, metadata_raw_logs=4)
    roots = helper.input_roots(helper.RUNS, helper.SOURCES)
    assert len(roots) == len(set(roots.values())) == 3
    assert roots['windows/archive-parent-source-01'] != helper.SOURCES / 'archive-source-01'
    assert all(Path(p).is_relative_to(helper.RUNS / 'parent-01') for p in inputs[2])
    assert all(Path(p) in pins for p in inputs[1]['snapshots'])
    assert [e['binary_sha256'] for e in evidence['features']] == [
        'f655b8541f3c556548149534999ffbf43423e38232ea75f03d8c161ceb732d4c',
        '366064aaa01148d2c7f4139af1750ccd07a9009217013cf33a568d8efe6375d8']
    assert evidence['original_exit_histogram'] == {'0': 56, '1': 40}
    assert len(observed) == 14 and len(census_only) == 4

    negative_results = []
    for label in ('unreaped-command', 'binary-pin-mismatch', 'source-snapshot-mismatch',
                  'generated-path-escape', 'false-fullcore-qualification', 'unknown-multiplication-promoted'):
        bad = copy.deepcopy(inputs)
        if label == 'unreaped-command':
            bad[0]['commands'][0]['reaped'] = False
        elif label == 'binary-pin-mismatch':
            path = str(helper.RUNS / 'parent-01/feature1/obj' / helper.BINARY)
            bad[2][path] = '0' * 64
        elif label == 'source-snapshot-mismatch':
            path = str(helper.RUNS / 'parent-01/source-snapshot/parent_binding.py')
            bad[1]['snapshots'][path] = '0' * 64
        elif label == 'generated-path-escape':
            bad[5][0]['generated-files.json'][0]['path'] = '../external.sv'
        elif label == 'false-fullcore-qualification':
            bad[0]['fullcore_qualified'] = True
        elif label == 'unknown-multiplication-promoted':
            bad[0]['upstream_multiplication_miter_status'] = 'PASS'
        try:
            check(bad)
        except ValueError as error:
            negative_results.append(dict(case=label, status='REJECTED', reason=str(error)))
        else:
            raise AssertionError('negative was not rejected: ' + label)

    helpers = {}
    for name in ('need', 'stamp', 'stream_sha', 'sha', 'read', 'encoded', 'scan'):
        new_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        old_node = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        new = ast.get_source_segment(source, new_node); old = ast.get_source_segment(original, old_node)
        assert new == old, name
        helpers[name] = digest(new.encode())
    start, end = '        raw_manifest = encoded(manifest)\n', '        audit = dict(status='
    transport = source[source.index(start):source.index(end)]
    assert transport == original[original.index(start):original.index(end)]
    start, end = '    started, deadline = stamp(), time.monotonic() + ', '        signal.setitimer(signal.ITIMER_REAL, '
    timer = source[source.index(start):source.index(end) + len(end) + len('600)\n')]
    old_timer = original[original.index(start):original.index(end) + len(end) + len('300)\n')]
    assert timer == old_timer.replace('300', '600')
    start, end = '    except BaseException as error:\n', "\n\nif __name__ == '__main__':"
    assert source[source.index(start):source.index(end)] == original[original.index(start):original.index(end)]
    imports = {alias.name for n in tree.body if isinstance(n, ast.Import) for alias in n.names}
    assert 'subprocess' not in imports and 'importlib' not in imports
    report = dict(status='STATIC_AND_CLOSED_METADATA_CHECK_PASS', helper_bytes=len(raw), helper_sha256=digest(raw),
        actual_cloud_records=observed, identities_only_from_original_census=census_only,
        fixed_input_roots=3, local_pins=len(pins), original_spans=len(sizes), external_original_dependencies=len(external),
        recorded_pin_counts={k: len(v) for k, v in groups.items()}, source_evidence=evidence,
        negative_controls=negative_results, unchanged_helpers=helpers,
        unchanged_zip_readback_after_sha256=digest(transport.encode()),
        timer_only_budget_change='300 to 600 seconds, parent-approved', failure_tail_unchanged=True,
        archive_main_called=False, scan_called=False, zip_created=False, native_pc_accessed=False,
        original_checker_rerun=False, new_guest_runs=0, new_builds=0, new_eda_runs=0,
        scope='Cloud records and source comparison only; actual full-tree hashes/ZIP/after-scan remain unexecuted.')
    (OUT / 'selfcheck.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'helper_bytes', 'helper_sha256', 'local_pins',
        'original_spans', 'external_original_dependencies', 'zip_created')}, indent=2))


if __name__ == '__main__':
    main()
