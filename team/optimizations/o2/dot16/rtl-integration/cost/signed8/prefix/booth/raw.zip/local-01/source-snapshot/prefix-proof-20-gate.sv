module Gate(input wire [19:0] a0, input wire [19:0] a1, input wire [19:0] a2, input wire [19:0] a3, output wire [19:0] result);
VDotPrefixFinish20 actual(.rows_0(a0), .rows_1(a1), .rows_2(a2), .rows_3(a3), .result(result));
endmodule
