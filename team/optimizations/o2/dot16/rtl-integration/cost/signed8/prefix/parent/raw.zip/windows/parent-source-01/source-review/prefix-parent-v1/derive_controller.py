"""Derive the finite prefix-parent controller from the closed signed8-parent v3."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'inline-parent-candidate-v3/inline_parent.py'
BASE_SHA = '29e72bff3d508eb9a88cdb5cf95e1eed7ad1a7be9cb8f84c41588c8790e3942d'
raw = BASE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == BASE_SHA
original = raw.decode()
text = original
edits = []


def change(old, new, count=1):
    global text
    assert text.count(old) == count, (old[:100], text.count(old), count)
    text = text.replace(old, new)
    edits.append({'old': old, 'new': new, 'count': count})


change('already-qualified signed8 overlay', 'already-qualified prefix overlay')
change('completed local-03.', 'completed prefix local-01.')
change("CONTRACT = 'dot16-inline-signed8-real-parent-v3'", "CONTRACT = 'dot16-prefix-real-parent-v1'")
change("LOCAL_CONTRACT = 'dot16-inline-signed8-local-v3'", "LOCAL_CONTRACT = 'dot16-csa-prefix-local-v1'")
change("LOCAL_INPUTS_SHA = '9d57548b34dd3baad89e9c8600742fa6e1b585219cad83f0965f5311502a2e22'",
       "LOCAL_INPUTS_SHA = '1afacb22c143705355ffed93b62824b2a02153e799b003bcc7f92dba1b10c219'")
change("OVERLAY_SHA = '83844b0a2fd203a87f2d08c92fe7251a7c655469524290196ad0ec5a04fdaa77'",
       "OVERLAY_SHA = 'f36dd44ef66c0058a73839bfeaacd321cc6ac7d41144c622c38371948375c4bf'")
change("CANDIDATE_SHA = '50522c0cd2700f7f852872049533bc31f79ce811ad2ed53da2c1d333cece45e2'",
       "CANDIDATE_SHA = '1d02d8a34772e7d9b9947f997f32465f3e946f4b24cacc66159eef7ee10ab3bb'\n"
       "WRAPPER_SHA = '912c1a038ef8e9a1ac56cfa349161ae1c582d763acfce5352b08ebde2a227f92'\n"
       "LOCAL_RESULT_SHA = 'a0c4dd60fddc001f368b71ec283327f2d7fe0874080ac35304e3debe783116d0'\n"
       "BINDING_SHA = '"+hashlib.sha256((HERE/'parent_binding.py').read_bytes()).hexdigest()+"'")
change("PRODUCT_SHA = '408856505a97565531f567d25840ed4d02ec54b5d53b8b2bbb01e00dab9406a5'\n"
       "INLINE_SHA = '98f3972c5d5fe0d638cf7ac45940e1556138e14877dbc2a5817b48f0c2682c5a'",
       "CSA_RTL_SHA = '68227036423ff34235b275546dc7d2341fb5e890857e1b9098f4bc070f9545f6'\n"
       "PREFIX_RTL_SHA = {0: '8cbaa598a2d7887b31b616b36894a4769b3e60de627f31972d34840f7c712f3d',\n"
       "                  1: '3ce276e8ea48a36ebbb77e6251d1607c39cc6e7a7b988a38e5cb9a563f4afe5a'}")
begin = text.index('PRODUCT_PRINTF_HEADER = (')
end = text.index('LOG_OBJECT_MESSAGES = (', begin)
change(text[begin:end], '')
begin = text.index('def compare_parent_products(')
end = text.index('def compare_log_object_labels(', begin)
change(text[begin:end], '')
change("need(re.fullmatch(r'[0-9a-f]{64}', a.local_result_sha256) is not None,\n"
       "         'reviewed complete local-03 result SHA required')",
       "need(a.local_result_sha256 == LOCAL_RESULT_SHA,\n"
       "         'reviewed exact completed prefix result SHA required')")
change("upstream['status'] == 'INLINE_SIGNED8_GENERATED_EQUIVALENT_FU_AND_COST_COMPLETE'",
       "upstream['status'] == 'PREFIX_GENERATED_ARITHMETIC_FU_AND_COST_COMPLETE'")
change("'applicable completed local-03'", "'applicable completed prefix local-01'")
change("'all_children_reaped')) and upstream['candidate_source_sha256'] == CANDIDATE_SHA,\n"
       "             'complete upstream source/equivalence/FU identity')",
       "'all_children_reaped')) and upstream['candidate_source_sha256'] == CANDIDATE_SHA\n"
       "             and upstream['candidate_wrapper_sha256'] == WRAPPER_SHA,\n"
       "             'complete upstream source/wrapper/arithmetic/FU identity')\n"
       "        need(len(upstream['prefix_miters']) == 2 and\n"
       "             {(x['feature'], x['width'], x['row_count']) for x in upstream['prefix_miters']}\n"
       "             == {(0, 19, 2), (1, 20, 4)} and all(x['status'] == 'PASS'\n"
       "             and x['solver_equivalence_proved'] is True for x in upstream['prefix_miters']),\n"
       "             'both actual prefix modular-sum proofs completed')\n"
       "        need(len(upstream['fu_results']) == 2 and\n"
       "             {x['feature'] for x in upstream['fu_results']} == {0, 1}\n"
       "             and all(x['passed'] is True for x in upstream['fu_results']),\n"
       "             'both original prefix FU campaigns completed')")
change("need(overlay.is_dir() and overlay_pins, 'complete original candidate class directory')",
       "need(overlay.is_dir() and len(overlay_pins) == 23, 'complete23 prefix overlay classes')")
change("        reference_rtl = local/'fu-feature1/rtl'\n"
       "        pin(reference_rtl/'VDotProducts.sv', PRODUCT_SHA)\n"
       "        pin(reference_rtl/'VDotSignedByteProduct.sv', INLINE_SHA)",
       "        pin(local/'source-snapshot/VDotDatapath.scala', CANDIDATE_SHA)\n"
       "        pin(local/'source-snapshot/VDotElastic.scala', WRAPPER_SHA)\n"
       "        reference_rtl = {}\n"
       "        for feature in (0, 1):\n"
       "            rows = [x for x in upstream['generated'] if x['feature'] == feature and x['kind'] == 'cost']\n"
       "            need(len(rows) == 1, 'one completed local cost generation per feature')\n"
       "            root = local/f'cost-feature{feature}/rtl'\n"
       "            names = {Path(x['path']).name for x in rows[0]['files']}\n"
       "            need(names == {'CommonFuCostTop.sv', 'VDotElastic.sv', 'VDotCarrySaveRows.sv',\n"
       "                          f'VDotPrefixFinish{20 if feature else 19}.sv', 'extern_modules.sv'},\n"
       "                 'exact frozen prefix local generation closure')\n"
       "            for record in rows[0]['files']:\n"
       "                path = local/record['path']\n"
       "                need(path.resolve().is_relative_to(root), 'local reference remains inside its RTL root')\n"
       "                pin(path, record['sha256'])\n"
       "                need(path.stat().st_size == record['bytes'], 'local reference byte count')\n"
       "            pin(root/'VDotCarrySaveRows.sv', CSA_RTL_SHA)\n"
       "            pin(root/f'VDotPrefixFinish{20 if feature else 19}.sv', PREFIX_RTL_SHA[feature])\n"
       "            reference_rtl[feature] = root")
change("'signed8_parent_process'", "'prefix_parent_process'")
change("'signed8_parent_classpath'", "'prefix_parent_classpath'")
change("        snapshot(Path(__file__).resolve(), snap/'inline_parent.py')\n"
       "        snapshot(here/'PARENT_CONTRACT.md', snap/'PARENT_CONTRACT.md')",
       "        snapshot(Path(__file__).resolve(), snap/'prefix_parent.py')\n"
       "        snapshot(here/'PARENT_CONTRACT.md', snap/'PARENT_CONTRACT.md')\n"
       "        binding_path = pin(here/'parent_binding.py', BINDING_SHA)\n"
       "        binding = load_module(snapshot(binding_path, snap/'parent_binding.py'), 'prefix_parent_binding')")
change("'signed8_parent_negative_interface'", "'prefix_parent_negative_interface'")
change("'signed8_parent_original_deriver'", "'prefix_parent_original_deriver'")
change("'same local-03 Verilator support'", "'same prefix-local Verilator support'")
change("'tool already bound by local-03: '", "'tool already bound by prefix-local: '")
change("result.update(status='RUNNING', upstream_local03=str(local),\n"
       "                      upstream_result_sha256=a.local_result_sha256, candidate_source_sha256=CANDIDATE_SHA)",
       "result.update(status='RUNNING', upstream_prefix_local=str(local),\n"
       "                      upstream_result_sha256=a.local_result_sha256, candidate_source_sha256=CANDIDATE_SHA,\n"
       "                      candidate_wrapper_sha256=WRAPPER_SHA,\n"
       "                      upstream_multiplication_miter_status=upstream['independent_miter']['status'])")
begin = text.index("            need(new_names == old_names | {'VDotSignedByteProduct.sv'}")
end = text.index("            generated_pins[str(boundary_report)]", begin)
replacement = '''            removed_modules = {'VDotProducts.sv', 'VDotReduce.sv'}
            new_modules = {'VDotCarrySaveRows.sv', f'VDotPrefixFinish{20 if feature else 19}.sv'}
            need(removed_modules <= old_names and not new_modules & old_names,
                 'original parent arithmetic closure matches the declared replacement')
            need(new_names == (old_names-removed_modules) | new_modules,
                 'real parent closure replaces only Products/Reduce with CSA/prefix')
            boundary_records = []
            for name in sorted(old_names-removed_modules):
                new_path, old_path = rtl/name, old['rtl']/name
                if name == 'VDotElastic.sv':
                    record = binding.verify_parent_wrapper(new_path.read_bytes(), old_path.read_bytes(), feature)
                    record.update(file=name, reference_file=str(old_path))
                    boundary_records.append(record)
                elif name == 'LogPerfEndpoint.sv':
                    record = compare_log_object_labels(new_path.read_bytes(), old_path.read_bytes())
                    record.update(file=name, reference_file=str(old_path))
                    boundary_records.append(record)
                elif name == 'extern_modules.sv':
                    raw = new_path.read_bytes()
                    for module_name in ('VDotCarrySaveRows', f'VDotPrefixFinish{20 if feature else 19}'):
                        marker = ('// external module '+module_name+'\\n\\n').encode()
                        need(raw.count(marker) == 1, 'one exact new external module comment')
                        raw = raw.replace(marker, b'', 1)
                    need(raw == old_path.read_bytes(), 'all existing external comments byte-exact')
                else:
                    need(new_path.read_bytes() == old_path.read_bytes(), 'unchanged parent/clock/DIV boundary '+name)
            for name in sorted(new_modules):
                actual_path, reference_path = rtl/name, reference_rtl[feature]/name
                need(actual_path.read_bytes() == reference_path.read_bytes(), 'same proved arithmetic RTL '+name)
                boundary_records.append(dict(file=name, actual_sha256=sha(actual_path),
                    reference_file=str(reference_path), reference_sha256=sha(reference_path), byte_exact=True))
            boundary_report = folder/'generation-boundary.json'
            save(boundary_report, dict(contract=CONTRACT, feature=feature,
                 comparisons=boundary_records, real_rtl_modified=False,
                 removed_modules=sorted(removed_modules), new_modules=sorted(new_modules),
                 changed_existing_modules=['VDotElastic.sv', 'LogPerfEndpoint.sv', 'extern_modules.sv'],
                 all_other_retained_sv_v_byte_exact=True))
'''
change(text[begin:end], replacement)
change("== resource_names | {'VDotSignedByteProduct.sv'} and set(resources).issubset(files),\n"
       "                 'complete unchanged real ClockGate resources plus signed8')",
       "== resource_names | new_modules and set(resources).issubset(files),\n"
       "                 'complete unchanged real ClockGate resources plus CSA/prefix')")
change("status='INLINE_SIGNED8_REAL_PARENT_PASS'", "status='PREFIX_REAL_PARENT_PASS'")

output = HERE/'prefix_parent.py'
output.write_text(text)
diff = ''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True),
                                 fromfile='inline-parent-v3/inline_parent.py', tofile='prefix-parent-v1/prefix_parent.py'))
(HERE/'source-derivation.diff').write_text(diff)
record = {'schema': 1, 'baseline_path': str(BASE), 'baseline_sha256': BASE_SHA,
          'candidate_file': output.name, 'candidate_bytes': len(output.read_bytes()),
          'candidate_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
          'binding_file': 'parent_binding.py',
          'binding_sha256': hashlib.sha256((HERE/'parent_binding.py').read_bytes()).hexdigest(),
          'deriver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'diff_file': 'source-derivation.diff', 'diff_sha256': hashlib.sha256(diff.encode()).hexdigest(),
          'edits': edits, 'official_and_original_checkers_changed': False,
          'candidate_datapath_or_wrapper_recompiled': False,
          'generation_or_parent_execution_performed': False}
(HERE/'source-derivation.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key: value for key, value in record.items() if key != 'edits'}, indent=2))
