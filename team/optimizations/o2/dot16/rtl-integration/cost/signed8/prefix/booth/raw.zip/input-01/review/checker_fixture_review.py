#!/usr/bin/env python3
"""Lightweight tests of verify_booth, using explicitly synthetic SV fixtures.

These are NOT Scala/Chisel-generated RTL and cannot qualify the candidate.
The production source/driver is not executed. Only the pure prove(raw) function
of the fixed checker is called; all generated artifacts stay in review/.
"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CHECKER = ROOT / 'controller/verify_booth.py'
CHECKER_SHA = 'b3044e637a5f312b71497de1eaa44503e27894cb7fd313ee389208a8fc351dc5'
LIMITS = (28, 19, 13, 9, 6, 4, 3, 2)
ONE, ZERO = "1'b1", "1'b0"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def synthetic_module(neg_policy='correct', omit_bias=False):
    """Independent Python fixture construction of the documented fixed heap."""
    declarations, equations = [], []
    heap = [[] for _ in range(20)]
    counts = Counter()

    def wire(name, value):
        declarations.append('wire ' + name + ';')
        equations.append('assign ' + name + ' = ' + value + ';')

    for lane in range(8):
        for group in range(4):
            low = ZERO if group == 0 else f'vs2[{8*lane+2*group-1}]'
            mid, high = f'vs2[{8*lane+2*group}]', f'vs2[{8*lane+2*group+1}]'
            one, two, neg = (f'{name}_{lane}_{group}' for name in ('one', 'two', 'neg'))
            wire(one, f'{low} ^ {mid}')
            wire(two, f'(~{high} & {mid} & {low}) | ({high} & ~{mid} & ~{low})')
            wire(neg, high)
            for bit in range(9):
                name = f'pp_{lane}_{group}_{bit}'
                a = f'vs1[{8*lane+min(bit,7)}]'
                doubled = ZERO if bit == 0 else f'vs1[{8*lane+bit-1}]'
                selected = f'(({one} & {a}) | ({two} & {doubled})) ^ {neg}'
                wire(name, f'~({selected})' if bit == 8 else selected)
                heap[2*group+bit].append(name)
            weight = 2*group
            if lane == 0 and group == 0:
                if neg_policy == 'omitted':
                    continue
                if neg_policy == 'shifted':
                    weight += 1
            heap[weight].append(neg)
    for weight in (18, 16, 14, 12, 11):
        if not (omit_bias and weight == 18):
            heap[weight].append(ONE)
    for layer, limit in enumerate(LIMITS):
        following = [[] for _ in range(20)]
        for weight, before in enumerate(heap):
            remaining = list(before)
            serial = 0
            while len(remaining) + len(following[weight]) > limit:
                excess = len(remaining) + len(following[weight]) - limit
                size = 3 if excess >= 2 else 2
                assert len(remaining) >= size
                picked, remaining = remaining[:size], remaining[size:]
                s, c = f's_{layer}_{weight}_{serial}', f'c_{layer}_{weight}_{serial}'
                x, y = picked[:2]
                if size == 3:
                    z = picked[2]
                    wire(s, f'{x} ^ {y} ^ {z}')
                    wire(c, f'({x} & {y}) | (({x} ^ {y}) & {z})')
                    counts['FA'] += 1
                else:
                    wire(s, f'{x} ^ {y}')
                    wire(c, f'{x} & {y}')
                    counts['HA'] += 1
                following[weight].append(s)
                if weight < 19:
                    following[weight+1].append(c)
                serial += 1
            following[weight].extend(remaining)
            assert len(following[weight]) <= limit
        heap = following
    assert all(len(bits) <= 2 for bits in heap)
    rows = []
    for row in range(2):
        terms = [bits[row] if row < len(bits) else ZERO for bits in reversed(heap)]
        rows.append(f'assign row{row} = ' + '{' + ', '.join(terms) + '};')
    text = '\n'.join([
        'module VDotCarrySaveRows(',
        'input wire [63:0] vs1, input wire [63:0] vs2,',
        'output wire [19:0] row0, output wire [19:0] row1',
        ');', *declarations, *equations, *rows, 'endmodule', ''])
    return text.encode('ascii'), dict(counts)


def replace_once(raw, before, after):
    assert raw.count(before) == 1, before
    return raw.replace(before, after, 1)


def signed20(x):
    x &= (1 << 20) - 1
    return x if x < (1 << 19) else x - (1 << 20)


def main():
    raw_checker = CHECKER.read_bytes()
    assert sha(raw_checker) == CHECKER_SHA
    api = runpy.run_path(str(CHECKER), run_name='booth_checker_review_only')
    prove, invalid = api['prove'], api['Invalid']
    folder = HERE / 'checker-fixtures'
    folder.mkdir(exist_ok=False)
    good, counts = synthetic_module()
    cases = [('synthetic-correct', good, True)]
    cases.append(('missing-neg-correction', synthetic_module(neg_policy='omitted')[0], False))
    cases.append(('wrong-neg-weight', synthetic_module(neg_policy='shifted')[0], False))
    cases.append(('missing-bias-bit18', synthetic_module(omit_bias=True)[0], False))
    cases.append(('wrong-input-lane', replace_once(good,
        b'assign pp_0_0_0 = ((one_0_0 & vs1[0])',
        b'assign pp_0_0_0 = ((one_0_0 & vs1[8])'), False))
    cases.append(('wrong-neg-control', replace_once(good,
        b'assign neg_0_0 = vs2[1];', b'assign neg_0_0 = vs2[0];'), False))
    cases.append(('missing-sign-bit-inversion', replace_once(good,
        b'assign pp_0_0_8 = ~(((one_0_0 & vs1[7]) | (two_0_0 & vs1[7])) ^ neg_0_0);',
        b'assign pp_0_0_8 = ((one_0_0 & vs1[7]) | (two_0_0 & vs1[7])) ^ neg_0_0;'), False))
    cases.append(('extra-unknown-output-text', good + b'assign unrelated = 1\'b0;\n', False))
    results = []
    for label, raw, expected in cases:
        path = folder / (label + '.sv')
        path.write_bytes(raw)
        try:
            result = prove(raw)
            accepted, error = True, None
        except invalid as exc:
            accepted, error, result = False, str(exc), None
        assert accepted == expected, (label, expected, accepted, error)
        if result is not None:
            assert not result['wrapper_binding_verified']
            assert not result['sequential_fu_qualified']
        results.append(dict(case=label, fixture=str(path.relative_to(HERE)),
            fixture_bytes=len(raw), fixture_sha256=sha(raw),
            accepted=accepted, expected_accepted=expected, error=error,
            proof=result))
    # A disabled-high-half mutation lies outside VDotCarrySaveRows. Show the
    # concrete modular error without pretending prove(raw) checks VDotElastic.
    low_dot8 = 0
    low_encoded = low_dot8 + (1 << 19)
    correct = signed20(low_encoded + (1 << 19))
    mutated = signed20(low_encoded + 0)
    assert correct == 0 and mutated == -(1 << 19)
    summary = dict(status='CHECKER_SYNTHETIC_FIXTURE_REVIEW_PASS',
        scope='Pure checker tests on hand-generated SV; NOT actual Scala/Chisel RTL qualification.',
        checker=dict(path=str(CHECKER),bytes=len(raw_checker),sha256=CHECKER_SHA),
        synthetic_positive_heap_counts=counts,tests=results,
        disabled_high_half=dict(input='all-zero operands in dot8 mode',
            correct_saved_high_rows=[1 << 19,0],mutated_saved_high_rows=[0,0],
            correct_result=correct,mutated_signed20_result=mutated,
            rejected_by_carry_save_checker=False,
            reason='The mutation changes the wrapper, outside this one-module parser; separate wrapper binding/FU check required by the existing contract.'),
        actual_candidate_sv_generated=False,actual_candidate_fu_run=False,
        new_builds=0,new_eda_runs=0)
    assert CHECKER.read_bytes() == raw_checker
    output = HERE / 'CHECKER_TEST_RESULT.json'
    with output.open('x',encoding='utf-8') as f:
        json.dump(summary,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(dict(status=summary['status'],cases=len(results),accepted=sum(x['accepted'] for x in results),
        rejected=sum(not x['accepted'] for x in results),positive_counts=counts,
        result_bytes=output.stat().st_size,result_sha256=sha(output.read_bytes()))))


if __name__ == '__main__':
    main()
