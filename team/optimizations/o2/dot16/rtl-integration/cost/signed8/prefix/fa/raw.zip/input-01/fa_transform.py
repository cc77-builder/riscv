"""A narrow, reversible Boolean-to-FA_X1 mapping experiment.

Only the frozen generated carry-save module is rewritten.  This is not a
sequential or complete mapped-netlist equivalence checker.
"""
from collections import Counter
import hashlib
import itertools
import re


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def braced(text, start):
    """Return an entire observed Liberty group, respecting quoted braces."""
    opening = text.index('{', start)
    depth, quoted, escaped = 1, False, False
    for i in range(opening + 1, len(text)):
        c = text[i]
        if quoted:
            if escaped:
                escaped = False
            elif c == '\\':
                escaped = True
            elif c == '"':
                quoted = False
        elif c == '"':
            quoted = True
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise ValueError('unterminated Liberty group')


def library_fa(library, verifier):
    text = library.decode('ascii')
    matches = list(re.finditer(r'\bcell\s*\(FA_X1\)\s*\{', text))
    need(len(matches) == 1, 'unique FA_X1 library cell')
    cell = braced(text, matches[0].start())
    need(sha(cell.encode()) == '375af4ef4d5ebea75126fe0180c84007c5bb3645c3f8da4a18bb8d72a223439b',
         'exact captured FA_X1 cell changed')
    pins, functions, expressions = {}, {}, {}
    for match in re.finditer(r'\bpin\s*\((\w+)\)\s*\{', cell):
        name = match[1]
        need(name not in pins, 'duplicate Liberty pin')
        body = braced(cell, match.start())
        directions = re.findall(r'\bdirection\s*:\s*(\w+)\s*;', body)
        need(len(directions) == 1, 'one pin direction')
        pins[name] = directions[0]
        funcs = re.findall(r'\bfunction\s*:\s*"([^"]+)"\s*;', body)
        if directions[0] == 'output':
            need(len(funcs) == 1, 'one output function')
            functions[name] = funcs[0]
            parser = verifier.Parser(funcs[0])
            expressions[name] = parser.expression()
            need(parser.pos == len(parser.tokens), 'complete Liberty function parse')
        else:
            need(not funcs, 'unexpected input function')
    need(pins == {'A':'input','B':'input','CI':'input','CO':'output','S':'output'},
         'complete named Liberty signal ports')
    need(set(expressions) == {'CO','S'}, 'complete output function set')
    table = []
    for bits in itertools.product((0,1), repeat=3):
        values = dict(zip(('A','B','CI'), bits))
        co, s = (verifier.evaluate(expressions[n], values) for n in ('CO','S'))
        need(co == int(sum(bits) >= 2) and s == sum(bits) % 2, 'library binary FA function')
        table.append(dict(A=bits[0],B=bits[1],CI=bits[2],CO=co,S=s))
    return dict(cell='FA_X1',cell_sha256=sha(cell.encode()),pins=pins,
                functions=functions,truth_table=table), expressions


def derive(raw, library, verifier):
    need(sha(raw) == '68227036423ff34235b275546dc7d2341fb5e890857e1b9098f4bc070f9545f6',
         'one frozen original CSA required')
    original = verifier.prove(raw)
    need(original['full_adders'] == 477 and original['half_adders'] == 17 and
         not original['discarded_carries'], 'original CSA structure differs')
    lib, expressions = library_fa(library, verifier)
    text = raw.decode('ascii')
    declarations, assignments = verifier.Parser(text).module()
    pairs, derived = [], text
    for name in sorted(declarations):
        if not name.startswith('s_'):
            continue
        terms = verifier.xor_inputs(assignments[name])
        if len(terms) == 2:
            continue
        need(len(terms) == 3, 'exact FA input count')
        suffix, carry = name[2:], 'c_' + name[2:]
        need(carry in assignments, 'carry paired by complete identity')
        for bits in itertools.product((0,1), repeat=3):
            old_values = dict(zip(terms, bits))
            values = dict(zip(('A','B','CI'), bits))
            need(verifier.evaluate(assignments[name],old_values) == verifier.evaluate(expressions['S'],values)
                 and verifier.evaluate(assignments[carry],old_values) == verifier.evaluate(expressions['CO'],values),
                 'original FA and actual library functions differ')
        pattern = re.compile(r'^  assign '+re.escape(name)+r' = [^;\n]+;\n'
                             r'  wire '+re.escape(carry)+r';\n'
                             r'  assign '+re.escape(carry)+r' = [^;\n]+;\n', re.M)
        matches = list(pattern.finditer(text))
        need(len(matches) == 1, 'exact original paired assignment text')
        old = matches[0][0]
        instance = 'mapped_fa_' + suffix
        new = (f'  wire {carry};\n  FA_X1 {instance} '
               f'(.A({terms[0]}), .B({terms[1]}), .CI({terms[2]}), .CO({carry}), .S({name}));\n')
        need(text.count(instance) == 0 and derived.count(old) == 1, 'unique replacement identity')
        derived = derived.replace(old,new,1)
        pairs.append(dict(instance=instance,ports=dict(zip(('A','B','CI','CO','S'),(*terms,carry,name))),
                          original=old,replacement=new))
    need(len(pairs) == 477 and derived.count('  FA_X1 mapped_fa_') == 477, 'all and only original FAs')
    actual = list(re.finditer(r'^  FA_X1 (mapped_fa_\w+) \(([^;\n]+)\);$', derived, re.M))
    need(len(actual) == 477, 'complete emitted instance syntax')
    by_name = {p['instance']:p for p in pairs}
    seen = set()
    for match in actual:
        name, ports_text = match[1], match[2]
        need(name in by_name and name not in seen, 'unique emitted FA identity')
        seen.add(name)
        ports = {}
        for field in ports_text.split(', '):
            pin = re.fullmatch(r'\.(A|B|CI|CO|S)\(([A-Za-z_][A-Za-z_0-9]*|1\x27b1)\)', field)
            need(pin is not None and pin[1] not in ports, 'exact emitted named pin')
            ports[pin[1]] = pin[2]
        need(ports == by_name[name]['ports'], 'emitted pins differ from parsed original pair')
        terms = verifier.xor_inputs(assignments[ports['S']])
        for bits in itertools.product((0,1), repeat=3):
            old_values = dict(zip(terms,bits))
            values = {pin:old_values[ports[pin]] for pin in ('A','B','CI')}
            need(verifier.evaluate(assignments[ports['S']],old_values) == verifier.evaluate(expressions['S'],values)
                 and verifier.evaluate(assignments[ports['CO']],old_values) == verifier.evaluate(expressions['CO'],values),
                 'emitted FA function differs from original pair')
    need(seen == set(by_name), 'all original FAs have one emitted instance')
    inverse = derived
    for pair in pairs:
        need(inverse.count(pair['replacement']) == 1, 'unique inverse replacement')
        inverse = inverse.replace(pair['replacement'],pair['original'],1)
    need(inverse.encode() == raw, 'full inverse byte identity')
    result = dict(status='FA_X1_LOCAL_SUBSTITUTION_VERIFIED',original_sha256=sha(raw),
                  derived_sha256=sha(derived.encode()),derived_bytes=len(derived.encode()),
                  full_inverse_byte_match=True,full_adders_per_module=477,unchanged_half_adders=17,
                  emitted_named_pin_connections_verified=477*5,
                  per_pair_binary_cases=8,library=lib,original_structure=original,pairs=pairs,
                  proof_scope='All binary inputs of the derived CSA under the actual Liberty Boolean functions. '
                              'Four-state behavior and complete mapped-netlist equivalence are not claimed.',
                  mapped_netlist_equivalence_tested=False)
    return derived.encode(), result


def audit_mapped(design, substitution):
    """Bind actual surviving library cells to both original CSA instances."""
    cells, nets = design['cells'], design['netnames']
    fas = {n:c for n,c in cells.items() if c['type'] == 'FA_X1'}
    expected = {p['instance']:p['ports'] for p in substitution['pairs']}
    need(len(fas) == 954, 'actual flattened FA count must be 2 x 477')
    consumed = Counter()
    for c in cells.values():
        for port,bits in c['connections'].items():
            if c['port_directions'][port] == 'input':
                consumed.update(bits)
    for p in design['ports'].values():
        if p['direction'] == 'output':
            consumed.update(p['bits'])
    seen, instances = Counter(), {}
    for name,c in sorted(fas.items()):
        prefix, suffix = name.rsplit('.',1)
        need(suffix in expected, 'unexpected FA instance')
        need(c['port_directions'] == substitution['library']['pins'], 'FA directions differ')
        need(set(c['connections']) == set(expected[suffix]), 'FA complete named pins')
        for port,signal in expected[suffix].items():
            bits = ['1'] if signal == "1'b1" else nets[prefix+'.'+signal]['bits']
            need(len(bits) == 1 and c['connections'][port] == bits, 'actual FA pin binding differs: '+name+'.'+port)
        outs = [c['connections'][p][0] for p in ('CO','S')]
        need(len(set(outs)) == 2 and all(isinstance(b,int) and consumed[b] > 0 for b in outs),
             'both distinct FA outputs must remain used')
        seen[suffix] += 1
        instances.setdefault(prefix,[]).append(suffix)
    need(set(seen) == set(expected) and set(seen.values()) == {2}, 'two complete original FA sets')
    need(len(instances) == 2 and all(len(x) == 477 for x in instances.values()), 'exact two CSA instances')
    return dict(status='MAPPED_FA_BINDINGS_PASS',actual_fa_cells=954,
                csa_instances={n:len(v) for n,v in sorted(instances.items())},
                named_pin_connections_verified=954*5,both_outputs_used_cells=954,
                mapped_netlist_equivalence_tested=False)
