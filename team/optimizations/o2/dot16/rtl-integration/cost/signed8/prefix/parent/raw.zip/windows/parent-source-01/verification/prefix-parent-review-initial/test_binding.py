"""Negative checks on actual already-generated prefix RTL; no parent qualification."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prefix_parent_binding_tested', HERE/'parent_binding.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
root = HERE.parent/'prefix-parent-inputs'
expected = {0: '771d4cf6466811717592c3a939e4d5a1a9cf4318406c12c371f0d78e60b9a868',
            1: '1edb96e8012180926e8bd08082c97ff74ca332e59c12e62bdbd00d557aa8033f'}
cases = []
texts = {}
for feature in (0, 1):
    raw = (root/f'prefix-cost-feature{feature}.sv').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected[feature]
    texts[feature] = raw.decode()
    record = module.verify_data_binding(texts[feature], feature)
    assert record['result_width'] == 19+feature
    cases.append(dict(feature=feature, case='actual_closed_local_data_binding', status='PASS'))
    renamed, count = re.subn(r'\b_GEN\b', '_GEN_42', texts[feature])
    assert count >= 3
    assert module.verify_data_binding(renamed, feature)['sign_extension_wire'] == '_GEN_42'
    cases.append(dict(feature=feature, case='same_graph_with_bound_sign_wire_name', status='PASS'))


def reject(label, feature, pattern, replacement):
    changed, count = re.subn(pattern, replacement, texts[feature], flags=re.S)
    assert count == 1, (label, count)
    try:
        module.verify_data_binding(changed, feature)
    except ValueError as exc:
        cases.append(dict(feature=feature, case=label, status='EXPECTED_REJECT', reason=str(exc)))
    else:
        raise AssertionError('mutation unexpectedly accepted: '+label)


reject('wrong_high_input_half', 1,
       r'(\.vs1\s*\()io_in_bits_data_src_0\[127:64\](\))', r'\g<1>io_in_bits_data_src_0[63:0]\2')
reject('wrong_saved_row_width', 0,
       r'(reg\s+\[)18(:0\]\s+pRows_0_0\s*;)', r'\g<1>17\2')
reject('wrong_saved_r_width', 1,
       r'(reg\s+\[)19(:0\]\s+rPacket_res_data\s*;)', r'\g<1>31\2')
reject('nonzero_dot8_high_row', 1,
       r'(pRows_1_0\s*<=\s*isDot16\s*\?\s*_highProducts_row0\s*:\s*)19\x27h0(\s*;)',
       r'\g<1>19\x27h1\2'.replace('\\x27', "'"))
reject('aliased_saved_prefix_row', 1,
       r'(\.rows_2\s*\()\{pRows_1_0\[18\],\s*pRows_1_0\}(\))',
       r'\g<1>{pRows_0_0[18],pRows_0_0}\2')
reject('wrong_prefix_result_width', 1,
       r'(wire\s+\[)19(:0\]\s+_prefixSum_result\s*;)', r'\g<1>18\2')
reject('illegal_result_not_zero', 0,
       r'(rPacket_res_data\s*<=\s*pCtrl_exceptionVec_2\s*\?\s*)19\x27h0',
       r'\g<1>19\x27h1'.replace('\\x27', "'"))
reject('architectural_high_not_zero', 1,
       r'(assign\s+io_out_bits_res_data\s*=\s*\{)96\x27h0',
       r'\g<1>96\x27h1'.replace('\\x27', "'"))
reject('wrong_r_sign_bit', 1,
       r'(wire\s+\[11:0\]\s+_GEN\s*=\s*\{12\{rPacket_res_data\[)19(\]\}\}\s*;)',
       r'\g<1>18\2')
reject('wrong_finish_module', 1, r'\bVDotPrefixFinish20\s+prefixSum\s*\(',
       'VDotPrefixFinish19 prefixSum(')
reject('duplicate_csa_instance', 1, r'\bVDotCarrySaveRows\s+highProducts\s*\(',
       'VDotCarrySaveRows products(')

report = dict(schema=1, scope='closed local RTL parser self-check only; not parent generation or validation',
              binding_sha256=hashlib.sha256((HERE/'parent_binding.py').read_bytes()).hexdigest(),
              input_sha256=expected, cases=cases, all_passed=True,
              parent_qualified=False, fullcore_qualified=False)
print(json.dumps(report, indent=2)+'\n', end='')
