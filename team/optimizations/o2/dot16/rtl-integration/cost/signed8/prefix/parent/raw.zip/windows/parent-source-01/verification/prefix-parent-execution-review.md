# prefix 父级控制器：执行侧有限审查

**结论：当前执行侧未发现需要修改代码的实质缺陷。** 审查对象为 `prefix_parent.py` 38972 B、SHA `ff9403d474a77a71b1cade45944d5f661476280de0c609399e08729c3a2eb783`；基底为 `inline_parent.py` SHA `29e72bff…`。未审算术 binding 内部，未调用本机、Git、构建或仿真。当前尚未执行，以下均为静态结论。

## 两项配套事项

1. 初次审查时未提供 `PARENT_CONTRACT.md`，此后已补齐到 controller 同目录。当前文件为7319 B，SHA `c23fbfc3851be7dcbe787acbba1aeb64af9fc1086a580edba216e9e760c08677`；基本 scope 是同一冻结 prefix 的真实父级功能验证、CPU1/nice5、最多1200秒，不构建 EMU、不授予整核／应用／成本资格。同目录读取条件已具备。本报告仍仅适用于上列 `ff9403…` 初版 controller，不提前覆盖后续 predicate guard 或新 BINDING_SHA。初版 binding 已由固定 SHA 绑定并在 snapshot 后导入；derive_controller、diff/json 是派生依据，不是本控制器实际读取的执行输入，不应把它们描述为运行时已 pin。
2. 尚未看到实际资源提案，不能确认其声明完整。四个 CLI 输入根不足以覆盖读集合：控制器还逐项读取 prefix local 的675份 originals、21份 snapshots，完整23类 overlay、基础 classpath 和工具。既有清单跨 production-cost、CSA、rwidth、inline-signed8、旧 production 运行根、resident source/cache、Windows 冻结源及系统工具目录。声明应依据这些原清单覆盖只读输入；唯一工程写入是新 out。原 K288 worker 释放后再按既定顺序执行，不另加并发。

## 已确认的身份和路径闭合

27条声明派生能逐字节重建当前 controller，未执行派生脚本。原16项 PARENT_INPUTS、两态 status/generated manifest SHA、20项 FAULTS 均与基底一致。

新入口固定 prefix result `a0c4dd60…`、inputs `1afacb22…`、overlay manifest `f36dd44e…` 和两份候选源码；overlay 的完整实际目录与23条清单比较，而非只挑主 class。实际23类没有与新编 `GenerateVDotElasticParent/VDotElasticParentTestTop` 同名的类。编译 classpath 为 overlay→原 run_paths；运行时为 overlay→新 harness classes→原 run_paths，且新输出只允许 team/vdot 类。原 classpath 内容与 optional-resource 缺失状态前后复核。

同名快照无冲突：父级16输入 basename 唯一；第二态仅核对第一态 tree 副本，不重写它；prefix/controller/helper/vectors 在另一层 snapshot。audit 保持 `tree/team/optimizations/o4/perf/audit.py` 布局，其 `parents[4]` 正确返回 tree，能找到原 check_trace。

原父级 `.sv/.v` 与资源文件受原 manifest 绑定；新 filelist 必须精确覆盖新 RTL，resource 必须是原 ClockGate 集合加两个新模块。其余父级/时钟/DIV 字节检查保留；wrapper 与新增算术模块的具体判据由另一审查承担。

## 原 harness、预算与回收

`command/interrupt/check/pin/snapshot` 与基底逐字一致；从 DIV waiver、lint/build 到正测、metadata audit、coverage、20组注错/checker及最终身份复核的尾段亦逐字一致。两态派生 C++ 必须逐字等于原冻结 C++。577-bit audit、check_trace、check_negative 均使用原 SHA，20项错误不删不换；计划仍是96条命令。这里的 replay 是原 checker 重读日志，不应写成另一次硬件运行。

deadline 自入口开始，最多1200秒；固定 CPU1、absolute nice5，线程变量为1、make/Verilator -j1。每命令限额取剩余总预算，独立进程组；TERM/INT 只 latch，0.25秒等待安全点检查，finally 调原 stop_group 并记录 reaped/group_absent。输出必须 fresh、绝对、无父路径 symlink，并与 repo/cost/parent/local/controller 树分离；原 cache/overlay 只读，最终全 pin、链接目标和完整 classpath/overlay 复核。

PASS 只设置新 `parent_qualified`；fullcore、应用、cost/core-cost 和性能仍 false，旧乘法 miter 状态单独保留。没有借父级成功扩大这些资格。

证据入口：`source-review/prefix-parent-v1/` 三份派生材料及 controller；`source-review/inline-parent-candidate-v3/inline_parent.py`；`source-review/prefix-candidate-v1/actual-manifests/{inputs.json,overlay-classes.json}`；旧父级资料在 `source-review/inline-parent-inputs/`。后者部分审查副本末尾多一个 LF；只在内存核对去掉该额外 LF 后与原记录 SHA 相同，没有改文件或把副本原字节当执行身份。
