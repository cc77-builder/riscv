# prefix 父级绑定检查器独立审查

**结论：发现的一项数据绑定缺口已修复；其余审查未发现确定的新增代码阻塞。** 这只评价控制器和静态判据，不授予新父级 PASS；执行仍按既定资源顺序及首次生成回执判断。

审查初版为 controller `ff9403d4…` / helper `d52a5fb1…`；已读回修复版 controller `3e0782b47f623e9c8e6837a43d04c32f3ca1f71140adf55bed264bac12e3f3c2`、helper `eefefaea3ab263b2be754a076dd5d07465bf3392699e217df017da7435921dc7`，派生清单及驱动中的 helper pin 相符。契约为 `f556e403…`。

## 已解决：dot8 高半零的模式条件未闭合

初版只要求高半 P 更新形如 `isDot16 ? row : 0`，未绑定 `isDot16` 的定义。我对实际 prefix cost feature1 SV（SHA `1edb96e8…`）做单个内存反例：仅将定义改为恒真，`verify_data_binding` 仍返回 true；未写回 SV，也未调用完整父级流程。这是 helper 的独立数据绑定缺口，不能据此推断完整 driver 会错误授予 PASS。

修复版要求唯一声明和唯一赋值都为 `fuOpType == 9'h1`，支持已见的模块级 `wire` 与旧父级块内 `automatic logic`，不强定位置。常量、第二赋值或错误比较不会满足该判据；主端已将对应负控及原父级声明正例纳入自测。本审查读代码确认修复，不重复其整个自测矩阵。

## 其余数据及生成边界

- CSA 一/二实例的四端口必须完整、唯一，输入低/高64位、输出 row 名称固定；19位 P rows、19/20位 R、prefix行序及各输入符号扩展均显式检查。
- feature0/1 分别把 R 的 bit18/19 重复13/12位，形成低32位；高96位固定零。输出及941位 stalled shadow 绑定同一符号扩展线，不依赖必须叫 `_GEN`。R的异常零分支与唯一 prefix结果也有精确约束。
- driver 明确删除 Products/Reduce、增加对应 CSA/Finish，并逐字核对已验证黑盒；资源保留 ClockGate，完整 filelist 无重复。新 wrapper 与同父级旧件比较，未用 cost全文作模板；其余保留模块逐字检查，LogPerf v3 有限规则保持。
- 完整23类 overlay、源对、结果、两个模和 SAT及两态 FU 均绑定；原正例、回放、577-bit audit、coverage、20项观察负控和回收检查保留。没有把乘法 UNKNOWN 变成 PASS，也未授予 core/app/cost 资格。

## 必须保持的解释范围

`assignments()` 比较的是有序更新右值，未比较所有 if、时钟边沿或组合控制定义；契约已明确这一点。它不能单独证明控制时序等价，协议行为仍由固定源码身份及原父级套件验证，不应扩大为顺序 formal。

已读 cost 比旧父级多八个控制状态，是不同边界裁剪；不是此次判据错误。尚无新 prefix 父级实物，不能保证实际模块集合、声明形式、非数据表达式顺序和日志文本必然满足有限模板。出现偏差应保留实物分析，不提前放宽生成比较，也不保证1200秒必闭合。

证据入口：`source-review/prefix-parent-v1/` 的 helper、driver、派生及契约；`source-review/prefix-parent-inputs/` 四份实际 SV 与 read-receipt；旧 parent-v3 控制器及两态生成清单。初版反例与修复记录由主端保留在 `verification/prefix-parent-review-initial/`、`prefix-parent-final-selfcheck-01/`。

本次仅只读审查、一个内存负控及版本核对，写本记录；未改实现或SV，未调用 ChatPC/Git，未构建、运行EDA或父级仿真。
