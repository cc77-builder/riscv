# prefix 仓外整核构建入口 v1 — 输入准备已补齐，未执行

本入口只为已完成局部算术、FU 和真实父级功能验证的同一个 prefix 候选准备独立整核构建。当前阶段为源码准备和轻量检查；尚未运行 Java/Scala、FIR lowering、Verilator、native 编译或新 EMU。当前锁为 `INPUT_LOCK.json`：`ready=true` 只表示所需输入记录已捕获并完成静态适用性核对，不表示已执行前后 helper 校验、构建可成功或获得构建许可。初版 `INPUT_LOCK.pending.json` 保留为未就绪准备快照，不作为当前入口。

录屏任务具有最高优先级。按人工 2026-11-08 00:20:37Z 明确的保护范围及首席 00:22:40Z 通知，本阶段允许轻量读取和本隔离目录写入；不触碰 `D:\Users\LiZufan\Downloads\比赛视频-20261108`、WSL `video-recording-20261108-0754`、录制终端/GTKWave/FFmpeg/桌面或显示设置。录制使用 CPU4/5 构建、CPU6 录屏，现有完整 forward 保留 CPU0–3。准备不会自行转为重构建授权；实际启动必须先协调录屏和内存，不能占用未获授权的额外核心。

## 1. 固定候选与适用范围

- Windows 预定源码位置：`D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runs\dot16-prefix-20261107-main\core-builder-source-01`。不覆盖现有 core-source、parent-source 或旧运行输出。
- 仅复用常驻 WSL 源 `/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source`，其原 HEAD/源码/依赖仍按旧 native-02 身份核验；不新建检出、不调用 Mill/scalac、不改 resident/cache/生产源/Git index。
- 候选 `VDotDatapath.scala` SHA `1d02d8a34772e7d9b9947f997f32465f3e946f4b24cacc66159eef7ee10ab3bb`；wrapper SHA `912c1a038ef8e9a1ac56cfa349161ae1c582d763acfce5352b08ebde2a227f92`。
- prefix local-01 结果 SHA `a0c4dd60fddc001f368b71ec283327f2d7fe0874080ac35304e3debe783116d0`；完整 23 类 overlay 清单 SHA `f36dd44ef66c0058a73839bfeaacd321cc6ac7d41144c622c38371948375c4bf`。运行时完整 overlay 第一，原完整测试 classpath 随后。
- 沿旧 fullcore 条件：`MinimalConfig`、NUM_CORES=1、VDOT_DOT16/O2_ELASTIC/T14_FUSED_INPUT=1，O1_HANDOFF 与四种 trace=0，EMU_THREADS=1、EMU_TRACE=0、NO_DIFF=0、WITH_CHISELDB/CONSTANTIN/ROLLINGDB=0，`OPT_FAST=-O3`、`OPT_SLOW=-O0`、原 Clang19 链接规则。不另加 `--disable-alwaysdb`，不把旧 EMU_THREADS=1 改成0。
- 时钟、复位、端口、VLEN128、P/R 两槽、最早 E2、II1、dot8/16 数据语义沿已测 prefix，不引入第三个 RTL 候选。这是生成配置声明；实际生成和整核功能仍须新证据。

## 2. 最薄路径与所有已知显式写点

输出只接受全新 `.../runs/dot16-prefix-20261107-main/core-build-NN`；拒绝存在目录、符号链接父路径及其他输出位置。没有 resume/clean/自动重试模式。

| 阶段 | cwd / 输入 | 新输出 |
| --- | --- | --- |
| 直接 Java `top.SimTop` | `out/cwd`；完整已冻结测试 CP；生成环境 `NOOP_HOME=out/cwd` | `out/cwd/build/rtl`、`out/cwd/build/generated-src`、`out/cwd/build` 辅助文件 |
| JVM/原生临时文件 | `TMPDIR/TMP/TEMP=out/tmp`；Java `java.io.tmpdir` 同目录 | `out/tmp`；JVM 错误/heap 文件也显式放 out |
| 官方 memory 脚本 | 原绝对 `gen_sep_mem.sh`/`vlsi_mem_gen`，`bash -e` | 新 `.conf.tmp` 和新 RTL 下各 `.v` |
| 原模拟后处理 | Git 信息只读真实 repo；只改新 RTL | 新 SimTop 的 Git 注释；原 `$fatal`/`$error(` 替换 |
| 原 DiffTest make | `make -C repo/difftest emu`，命令行绝对 `BUILD_DIR=out/cwd/build`，native NOOP_HOME/DESIGN_DIR=repo | 新 generated C++、`emu-compile`、`emu`、`time.log` |
| 控制器 | out 下日志/回执/自己的源码与锁快照 | out 下固定清单、逐命令记录、最终 artifact 身份 |

两处不同的 Scala 输出规则已按原始源码核对，不能合并为一个“改 cwd”假设：

1. `top/SimTop.scala` 最后使用 `FileRegisters.write("./build")`，因此 Java cwd 与 target-dir 必须对齐。
2. 固定 DiffTest `62e4540c03c03aa947bdb67f4b6bf66f1a29c5d0` 的 `src/main/scala/common/FileControl.scala` 使用 `sys.env("NOOP_HOME")/build/generated-src`。该源 1688B，SHA `3caddbe9129a2bdc57ae0b75d5279be42ea8a6c9d7e2703c50510debca4e5695`。Java 阶段不能把 NOOP_HOME 留在 resident。

原 utility `FileRegisters.scala` SHA `236753f4b936c5918d30281db5f16ba6de734a79b3690c656f240098bad0542e`；原 `top/Generator.scala` SHA `8a95e4ecc367a1ff0b6a7409d44618f1268bf0c6cf5f76511d161f5ad5524848`。这些原件已与实际 WSL 文件 SHA 对齐。对冻结源目录内 Scala 的有界检索另命中 Constantin 生成的 C++ 字符串与独立 `ExtractVerilogModules.main`：前者在 Scala 阶段只注册到 FileRegisters，不读取 NOOP_HOME；后者不是本次 `top.SimTop` 入口。两份实际源已完整阅读，身份与检索范围见 `INPUT_CAPTURE.json`。本结论属于静态路径核对，不宣称 OS 沙箱或动态执行证明。

DiffTest 的五个 include 已静态读取。固定 emu 分支显式输出经 BUILD_DIR；保留原 cwd 是为了复用相对源/include 和递归 make，不复制 DiffTest。明确关闭 PGO_WORKLOAD/PGO flags/PGO_EMU_ARGS、REMOTE 非本地、fuzzer、coverage、trace-all、snapshot、screen；不清空聚合编译 flags。窄环境不继承 MAKEFILES/MAKEFLAGS/MAKEOVERRIDES 或额外后端开关。`VERILATOR_ROOT/VERILATOR_BIN` 不新增覆盖，沿原 launcher sibling-payload 绑定。解析期只读 version/find 探测会随 make 进入受控进程组。

不调用 root `sim-verilog`（会在原 cwd 写 `.__*`），不调用任何 `clean`（`vcs-clean` 有相对路径删除），不调用 emu-run。memory 名称仅接受简单 HDL 标识符，拒绝路径穿越/空集合/重复；官方脚本成功后核对每个应生成文件。原脚本不修改，`bash -e` 只使原本可能被末尾 rm 掩盖的失败及时传播。

## 3. 已捕获的输入身份

原 generation recipe SHA `ec29dc8725cf3a1c04ea684e2753debc1a9b2a04d37b4adadcdfe96f85ec20d8`；原完整基础 CP 清单 SHA `d9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902`；旧 native-02/build-inputs SHA `76853412c2c2f27e3e91fbdb0c25b89064023c908d648aa33491372fb5d6231e`。

**原 cost/parent CP 不是整核测试 CP。**实际旧缓存 `out/dot16-fu-20261106-pro2/xiangshan/test/runClasspath.json` 已只读取得：20881B，SHA `728ce67a49e9b883c7d37eaad0721c34b6d5c930404cbec7976a6b8367a4a4d5`。与 FU run_paths 的集合差异恰为新增 difftest/test classes、xiangshan/test classes 及两项 test resources，去掉 vdotElasticFu 的三项专用条目；完整顺序仍取该缓存原件，不手拼替代。`top/SimTop.class` 实际 SHA `ad7fb46505dcf5defeb2c4a04e50cf779925bdb88ac95bae488295731b399238`。

2026-11-08 00:36:55Z 的只读取证及 00:37:47Z 的两文件窄核对已补齐：

1. 两个 test resources 均为缺失资源；DiffTest test classes 为 9 文件/55,770B，XS test classes 为 60 文件/716,727B；四项均有完整目录摘要或缺失身份，不只 pin SimTop.class。
2. 旧 native-02 的 tools.json SHA `c1a800e5d7c54f057fb3ee0036b1f3199f07125150cd8df996825ca9faa5dbb8`；verilator-support.json SHA `92d587b1a4f81421c1eac77f9d88ed3f2b5b85f2dd6bd90ec1ab35ef0f6651cf`；compiler-runtime.json SHA `f2f55423103afa27568398668b86c930681f89a5bff31889c21f077b5d444dbe`。
3. prefix parent-01/result.json 为 160,379B，SHA `03eb17ce008ab0be25b9d46ddf53a237daa2ee912c817be801ba8a80c6deaa8d`；PASS、parent=true、当前源/wrapper 身份、全部 unchanged/reaped 字段与入口要求一致。原 fullcore/application/cost/core-cost/performance 标志仍为 false。
4. 固定源实际 FileControl/FileRegisters/Generator/SimTop 的身份和 NOOP_HOME 用途核对已完成；不会把默认分支搜索的缺失结果当作冻结源证明。

新增目录身份使用完整文件清单的摘要：每个常规文件记录相对 POSIX 路径、字节数和全文件 SHA，按路径排序，以 `json.dumps(files, sort_keys=True, separators=(',', ':'))` 的 UTF-8 字节再次取 SHA。锁保留 `count`、`total_bytes` 和 `files_sha256`；缺失资源单独记录，入口及枚举到的符号链接、FIFO/socket/设备等特殊文件拒绝（本函数不单独证明所有祖先目录无链接）。它绑定整个目录中的文件名和内容，不只绑定 SimTop.class，也不把空目录和缺失资源混为一类。

源/依赖/旧 EMU、完整 base/test CP、overlay、工具、支持树和编译 runtime 的前后核验复用成熟 helper；其中可能调用 Git/ldd 的整段使用锁定的原 `/usr/bin/python3.10` 在受控 Python 子阶段内完成，不在主控制器中裸调用。此次准备未运行这段实际 helper；开始构建前仍须通过全部运行时输入核验。

## 4. 执行与停止

默认调用只输出计划；只有完整且 SHA 固定的锁、显式 `--execute`、带时区绝对截止和 120..3600秒预算才进入构建。每次只一个 worker：CPU1、absolute nice5、j1；JVM 8G/16m 沿旧整核构建，ActiveProcessorCount1/SerialGC。实际启动前由首席核实录屏、四核总占用、内存与在途冻结目录；代码中的资源声明不是 OS 沙箱，也不证明零竞争。

原 process helper 负责每个子阶段的新 session/PGID、TERM→KILL→wait；总 deadline 包含前后校验。SIGINT/SIGTERM 进入同一清理路径。非零退出、超时、未回收 group、输入变动或生成闭包不符均保留原输出并失败，不改旧 guard、不自动重跑。最后全部 SHA 完成后再次检查停止/deadline，才允许 `PREFIX_CORE_BUILD_COMPLETE`。

成功也只表示 **该新二进制已按记录输入构建**。`fullcore_qualified`、`application_performance_qualified`、`ppa_qualified` 保持 false。新的 ABI/六例整核差分冒烟与后续应用测量另按原合同和实际资源安排；旧 f149 的 PASS、旧 2ns 或新局部 FU/父级证据都不会转移为新整核/应用结论。

## 5. 本阶段验收

源码语法、纯命令计划、路径拒绝与未完成锁拒绝可在云端轻量检查；原生助手独立静态审查过程/输出边界。它们不替代真实生成、原生链接、源前后比对或整核运行。主端收到源码/合同/当前锁状态及真实 SHA 后决定继续、缩减或暂缓，不让本适配阻塞 02:00 的已有成果整理。
