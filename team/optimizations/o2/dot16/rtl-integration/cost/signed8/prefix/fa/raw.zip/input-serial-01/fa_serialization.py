#!/usr/bin/env python3
"""Re-export one closed FA netlist for the installed old OpenSTA; never remap."""
import argparse
from collections import Counter, defaultdict
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-fa-20261108-main')
OLD = ROOT/'local-01'
OUT = ROOT/'serialization-01'
LIB = Path('/home/lizufan/riscv-tools/nangate45/NangateOpenCellLibrary_typical.lib')
PREFIX = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main/local-01')
EXPECTED = {'result.json':'476d893ba770a9faf323a61b7f1403c5999f4f00569b68d95b4620ff9b61a473',
            'inputs.json':'34e35febe16299e0d8ed9d18b70cf21364f20b218004454ade92aec5e86b0586',
            'mapped.v':'a67ed496a2d337969ae8387defb9425027ce67b59ec35276d39d8bd3fb9b5c48',
            'mapped-fa-bindings.json':'7a51e45bdcdce2b66a9213ddee2745130ae0e58334fcdc37311f28081049f1c8',
            'sta-feature1.log':'73b781c72e81bc55103eb01dc5e3f50aacd7502dd6c959fcd8f1d78a63ba6b9b'}


def need(ok,message):
    if not ok: raise ValueError(message)


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p,value): Path(p).write_text(json.dumps(value,indent=2)+'\n')


def module(p,name):
    spec=importlib.util.spec_from_file_location(name,p)
    obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj)
    return obj


def circuit(design):
    """Canonical complete terminal graph, independent of bit IDs/net aliases."""
    need(not design.get('memories') and not design.get('processes'),'flat mapped circuit only')
    need(not any('init' in n.get('attributes',{}) for n in design['netnames'].values()),
         'do not discard initialization attributes')
    ports,cells,nets={},{},defaultdict(list)
    def terminal(bit,label):
        need(isinstance(bit,int) or bit in ('0','1','x','z'),'known signal bit kind')
        key=('wire',bit) if isinstance(bit,int) else ('constant',bit)
        nets[key].append(label)
    for name,p in sorted(design['ports'].items()):
        ports[name]=dict(direction=p['direction'],width=len(p['bits']),offset=p.get('offset',0),
                         upto=p.get('upto',0),signed=p.get('signed',0))
        for i,b in enumerate(p['bits']): terminal(b,('port',name,i))
    for name,c in sorted(design['cells'].items()):
        need(set(c['connections'])==set(c['port_directions']),'complete mapped cell directions')
        cells[name]=dict(type=c['type'],parameters=c['parameters'],directions=c['port_directions'],
                         widths={p:len(b) for p,b in sorted(c['connections'].items())})
        for port,bits in sorted(c['connections'].items()):
            for i,b in enumerate(bits): terminal(b,('cell',name,port,i))
    # Preserve constants as labels; all aliases without a circuit terminal are irrelevant.
    netrows=[dict(constant=k[1] if k[0]=='constant' else None,
                  terminals=sorted(v,key=lambda x:json.dumps(x))) for k,v in nets.items()]
    netrows.sort(key=lambda x:json.dumps(x,sort_keys=True))
    return dict(ports=ports,cells=cells,nets=netrows)


def main(execute):
    need(sys.dont_write_bytecode,'invoke with -B')
    os.sched_setaffinity(0,{2});os.setpriority(os.PRIO_PROCESS,0,5)
    need(not OUT.exists() and not OUT.is_symlink(),'fresh serialization output')
    pins={str(OLD/n):h for n,h in EXPECTED.items()}
    prior=json.loads((OLD/'result.json').read_bytes())
    need(prior['status']=='FAILED' and prior['error']=="ValueError('incomplete STA')",
         'preserved specific failed prior experiment')
    need(len(prior['commands'])==2 and all(c['exit_code']==0 and c['reaped'] and c['group_absent']
                                          for c in prior['commands']),'closed original commands')
    original_inputs=json.loads((OLD/'inputs.json').read_bytes())
    for section in ('originals','generated'): pins.update(original_inputs[section])
    for p in (OLD/'mapped.json',Path(__file__),Path(__file__).with_name('SERIALIZATION_CONTRACT.md')):
        pins[str(p)]=sha(p)
    for p,h in pins.items(): need(sha(p)==h,'frozen input changed: '+p)
    util=module(PREFIX/'source-snapshot/process_helper.py','fa_serial_process')
    for pid in [31999]+[c['pid'] for c in prior['commands']]:
        need(not util.group_exists(pid),'original process group remains')
    original_design=json.loads((OLD/'mapped.json').read_bytes())['modules']['CommonFuCostTop']
    original_graph=circuit(original_design)
    mapped_pins=json.loads((OLD/'mapped-fa-bindings.json').read_bytes())
    need(mapped_pins['status']=='MAPPED_FA_BINDINGS_PASS' and mapped_pins['actual_fa_cells']==954,
         'prior exact mapped binding')
    serialized=('read_json '+str(OLD/'mapped.json')+'\nsplitnets\n'
                'write_json '+str(OUT/'split.json')+'\n'
                'write_verilog -noattr -norename '+str(OUT/'mapped.v')+'\n')
    reparsed=('read_liberty -lib '+str(LIB)+'\nread_verilog '+str(OUT/'mapped.v')+'\n'
              'hierarchy -check -top CommonFuCostTop\ncheck -assert\n'
              'write_json '+str(OUT/'reparsed.json')+'\n')
    oldsta=(OLD/'timing.tcl').read_text();sta=oldsta.replace(str(OLD),str(OUT))
    need(sta.replace(str(OUT),str(OLD))==oldsta,'STA path-only inverse')
    if not execute:
        print(json.dumps(dict(status='PLAN_ONLY',output=str(OUT),original_pins=pins,
                             serialize_script=serialized,reparse_script=reparsed,sta_script=sta,
                             original_graph_sha256=hashlib.sha256(json.dumps(original_graph,sort_keys=True).encode()).hexdigest(),
                             new_mapping_runs=0),indent=2));return
    deadline=time.monotonic()+120
    OUT.mkdir();(OUT/'tmp').mkdir();snap=OUT/'source-snapshot';snap.mkdir()
    for n in ('fa_serialization.py','SERIALIZATION_CONTRACT.md'):
        (snap/n).write_bytes(Path(__file__).with_name(n).read_bytes())
    for n,t in (('serialize.ys',serialized),('reparse.ys',reparsed),('timing.tcl',sta)):
        (OUT/n).write_text(t)
    generated={str(p):sha(p) for p in [*snap.iterdir(),OUT/'serialize.ys',OUT/'reparse.ys',OUT/'timing.tcl']}
    save(OUT/'inputs.json',dict(originals=pins,generated=generated))
    result=dict(contract='dot16-fa-netlist-serialization-v1',status='RUNNING',started=util.stamp(),
                prior_result_sha256=EXPECTED['result.json'],prior_status_preserved='FAILED',
                cpu_affinity=[2],nice=5,budget_seconds=120,commands=[],new_mapping_runs=0,
                new_fu_runs=0,new_core_runs=0,mapped_netlist_equivalence_tested=False,
                application_performance_qualified=False,core_cost_qualified=False,production_default_changed=False)
    save(OUT/'result.json',result);pending=[None]
    def interrupted(sig,frame): pending[0]=sig
    handlers={sig:signal.signal(sig,interrupted) for sig in (signal.SIGTERM,signal.SIGINT)}
    def check():
        if pending[0] is not None: raise InterruptedError(str(pending[0]))
        need(time.monotonic()<deadline,'total budget')
    env=dict(PATH='/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',TMPDIR=str(OUT/'tmp'),
             OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    def command(label,argv,limit):
        check();row=dict(label=label,argv=list(map(str,argv)),started=util.stamp(),
                         budget_seconds=min(limit,deadline-time.monotonic()))
        result['commands'].append(row);proc=None
        try:
            with (OUT/(label+'.log')).open('wb') as log:
                proc=subprocess.Popen(row['argv'],cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                row['pid']=proc.pid;save(OUT/'result.json',result);until=time.monotonic()+row['budget_seconds']
                while proc.poll() is None:
                    check();left=until-time.monotonic()
                    if left<=0: raise subprocess.TimeoutExpired(row['argv'],row['budget_seconds'])
                    try:proc.wait(timeout=min(.25,left))
                    except subprocess.TimeoutExpired:pass
                row['exit_code']=proc.returncode
            check();need(time.monotonic()<=until and proc.returncode==0,label+' failed or exceeded budget')
            need(not util.group_exists(proc.pid),label+' remaining group')
        finally:
            if proc is not None:
                if util.group_exists(proc.pid):row['cleanup_complete']=util.stop_group(proc)
                row['reaped']=proc.poll() is not None;row['group_absent']=not util.group_exists(proc.pid)
            row['finished']=util.stamp();save(OUT/'result.json',result)
        return (OUT/(label+'.log')).read_text(errors='replace')
    try:
        helptext=command('splitnets-help',['/usr/bin/yosys','-Q','-T','-p','help splitnets'],10)
        need('splitnets' in helptext and '-ports' in helptext,'actual supported splitnets help')
        command('serialize',['/usr/bin/yosys','-T','-s',OUT/'serialize.ys'],30)
        need(not re.search(r'(?m)^\s*assign\s*\{',(OUT/'mapped.v').read_text()),'concat LHS remains')
        split_design=json.loads((OUT/'split.json').read_bytes())['modules']['CommonFuCostTop']
        need(circuit(split_design)==original_graph,'splitnets changed complete circuit graph')
        command('reparse',['/usr/bin/yosys','-T','-s',OUT/'reparse.ys'],30)
        design=json.loads((OUT/'reparsed.json').read_bytes())['modules']['CommonFuCostTop']
        need(circuit(design)==original_graph,'serialized Verilog changed complete circuit graph')
        graph_audit=dict(status='EXACT_TERMINAL_GRAPH_MATCH',original_json_sha256=sha(OLD/'mapped.json'),
                         split_json_sha256=sha(OUT/'split.json'),reparsed_json_sha256=sha(OUT/'reparsed.json'),
                         graph_sha256=hashlib.sha256(json.dumps(original_graph,sort_keys=True).encode()).hexdigest(),
                         cells=len(original_graph['cells']),ports=len(original_graph['ports']),nets=len(original_graph['nets']),
                         ignored='Only wire aliases, bit numbering and source/display attributes; no init attributes present.',
                         rtl_to_mapped_equivalence_claimed=False)
        save(OUT/'graph-audit.json',graph_audit)
        helper=module(PREFIX/'source-snapshot/cost_helpers.py','fa_serial_cost')
        counts=Counter(c['type'] for c in design['cells'].values());areas=helper.library_areas(LIB)
        need(not set(counts)-set(areas),'unmapped cell');area=sum(areas[k]*v for k,v in counts.items())
        need(counts['FA_X1']==954 and sum(v for k,v in counts.items() if k.startswith('DFF'))==1678,
             'fixed actual FA and register counts')
        baseline=prior['baseline_cost']
        ports={n:dict(direction=p['direction'],width=len(p['bits']),offset=p.get('offset',0)) for n,p in design['ports'].items()}
        need(ports==baseline['ports'],'complete original top boundary')
        log=command('sta',['/usr/bin/sta','-no_init','-exit',OUT/'timing.tcl'],30)
        need(not re.search(r'(?m)^.*\bError:',log) and 'not found' not in log and
             log.splitlines().count('DOT16_GENERATED_FU_STA_COMPLETE')==1,'incomplete adapted STA')
        paths={n:helper.parse_path((OUT/(n+'.rpt')).read_text()) for n in ('r2r','i2r','r2o','i2o','ready')}
        need(all(p['exists'] for p in paths.values()),'all five path classes')
        constants=helper.constant_warnings((OUT/'setup-checks.rpt').read_text(),design)
        for p,h in {**pins,**generated}.items():check();need(sha(p)==h,'input changed: '+p)
        result.update(status='PREFIX_FA_SERIALIZATION_AND_COST_COMPLETE',terminal_graph_preserved=True,
                      graph_audit=graph_audit,cell_area=area,cell_count=sum(counts.values()),
                      cell_histogram=dict(sorted(counts.items())),dff_cells=1678,ports=ports,timing=paths,
                      reviewed_constant_endpoints=constants,nominal_setup_met=all(p['slack_ns']>=0 for p in paths.values()),
                      delta_from_D1000=dict(cell_area=area-baseline['cell_area'],
                        timing={n:{k:paths[n][k]-baseline['timing'][n][k] for k in ('arrival_ns','slack_ns')} for n in paths}),
                      mapped_sha256=sha(OUT/'mapped.v'),inputs_unchanged=True,
                      all_children_reaped=all(c['reaped'] and c['group_absent'] for c in result['commands']))
        check()
    except BaseException as exc:
        result.update(status='FAILED',error=repr(exc));raise
    finally:
        result['finished']=util.stamp();save(OUT/'result.json',result)
        for sig,h in handlers.items():signal.signal(sig,h)
    print(json.dumps({k:v for k,v in result.items() if k not in ('ports','cell_histogram')},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true')
    main(p.parse_args().execute)
