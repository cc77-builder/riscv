module Gold(input wire [18:0] a0, input wire [18:0] a1, output wire [18:0] result);
assign result=a0+a1;
endmodule
