# Prefix 原始证据归档合同

用途：运输唯一已闭合的 prefix `local-01`，完整保留本轮新源码、实际生成物和原始证据，并提供原外部依赖的明确路径/SHA入口。首席审阅、准备来源目录并声明资源后执行；本辅助开发阶段未执行归档或任何工程工具。

## 绑定与范围

原运行合同为 `dot16-csa-prefix-local-v1`，结果 `PREFIX_GENERATED_ARITHMETIC_FU_AND_COST_COMPLETE`。原 host operation 后缀 `.dc89d9ab3661ae50c18f8f4ed3d3514e`，20:47:27–20:51:24Z；host exit0/cleanuptrue由首席读取原回执确认，helper仅原样保存回执，不重新查询进程或解释未知host schema。

固定四份原始清单在读取时检查完整长度和SHA：

| 文件 | 字节数 | SHA256 |
|---|---:|---|
| result.json | 205865 | `a0c4dd60fddc001f368b71ec283327f2d7fe0874080ac35304e3debe783116d0` |
| inputs.json | 131374 | `1afacb22c143705355ffed93b62824b2a02153e799b003bcc7f92dba1b10c219` |
| final-artifact-pins.json | 18231 | `07d4a614ba2b7fd06652290d266023ae405881578cc370fa86d368086baa3451` |
| overlay-classes.json | 5289 | `f36dd44ef66c0058a73839bfeaacd321cc6ac7d41144c622c38371948375c4bf` |

只接受这次实际33命令、25次exit0及8次注错exit1的闭合记录。两个 prefix SAT 的 expected_exit 为None、实际exit0；保留其独立 PASS、实际SV/gold/gate/script/log身份。旧乘法 miter 继续为 `UNKNOWN_EXTERNAL_TIMEOUT`，不重试，不升级为solver PASS。所有 parent/fullcore/application/corecost 和生产修改标志保持原值。

归档覆盖四棵输入树：实际 WSL `local-01`、Windows根下 `source`、`controller`、`archive-source-01`。执行器在WSL读取Windows对应 `/mnt/d` 路径。所有输入树需真实、规范、互不包含；输出必须为fresh且与任何输入树分离。

## 内容闭合

完整归档已有文件，核对96项由实际固定结果和最终清单给出的本地必要pin。覆盖21份源码快照、23个新编译class、四套各5份实际SV、全部filelist/resource、新prefix两个完整SAT、全部FU正负原始日志和两份实际FU二进制、完整mapper/STA输入输出及结果。完整命令argv、classpaths、原工具和库身份都保留在原JSON/脚本中。已有 `timing.tcl` 和任何实际SDC文件完整保留，不生成原运行没有的文件。

`source` 下3个实际执行输入和 `controller` 下3个实际执行输入必须同时与 `inputs.originals`、local源码快照和固定SHA相同。其他源码差分、审查说明、文字派生工具等也完整运输，但明确标记未由transport获得执行资格。运行前inputs、快照、最终artifact清单及其实际文件前后身份一并保留。

新运行的 `classpath-before.json` 必须存在并全量运输，使用本次inventory得到的真实SHA及前后核验；不假设它重新序列化后仍与旧原始classpath文件字节相同。旧生成classpath SHA `d9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902` 作为独立外部入口保留，不能冒充新文件SHA。

仅允许省略 local-01 的 `fu-feature0/1/obj` 内、没有任何必要pin引用的 `.o`/`.a`。每个省略项仍登记完整路径、长度和SHA，完成后再核原文件未变；编译对象以外的日志、源、class、二进制、失败/注错证据均保留。**不删除、改名、移动任何原件。**

## 外部依赖

旧CSA两次失败和成功continuation已保存在既有归档：

```text
/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-csa-20261107-main/archive-01/raw.zip
```

该ZIP为33360816B，SHA `448c21c5ab692ade045ac21d0c15d5e4a3738a1aa9701b62360f80b1d33bcaa0`。其audit为25748B，SHA `f764483895b7c9cf919e2af9ee41e9c1ba6e2fa7909a45a254b1f3bbacb3b97d`。在新的 `archive-source-01/csa-archive-audit.json` 放一份该audit原字节；helper核对小副本并登记旧ZIP入口，不读取、复制或重新hash旧ZIP。

其local03结果SHA `21510c330817f12c03426ac0ca262331c4ff088d90e33b2be1fefae0c605707a`，local02失败结果SHA `84b752a19a62d6e436d347cdd1273110c6530bd6024c41eecd58fbd8574e450d`。本轮原inputs中的669项跨树旧输入，以及完整原classpath清单，均保留原路径/SHA；复现时按这些入口恢复旧工具、库、生成配方和缓存。归档器不读取外部旧源码或大型依赖内容。

## 运行准备与CLI

首席把以下文件放入新的Windows `runs\dot16-prefix-20261107-main\archive-source-01`：

- `archive_prefix.py`：已审辅助器原件。
- `ARCHIVE_PREFIX_CONTRACT.md`：本合同。
- `receipts.json`：原prefix host回执完整字节；不截断、不改写工程状态整数。helper不猜其JSON字段格式。
- `csa-archive-audit.json`：上述已闭合CSA audit原字节。
- 可同时保存本次helper差分与自检材料；完整树都将归档。

计划CLI：

```sh
python3 -B /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main/archive-source-01/archive_prefix.py \
  --run /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main/local-01 \
  --sources /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main \
  --output /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main/archive-01
```

`archive-01` 必须尚不存在。来源Windows路径由实际 `inputs.originals` 确认是 `source/controller`，不存在 `core-source-01` 的迁移假设。

执行资源：CPU1、absolute nice5、单进程Python、600s总计时器。只需要读取上述WSL local-01、Windows source/controller/archive-source-01及Python系统依赖；唯一写入范围是fresh archive-01。无需读取旧CSA archive、生产工作树、活动forward、旧大缓存或调用EDA/guest。平台外层应为Python异常处理和写失败回执留出有限余量。

## 输出与成功条件

成功输出 `archive-01/raw.zip` 和 `archive-01/audit.json`。ZIP保留四个根的原相对树，并增加 `ARCHIVE-MANIFEST.json`；manifest包含所有成员/目录、省略项、执行pin覆盖、源码对应关系、原资格范围及外部依赖入口。

复用既有 `archive_csa.py` 的完整流式SHA、ZIP压缩、所有成员CRC/长度/SHA回读、无重复成员检查、完成后重新扫描及所有源字节前后比较。成功audit状态为 `PREFIX_RAW_ARCHIVE_VERIFIED`，仅表示运输完整性。任何异常写 `archive-failure.json`，保留部分新输出与全部原件，不自动重试。

本辅助开发自检仅执行AST解析与已取回真实元数据的纯函数检查、少量元数据反例；没有调用archive main、创建ZIP、hash本机原目录或重跑原检查器。最终ZIP大小/SHA、实际成员数和省略总量只能在首席真实执行后报告。
