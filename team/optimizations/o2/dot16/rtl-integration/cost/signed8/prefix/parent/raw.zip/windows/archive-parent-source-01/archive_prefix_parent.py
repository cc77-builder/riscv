#!/usr/bin/env python3
"""Transport the fixed CLOSED prefix parent-01; never run a checker or guest.

Adapted from archive_packed_target.py: complete trees, streaming SHA, whole ZIP
CRC/SHA readback, original-tree after-scan, CPU1/nice5 and finite failure retention.
External original inputs/classpaths are recorded, not opened or rehashed.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import stat
import sys
import time
import zipfile

RUNS = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main')
SOURCES = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main')
CONTRACT = 'dot16-prefix-real-parent-v1'
HOST_OPERATION = '0250d6044ba18f5fd71831ae3131d2ce.e40fda7c58fb6656b3580c4529f40a2f'
UPSTREAM_RESULT_SHA = 'a0c4dd60fddc001f368b71ec283327f2d7fe0874080ac35304e3debe783116d0'
DATAPATH_SHA = '1d02d8a34772e7d9b9947f997f32465f3e946f4b24cacc66159eef7ee10ab3bb'
WRAPPER_SHA = '912c1a038ef8e9a1ac56cfa349161ae1c582d763acfce5352b08ebde2a227f92'
BINARY = 'VVDotElasticParentTestTop'
FAULTS = ('identity', 'rob', 'high', 'metadata', 'wen', 'stall', 'route', 'double',
          'clock', 'occupancy', 'kill_p', 'kill_r', 'survivor', 'duplicate',
          'missing', 'reset', 'perf_input', 'perf_swap', 'perf_parent', 'perf_cross')
QUALIFICATION_FALSE = ('fullcore_qualified', 'application_performance_qualified',
                      'cost_qualified', 'core_cost_qualified', 'performance_measured')
SOURCE_PINS = {
    'prefix_parent.py': '3e0782b47f623e9c8e6837a43d04c32f3ca1f71140adf55bed264bac12e3f3c2',
    'PARENT_CONTRACT.md': 'f556e403231b4b3e17da0e0ca105219684aa6bc4339caa332a4c694ea6b6c553',
    'parent_binding.py': 'eefefaea3ab263b2be754a076dd5d07465bf3392699e217df017da7435921dc7',
}
FIXED_PARENT = {
    'classpath-before.json': (1975228, 'd9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902'),
    'feature0/additional-coverage.json': (8545, 'c2216521c40bd14f7303934952fe156a2490e3c0d01289ff35172b8c41ac8586'),
    'feature0/generated-files.json': (8429, '51aa78171fbfc217e76ee869be9fa1e376e8e7a598256b3f4dfd0e369e86bf0a'),
    'feature0/generation-boundary.json': (5491, 'b6ea38dca7bb62765db251c96bce90e8ac3c5058b0471ace2bcf31fd7adcc731'),
    'feature0/metadata-audit.json': (4341, '2bc1b19def2b8f5491c8cb621d5f42af8023f3658a5bfc714d43eb9c255c4142'),
    'feature1/additional-coverage.json': (73351, '86b520a4f6ca1707c87f1f3b21527df1d635bf2bc72686fff3c4990c100c7a8a'),
    'feature1/generated-files.json': (8429, 'ebc92a33fb0f14742f86f4f72f8e552680c80087e800bffad1d6a6037593c41b'),
    'feature1/generation-boundary.json': (5711, 'e17ca01ce0365596d199d26aefbb1531f67dd282fe7779dfc841ee65b089041c'),
    'feature1/metadata-audit.json': (4341, '2839bbdffdc70520d80105cfb8e22cac2ebb87ed395c69f42876110b280f6b99'),
    'final-artifact-pins.json': (34607, '44b2264e379031be9d77fe8007b6673dacd475d6ca79b419e70969789d8a0ade'),
    'inputs.json': (178536, '96b3e9e7a7679a7a38f258068c58ba5055205d757be47bc763dc967779d4a609'),
    'observed-input-pins.json': (394172, '89f76fc9785dc4d094c096a07bee77c86dccfd620c5189b570e05994f38fd509'),
    'original-checker-tests.log': (4643, 'de2c1405c90041bf2f3b533b7063c68091be884a60cccc9c668c6fbc49f43395'),
    'parent-harness-classes.json': (1171, '42484ab75b0bbfdfae6c6de967df7641ea9a69c8cd2da67488aa94ff4716648b'),
    'result.json': (160379, '03eb17ce008ab0be25b9d46ddf53a237daa2ee912c817be801ba8a80c6deaa8d'),
    'runtime-classpath.json': (18002, 'd6bbcef262102ef786590bf61651379f11f4208a553068423afe736578b9f3a2'),
}
FIXED_ARCHIVE_SOURCE = {
    'archive-census.json': (37846, 'c4ce6902ae27af20c184349b6f695391f4c31901b44c6831ad83bdd2f5d45098'),
    'host-receipt.json': (3552, '1ff510c99e11af6d178032dff6d26c8f457601b1488932d323560f81a6fc33f6'),
}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def input_roots(runs, sources):
    return {'wsl/parent-01': runs / 'parent-01',
            'windows/parent-source-01': sources / 'parent-source-01',
            'windows/archive-parent-source-01': sources / 'archive-parent-source-01'}


def evidence_metadata(runs, sources, result, inputs, final, census, host, features):
    """Bind existing records only; no filesystem reads or functional replay."""
    roots = input_roots(runs, sources); run = runs / 'parent-01'
    archive_source = sources / 'archive-parent-source-01'
    source = sources / 'parent-source-01/source-review/prefix-parent-v1'
    pins, sizes, groups, external = {}, {}, {}, {}

    def local(path):
        path = Path(path)
        need(path.is_absolute() and '..' not in path.parts and
             any(path.is_relative_to(root) for root in roots.values()), 'pin inside one selected closed tree')
        return path

    def span(path, size):
        path = local(path)
        need(type(size) is int and size >= 0 and (path not in sizes or sizes[path] == size), 'consistent original size')
        sizes[path] = size

    def pin(path, digest, group, size=None):
        path = local(path)
        need(re.fullmatch('[0-9a-f]{64}', digest) is not None, 'recorded SHA256')
        need(path not in pins or pins[path] == digest, 'consistent recorded pin')
        pins[path] = digest; groups.setdefault(group, set()).add(path)
        if size is not None:
            span(path, size)

    for name, (size, digest) in FIXED_PARENT.items():
        pin(run / name, digest, 'fixed_parent_records', size)
    for name, (size, digest) in FIXED_ARCHIVE_SOURCE.items():
        pin(archive_source / name, digest, 'fixed_captures', size)
    need(result['contract'] == CONTRACT and result['status'] == 'PREFIX_REAL_PARENT_PASS' and
         result['finished'] and result['parent_qualified'] is True and
         all(result[k] is True for k in ('inputs_unchanged', 'generated_inputs_unchanged',
             'original_classpath_unchanged', 'original_overlay_unchanged', 'all_children_reaped')),
         'fixed terminal parent result and recorded stable inputs/child closure')
    need(all(result[k] is False for k in QUALIFICATION_FALSE) and
         all(result[k] is False for k in ('resident_modified', 'original_cache_modified', 'production_default_changed')) and
         result['new_core_builds'] == result['new_core_runs'] == 0,
         'original parent-only qualification and production boundary retained')
    need(result['cpu_affinity'] == [1] and result['nice'] == 5 and result['budget_seconds'] == 1200 and
         result['upstream_prefix_local'] == str(runs / 'local-01') and
         result['upstream_result_sha256'] == inputs['local_result_sha256'] == UPSTREAM_RESULT_SHA and
         result['candidate_source_sha256'] == DATAPATH_SHA and result['candidate_wrapper_sha256'] == WRAPPER_SHA and
         result['upstream_multiplication_miter_status'] == 'UNKNOWN_EXTERNAL_TIMEOUT',
         'original resources, candidate and upstream UNKNOWN identity retained')
    labels = ['original-checker-tests', 'compile-parent-harness']
    for feature in (0, 1):
        labels += [f'generate-parent-{feature}'] + [f'parent-{feature}-{name}' for name in
            ('lint', 'build', 'positive', 'positive-replay', 'metadata-replay', 'coverage')]
        labels += [f'parent-{feature}-{action}-{fault}' for fault in FAULTS for action in ('inject', 'check')]
    need(len(result['commands']) == 96 and [r['label'] for r in result['commands']] == labels,
         'original 96-command inventory including all 40 injected failures')
    for command in result['commands']:
        inject = '-inject-' in command['label']
        need(command['finished'] and command['reaped'] is True and command['group_absent'] is True and
             type(command['exit_code']) is int and command['exit_code'] == (1 if inject else 0) and
             command['expected_exit'] == (None if inject else 0), 'recorded child closure and original exit semantics')

    need(len(inputs['originals']) == 893 and len(inputs['snapshots']) == 22 and len(final) == 177,
         'actual 893 original inputs, 22 snapshots and 177 final artifacts')
    for path, digest in inputs['originals'].items():
        p = Path(path); normalized = Path(os.path.normpath(p))
        need(p.is_absolute() and re.fullmatch('[0-9a-f]{64}', digest) is not None, 'original dependency identity')
        if any(p.is_relative_to(root) or normalized.is_relative_to(root) for root in roots.values()):
            pin(p, digest, 'archived_original_inputs')
        else:
            external[path] = digest  # Preserve external spellings; never open/resolve them.
    expected_sources = {source / name: digest for name, digest in SOURCE_PINS.items()}
    need(groups['archived_original_inputs'] == set(expected_sources) and len(external) == 890,
         'original input partition: three source originals and 890 external identities')
    for group, mapping in (('snapshots', inputs['snapshots']), ('final_artifacts', final)):
        for path, digest in mapping.items():
            need(Path(path).is_relative_to(run), 'snapshot/final artifact belongs to this parent run')
            pin(path, digest, group)
    for path, digest in expected_sources.items():
        need(pins[path] == digest and inputs['snapshots'][str(run / 'source-snapshot' / path.name)] == digest,
             'three original executed sources equal their snapshots')

    need(census['root'] == str(run) and len(census['records']) == 7, 'actual closed-run census identity')
    records = {row['name']: row for row in census['records']}
    need(len(records) == 7 and set(records) == {'classpath-before.json', 'final-artifact-pins.json',
         'inputs.json', 'observed-input-pins.json', 'parent-harness-classes.json', 'result.json', 'runtime-classpath.json'},
         'all seven captured manifest records')
    for name, row in records.items():
        need((row['bytes'], row['sha256']) == FIXED_PARENT[name], 'census original byte identity')
    need(set(records['final-artifact-pins.json']['keys']) == set(final), 'captured final pin membership')
    class_paths = set(records['parent-harness-classes.json']['keys'])
    need(len(class_paths) == 5 and all(Path(p).is_relative_to(run / 'parent-harness-classes') and p in final
         for p in class_paths), 'all five new parent harness classes retained by final pins')
    top_names, census_dirs = set(), set()
    for item in census['directory_census']:
        name = item['name']; rel = PurePosixPath(name)
        need(len(rel.parts) == 1 and str(rel) == name and name not in ('.', '..') and name not in top_names,
             'unique safe top-level census member')
        top_names.add(name)
        if item['type'] == 'file':
            span(run / name, item['bytes'])
        else:
            need(item['type'] == 'dir' and item['bytes'] is None, 'original census directory')
            census_dirs.add('wsl/parent-01/' + name + '/')
    need(len(top_names) == 108 and len(census_dirs) == 5, '103 original root files and five directories')

    need([r['feature'] for r in result['parent_results']] == [0, 1] and set(features) == {0, 1}, 'both recorded parent features')
    feature_evidence = []
    for row in result['parent_results']:
        feature = row['feature']; folder = run / f'feature{feature}'
        data = features[feature]; generated = data['generated-files.json']
        coverage, audit = data['additional-coverage.json'], data['metadata-audit.json']
        boundary = data['generation-boundary.json']
        binary = folder / 'obj' / BINARY
        need(row['checks_completed'] is True and row['faults'] == list(FAULTS) and
             final[str(binary)] == row['binary_sha256'], 'qualified binary and exact 20 original faults per feature')
        need(row['generation_boundary_report'] == str(folder / 'generation-boundary.json') and
             row['generation_boundary_report_sha256'] == FIXED_PARENT[f'feature{feature}/generation-boundary.json'][1] and
             boundary['contract'] == CONTRACT and boundary['feature'] == feature,
             'actual generation-boundary record identity; no binding checker rerun')
        seen = set()
        need(len(generated) == 58, 'actual full generated-file inventory')
        for item in generated:
            rel = PurePosixPath(item['path'])
            need(str(rel) == item['path'] and not rel.is_absolute() and '..' not in rel.parts and rel.parts and
                 item['path'] not in seen, 'unique safe generated relative path')
            seen.add(item['path']); path = folder / rel
            need(final[str(path)] == item['sha256'], 'generated inventory agrees with final artifact pin')
            pin(path, item['sha256'], 'generated_files', item['bytes'])
        need(coverage['feature'] == feature and coverage['status'] == f'DOT16_PARENT_FEATURE_{feature}_COVERAGE_PASS' and
             {k: v for k, v in coverage.items() if k != 'cases'} == row['coverage'] and
             all(coverage[k] is False for k in ('decode_qualified', 'fullcore_qualified', 'performance_measured')),
             'original coverage record and qualification scope, without rerunning it')
        for path, digest in coverage['inputs'].items():
            need(Path(path).is_relative_to(folder) or Path(path) == run / f'parent-{feature}-positive.log',
                 'coverage raw log is local to this feature')
            need(final[path] == digest, 'coverage raw log matches final pin')
            pin(path, digest, 'coverage_raw_logs')
        need(audit['status'] == 'R3_PERF_PAYLOAD_REPLAY_PASS' and audit['bits'] == 577 and
             audit['new_fullcore'] is False and audit['new_ppa'] is False and
             set(audit['inputs']) == set(coverage['inputs']), 'recorded 577-bit audit remains parent-scoped')
        for path, record in audit['inputs'].items():
            need(record['stored_sha256'] == final[path], 'stored raw audit log identity')
            pin(path, record['stored_sha256'], 'metadata_raw_logs', record['stored_bytes'])
        feature_evidence.append(dict(feature=feature, binary_path=str(binary), binary_sha256=row['binary_sha256'],
            generated_files=len(generated), faults=list(row['faults']), original_checks_completed=True,
            coverage_status=coverage['status'], metadata_status=audit['status'], metadata_bits=audit['bits'],
            generation_boundary_report=row['generation_boundary_report'],
            generation_boundary_report_sha256=row['generation_boundary_report_sha256']))

    need(host['operation_id'] == HOST_OPERATION and host['status'] == 'succeeded' and
         host['shell']['operation_id'] == HOST_OPERATION and host['shell']['status'] == 'succeeded', 'same original host operation')
    outer = host['shell']['result']
    need(outer['exit_code'] == 0 and outer['cleanup_complete'] is True and
         all(outer[k] is False for k in ('timed_out', 'cancelled', 'stdout_truncated', 'stderr_truncated')),
         'complete original host closure and untruncated receipt')
    first, rest = outer['stdout'].split('\n', 1); launch = json.loads(first)
    need(launch['event'] == 'PREFIX_PARENT_LAUNCH' and launch['cpu_affinity'] == [1] and launch['nice'] == 5 and
         launch['output'] == str(run) and launch['source_pins'] == SOURCE_PINS and
         json.loads(rest) == {k: v for k, v in result.items() if k not in ('commands', 'parent_results')},
         'launch identity and host terminal summary match the fixed original result')
    evidence = dict(original_status=result['status'], original_contract=CONTRACT,
        original_parent_qualified=True, original_false_qualifications={k: result[k] for k in QUALIFICATION_FALSE},
        original_multiplication_miter_status=result['upstream_multiplication_miter_status'],
        parent_result_sha256=FIXED_PARENT['result.json'][1], original_started=result['started'], original_finished=result['finished'],
        host_operation_id=HOST_OPERATION, host_started=host['shell']['started_at'], host_finished=host['shell']['updated_at'],
        original_commands=96, original_exit_histogram={'0': 56, '1': 40}, all_recorded_children_closed=True,
        original_input_count=893, archived_original_input_count=3, external_original_input_count=890,
        snapshot_count=22, final_artifact_pin_count=177, features=feature_evidence,
        candidate_source_sha256=DATAPATH_SHA, candidate_wrapper_sha256=WRAPPER_SHA,
        upstream_prefix_local=result['upstream_prefix_local'], upstream_result_sha256=UPSTREAM_RESULT_SHA,
        pin_scope='Original/final/generated pins are historical execution identities; captures are provenance. Other files receive transport hashes only.')
    return pins, sizes, groups, external, census_dirs, evidence


def recorded_evidence(runs, sources):
    run, archive_source = runs / 'parent-01', sources / 'archive-parent-source-01'
    for root, fixed in ((run, FIXED_PARENT), (archive_source, FIXED_ARCHIVE_SOURCE)):
        for name, (size, digest) in fixed.items():
            path = root / name
            need(path.stat().st_size == size and sha(path) == digest, 'fixed original record bytes: ' + name)
    features = {feature: {name: read(run / f'feature{feature}' / name) for name in
        ('generated-files.json', 'additional-coverage.json', 'metadata-audit.json', 'generation-boundary.json')}
        for feature in (0, 1)}
    return evidence_metadata(runs, sources, read(run / 'result.json'), read(run / 'inputs.json'),
        read(run / 'final-artifact-pins.json'), read(archive_source / 'archive-census.json'),
        read(archive_source / 'host-receipt.json'), features)


def scan(roots, pinned):
    # Same real-file/link policy as archive_prefix; no .o/.a or other exclusions.
    kept, omitted, directories = {}, {}, set()
    for namespace, root in roots.items():
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        directories.update((namespace.split('/')[0] + '/', namespace + '/'))
        for path in sorted(root.rglob('*')):
            mode = path.lstat().st_mode
            need(not stat.S_ISLNK(mode), 'archive tree contains a link: ' + str(path))
            name = namespace + '/' + path.relative_to(root).as_posix()
            if stat.S_ISDIR(mode):
                directories.add(name + '/')
                continue
            need(stat.S_ISREG(mode), 'regular archive input: ' + str(path))
            need(name not in kept, 'unique archive name')
            kept[name] = path
    return kept, omitted, directories


def main(a):
    need(sys.dont_write_bytecode, '-B required; frozen source inputs stay read-only')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(os.sched_getaffinity(0) == {1} and os.getpriority(os.PRIO_PROCESS, 0) == 5,
         'actual archive CPU1 and absolute nice5')
    need(a.runs == RUNS and a.sources == SOURCES and a.output == SOURCES / 'archive-parent-01', 'fixed evidence roots and output')
    need(all(p.is_absolute() and p == p.resolve() for p in (a.runs, a.sources, a.output)), 'canonical absolute paths')
    runs, sources, out = a.runs, a.sources, a.output
    roots = input_roots(runs, sources); archive_source = sources / 'archive-parent-source-01'
    need(all(p.is_dir() and not p.is_symlink() and p == p.resolve() for p in roots.values()), 'three canonical closed input trees')
    values = list(roots.values())
    need(all(not p.is_relative_to(q) and not q.is_relative_to(p)
             for i, p in enumerate(values) for q in values[i+1:]), 'disjoint input roots')
    need(not out.exists() and all(not out.is_relative_to(p) and not p.is_relative_to(out) for p in values),
         'fresh output separate from all input trees')
    need(Path(__file__).resolve() == archive_source / 'archive_prefix_parent.py', 'actual helper included in fresh archive source')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone archive owns its finite timer')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 600
    handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM)}
    def interrupted(sig, _frame):
        raise InterruptedError('archive signal/deadline ' + str(sig))
    try:
        for sig in handlers:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 600)
        files, omitted, directories = scan(roots, {})
        pinned, sizes, groups, external, census_dirs, evidence = recorded_evidence(runs, sources)
        inventory = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
        by_path = {path: inventory[name] for name, path in files.items()}
        need(not omitted and len(by_path) == len(files), 'no omitted file or overlapping namespace')
        need(census_dirs <= directories, 'all original top-level directories retained, including empty directories')
        need(all(p in by_path and by_path[p]['sha256'] == digest for p, digest in pinned.items()), 'all recorded local pins retained unchanged')
        need(all(p in by_path and by_path[p]['bytes'] == size for p, size in sizes.items()), 'all original complete file spans')
        manifest = dict(schema=1, evidence=evidence, input_roots={name: str(path) for name, path in roots.items()},
            recorded_pin_counts={key: len(value) for key, value in groups.items()},
            files=inventory, directories=sorted(directories), omitted=omitted,
            omissions_deleted=False, all_selected_closed_tree_files_included=True,
            external_dependencies=dict(original_path_sha256_pins=external,
                classpath_metadata={name: dict(member='wsl/parent-01/' + name, bytes=FIXED_PARENT[name][0],
                    sha256=FIXED_PARENT[name][1]) for name in ('classpath-before.json', 'runtime-classpath.json', 'observed-input-pins.json')},
                upstream_prefix_result=dict(path=str(runs / 'local-01/result.json'), sha256=UPSTREAM_RESULT_SHA),
                policy='External inputs, old source/overlay classes, classpath/cache/tool files are not opened, copied or rehashed; original manifests remain complete.'),
            receipts='windows/archive-parent-source-01/host-receipt.json retained verbatim; original operation is not replayed.',
            scope='ZIP transport only. Original real-parent functional result is preserved; no new functional, fullcore, application, cost, core-cost or performance qualification.',
            cpu_affinity=[1], nice=5, budget_seconds=600)
        raw_manifest = encoded(manifest)
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in sorted(directories):
                z.writestr(name, b'')
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            expected = set(files) | directories | {'ARCHIVE-MANIFEST.json'}
            need(len(z.namelist()) == len(expected) and set(z.namelist()) == expected, 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name in directories:
                need(z.getinfo(name).is_dir() and z.getinfo(name).file_size == 0 and z.read(name) == b'', 'exact directory member')
            for name, record in inventory.items():
                need(not z.getinfo(name).is_dir() and z.getinfo(name).file_size == record['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == record['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted, after_directories = scan(roots, pinned)
        need(after == files and after_omitted == omitted and after_directories == directories, 'closed tree inventory unchanged')
        need(all(path.stat().st_size == inventory[name]['bytes'] and sha(path) == inventory[name]['sha256']
                 for name, path in after.items()), 'all retained source bytes unchanged')
        audit = dict(status='PREFIX_PARENT_RAW_ARCHIVE_VERIFIED', started=started, finished=stamp(),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive), files=len(files),
            members=len(expected), directories=len(directories), raw_kept_bytes=sum(x['bytes'] for x in inventory.values()),
            recorded_pins_verified=len(pinned), recorded_size_checks=len(sizes), recorded_pin_counts=manifest['recorded_pin_counts'],
            omitted_files=0, omitted_bytes=0, member_crc_and_sha_verified=True, empty_directories_retained=True,
            retained_files_unchanged=True, source_membership_unchanged=True, original_files_deleted=False,
            original_recorded_child_closures_checked=True, live_processes_requeried=False,
            external_dependencies_rehashed=False, original_validators_rerun=False,
            new_builds=0, new_eda_runs=0, new_guest_runs=0, source_evidence=evidence,
            input_roots=manifest['input_roots'], external_dependency_count=len(external),
            qualification='Transport integrity only; original parent PASS, fullcore/application/cost/performance false and multiplication UNKNOWN retained.')
        need(time.monotonic() < deadline, 'complete archive within total budget')
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error),
            started=started, finished=stamp(), original_files_retained=True, new_guest_runs=0, new_eda_runs=0)))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('runs', 'sources', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    main(parser.parse_args())
