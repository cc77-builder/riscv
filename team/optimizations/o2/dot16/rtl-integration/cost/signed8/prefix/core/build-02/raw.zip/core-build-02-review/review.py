import os,json,hashlib,stat,subprocess,signal,time
from pathlib import Path
from datetime import datetime,timezone
os.sched_setaffinity(0,{2});os.setpriority(os.PRIO_PROCESS,0,5)
core=Path("/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main/core-build-02");out=Path("/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main/core-build-02-review");fa=Path("/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main/fa-map-feasibility-01")
assert not out.exists() and not fa.exists()
def pin(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
fixed={
'result.json':'06b38d232feda7ea93e3b34d806888163a5abf89de916e63af185d383773a5e2',
'input-lock.json':'01ebfe385c649d14e02f0f1a880dd60f5971cbb92c8219bc4a3a211b198d8ce4',
'generated-files.json':'2bf579a661d390d7c8d734580487c0ccb352e63b684471aa622498bddb102bc3',
'source-snapshot/prefix_core_build.py':'77f0d609f732a54c6376759ea2db1ed4b988945c93d8255bf1221774b8c81081',
'source-snapshot/CORE_BUILD_CONTRACT.md':'e7e86da82eead7092fe5a9d5da6939fc88372821b38c195a5e18b00828d2bec3',
'cwd/build/generated-src/diffstate.h':'6a2ce3ab51893908f74452522ab03c553cf7fa7e8aa25f74ea84d79aa45f044d',
'generate-core.log':'0381b86077928c33eddda3542b21c49c926dc372601f736aba9c5a3e06a325d9',
'cwd/build/emu':'6387d998c3f715a9ced1f44c4410f0f29f76780a96ec15c1830c8828ded6f887'}
pins={n:pin(core/n) for n in fixed}
for n,h in fixed.items():assert pins[n]['sha256']==h,n
record=json.loads((core/'result.json').read_bytes())
assert record['schema']=='dot16-prefix-external-core-build-v1' and record['status']=='PREFIX_CORE_BUILD_COMPLETE'
assert all(record.get(k) is True for k in ('build_completed','inputs_unchanged','all_children_reaped'))
names=['check-inputs-before','generate-core','generate-memory','git-log','git-diff','build-native','check-inputs-after']
assert [x['name'] for x in record['commands']]==names
assert all(x['exit_code']==0 and x['reaped'] and x['group_absent'] for x in record['commands'])
assert record['input_lock_sha256']==fixed['input-lock.json'] and record['generated_manifest_sha256']==fixed['generated-files.json']
assert record['emu']['path']==str(core/'cwd/build/emu') and record['emu']['bytes']==pins['cwd/build/emu']['bytes'] and record['emu']['sha256']==fixed['cwd/build/emu']
assert os.access(core/'cwd/build/emu',os.X_OK)
manifest=json.loads((core/'generated-files.json').read_bytes())
for name in ('cwd/build/emu','cwd/build/generated-src/diffstate.h'):
 rows=[x for x in manifest if x['path']==name];assert len(rows)==1 and rows[0]['bytes']==pins[name]['bytes'] and rows[0]['sha256']==pins[name]['sha256']
groups={19833}|{x['pid'] for x in record['commands']}
live=[]
for p in Path('/proc').iterdir():
 if p.name.isdecimal():
  try:
   fields=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(fields[2]) in groups:live.append(int(p.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
assert not live,live
out.mkdir(exist_ok=False)
copies={}
for n in fixed:
 if n=='cwd/build/emu':continue
 data=(core/n).read_bytes();dst=out/Path(n).name;assert not dst.exists();dst.write_bytes(data);assert pin(dst)==pins[n];copies[dst.name]=dict(source=str(core/n),**pins[n])
for n in ('check-inputs-before.log','check-inputs-after.log'):
 data=(core/n).read_bytes();p=out/n;p.write_bytes(data);assert p.read_bytes()==(core/n).read_bytes();copies[n]=dict(source=str(core/n),**pin(p))
for n in fixed:
 assert pin(core/n)==pins[n],n
audit=dict(status='PREFIX_CORE02_ROOT_IDENTITY_REVIEW',finished=datetime.now(timezone.utc).isoformat(),files=copies,generated_manifest_entries=len(manifest),generated_manifest_total_bytes=sum(x['bytes'] for x in manifest),manifest_all_file_bytes_rehashed=False,actual_emu=pins['cwd/build/emu'],actual_header=pins['cwd/build/generated-src/diffstate.h'],seven_stages_closed=True,recorded_groups_absent=True,selected_sources_unchanged=True,new_build_runs=0,new_emu_runs=0)
(out/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
yosys=Path('/usr/bin/yosys');assert pin(yosys)['sha256']=='dab84e88b53146fe22d675a142de32b1e545ee9b7fe1054238f6220245b24c8d'
fa.mkdir(exist_ok=False);help_records=[]
for label,args in [('version',['-V']),('help',['-Q','-T','-p','help extract_fa; help techmap; help abc'])]:
 t=time.monotonic();p=subprocess.run([str(yosys),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,env=dict(PATH='/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC'),start_new_session=True)
 (fa/(label+'.stdout')).write_bytes(p.stdout);(fa/(label+'.stderr')).write_bytes(p.stderr)
 help_records.append(dict(label=label,argv=[str(yosys),*args],returncode=p.returncode,elapsed_seconds=time.monotonic()-t,stdout=pin(fa/(label+'.stdout')),stderr=pin(fa/(label+'.stderr'))))
fa_audit=dict(status='YOSYS_READ_ONLY_HELP_CAPTURED',time=datetime.now(timezone.utc).isoformat(),yosys=pin(yosys),commands=help_records,new_designs=0,new_synthesis_runs=0,cpu_affinity=sorted(os.sched_getaffinity(0)),nice=os.getpriority(os.PRIO_PROCESS,0))
(fa/'audit.json').write_text(json.dumps(fa_audit,indent=2)+'\n')
print(json.dumps(dict(core_review=audit,help=fa_audit)))
