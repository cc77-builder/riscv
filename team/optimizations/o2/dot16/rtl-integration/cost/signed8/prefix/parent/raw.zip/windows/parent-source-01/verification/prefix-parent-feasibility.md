# prefix 真实父级流程：有限复用审查

**结论：代码上可复用，建议缩减为一次有界父级功能闭合；不能视作给旧控制器换 SHA 即可执行的作业。** 上游输入足够定位候选，主要改动在身份和生成边界，而非新造测试。1200 秒只覆盖运行预算，不含边界设计及失败诊断；是否投入由主端结合目标与资源决定。

## 必须改变的部分

1. 旧 `inline_parent.py` 固定 signed8 的合同、终态、单份 datapath、inputs 和 overlay。新入口须绑定 prefix 完成记录 `a0c4dd60…`、datapath `1d02d8a3…`、wrapper `912c1a03…`、inputs `1afacb22…` 与完整 overlay `f36dd44e…`，并据实际字段核对局部算术/FU、输入稳定及回收结果。不能把原乘法 miter 的 UNKNOWN 写成 SAT PASS。
2. prefix overlay 有 **23 类**：旧13类逐 SHA 保持，增加 CSA、prefix 各3类及 wrapper/status/匿名类4类。需整体优先于基础 classpath；只替算术类会继续用旧 wrapper。原 generation recipe、基础 classpath、两份 helper 和 vectors 的记录身份相同，路径布局也兼容，可保留现有外部 harness 编译方式，无需重编候选算术或改 resident。
3. 原生成断言只允许旧父级集合增加 `VDotSignedByteProduct.sv`，要求 `VDotElastic.sv` 不变并检查8个 inline 实例，现已不适用。实际四组局部生成均只有 wrapper、CSA、Finish19/20、top、extern 五个 SV，没有 Products 或 SignedByteProduct；旧父级则含 Products、Reduce。新合同必须声明 wrapper 的 P 行/R 窄化及后 P prefix 是预期改动，重新定义完整文件集合、实例和黑盒资源合并关系，保留 ClockGate 等原资源。

## 可以原样沿用

两态原 parent source snapshot、harness、派生 C++、10022向量、14组刺激、dot16扩展、59个 checker 自测，以及正例、事务回放、577-bit metadata audit、coverage和全部20项观察负控。C++通过父级公开 IO 检查两槽、ready/valid、时钟、DIV切换、控制和完整结果，未直接依赖旧 P 乘积寄存器表示。仍沿上升沿、同步高有效 valid reset、E2最早响应、无阻塞II1；不增新验收项目。CPU1/nice5、j1、独立输出、进程组回收及前后身份审计也可复用。

## 文本比较风险与停止边界

旧 v1/v2 曾因公共宏头、日志块排列停止；prefix 此次还有真实 wrapper/模块结构变化，不能继续套“其余全部相同”。同一 feature 的现有 FU 与 cost wrapper 已有不同大小和 SHA，故不能把局部 wrapper 全文当作未知父级的固定模板。其 `wrapper_bindings` 比较对象是 CSA 局部 wrapper，并非旧 signed8 父级。

新父级实际文件闭包、Products/Reduce是否消失、资源并集、日志标签/顺序及宏头仍待首次生成观察。运行前应写出有限的预期变化范围；实际超出时保留输出并诊断，不预先增加通用去头、空白归一化或日志放宽。若必须反复增加无依据例外才能继续，宜延后，避免重复三轮文本补丁。既有 CSA/prefix 组合证明可按身份引用，无需为此次父级再跑乘法 SAT 或 EDA。

即使全部通过，也只授予该候选在真实 VFEX4 父级、已解码请求边界下的功能资格；不覆盖译码/重命名/退休、完整整核、生产采用、父级PPA或应用50%收益。

## 已读证据

- `source-review/inline-parent-candidate-v3/inline_parent.py`、`PARENT_CONTRACT.md`：固定输入、生成比较、原套件及资源边界。
- `source-review/inline-parent-inputs/`：两态输入、C++、原生成清单及旧13类 overlay。
- `source-review/prefix-candidate-v1/source/`、`actual-result.json`、`actual-manifests/`：实际源码、四组生成清单、23类 overlay、局部资格；完整 SHA 保存在原件中。
- `verification/optimization-publication-20261107/cost-RESULT.md`：旧 parent-03 与新 prefix 的不同资格范围。

本次仅做 scratch 只读源码/JSON核对及独立辅助复核，写本审查；未调用 ChatPC/Git、构建、仿真或EDA，未修改控制器或冻结输入。
