#!/usr/bin/env python3
"""Transport the one CLOSED prefix local-01 without running any engineering tool.

Adapted from archive_csa.py: full streaming hashes, exact ZIP member readback,
unchanged original-tree audit, CPU1/nice5, a finite timer, and failure retention.
Only rebuildable unpinned FU .o/.a files may be omitted; no original is deleted.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import sys
import time
import zipfile

CONTRACT = 'dot16-csa-prefix-local-v1'
COMPLETE = 'PREFIX_GENERATED_ARITHMETIC_FU_AND_COST_COMPLETE'
FIXED_MANIFESTS = {
    'result.json': (205865, 'a0c4dd60fddc001f368b71ec283327f2d7fe0874080ac35304e3debe783116d0'),
    'inputs.json': (131374, '1afacb22c143705355ffed93b62824b2a02153e799b003bcc7f92dba1b10c219'),
    'final-artifact-pins.json': (18231, '07d4a614ba2b7fd06652290d266023ae405881578cc370fa86d368086baa3451'),
    'overlay-classes.json': (5289, 'f36dd44ef66c0058a73839bfeaacd321cc6ac7d41144c622c38371948375c4bf'),
}
CLASSPATH_SHA = 'd9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902'
RECIPE_SHA = 'ec29dc8725cf3a1c04ea684e2753debc1a9b2a04d37b4adadcdfe96f85ec20d8'
CSA_RESULT_SHA = '21510c330817f12c03426ac0ca262331c4ff088d90e33b2be1fefae0c605707a'
CSA_PREDECESSOR_SHA = '84b752a19a62d6e436d347cdd1273110c6530bd6024c41eecd58fbd8574e450d'
CSA_STRUCTURE_SHA = '9483d70f24876e7c89281e559d3d062355c0787e38a7f3fd7ab9cf36d3cd8ad6'
CSA_MITER_SHA = 'a9175ff5e52888f37d8cf8eeeb1673f6975e32cc8e08687be91f3db2cc845b2b'
CSA_AUDIT_SHA = 'f764483895b7c9cf919e2af9ee41e9c1ba6e2fa7909a45a254b1f3bbacb3b97d'
CSA_ARCHIVE_SHA = '448c21c5ab692ade045ac21d0c15d5e4a3738a1aa9701b62360f80b1d33bcaa0'
CSA_ARCHIVE_BYTES = 33360816
BINARY = 'VVDotElasticFuTestTop'
FAULTS = ('identity', 'wen', 'high', 'cancel')
EXEC_SOURCES = {
    'source': {
        'VDotDatapath.scala': '1d02d8a34772e7d9b9947f997f32465f3e946f4b24cacc66159eef7ee10ab3bb',
        'VDotElastic.scala': '912c1a038ef8e9a1ac56cfa349161ae1c582d763acfce5352b08ebde2a227f92',
        'source-derivation.json': '2c1fd758ba8ebb22537ee1ab776c3e9418331b16d5aa2064ff84163674d61caa',
    },
    'controller': {
        'prefix.py': '8f33f550c9b7e74e8190cb5f5a2cfdcc693a783d86ae905ec3e60c7ad10d148c',
        'PREFIX_CONTRACT.md': '22a4b7b6319f8c97a2f20a02e3c25237bce48d4fd77258ed54172547c493bf40',
        'controller-derivation.json': '1c949287035ec30e1cd4734a527522a22da44a56da3d5bfeb2e46a4def9f73ea',
    },
}
SOURCE_IDENTITIES = {
    'VDotDatapath.scala': ('candidate_source_sha256', EXEC_SOURCES['source']['VDotDatapath.scala']),
    'original-VDotDatapath.scala': ('original_source_sha256', '161df70403fd131a3adf445230ed637dc7ad7c619d05c0a890aa8aa1791546d8'),
    'VDotElastic.scala': ('candidate_wrapper_sha256', EXEC_SOURCES['source']['VDotElastic.scala']),
    'original-VDotElastic.scala': ('original_wrapper_sha256', '63911b937a526b97ddaa67e34526fd19bbd2fa2801eadfda10ae6c2fa4b9fe9e'),
}
OUT_OF_SCOPE = ('parent_qualified', 'fullcore_qualified', 'application_performance_qualified',
                'core_cost_qualified', 'resident_modified', 'original_cache_modified', 'production_default_changed')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def command_labels():
    labels = ['compile-source-overlay'] + [f'generate-{kind}-{feature}'
        for feature in (0, 1) for kind in ('cost', 'fu')]
    labels += ['actual-prefix-19-miter', 'actual-prefix-20-miter']
    for feature in (0, 1):
        labels += [f'fu-{feature}-{step}' for step in ('lint', 'build', 'positive')]
        labels += [f'fu-{feature}-{action}-{fault}' for fault in FAULTS for action in ('inject', 'check')]
    labels += [f'{step}-{feature}' for feature in (0, 1) for step in ('map', 'sta')]
    return labels


def evidence_metadata(run, result, inputs, classes, final_pins):
    """Validate only captured metadata and return required pins; no file I/O."""
    need(run.name == 'local-01' and result['contract'] == CONTRACT and
         result['status'] == COMPLETE and result['finished'], 'the one fixed closed prefix result')
    need(all(result[name] is False for name in OUT_OF_SCOPE) and
         result['new_core_builds'] == result['new_core_runs'] == 0,
         'preserve original qualification and mutation boundary')
    need(all(result.get(name) is True for name in
         ('all_children_reaped', 'inputs_unchanged', 'generated_inputs_unchanged',
          'original_classpath_unchanged', 'arithmetic_equivalent', 'fu_qualified',
          'wrapper_post_p_decode_review_completed', 'local_cost_recorded',
          'arithmetic_proof_completed', 'fu_tests_completed')),
         'recorded completed local arithmetic/FU/cost qualification')
    labels = [row['label'] for row in result['commands']]
    need(labels == command_labels() and len(labels) == 33, 'all 33 actual command labels and order')
    for row in result['commands']:
        injected = '-inject-' in row['label']
        unchecked = injected or row['label'] in ('actual-prefix-19-miter', 'actual-prefix-20-miter')
        need(row.get('reaped') is True and row.get('group_absent') is True and row.get('finished'),
             'recorded command child closure: ' + row['label'])
        need(type(row['exit_code']) is int and row['exit_code'] == (1 if injected else 0) and
             row['expected_exit'] == (None if unchecked else 0), 'recorded actual command exit: ' + row['label'])
    need(Counter(row['exit_code'] for row in result['commands']) == Counter({0: 25, 1: 8}),
         '25 exit0 commands and eight expected exit1 observations')
    need(result['cpu_affinity'] == [1] and result['nice'] == 5 and result['budget_seconds'] == 1200,
         'recorded actual resource profile')
    need(inputs['recipe_sha256'] == RECIPE_SHA and len(inputs['originals']) == 675 and
         len(inputs['snapshots']) == 21 and len(classes) == 23 and len(final_pins) == 88,
         'complete actual before/snapshot/class/final manifests')

    pins, groups, sizes = {}, {}, {}
    def pin(path, digest, group, size=None):
        path = Path(path)
        need(path.is_absolute() and '..' not in path.parts and path.is_relative_to(run),
             'local recorded pin: ' + str(path))
        need(isinstance(digest, str) and len(digest) == 64 and
             all(x in '0123456789abcdef' for x in digest), 'recorded SHA256')
        need(path not in pins or pins[path] == digest, 'consistent recorded pin')
        pins[path] = digest
        groups.setdefault(group, set()).add(path)
        if size is not None:
            need(type(size) is int and size >= 0 and (path not in sizes or sizes[path] == size),
                 'consistent recorded size')
            sizes[path] = size
    for name, (size, digest) in FIXED_MANIFESTS.items():
        pin(run / name, digest, 'record_manifests', size)
    for path, digest in inputs['snapshots'].items():
        pin(path, digest, 'snapshots')
    for path, digest in classes.items():
        need(Path(path).is_relative_to(run / 'overlay-classes'), 'actual new class stays in this run')
        pin(path, digest, 'overlay_classes')
    need([(x['feature'], x['kind']) for x in result['generated']] ==
         [(f, k) for f in (0, 1) for k in ('cost', 'fu')], 'all four actual generated consumers')
    for row in result['generated']:
        rtl = run / f"{row['kind']}-feature{row['feature']}" / 'rtl'
        top = 'CommonFuCostTop' if row['kind'] == 'cost' else 'VDotElasticFuTestTop'
        width = 20 if row['feature'] else 19
        names = {'VDotElastic.sv', 'VDotCarrySaveRows.sv', f'VDotPrefixFinish{width}.sv', top + '.sv', 'extern_modules.sv'}
        need(len(row['files']) == 5 and {Path(x['path']).name for x in row['files']} == names,
             'complete recorded five-SV consumer inventory')
        for item in row['files']:
            rel = PurePosixPath(item['path'])
            need(not rel.is_absolute() and '..' not in rel.parts and (run / rel).parent == rtl,
                 'relative generated source path')
            pin(run / rel, item['sha256'], 'generated_sv', item['bytes'])
        pin(rtl / 'firrtl_black_box_resource_files.f', row['resource_manifest_sha256'], 'resource_manifests')
        pin(rtl / 'filelist.f', row['filelist_sha256'], 'filelists')
    for name in ('fu_results', 'cost_results'):
        need([row['feature'] for row in result[name]] == [0, 1], 'both complete feature records: ' + name)
    for row in result['fu_results']:
        need(row['passed'] is True and row['faults'] == list(FAULTS), 'recorded FU stage and fault inventory')
        pin(run / f"fu-feature{row['feature']}" / 'obj' / BINARY, row['binary_sha256'], 'fu_binaries')
    for row in result['cost_results']:
        folder = run / f"cost-feature{row['feature']}" / 'mapped'
        pin(folder / 'mapped.v', row['mapped_sha256'], 'mapped_outputs')
        pin(folder / 'mapped.json', row['mapped_json_sha256'], 'mapped_outputs')
    for name, (key, digest) in SOURCE_IDENTITIES.items():
        need(result[key] == digest, 'fixed source identity: ' + name)
        pin(run / 'source-snapshot' / name, digest, 'source_identity')
    for entries in EXEC_SOURCES.values():
        for name, digest in entries.items():
            pin(run / 'source-snapshot' / name, digest, 'source_identity')

    need(result['csa_baseline_result_sha256'] == CSA_RESULT_SHA and result['csa_baseline_result_bytes'] == 109822,
         'fixed old CSA result identity')
    for name, digest in {'csa-result.json': CSA_RESULT_SHA, 'csa-arithmetic-structure.json': CSA_STRUCTURE_SHA,
                         'csa-independent-miter.log': CSA_MITER_SHA}.items():
        pin(run / 'source-snapshot' / name, digest, 'reused_csa_proof')
    old = result['independent_miter']
    need(old['status'] == 'UNKNOWN_EXTERNAL_TIMEOUT' and old['retried'] is False and
         old['solver_equivalence_proved'] is False and old['counterexample_found'] is False and
         old['log_sha256'] == CSA_MITER_SHA and result['multiplication_miter_retried'] is False,
         'old multiplication UNKNOWN remains UNKNOWN, never retried or promoted')
    structure = result['arithmetic_structure_proof']
    need(structure['status'] == 'CSA_STRUCTURAL_EQUIVALENCE_PASS' and structure['all_inputs_equivalent'] is True and
         structure['discarded_carries'] == [] and structure['rows_msb_to_lsb']['row0'][0] == "1'b1" and
         structure['rows_msb_to_lsb']['row1'][0] == "1'b0", 'recorded complete reused structural proof scope')
    need([(p['feature'], p['width'], p['row_count']) for p in result['prefix_miters']] ==
         [(0, 19, 2), (1, 20, 4)], 'both actual prefix proof records')
    for proof in result['prefix_miters']:
        feature, width = proof['feature'], proof['width']
        need(proof['status'] == 'PASS' and proof['exit_code'] == 0 and proof['solver_equivalence_proved'] is True and
             proof['unconstrained_inputs'] is True and proof['counterexample_found'] is False and
             proof['retried'] is False and proof['solver_timeout_seconds'] == 30 and
             proof['total_command_budget_seconds'] == 60, 'new prefix solver PASS remains separately scoped')
        for kind in ('cost', 'fu'):
            pin(run / f'{kind}-feature{feature}' / 'rtl' / f'VDotPrefixFinish{width}.sv',
                proof['actual_rtl_sha256'], 'proved_actual_prefix_sv')
        folder = run / f'prefix-proof-{width}'
        for name, key in (('gold.sv', 'gold_sha256'), ('gate.sv', 'gate_sha256'), ('prove.ys', 'script_sha256')):
            pin(folder / name, proof[key], 'prefix_proof_inputs')
        pin(run / f'actual-prefix-{width}-miter.log', proof['log_sha256'], 'prefix_proof_logs')
    before_final = dict(pins)
    for path, digest in final_pins.items():
        pin(path, digest, 'persisted_final_artifact_pins')
    for path, digest in before_final.items():
        if path not in groups['record_manifests'] | groups['mapped_outputs']:
            need(final_pins.get(str(path)) == digest, 'final manifest covers every original recorded artifact')
    need(all(str(run / f'cost-feature{f}' / 'mapped' / name) in final_pins
             for f in (0, 1) for name in ('abc.constr', 'map.ys', 'timing.tcl')),
         'all actual mapping and STA input pins retained')
    return pins, groups, sizes, labels


def recorded_evidence(run):
    for name, (size, digest) in FIXED_MANIFESTS.items():
        need((run / name).stat().st_size == size and sha(run / name) == digest, 'fixed actual manifest: ' + name)
    result, inputs = read(run / 'result.json'), read(run / 'inputs.json')
    pins, groups, sizes, labels = evidence_metadata(run, result, inputs,
        read(run / 'overlay-classes.json'), read(run / 'final-artifact-pins.json'))
    return result, inputs, pins, groups, sizes, labels


def scan(roots, pinned):
    kept, omitted, directories = {}, {}, set()
    for root in roots:
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        directories.add(root.name + '/')
        for path in sorted(root.rglob('*')):
            mode = path.lstat().st_mode
            need(not stat.S_ISLNK(mode), 'archive tree contains a link: ' + str(path))
            rel = path.relative_to(root); name = root.name + '/' + rel.as_posix()
            if stat.S_ISDIR(mode):
                directories.add(name + '/')
                continue
            need(stat.S_ISREG(mode), 'regular archive input: ' + str(path))
            is_cache = (root.name in ('local-01', 'local-02', 'local-03') and len(rel.parts) >= 3 and
                        rel.parts[0] in ('fu-feature0', 'fu-feature1') and rel.parts[1] == 'obj' and
                        path.suffix in ('.o', '.a') and path not in pinned)
            if is_cache:
                omitted[name] = dict(bytes=path.stat().st_size, sha256=sha(path),
                    reason='Rebuildable Verilator object/static-library cache only; original retained.')
            else:
                need(name not in kept, 'unique archive name')
                kept[name] = path
    return kept, omitted, directories


def main(a):
    need(sys.dont_write_bytecode, '-B required; frozen source inputs stay read-only')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(os.sched_getaffinity(0) == {1} and os.getpriority(os.PRIO_PROCESS, 0) == 5,
         'actual archive CPU1 and absolute nice5')
    need(all(p.is_absolute() and p == p.resolve() for p in (a.run, a.sources, a.output)), 'canonical absolute paths')
    run, sources, out = a.run, a.sources, a.output
    archive_source = sources / 'archive-source-01'
    roots = [run, sources / 'source', sources / 'controller', archive_source]
    need(run.name == 'local-01' and all(p.is_dir() and not p.is_symlink() and p == p.resolve() for p in roots),
         'four canonical real input roots')
    need(all(not p.is_relative_to(q) and not q.is_relative_to(p)
             for i, p in enumerate(roots) for q in roots[i+1:]), 'disjoint input roots')
    need(not out.exists() and all(not out.is_relative_to(p) and not p.is_relative_to(out) for p in roots),
         'fresh output separate from all input trees')
    need(Path(__file__).resolve().is_relative_to(archive_source), 'actual helper included in archive-source-01')
    need((archive_source / 'receipts.json').is_file() and (archive_source / 'receipts.json').stat().st_size > 0,
         'complete original host receipt bytes supplied by the caller; no receipt schema guessed')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone archive owns its finite timer')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 600
    handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM)}
    def interrupted(sig, _frame):
        raise InterruptedError('archive signal/deadline ' + str(sig))
    try:
        for sig in handlers:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 600)
        result, inputs, pinned, groups, sizes, labels = recorded_evidence(run)
        csa_audit_path = archive_source / 'csa-archive-audit.json'
        need(csa_audit_path.stat().st_size == 25748 and sha(csa_audit_path) == CSA_AUDIT_SHA,
             'exact copied small audit of the already retained CSA archive')
        csa_audit = read(csa_audit_path)
        need(csa_audit['status'] == 'CSA_RAW_ARCHIVE_VERIFIED' and
             csa_audit['archive_sha256'] == CSA_ARCHIVE_SHA and csa_audit['archive_bytes'] == CSA_ARCHIVE_BYTES and
             csa_audit['source_evidence']['local-03']['result_sha256'] == CSA_RESULT_SHA and
             csa_audit['source_evidence']['local-02']['result_sha256'] == CSA_PREDECESSOR_SHA,
             'existing CSA archive entry covers the reused success and unresolved earlier attempt')
        files, omitted, directories = scan(roots, pinned)
        inventory = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
        by_path = {path: inventory[name] for name, path in files.items()}
        need(all(p in by_path and by_path[p]['sha256'] == digest for p, digest in pinned.items()),
             'every recorded snapshot/generated/mapped/binary/class/proof pin included unchanged')
        need(all(by_path[p]['bytes'] == size for p, size in sizes.items()), 'all recorded original lengths')
        need(all('local-01/' + label + '.log' in files for label in labels),
             'all 33 original compile/generation/SAT/FU-positive/FU-negative/map/STA logs retained')
        need('local-01/classpath-before.json' in files, 'complete actual new classpath record retained')
        for feature in (0, 1):
            for name in ('abc.constr', 'map.ys', 'timing.tcl', 'r2r.rpt', 'i2r.rpt',
                         'r2o.rpt', 'i2o.rpt', 'ready.rpt', 'setup-checks.rpt'):
                need(f'local-01/cost-feature{feature}/mapped/{name}' in files,
                     'all completed mapping/STA constraints and reports retained')
        archived_originals, external_originals = {}, {}
        for path, digest in inputs['originals'].items():
            p = Path(path)
            if any(p.is_relative_to(root) for root in roots):
                need(p in by_path and by_path[p]['sha256'] == digest, 'archived original matches execution pin')
                archived_originals[path] = digest
            else:
                external_originals[path] = digest
        source_audit = {}
        for source_name, expected in EXEC_SOURCES.items():
            source = sources / source_name
            source_files = {name[len(source_name)+1:]: info for name, info in inventory.items()
                            if name.startswith(source_name + '/')}
            need(set(expected) <= set(source_files), 'complete executed ' + source_name + ' set')
            rows = []
            for filename, info in sorted(source_files.items()):
                original_pin = inputs['originals'].get(str(source / filename))
                snapshot = run / 'source-snapshot' / filename
                snapshot_pin = inputs['snapshots'].get(str(snapshot))
                if filename in expected:
                    need(original_pin == snapshot_pin == info['sha256'] == expected[filename] and
                         snapshot in by_path and by_path[snapshot]['sha256'] == info['sha256'],
                         'source equals execution original, snapshot and fixed identity: ' + source_name + '/' + filename)
                rows.append(dict(name=filename, **info, original_input_pin=original_pin,
                    snapshot_pin=snapshot_pin, execution_pinned=original_pin is not None,
                    scope='Original execution input and matching snapshot.' if filename in expected else
                          'Retained review/derivation/helper; no execution qualification inferred from transport.'))
            source_audit[source_name] = dict(execution_run='local-01', files=rows)
        csa_root = Path(result['multiplication_miter_reused_from']).parent
        need(inputs['originals'].get(str(csa_root / 'local-03/result.json')) == CSA_RESULT_SHA,
             'CSA retained dependency location comes from the actual execution input map')
        dependencies = dict(
            csa_archive=dict(path=str(csa_root / 'archive-01/raw.zip'), bytes=CSA_ARCHIVE_BYTES,
                sha256=CSA_ARCHIVE_SHA, audit_path=str(csa_root / 'archive-01/audit.json'),
                audit_bytes=25748, audit_sha256=CSA_AUDIT_SHA,
                audit_copy='archive-source-01/csa-archive-audit.json',
                local03_result_sha256=CSA_RESULT_SHA, local02_result_sha256=CSA_PREDECESSOR_SHA,
                external_archive_read_or_rehashed=False),
            original_input_manifest='local-01/inputs.json', original_external_pins=external_originals,
            classpath_manifest='local-01/classpath-before.json',
            classpath_manifest_sha256=inventory['local-01/classpath-before.json']['sha256'],
            original_generation_classpath_sha256=CLASSPATH_SHA,
            generation_recipe_sha256=RECIPE_SHA,
            policy='Only explicit path/SHA identities and the small CSA audit are retained for external dependencies; no external cache, tool, library or old archive is read/copied/rehashed.')
        evidence = dict(result_sha256=FIXED_MANIFESTS['result.json'][1], result_bytes=205865,
            status=result['status'], contract=result['contract'], commands=33,
            exit_histogram=dict(Counter(str(row['exit_code']) for row in result['commands'])),
            recorded_commands_closed=True, original_inputs=len(inputs['originals']),
            archived_original_inputs=len(archived_originals), snapshots=len(inputs['snapshots']),
            overlay_classes=23, persisted_final_pins=88, recorded_pins=len(pinned),
            original_qualification={key: result[key] for key in
                ('arithmetic_equivalent', 'fu_qualified', 'local_cost_recorded', *OUT_OF_SCOPE,
                 'new_core_builds', 'new_core_runs')},
            prefix_miters=result['prefix_miters'], independent_miter=result['independent_miter'],
            arithmetic_structure_proof_reused_from=result['arithmetic_structure_proof_reused_from'],
            multiplier_miter_retried=False,
            pin_policy='Persisted execution pins checked; every other existing file retained with a transport hash. No validator, SAT, build, STA or guest is rerun.')
        manifest = dict(schema=1, evidence=evidence, source_files=source_audit,
            recorded_pin_counts={key: len(value) for key, value in groups.items()},
            files=inventory, directories=sorted(directories), omitted=omitted,
            omissions_deleted=False, all_existing_original_sources_and_logs_included=True,
            external_dependencies=dependencies,
            receipts='archive-source-01/receipts.json is retained verbatim; no host receipt schema reinterpreted.',
            constraints='All mapped files are retained, including timing.tcl and any existing SDC. No missing constraint file is synthesized.',
            scope='ZIP transport integrity only; old multiplication UNKNOWN remains UNKNOWN. No new correctness, performance, parent, full-core or PPA qualification.',
            cpu_affinity=[1], nice=5, budget_seconds=600)
        raw_manifest = encoded(manifest)
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in sorted(directories):
                z.writestr(name, b'')
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            expected = set(files) | directories | {'ARCHIVE-MANIFEST.json'}
            need(len(z.namelist()) == len(expected) and set(z.namelist()) == expected, 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name in directories:
                need(z.getinfo(name).is_dir() and z.getinfo(name).file_size == 0 and z.read(name) == b'', 'exact directory member')
            for name, record in inventory.items():
                need(not z.getinfo(name).is_dir() and z.getinfo(name).file_size == record['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == record['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted, after_directories = scan(roots, pinned)
        need(after == files and after_omitted == omitted and after_directories == directories, 'closed tree inventory unchanged')
        need(all(path.stat().st_size == inventory[name]['bytes'] and sha(path) == inventory[name]['sha256']
                 for name, path in after.items()), 'all retained source bytes unchanged')
        audit = dict(status='PREFIX_RAW_ARCHIVE_VERIFIED', started=started, finished=stamp(),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive), files=len(files),
            members=len(expected), directories=len(directories), raw_kept_bytes=sum(x['bytes'] for x in inventory.values()),
            recorded_pins_verified=len(pinned), recorded_pin_counts=manifest['recorded_pin_counts'],
            omitted_files=len(omitted), omitted_bytes=sum(x['bytes'] for x in omitted.values()),
            member_crc_and_sha_verified=True, retained_files_unchanged=True, omitted_originals_unchanged=True,
            source_membership_unchanged=True, original_files_deleted=False,
            original_recorded_child_closures_checked=True, live_processes_requeried=False,
            external_dependencies_rehashed=False, original_validators_rerun=False,
            new_builds=0, new_eda_runs=0, new_guest_runs=0, source_evidence=evidence, source_files=source_audit,
            dependency_archive=dependencies['csa_archive'],
            qualification='Transport integrity only; original local prefix qualification and old multiplier UNKNOWN preserved.')
        need(time.monotonic() < deadline, 'complete archive within total budget')
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error),
            started=started, finished=stamp(), original_files_retained=True, new_guest_runs=0, new_eda_runs=0)))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('run', 'sources', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    main(parser.parse_args())
