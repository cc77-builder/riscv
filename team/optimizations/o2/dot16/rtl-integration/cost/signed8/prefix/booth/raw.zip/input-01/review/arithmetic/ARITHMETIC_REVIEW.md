# Booth9 独立算术与 wrapper 审查

2026-11-08，云端有限审查。未访问 PC/Pro/网络，未运行候选生成器、Chisel、EDA 或实际 FU；仅阅读固定源并执行本目录独立整数脚本。结论：**未发现算术或 dot8/dot16 编码阻塞。** 本结论不替代实际生成 SV、FU 和成本验证。

## 固定源码与改动范围

- `source/VDotDatapath.scala`：9711 B / `f0a8bbe58440c6113aa56f848387c6b4e4a487d71ec2832a1e43fca55d3a8245`。
- `source/VDotElastic.scala`：9049 B / `0fcc5df10355ee1e6382678ba40bc9d7ddf830b560dcc469c46e6a6888441556`。
- `derive_source.py` 与 `source-derivation.json` 的身份及父源身份已由 `arithmetic-result.json` 和脚本绑定。独立逆用五项 edits 后，两份源均逐字节恢复 `prefix-pgroup-candidate-01/base/source`；未执行 derive_source。

内部 carry-save 行接口由 19 位改为 20 位，wrapper 数据表示确有变化，不能声称 wrapper 全字节未变。实际差分只有 P 数据宽度、行的扩展方式、低半捕获切片和高半禁用编码。外部 FU 接口、P/R valid、ready/move/flush、控制与 perf 身份、异常屏蔽、复位及停顿断言均保持。旧 `VDotPrefixFinish` 的整个源码后缀逐字相同，SHA256 `6f83e395ffb89690b5eed4325530f0055a431473248a0549746b9c8ed257711f`。

因此 E0 捕获、E1 推进、E2 最早响应和无阻塞 II=1 的控制拓扑保持；这里没有通过新实际 FU 仿真重新授予该资格。

## 独立数学推导

每组 Booth digit 为 `d = -2·high + mid + low`，四组权重为 `1,4,16,64`，正确重构 signed8 乘数。9 位 selected 可以表示 `a` 或 `2a`，范围包含 `-256`。设 `q` 为 selected 按 neg 逐位取反后的 signed9 数，则 `q + neg = a·d`。仅翻转 bit8 后的 unsigned 行值严格等于 `q + 256`。

`a=-128,d=-2` 是关键边界：selected=-256，取反后 q=255；符号位反相的 unsigned 行为 511，独立 neg=1，使行加 neg 为 512，去偏置后得到 +256。neg 若提前加进 9 位并截断会破坏这一边界；当前源将 neg 留在堆的对应列，处理正确。`111` 编码的零 digit 同样需要 neg，不能仅对非零 digit 补偿。

每 lane 偏置为 `256×(1+4+16+64)=21760`。源码常量列 `18,16,14,12,11` 合计 `350208`；故每半 `8×21760+350208=524288=2^19`。两行 unsigned 总和为 `S8+2^19`。S8 的实际范围为 `[-130048,131072]`，这一编码可用 20 位无符号数精确表示。

feature0 逐行截取 low19 后做模19加法，偏置消失，signed19 恢复 S8。feature1 将两个偏置相加得到 `2^20`，模20消失；S16 范围 `[-260096,262144]` 能由 signed20 精确表示。feature1 的 dot8 保存高半 `(2^19,0)`，因此仍正确取消低半偏置，并独立于高半输入。

## 实际执行的轻量检查

命令：`python -B review/arithmetic/check_arithmetic.py`，退出码 0，约 1.04 秒。脚本没有导入或执行候选代码；按已读布尔式建立独立 Python 整数模型，与普通 signed 整数乘法比较。

| 检查 | 已执行范围 | 结果 |
|---|---:|---|
| 单组 digit 乘积 | 256 个 a × 8 个 recode | 全 2048 例相等 |
| signed8 乘数分解 | 256 个 b | 全相等 |
| 完整单 lane 乘法 | 256×256 | 全 65536 例相等 |
| 八 lane 数值堆与逐层守恒 | 49 个均匀边界、8 个单 lane 激励、1024 个固定种子随机向量 | 全 1081 例相等 |
| feature0 / feature1 dot8 | 各 1081 例 | 全等于真实 S8 |
| feature1 dot16 | 1081 对及两个全局极值 | 全 1083 例相等 |

独立堆重建得到 288 FA、20 HA、8 层；每层仅消费上一层位，最终各列至多两位。最终列19为空，列18只有一个位，结构无第20列丢弃路径。正极值得到 dot8=131072、dot16=262144；负极值得到 dot8=-130048、dot16=-260096。

报告还保留三项数学反例供主审定位测试边界：漏 neg 时 `a=-128,d=-2` 得255而非256；feature1 dot8 错存高半全零时，全零输入得 -524288 而非0；仅交换乘数前两 lane 时 `[1,2]·[3,4]` 得10而非11。它们不是本子任务执行 checker 反例注入的声明，主审的 checker 测试另有证据。

## 交付及资格边界

- `check_arithmetic.py`：10317 B / `ccfa4dab5024659ffd9c57a79f84ddeb42a2a1ceeeb760312e6fd7ad57adc9aa`。
- `arithmetic-result.json`：4091 B / `48430b16886e56284ef391617aabae24c8581f5c6addb5339753e004d77d4a9c`。

这是固定源码的独立算术审查与整数模型测试。实际 RTL 生成、与生成结果的绑定、接口及完整两态 FU、综合/时序仍由既定主线验证承担；本审查没有创建新的验收门槛，也没有据静态计数预测 PPA 优势。
