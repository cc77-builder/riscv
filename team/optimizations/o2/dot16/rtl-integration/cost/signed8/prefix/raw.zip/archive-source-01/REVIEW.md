# archive_prefix.py 有限交付审查

交付脚本：`verification/archive_prefix.py`，27680B，SHA256 `953ffe8c8c2880d7093bd6f4b2d493991a08d18f81d59704af6964b684fa9c22`。

本次只编写辅助器并进行云端静态/已取回元数据自检。**未调用归档 main、未创建ZIP、未访问本机、未执行工程工具。**实际归档成功与否须由首席执行后的完整audit决定。

## 从成熟实现保留的部分

基准 `verification/archive_csa.py` SHA `49a842f7e4635c9da1ad682340a4b841bcd6ad33a332ff7799081aae1a12f5d4`。流式hash、scan与6个基础函数、ZIP写入/逐成员完整读回/源后扫描块、timer/signal建立块均与该基准逐字节相同。ZIP块 SHA `e9a5349ecd41b9d0531ae8a86f009e14692c61c098b449cf50c97743a8c4ef7a`。

派生将旧CSA三次运行/四版source，收为唯一prefix local01与source/controller两个真实目录。四份元数据采用实际原字节SHA锚定；保留96项本地执行/产物必要pin。新class由本次overlay拥有，不采用旧CSA跨root class重用分支。原旧CSA结构报告/失败miter在本次快照中已有完整小副本；旧大archive仅登记路径/大小/SHA，并保留25748B小audit副本。

## 自检结果与适用范围

`selfcheck_metadata.py` 用 `-B` 执行，只调用无I/O的 `evidence_metadata()`，输入为首席精确读回的实际result、inputs、final pins及classes JSON。原文件长度/SHA均已核对；其余真实FU binary/SV/class/log仍留在本机，未由本自检读取或重新hash。

实际元数据正例解析通过：33条命令、25次exit0/8次注错exit1、两个prefix SAT的expected_exit=None、21个snapshot、23个class、88项final pins，以及独立4份mapped输出和4份固定manifest，合计96必要pin。所有路径均在原local01内；无.o/.a属于这些必要pin。

8个有限元数据反例均拒绝：旧UNKNOWN被改为PASS、新prefix变UNKNOWN、证明引用错误SV、漏final pin、命令未回收、注错exit码错误、越级parent资格、外部final pin。此处验证metadata约束能拒绝这些错误，不证明本机文件或ZIP已通过运输审计。

独立原生审查者whole2完成实际metadata/pin覆盖和运输尾段复核，未发现其他阻塞。双方识别并修正一个未经实测的raw等同假设：新classpath-before由旧对象重新保存，不能直接给新文件贴旧原始SHA。最终版要求新文件存在，完整运输/前后hash，manifest使用其自身inventory SHA；旧 d9a307…另作为original_generation_classpath_sha256保留。

详细自检回执在 `selfcheck.json`，完整派生差分在 `archive-prefix.diff`。未以结构审查、旧FU PASS或运输hash扩张工程资格；旧乘法UNKNOWN与新prefix SAT PASS分开保留。

## 首席执行前所需准备

按照 `ARCHIVE_PREFIX_CONTRACT.md` 的计划CLI，在Windows对应prefix runs根建立 `archive-source-01`，放入已审helper/合同、原host `receipts.json` 与真实 `csa-archive-audit.json`。后者必须为25748B/`f764483895b7c9cf919e2af9ee41e9c1ba6e2fa7909a45a254b1f3bbacb3b97d`，完整字节可从已经取回的 `source-review/csa-continuation-v4/archive-audit.json` 传输；不要重序列化成不同身份。

资源只需：WSL闭合local01 read；Windows source/controller/archive-source-01 read；Python系统依赖 read；fresh archive-01 write。CPU1/absolute nice5、600s内层计时器；外层保留有限失败回执余量。无需为本helper重新开放旧CSA运行根、旧ZIP、生产RTL、工具chain cache或任何活跃实验目录。

成功将产生 raw.zip、audit.json及ZIP内完整ARCHIVE-MANIFEST。当前没有实际archive大小/SHA/成员数，也没有必要提前猜它们。失败原件与部分新输出保留。
