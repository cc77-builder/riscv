#!/usr/bin/env python3
"""Build one frozen prefix core outside the resident tree; default is plan-only.

The input lock is prepared and reviewed separately. No Mill, scalac, checkout,
resume, simulation, PGO, production patch or automatic retry is performed here.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
BASE = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
REPO = BASE / 'checkout/source'
PREFIX = BASE / 'runs/dot16-prefix-20261107-main'
LOCAL = PREFIX / 'local-01'
GEN = BASE / 'runs/dot16-production-cost-20261107-main/generation-01'
NATIVE = BASE / 'runs/dot16-fullcore-20261106-pro2/native-02'
TEST_CACHE = REPO / 'out/dot16-fu-20261106-pro2/xiangshan/test'
SCHEMA = 'dot16-prefix-external-core-build-v1'
FIXED = {
    str(LOCAL / 'result.json'): 'a0c4dd60fddc001f368b71ec283327f2d7fe0874080ac35304e3debe783116d0',
    str(LOCAL / 'inputs.json'): '1afacb22c143705355ffed93b62824b2a02153e799b003bcc7f92dba1b10c219',
    str(LOCAL / 'overlay-classes.json'): 'f36dd44ef66c0058a73839bfeaacd321cc6ac7d41144c622c38371948375c4bf',
    str(GEN / 'inputs.json'): 'ec29dc8725cf3a1c04ea684e2753debc1a9b2a04d37b4adadcdfe96f85ec20d8',
    str(GEN / 'classpath-before.json'): 'd9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902',
    str(NATIVE / 'build-inputs.json'): '76853412c2c2f27e3e91fbdb0c25b89064023c908d648aa33491372fb5d6231e',
    str(TEST_CACHE / 'runClasspath.json'): '728ce67a49e9b883c7d37eaad0721c34b6d5c930404cbec7976a6b8367a4a4d5',
    str(LOCAL / 'source-snapshot/process_helper.py'): 'db8fc437041c9b3580126ef8498085212313510ce96eb483f21a8c04e17479b3',
    str(LOCAL / 'source-snapshot/classpath_helper.py'): '0214e9a220b905156c9818342832a9226e3b7bfcce2a8f5340f0b659f7c68b7c',
    str(REPO / 'Makefile'): 'dca95c980ef18099f2b847bd7d5974ec2f07ae19933b91ca6f6d31f016f6a0f4',
    str(REPO / 'difftest/Makefile'): '6c64cccbf3b2ffbeca697e2a91cae0eb56a806a9d9dd9a485a1d48a534362535',
    str(REPO / 'difftest/verilator.mk'): 'd731149ba602dfdbf6667208380c14442c7d07e8f804f1de57c150b36e3dca88',
    str(REPO / 'difftest/vcs.mk'): '8cb44cacdf84547a9b65f8d6a5211c968efaa5c8d47e265407e656ddf485b010',
    str(REPO / 'difftest/palladium.mk'): '1b7efb3cb415e2954f837605cab33fc1a075efa06b94359f816ed1fc0bb00663',
    str(REPO / 'difftest/libso.mk'): 'b099c8610b527480b48c21d6ef0eb6c60a0da34ff5113bab4e74a2ee836ed455',
    str(REPO / 'difftest/fpga.mk'): 'e2fa66f399af7aab036142d4afd8c4a021d561e81165bb527a5f43b8a9d78516',
    str(REPO / 'scripts/gen_sep_mem.sh'): '594705f2fb9f2cd38537a52100aea98f394fd4fe2b28b52bdbd5ad59c2fcf733',
    str(REPO / 'scripts/vlsi_mem_gen'): '28442892aa533d5950ee14bd0d6d9afdaecf832e1e9d70f198359faed8a8834e',
}
FLAGS = dict(VDOT_DOT16='1', VDOT_O2_ELASTIC='1', VDOT_T14_FUSED_INPUT='1',
             VDOT_O1_HANDOFF='0', VDOT_O1_TRACE='0', VDOT_O2_TRACE='0',
             VDOT_T12_TRACE='0', VDOT_T13_TRACE='0')
TEST_EXTRAS = (
    REPO / 'difftest/src/test/resources',
    REPO / 'out/dot16-fu-20261106-pro2/difftest/test/compile.dest/classes',
    REPO / 'src/test/resources', TEST_CACHE / 'compile.dest/classes',
)
ARITHMETIC = {
    'VDotCarrySaveRows.sv': '68227036423ff34235b275546dc7d2341fb5e890857e1b9098f4bc070f9545f6',
    'VDotPrefixFinish20.sv': '3ce276e8ea48a36ebbb77e6251d1607c39cc6e7a7b988a38e5cb9a563f4afe5a',
}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def new_output(raw):
    path = Path(raw)
    resolved = path.resolve()
    need(path.is_absolute() and Path(os.path.abspath(path)) == resolved,
         'output must be absolute without symlink parents')
    need(resolved.parent == PREFIX and re.fullmatch(r'core-build-\d{2}', resolved.name),
         'only a new prefix/core-build-NN output is allowed')
    need(not resolved.exists() and not resolved.is_symlink(), 'output already exists; no resume')
    return resolved


def identity(path):
    path = Path(path)
    need(not path.is_symlink(), 'classpath addition cannot be a symlink')
    if not path.exists():
        return dict(path=str(path), type='missing-resource')
    need(path.is_dir(), 'classpath addition must be a directory or absent resource')
    files = []
    for p in sorted(path.rglob('*')):
        need(not p.is_symlink(), 'classpath addition contains a symlink')
        if p.is_file():
            files.append(dict(path=p.relative_to(path).as_posix(), bytes=p.stat().st_size, sha256=sha(p)))
        else:
            need(p.is_dir(), 'classpath addition contains a special file')
    encoded = json.dumps(files, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return dict(path=str(path), type='directory', count=len(files),
                total_bytes=sum(row['bytes'] for row in files),
                files_sha256=hashlib.sha256(encoded).hexdigest())


def make_plan(out, cfg, test_paths, tools, support_root):
    """Pure command construction; called by the cloud self-check too."""
    work, build = out / 'cwd', out / 'cwd/build'
    rtl, tmp = build / 'rtl', out / 'tmp'
    java = [cfg['java_base'][0], '-Xmx8G', '-Xss16m', '-XX:ActiveProcessorCount=1',
            '-XX:+UseSerialGC', '-XX:-UsePerfData', '-Djava.io.tmpdir=' + str(tmp),
            '-XX:ErrorFile=' + str(out / 'hs_err_pid%p.log'),
            '-XX:HeapDumpPath=' + str(out / 'heapdump.hprof')]
    cp = ':'.join([str(LOCAL / 'overlay-classes'), *test_paths])
    java += ['-cp', cp, 'top.SimTop', '--target-dir', str(rtl), '--config', 'MinimalConfig',
             '--issue', 'E.b', '--firtool-opt', '--repl-seq-mem --repl-seq-mem-file=SimTop.sv.conf',
             '--num-cores', '1', '--dump-fir', '--target', 'systemverilog', '--split-verilog',
             '--firtool-opt', '-O=release --disable-annotation-unknown --lowering-options=explicitBitcast,disallowLocalVariables,disallowPortDeclSharing,locationInfoStyle=none',
             '--enable-difftest', '--full-stacktrace']
    native = [tools['make']['path'], '-C', str(REPO / 'difftest'), 'emu',
              'BUILD_DIR=' + str(build), 'NOOP_HOME=' + str(REPO), 'DESIGN_DIR=' + str(REPO),
              'SIM_TOP=SimTop', 'RTL_SUFFIX=sv', 'NUM_CORES=1', 'EMU_THREADS=1',
              'OPT_FAST=-O3', 'OPT_SLOW=-O0', 'EMU_TRACE=0', 'EMU_TRACE_ALL=0', 'EMU_COVERAGE=0', 'EMU_SNAPSHOT=0',
              'WITH_CHISELDB=0', 'WITH_CONSTANTIN=0', 'WITH_ROLLINGDB=0', 'NO_DIFF=0',
              'WITH_DRAMSIM3=0', 'SHOW_SCREEN=0', 'REMOTE=localhost',
              'PGO_WORKLOAD=', 'PGO_CFLAGS=', 'PGO_LDFLAGS=', 'PGO_EMU_ARGS=',
              'FUZZER_LIB=', 'XFUZZ=0', 'FUZZING=0', 'PLDM=0', 'ENABLE_XPROP=0',
              'CXX=' + tools['cxx']['path'], 'CC=' + tools['cc']['path'],
              'LINK=' + shlex.join([tools['cxx']['path'], '--ld-path=' + tools['ld']['path']]),
              'AR=' + tools['ar']['path'], 'SHELL=' + tools['bash']['path'],
              'PYTHON3=' + tools['python']['path'], 'PERL=' + tools['perl']['path'],
              'TIME_CMD=' + shlex.join([tools['time']['path'], '-avp', '-o', str(build / 'time.log')]), '-j1']
    env = {**FLAGS, 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC',
           'PATH': str(Path(tools['verilator']['path']).parent) + ':/usr/bin:/bin',
           'TMPDIR': str(tmp), 'TMP': str(tmp), 'TEMP': str(tmp),
           'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0',
           'CHISEL_FIRTOOL_PATH': str(Path(cfg['firtool_path']).parent),
           'NOOP_HOME': str(REPO),
           'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'}
    return dict(java=java, memory=[tools['bash']['path'], '-e', str(REPO / 'scripts/gen_sep_mem.sh'),
                str(REPO / 'scripts/vlsi_mem_gen'), str(rtl / 'SimTop.sv.conf'), str(rtl)],
                native=native, cwd=str(work), build=str(build), environment=env,
                generation_environment={**env, 'NOOP_HOME': str(work)},
                native_support_root=str(support_root))


def input_bundle(lock_path, expected_sha):
    need(re.fullmatch(r'[0-9a-f]{64}', expected_sha or ''), 'complete input-lock SHA required')
    lock_path = Path(lock_path).resolve()
    need(sha(lock_path) == expected_sha, 'input lock identity changed')
    lock = json.loads(lock_path.read_bytes())
    need(lock['schema'] == SCHEMA and lock['ready'] is True, 'reviewed complete input lock required')
    need(sha(Path(__file__).resolve()) == lock['builder_sha256'], 'builder differs from input lock')
    need(sha(Path(__file__).resolve().with_name('CORE_BUILD_CONTRACT.md')) == lock['contract_sha256'], 'build contract differs from input lock')
    need(lock['fixed'] == FIXED, 'frozen authority map differs')
    pins = {**FIXED, **lock['additional_files']}
    need(not (set(FIXED) & set(lock['additional_files'])), 'additional pins cannot replace fixed authority')
    for name in ('tools.json', 'verilator-support.json', 'compiler-runtime.json'):
        need(str(NATIVE / name) in lock['additional_files'], 'native tool record must be fixed: ' + name)
    need(all(re.fullmatch(r'[0-9a-f]{64}', h or '') for h in pins.values()), 'all inputs need SHA256')
    for path, digest in pins.items():
        need(sha(path) == digest, 'input changed: ' + path)
    cfg = json.loads((GEN / 'inputs.json').read_bytes())
    cached = json.loads((TEST_CACHE / 'runClasspath.json').read_bytes())
    cp_util = module(LOCAL / 'source-snapshot/classpath_helper.py', 'prefix_core_cp')
    test_paths = cp_util.parse_classpath(json.dumps(cached['value']))
    tools = json.loads((NATIVE / 'tools.json').read_bytes())
    support = json.loads((NATIVE / 'verilator-support.json').read_bytes())
    need(cfg['flags'] == FLAGS, 'feature/trace flags differ')
    need(Path(cfg['java_base'][0]).resolve() == Path(tools['java']['path']).resolve() and
         Path(cfg['firtool_path']).resolve() == Path(tools['firtool']['path']).resolve(), 'original generation tools required')
    return lock, cfg, test_paths, tools, support, cp_util, pins


def verify_inputs(lock_path, expected_sha):
    """Run only as a supervised Python child; Git/ldd remain in that group."""
    lock, cfg, test_paths, tools, support, cp_util, pins = input_bundle(lock_path, expected_sha)
    original_cp = json.loads((GEN / 'classpath-before.json').read_bytes())
    original_paths = [item['path'] for item in original_cp]
    overlay = LOCAL / 'overlay-classes'
    overlay_pins = json.loads((LOCAL / 'overlay-classes.json').read_bytes())
    expected_extra = lock['test_classpath_additions']
    need([row['path'] for row in expected_extra] == list(map(str, TEST_EXTRAS)), 'exact four test additions')
    need(all(expected_extra[i]['type'] == 'directory' and expected_extra[i]['count'] > 0 for i in (1, 3)), 'both complete test class directories required')
    need(sha(TEST_CACHE / 'compile.dest/classes/top/SimTop.class') ==
         'ad7fb46505dcf5defeb2c4a04e50cf779925bdb88ac95bae488295731b399238', 'reviewed SimTop test class required')
    removed = {str(REPO / 'vdotElasticFu/compile-resources'), str(REPO / 'vdotElasticFu/src/main/resources'),
               str(REPO / 'out/dot16-fu-20261106-pro2/vdotElasticFu/compile.dest/classes')}
    need(set(test_paths) - set(cfg['run_paths']) == set(map(str, TEST_EXTRAS)) and
         set(cfg['run_paths']) - set(test_paths) == removed, 'only recorded fullcore test classpath delta')
    parent_path = Path(lock['parent_result'])
    need(str(parent_path) in lock['additional_files'], 'parent result must be hash-bound')
    parent = json.loads(parent_path.read_bytes())
    need(parent['status'] == 'PREFIX_REAL_PARENT_PASS' and parent['parent_qualified'] is True and
         parent['all_children_reaped'] is True and
         parent['candidate_source_sha256'] == '1d02d8a34772e7d9b9947f997f32465f3e946f4b24cacc66159eef7ee10ab3bb' and
         parent['candidate_wrapper_sha256'] == '912c1a038ef8e9a1ac56cfa349161ae1c582d763acfce5352b08ebde2a227f92' and
         all(parent.get(k) is True for k in ('inputs_unchanged', 'generated_inputs_unchanged',
             'original_classpath_unchanged', 'original_overlay_unchanged')),
         'completed current prefix parent and unchanged inputs required')
    native = json.loads((NATIVE / 'build-inputs.json').read_bytes())
    need(all(sha(REPO / p) == h for p, h in native['hardware_files'].items()), 'original compiler source inputs changed')
    drivers = native['driver_files'] | native['native_driver_files']
    def helper(suffix, name):
        matches = [Path(p) for p in drivers if p.endswith(suffix)]
        need(len(matches) == 1 and matches[0].is_relative_to(REPO), 'one original helper ' + suffix)
        need(sha(matches[0]) == drivers[str(matches[0])], 'original helper changed')
        sys.path.insert(0, str(matches[0].parent))
        return module(matches[0], name)
    recipe = helper('/o1/build_recipe.py', 'build_recipe')
    source = helper('/build_inputs.py', 'build_inputs')
    live = helper('/live_inputs.py', 'live_inputs')
    runtime = json.loads((NATIVE / 'compiler-runtime.json').read_bytes())
    for path, digest in pins.items():
        need(sha(path) == digest, 'fixed input changed: ' + path)
    source.verify_hardware_files(REPO, native['hardware_files'])
    need(all(sha(REPO / p) == h for p, h in native['candidate_files'].items()), 'resident source candidate changed')
    deps, files = live.dependency_snapshot(REPO)
    need(deps == native['dependencies'] and files == native['dependency_files'], 'original dependency identity changed')
    need(cp_util.classpath_identity(original_paths, REPO) == original_cp, 'base classpath changed')
    need([identity(path) for path in TEST_EXTRAS] == expected_extra, 'fullcore test classes/resources changed')
    need(len(overlay_pins) == 23 and all(Path(p).is_relative_to(overlay) for p in overlay_pins), 'complete23 overlay required')
    need({str(p): sha(p) for p in sorted(overlay.rglob('*')) if p.is_file()} == overlay_pins, 'overlay changed')
    for tool in tools.values():
        need(sha(tool['path']) == tool['sha256'], 'native tool changed')
        if 'payload_path' in tool:
            need(str(Path(tool['path']).resolve()) == tool['payload_path'], 'native tool target changed')
    need(recipe.verilator_support(support['root']) == support, 'Verilator support changed')
    need(recipe.compiler_runtime(tools) == runtime, 'compiler runtime changed')
    head = subprocess.check_output(['/usr/bin/git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    need(head == native['source_head'], 'resident HEAD changed')
    old_emu = native['emu']
    need(Path(old_emu['path']) == REPO / 'build/emu' and sha(old_emu['path']) == old_emu['sha256'], 'old frozen EMU changed')
    print('INPUTS_UNCHANGED')


def run(a):
    entered = time.monotonic()
    if a.execute:
        need(120 <= a.budget_seconds <= 3600, 'build budget must be 120..3600 seconds')
        stop_at = datetime.fromisoformat(a.deadline_utc.replace('Z', '+00:00'))
        need(stop_at.tzinfo is not None, 'deadline requires an explicit timezone')
        remaining = (stop_at - datetime.now(timezone.utc)).total_seconds()
        need(remaining > 0, 'deadline has passed')
        deadline = entered + min(a.budget_seconds, remaining)
    out = new_output(a.output)
    lock, cfg, test_paths, tools, support, cp_util, pins = input_bundle(a.input_lock, a.lock_sha256)
    plan = make_plan(out, cfg, test_paths, tools, support['root'])
    if not a.execute:
        print(json.dumps(dict(mode='PLAN_ONLY_NO_BUILD', output=str(out), **plan), indent=2))
        return
    need(time.monotonic() < deadline, 'deadline exhausted before output creation')
    os.sched_setaffinity(0, {1})
    os.setpriority(os.PRIO_PROCESS, 0, 5)
    out.mkdir()
    work, build = Path(plan['cwd']), Path(plan['build'])
    work.mkdir(); build.mkdir(); (build / 'rtl').mkdir(); (out / 'tmp').mkdir()
    state = dict(schema=SCHEMA, status='PREFLIGHT', started=now(), commands=[],
                 build_completed=False, fullcore_qualified=False,
                 application_performance_qualified=False, ppa_qualified=False,
                 cpu_affinity=[1], nice=5, budget_seconds=a.budget_seconds,
                 deadline_utc=a.deadline_utc, input_lock_sha256=a.lock_sha256)
    util = module(LOCAL / 'source-snapshot/process_helper.py', 'prefix_core_process')
    interrupted = [None]
    def interrupt(sig, frame):
        interrupted[0] = sig
    old_handlers = {sig: signal.signal(sig, interrupt) for sig in (signal.SIGINT, signal.SIGTERM)}
    def check():
        if interrupted[0] is not None:
            raise InterruptedError('received signal ' + str(interrupted[0]))
        need(time.monotonic() < deadline, 'total build deadline exhausted')
    def command(name, argv, cwd=work, env=None):
        check()
        row = dict(name=name, argv=list(map(str, argv)), cwd=str(cwd), started=now())
        state['commands'].append(row)
        proc = None
        try:
            with (out / (name + '.log')).open('wb') as log:
                proc = subprocess.Popen(row['argv'], cwd=cwd, env=env or plan['environment'],
                    stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                row['pid'] = row['pgid'] = proc.pid
                save(out / 'result.json', state)
                while proc.poll() is None:
                    check()
                    try:
                        proc.wait(timeout=min(.25, max(.001, deadline - time.monotonic())))
                    except subprocess.TimeoutExpired:
                        pass
                row['exit_code'] = proc.returncode
                need(proc.returncode == 0, name + ' failed; preserve output')
                need(not util.group_exists(proc.pid), name + ' left descendants')
        finally:
            if proc is not None:
                try:
                    if util.group_exists(proc.pid):
                        row['cleanup_complete'] = util.stop_group(proc)
                finally:
                    row['reaped'] = proc.poll() is not None
                    row['group_absent'] = not util.group_exists(proc.pid)
            row['finished'] = now()
            save(out / 'result.json', state)
        need(row['reaped'] and row['group_absent'], name + ' not fully reaped')
    try:
        (out / 'input-lock.json').write_bytes(a.input_lock.read_bytes())
        need(sha(out / 'input-lock.json') == a.lock_sha256, 'lock snapshot mismatch')
        save(out / 'plan.json', plan)
        snap = out / 'source-snapshot'
        snap.mkdir()
        (snap / 'prefix_core_build.py').write_bytes(Path(__file__).read_bytes())
        need(sha(snap / 'prefix_core_build.py') == lock['builder_sha256'], 'builder snapshot mismatch')
        (snap / 'CORE_BUILD_CONTRACT.md').write_bytes(Path(__file__).with_name('CORE_BUILD_CONTRACT.md').read_bytes())
        need(sha(snap / 'CORE_BUILD_CONTRACT.md') == lock['contract_sha256'], 'contract snapshot mismatch')
        verify_code = "import runpy; m=runpy.run_path(" + repr(str(snap / 'prefix_core_build.py')) + "); m['verify_inputs'](" + repr(str(out / 'input-lock.json')) + ", " + repr(a.lock_sha256) + ")"
        verify_command = [tools['python']['path'], '-B', '-c', verify_code]
        command('check-inputs-before', verify_command)
        state['status'] = 'BUILDING'
        command('generate-core', plan['java'], env=plan['generation_environment'])
        rtl = build / 'rtl'
        need((rtl / 'SimTop.sv').is_file() and (build / 'generated-src').is_dir(), 'complete SimTop and generated-src required')
        for name, digest in ARITHMETIC.items():
            need(sha(rtl / name) == digest, 'generated prefix arithmetic differs: ' + name)
        conf = rtl / 'SimTop.sv.conf'
        names = []
        for line in conf.read_text().splitlines():
            match = re.match(r'^name ([A-Za-z_][A-Za-z0-9_]*) ', line)
            need(match is not None, 'unexpected memory description/name')
            names.append(match[1])
        need(names and len(names) == len(set(names)), 'nonempty unique memory module names')
        command('generate-memory', plan['memory'])
        need(not Path(str(conf) + '.tmp').exists() and all((rtl / (n + '.v')).is_file() for n in names), 'memory generation incomplete')
        command('git-log', ['/usr/bin/git', '--no-pager', '-C', str(REPO), 'log', '-n', '1'])
        command('git-diff', ['/usr/bin/git', '--no-pager', '-C', str(REPO), 'diff', '--no-ext-diff', '--no-textconv'])
        header = (out / 'git-log.log').read_bytes() + (out / 'git-diff.log').read_bytes()
        top = rtl / 'SimTop.sv'
        top.write_bytes(b''.join(b'//' + line + b'\n' for line in header.splitlines()) + top.read_bytes())
        for path in sorted(rtl.glob('*.sv')):
            check()
            body = path.read_bytes().replace(b'$fatal', b'xs_assert_v2(`__FILE__, `__LINE__)')
            path.write_bytes(body.replace(b'$error(', b"$fwrite(32'h80000002, "))
        command('build-native', plan['native'])
        emu = build / 'emu'
        need(emu.is_file() and os.access(emu, os.X_OK), 'no executable new EMU')
        command('check-inputs-after', verify_command)
        need(all(row.get('reaped') and row.get('group_absent') for row in state['commands']), 'all process groups must be absent')
        generated = []
        for path in sorted(build.rglob('*')):
            check(); need(not path.is_symlink(), 'generated output contains a symlink')
            if path.is_file():
                generated.append(dict(path=path.relative_to(out).as_posix(), bytes=path.stat().st_size, sha256=sha(path)))
        save(out / 'generated-files.json', generated)
        check()
        emu_record = dict(path=str(emu), bytes=emu.stat().st_size, sha256=sha(emu))
        manifest_sha = sha(out / 'generated-files.json')
        check()
        state.update(status='PREFIX_CORE_BUILD_COMPLETE', build_completed=True,
                     inputs_unchanged=True, all_children_reaped=True,
                     emu=emu_record,
                     generated_manifest_sha256=manifest_sha)
    except BaseException as error:
        state.update(status='FAILED', error=repr(error), build_completed=False)
        raise
    finally:
        state['finished'] = now()
        save(out / 'result.json', state)
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-lock', type=Path, required=True)
    parser.add_argument('--lock-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--budget-seconds', type=int, default=3600)
    parser.add_argument('--deadline-utc')
    args = parser.parse_args()
    if args.execute and not args.deadline_utc:
        parser.error('--execute requires --deadline-utc')
    run(args)
