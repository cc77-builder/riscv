module Gate(input wire [19:0] a0, input wire [19:0] a1, input wire [19:0] a2, input wire [19:0] a3, input wire [19:0] a4, input wire [19:0] a5, output wire [19:0] result);
VDotPrefixFinish20 actual(.rows_0(a0), .rows_1(a1), .rows_2(a2), .rows_3(a3), .rows_4(a4), .rows_5(a5), .result(result));
endmodule
