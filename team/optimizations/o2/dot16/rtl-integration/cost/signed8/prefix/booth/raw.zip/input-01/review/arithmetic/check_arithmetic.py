#!/usr/bin/env python3
"""Independent bounded integer review; never imports or emits candidate RTL.

This reads the pinned Scala and derivation, models their observed scalar Boolean
equations in Python, and compares against ordinary signed integer products.
It is not Chisel elaboration, generated-SV verification, FU simulation or PPA.
"""
from pathlib import Path
import hashlib
import json
import random
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT.parent / "prefix-pgroup-candidate-01/base/source"
PIN = {
    "derive_source.py": "a6a28232c07ba54dd1a3390da584ef1cffcf158cba5e7090f26da76e9f025e02",
    "source/VDotDatapath.scala": "f0a8bbe58440c6113aa56f848387c6b4e4a487d71ec2832a1e43fca55d3a8245",
    "source/VDotElastic.scala": "0fcc5df10355ee1e6382678ba40bc9d7ddf830b560dcc469c46e6a6888441556",
    "source/source-derivation.json": "72b19ecbc899c0175c86a31e1032607b65897999c17117e2de21f21fac7c7eae",
}
WIDTH = 20
MASK20 = (1 << WIDTH) - 1
HALF_BIAS = 1 << 19
LANE_BIAS = 256 * sum(1 << (2 * g) for g in range(4))
CONSTANT_COLUMNS = (18, 16, 14, 12, 11)
CONSTANT = sum(1 << k for k in CONSTANT_COLUMNS)
LIMITS = (28, 19, 13, 9, 6, 4, 3, 2)


def signed(x, width):
    x &= (1 << width) - 1
    return x - (1 << width) if x & (1 << (width - 1)) else x


def partial(a, high, mid, low):
    """Literal bit equations observed in the pinned Scala, no signed multiply."""
    one = low ^ mid
    two = ((1 ^ high) & mid & low) | (high & (1 ^ mid) & (1 ^ low))
    neg = high
    bits = []
    for bit in range(9):
        a_bit = (a >> min(bit, 7)) & 1
        twice_bit = 0 if bit == 0 else (a >> (bit - 1)) & 1
        q_bit = ((one & a_bit) | (two & twice_bit)) ^ neg
        bits.append(q_bit ^ (bit == 8))
    return bits, neg


def lane_rows(a, b):
    rows = []
    for group in range(4):
        low = 0 if group == 0 else (b >> (2 * group - 1)) & 1
        mid = (b >> (2 * group)) & 1
        high = (b >> (2 * group + 1)) & 1
        bits, neg = partial(a, high, mid, low)
        rows.append((bits, neg))
    return rows


def biased_lane(a, b):
    return sum((sum(bit << j for j, bit in enumerate(bits)) + neg) << (2 * group)
               for group, (bits, neg) in enumerate(lane_rows(a, b)))


def heap_rows(left, right):
    """Numeric heap follows the source schedule; every cut is checked exactly."""
    assert len(left) == len(right) == 8
    columns = [[] for _ in range(WIDTH)]
    for a, b in zip(left, right):
        for group, (bits, neg) in enumerate(lane_rows(a, b)):
            for bit, value in enumerate(bits):
                columns[2 * group + bit].append(value)
            columns[2 * group].append(neg)
    for k in CONSTANT_COLUMNS:
        columns[k].append(1)
    before = sum(sum(col) << k for k, col in enumerate(columns))
    full_count = half_count = dropped = 0
    layer_shapes = []
    for limit in LIMITS:
        nxt = [[] for _ in range(WIDTH)]
        for column, old in enumerate(columns):
            consumed = 0
            while len(old) - consumed + len(nxt[column]) > limit:
                excess = len(old) - consumed + len(nxt[column]) - limit
                n = 3 if excess >= 2 else 2
                assert len(old) - consumed >= n
                x, y = old[consumed:consumed + 2]
                if n == 3:
                    z = old[consumed + 2]
                    total = x + y + z
                    out = x ^ y ^ z
                    carry = (x & y) | ((x ^ y) & z)
                    full_count += 1
                else:
                    total = x + y
                    out = x ^ y
                    carry = x & y
                    half_count += 1
                assert total == out + 2 * carry
                nxt[column].append(out)
                if column + 1 < WIDTH:
                    nxt[column + 1].append(carry)
                else:
                    dropped += carry << WIDTH
                consumed += n
            nxt[column].extend(old[consumed:])
            assert len(nxt[column]) <= limit
        after = sum(sum(col) << k for k, col in enumerate(nxt))
        assert before == after + dropped
        before = after
        dropped = 0
        columns = nxt
        layer_shapes.append([len(c) for c in columns])
    assert all(len(c) <= 2 for c in columns)
    rows = [sum((c[row] if row < len(c) else 0) << bit
                for bit, c in enumerate(columns)) for row in range(2)]
    return rows, {"full_adders": full_count, "half_adders": half_count,
                  "layers": len(LIMITS), "layer_column_heights": layer_shapes}


def main():
    started = time.monotonic()
    for name, h in PIN.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == h, name
    derivation = json.loads((ROOT / "source/source-derivation.json").read_bytes())
    names = ("VDotDatapath.scala", "VDotElastic.scala")
    restored = {n: (ROOT / "source" / n).read_text() for n in names}
    for edit in reversed(derivation["edits"]):
        assert restored[edit["file"]].count(edit["after"]) == 1
        restored[edit["file"]] = restored[edit["file"]].replace(edit["after"], edit["before"], 1)
    assert all(restored[n].encode() == (BASE / n).read_bytes() for n in names)
    candidate = (ROOT / "source/VDotDatapath.scala").read_text()
    baseline = (BASE / "VDotDatapath.scala").read_text()
    marker = "/** Fixed-width modulo sum"
    assert candidate[candidate.index(marker):] == baseline[baseline.index(marker):]
    assert LANE_BIAS == 21760 and CONSTANT == 350208
    assert 8 * LANE_BIAS + CONSTANT == HALF_BIAS

    digit_rows = 0
    for a in range(256):
        for code in range(8):
            high, mid, low = (code >> 2) & 1, (code >> 1) & 1, code & 1
            bits, neg = partial(a, high, mid, low)
            val = sum(bit << k for k, bit in enumerate(bits)) + neg
            digit = -2 * high + mid + low
            assert val == signed(a, 8) * digit + 256, (a, code, val)
            digit_rows += 1
    # Signed radix-4 decomposition checked independently of the multiplication.
    for b in range(256):
        digits = []
        for group in range(4):
            low = 0 if group == 0 else (b >> (2 * group - 1)) & 1
            mid, high = (b >> (2 * group)) & 1, (b >> (2 * group + 1)) & 1
            digits.append(-2 * high + mid + low)
        assert sum(d << (2 * g) for g, d in enumerate(digits)) == signed(b, 8)
    for a in range(256):
        for b in range(256):
            assert biased_lane(a, b) == signed(a, 8) * signed(b, 8) + LANE_BIAS, (a, b)

    rng = random.Random(0xB009)
    pairs = [([a] * 8, [b] * 8) for a in (0, 1, 127, 128, 129, 254, 255)
             for b in (0, 1, 127, 128, 129, 254, 255)]
    for lane in range(8):
        a, b = [0] * 8, [0] * 8
        a[lane], b[lane] = 128, 128
        pairs.append((a, b))
    pairs.extend(([rng.randrange(256) for _ in range(8)], [rng.randrange(256) for _ in range(8)])
                 for _ in range(1024))
    rows_and_sums = []
    shapes = []
    for a, b in pairs:
        expected = sum(signed(x, 8) * signed(y, 8) for x, y in zip(a, b))
        rows, shape = heap_rows(a, b)
        assert sum(rows) == expected + HALF_BIAS
        feature0 = signed(sum(x & ((1 << 19) - 1) for x in rows), 19)
        feature1_dot8 = signed(sum(rows) + HALF_BIAS, 20)
        assert feature0 == feature1_dot8 == expected
        rows_and_sums.append((rows, expected))
        shapes.append(shape)
    assert all(s == shapes[0] for s in shapes)
    assert (shapes[0]["full_adders"], shapes[0]["half_adders"], shapes[0]["layers"]) == (288, 20, 8)
    for (lo, s_lo), (hi, s_hi) in zip(rows_and_sums, reversed(rows_and_sums)):
        assert signed(sum(lo) + sum(hi), 20) == s_lo + s_hi
    # Both extrema are formed explicitly; reversed pairing above is not enough.
    extremes = {}
    for tag, a, b in (("positive", 128, 128), ("negative", 128, 127)):
        rows, _ = heap_rows([a] * 8, [b] * 8)
        s8 = 8 * signed(a, 8) * signed(b, 8)
        got16 = signed(2 * sum(rows), 20)
        assert got16 == 2 * s8
        extremes[tag] = dict(s8=s8, encoded_half=sum(rows), feature0_dot8=signed(sum(rows), 19),
                             feature1_dot8=signed(sum(rows) + HALF_BIAS, 20), feature1_dot16=got16)
    # Mathematical counterexamples, not claimed executions of the RTL checker.
    q_bits, neg = partial(128, 1, 0, 0)
    q_row = sum(bit << k for k, bit in enumerate(q_bits))
    assert q_row == 511 and neg == 1 and q_row + neg == 512
    counterexamples = {
        "drop_negative_digit_plus_one": dict(a=-128, digit=-2, row=511, neg=1,
                                             expected_unbiased_product=256, wrong_without_neg=255),
        "dot8_feature1_save_unbiased_high_zero": dict(low_all_zero=True, saved_low_sum=HALF_BIAS,
                                                     wrong_result=signed(HALF_BIAS, 20), expected=0),
        "swap_only_multiplier_lanes_0_1": dict(a=[1, 2], b=[3, 4], expected=11, wrong=10),
    }
    report = dict(status="INDEPENDENT_INTEGER_REVIEW_PASS", scope="source-pinned arithmetic model only",
                  source_pins=PIN, exact_source_inverse=True, prefix_finish_suffix_byte_equal=True,
                  digit_products_exhaustive=digit_rows, multiplier_decompositions=256,
                  signed8_pairs_exhaustive=65536, actual_integer_heap_vectors=len(pairs),
                  feature0_dot8_cases=len(pairs), feature1_dot8_cases=len(pairs),
                  feature1_dot16_pairs=len(pairs) + 2, shape=shapes[0],
                  constants=dict(lane_bias=LANE_BIAS, eight_lane_bias=8*LANE_BIAS,
                                 half_correction=CONSTANT, half_bias=HALF_BIAS),
                  extremes=extremes, counterexamples=counterexamples,
                  generated_sv_verified=False, chisel_elaborated=False, actual_fu_simulated=False,
                  asic_ppa_verified=False, elapsed_seconds=time.monotonic()-started)
    out = Path(__file__).with_name("arithmetic-result.json")
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("shape", "source_pins")}, indent=2))
    print("RESULT_SHA256", hashlib.sha256(out.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
