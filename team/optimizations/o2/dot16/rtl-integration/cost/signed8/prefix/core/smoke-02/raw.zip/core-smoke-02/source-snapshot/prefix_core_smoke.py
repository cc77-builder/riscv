#!/usr/bin/env python3
"""Run the unchanged six-case dot16 smoke gate on one completed external prefix core."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
BASE = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
REPO = BASE / 'checkout/source'
PREFIX = BASE / 'runs/dot16-prefix-20261107-main'
NATIVE = BASE / 'runs/dot16-fullcore-20261106-pro2/native-02'
IMAGE = NATIVE.parent / 'image-01'
REFERENCE = BASE / 'runs/dot16-nemu-reference-20261106-0105'
HERE = Path(__file__).resolve().parent
BUILDER_SHA = '77f0d609f732a54c6376759ea2db1ed4b988945c93d8255bf1221774b8c81081'
LOCK_SHA = '01ebfe385c649d14e02f0f1a880dd60f5971cbb92c8219bc4a3a211b198d8ce4'
LEGACY_SHA = '363725f7a54ed367c7302108bc73f70266c68674a25a72587aaa04bc80e9e755'
PROBE_SHA = '709fd1d0a130b905da505a6fc1defa660a5c6006ec4572f5384c45d9befd2bdf'
HELPER = PREFIX / 'local-01/source-snapshot/process_helper.py'
HELPER_SHA = 'db8fc437041c9b3580126ef8498085212313510ce96eb483f21a8c04e17479b3'
TOOLS_SHA = 'c1a800e5d7c54f057fb3ee0036b1f3199f07125150cd8df996825ca9faa5dbb8'
IMAGE_STATUS_SHA = 'dac699b691bf75063af179059b5220e67e07d32feaeecb117fad74d8fb5836c7'
IMAGE_SHA = '6f800620b3ed6e504691ef1a060e701d781f2c888765d006a04cf0a4cfce3a49'
FLASH_SHA = 'a3360212cf7bb784119c1719c9258362f8567803601b2359aee2c104864fa994'
BUILD_COMMANDS = ['check-inputs-before', 'generate-core', 'generate-memory', 'git-log',
                  'git-diff', 'build-native', 'check-inputs-after']


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def owned_path(raw, kind, must_exist):
    p = Path(raw)
    need(p.is_absolute() and Path(os.path.abspath(p)) == p.resolve(), 'absolute path without symlink parents required')
    need(p.parent == PREFIX and re.fullmatch(kind + r'-\d{2}', p.name), 'unexpected prefix output path')
    need(not p.is_symlink() and (p.is_dir() if must_exist else not p.exists()), 'directory freshness/type mismatch')
    return p


def build_record(core, expected_sha):
    need(re.fullmatch(r'[0-9a-f]{64}', expected_sha or ''), 'actual complete build-result SHA required')
    path = core / 'result.json'
    need(sha(path) == expected_sha, 'build result changed')
    record = json.loads(path.read_bytes())
    need(record['schema'] == 'dot16-prefix-external-core-build-v1' and
         record['status'] == 'PREFIX_CORE_BUILD_COMPLETE' and
         all(record.get(k) is True for k in ('build_completed', 'inputs_unchanged', 'all_children_reaped')),
         'completed current prefix build required')
    need(record['input_lock_sha256'] == LOCK_SHA and sha(core / 'input-lock.json') == LOCK_SHA,
         'reviewed prefix lock required')
    need([r['name'] for r in record['commands']] == BUILD_COMMANDS and
         all(r.get('exit_code') == 0 and r.get('reaped') is True and r.get('group_absent') is True
             for r in record['commands']), 'build stages were not successful and reaped')
    lock = json.loads((core / 'input-lock.json').read_bytes())
    builder = core / 'source-snapshot/prefix_core_build.py'
    need(lock['builder_sha256'] == BUILDER_SHA and sha(builder) == BUILDER_SHA, 'reviewed builder snapshot required')
    need(sha(builder.with_name('CORE_BUILD_CONTRACT.md')) == lock['contract_sha256'], 'build contract changed')
    emu = core / 'cwd/build/emu'
    need(record['emu']['path'] == str(emu) and emu.is_file() and os.access(emu, os.X_OK), 'wrong or absent external EMU')
    need(emu.stat().st_size == record['emu']['bytes'] and sha(emu) == record['emu']['sha256'], 'external EMU identity changed')
    manifest = core / 'generated-files.json'
    need(sha(manifest) == record['generated_manifest_sha256'], 'generated manifest changed')
    rows = json.loads(manifest.read_bytes())
    header = core / 'cwd/build/generated-src/diffstate.h'
    matches = [r for r in rows if r['path'] == header.relative_to(core).as_posix()]
    need(len(matches) == 1, 'one actual external DiffTest header required')
    need(header.stat().st_size == matches[0]['bytes'] and sha(header) == matches[0]['sha256'], 'generated header changed')
    return record, builder, emu, header


def run(args):
    entered = time.monotonic()
    core = owned_path(args.core_build, 'core-build', True)
    out = owned_path(args.output, 'core-smoke', False)
    need(re.fullmatch(r'[0-9a-f]{64}', args.source_sha256 or '') and sha(Path(__file__)) == args.source_sha256,
         'explicit reviewed smoke source SHA required')
    need(re.fullmatch(r'[0-9a-f]{64}', args.contract_sha256 or '') and
         sha(HERE / 'SMOKE_CONTRACT.md') == args.contract_sha256, 'explicit smoke contract SHA required')
    for path, digest in ((HERE / 'legacy-smoke.py', LEGACY_SHA), (HERE / 'abi_probe.cpp', PROBE_SHA),
                         (HELPER, HELPER_SHA), (NATIVE / 'tools.json', TOOLS_SHA),
                         (IMAGE / 'status.json', IMAGE_STATUS_SHA),
                         (IMAGE / 'dot16-core-smoke.bin', IMAGE_SHA), (IMAGE / 'boot-flash.bin', FLASH_SHA)):
        need(sha(path) == digest, 'fixed input changed: ' + str(path))
    record, builder, emu, header = build_record(core, args.core_result_sha256)
    tools = json.loads((NATIVE / 'tools.json').read_bytes())
    legacy = module(HERE / 'legacy-smoke.py', 'prefix_six_case_legacy')
    ref = REFERENCE / 'feature1-01/build/riscv64-nemu-interpreter-so'
    ref_header, ref_api = REFERENCE / 'inputs/diffstate.h', REFERENCE / 'inputs/reference_api.cpp'
    gate_path = REPO / 'team/optimizations/o1/audit/runtime_gate.py'
    for path, digest in ((ref, legacy.REF_SHA), (ref_header, legacy.REF_HEADER_SHA),
                         (ref_api, legacy.REF_API_SHA), (gate_path, legacy.GATE_SHA)):
        need(sha(path) == digest, 'fixed reference/checker changed: ' + str(path))
    image_status = json.loads((IMAGE / 'status.json').read_bytes())
    need(image_status['status'] == 'DOT16_SMOKE_IMAGE_PASS', 'original six-case image required')
    image_files = []
    for name, digest in image_status['files'].items():
        need(Path(name).name == name and sha(IMAGE / name) == digest, 'image artifact changed')
        image_files.append(IMAGE / name)
    cases = legacy.audit_elf((IMAGE / 'dot16-core-smoke.txt').read_text(), (IMAGE / 'symbols.txt').read_text())
    need(cases == image_status['compiled_cases'], 'unchanged actual image instruction checks required')
    blocks = legacy.architectural_blocks(header.read_text())
    need(blocks == legacy.architectural_blocks(ref_header.read_text()), 'actual architectural ABI field blocks differ')
    cxx = tools['cxx']['path']
    need(sha(cxx) == tools['cxx']['sha256'], 'fixed ABI compiler changed')
    inputs = [core / 'result.json', core / 'input-lock.json', core / 'generated-files.json', builder,
              builder.with_name('CORE_BUILD_CONTRACT.md'), emu, header, ref, ref_header, ref_api, gate_path,
              NATIVE / 'tools.json', IMAGE / 'status.json', *image_files, Path(__file__),
              HERE / 'SMOKE_CONTRACT.md', HERE / 'legacy-smoke.py', HERE / 'abi_probe.cpp', HELPER, Path(cxx)]
    frozen = {str(p): sha(p) for p in inputs}
    argv = [str(emu), '-i', str(IMAGE / 'dot16-core-smoke.bin'), '--flash=' + str(IMAGE / 'boot-flash.bin'),
            '--ram-size=128MB', '--diff=' + str(ref), '--max-cycles=300000', '--seed=1']
    if not args.execute:
        print(json.dumps(dict(status='PLAN_ONLY_NO_SMOKE', core_build=str(core), output=str(out),
              argv=argv, core_result_sha256=args.core_result_sha256, runtime_inputs=frozen), indent=2))
        return
    need(120 <= args.budget_seconds <= 1200, 'total smoke budget must be 120..1200 seconds')
    stop = datetime.fromisoformat(args.deadline_utc.replace('Z', '+00:00'))
    need(stop.tzinfo is not None, 'explicit timezone required')
    remaining = (stop - datetime.now(timezone.utc)).total_seconds()
    deadline = min(entered + args.budget_seconds, time.monotonic() + remaining)
    need(time.monotonic() < deadline, 'smoke deadline exhausted before output creation')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    out.mkdir(); (out / 'tmp').mkdir(); (out / 'source-snapshot').mkdir()
    for path in (Path(__file__), HERE / 'SMOKE_CONTRACT.md', HERE / 'legacy-smoke.py', HERE / 'abi_probe.cpp', HELPER):
        (out / 'source-snapshot' / path.name).write_bytes(path.read_bytes())
        need(sha(out / 'source-snapshot' / path.name) == frozen[str(path)], 'source snapshot mismatch')
    state = dict(schema='dot16-prefix-external-core-smoke-v1', status='RUNNING', started=now(), commands=[],
                 core_build=str(core), core_result_sha256=args.core_result_sha256, cpu_affinity=[1], nice=5,
                 fullcore_smoke_qualified=False, fullcore_qualified=False, application_performance_qualified=False,
                 ppa_qualified=False, qualification_scope='one unchanged six-legal-case image; no G3/illegal/performance transfer')
    save(out / 'runtime-inputs.json', frozen)
    save(out / 'abi-type-blocks.json', blocks)
    util = module(out / 'source-snapshot/process_helper.py', 'prefix_smoke_process')
    gate = module(gate_path, 'prefix_smoke_runtime_gate')
    env = dict(PATH='/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8', TZ='UTC',
               PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', NOOP_HOME=str(REPO),
               TMPDIR=str(out / 'tmp'), TMP=str(out / 'tmp'), TEMP=str(out / 'tmp'), OMP_NUM_THREADS='1')
    interrupted = [None]
    def interrupt(sig, frame):
        interrupted[0] = sig
    old_handlers = {sig: signal.signal(sig, interrupt) for sig in (signal.SIGINT, signal.SIGTERM)}
    def check(limit=None):
        need(interrupted[0] is None, 'interrupted')
        need(time.monotonic() < (deadline if limit is None else min(deadline, limit)), 'smoke deadline exhausted')
    def command(name, command_argv, budget):
        row = dict(name=name, argv=list(map(str, command_argv)), cwd=str(out), started=now(), budget_seconds=budget)
        state['commands'].append(row); proc = None
        stage_deadline = min(deadline, time.monotonic() + budget)
        try:
            check(stage_deadline)
            with (out / (name + '.log')).open('wb') as log, (out / (name + '.stderr')).open('wb') as err:
                proc = subprocess.Popen(row['argv'], cwd=out, env=env, stdout=log, stderr=err, start_new_session=True)
                row['pid'] = row['pgid'] = proc.pid; save(out / 'result.json', state)
                while proc.poll() is None:
                    check(stage_deadline)
                    try:
                        proc.wait(timeout=min(.25, max(.001, stage_deadline-time.monotonic())))
                    except subprocess.TimeoutExpired:
                        pass
                check(stage_deadline)
                row['exit_code'] = proc.returncode
                need(proc.returncode == 0, name + ' failed')
                need(not util.group_exists(proc.pid), name + ' left descendants')
        finally:
            if proc is not None:
                try:
                    if util.group_exists(proc.pid):
                        row['cleanup_complete'] = util.stop_group(proc)
                finally:
                    row['reaped'] = proc.poll() is not None
                    row['group_absent'] = not util.group_exists(proc.pid)
            row['finished'] = now(); save(out / 'result.json', state)
        need(row['reaped'] and row['group_absent'], name + ' not fully reaped')
    try:
        code = 'import runpy; m=runpy.run_path(' + repr(str(builder)) + "); m['verify_inputs'](" + repr(str(core / 'input-lock.json')) + ', ' + repr(LOCK_SHA) + ')'
        verify = [tools['python']['path'], '-B', '-c', code]
        command('check-inputs-before', verify, 300)
        includes = [header.parent, REPO / 'difftest/config', REPO / 'difftest/src/test/csrc/common',
                    REPO / 'difftest/src/test/csrc/difftest', REPO / 'difftest/src/test/csrc/plugin/include']
        command('abi-build', [cxx, '-std=c++17', '-DNUM_CORES=1', '-Wno-invalid-offsetof',
                 *['-I' + str(p) for p in includes], str(out / 'source-snapshot/abi_probe.cpp'), '-o', str(out / 'abi-probe')], 120)
        command('abi-run', [str(out / 'abi-probe')], 30)
        abi = json.loads((out / 'abi-run.log').read_bytes())
        need(abi == legacy.EXPECTED_ABI, 'actual new EMU register-copy ABI differs')
        save(out / 'abi-layout.json', abi)
        command('emulator', argv, 600)
        raw = (out / 'emulator.stderr').read_bytes() + (out / 'emulator.log').read_bytes()
        (out / 'run.log').write_bytes(raw)
        checked = legacy.runtime_gate(raw.decode('utf-8', errors='strict'), ref, gate)
        command('check-inputs-after', verify, 300)
        for path, digest in frozen.items():
            need(sha(path) == digest, 'smoke runtime/source input changed: ' + path)
            check()
        need(all(r.get('reaped') and r.get('group_absent') for r in state['commands']), 'all process groups must be absent')
        runtime_inputs_sha = sha(out / 'runtime-inputs.json')
        log_shas = {n: sha(out / n) for n in ('emulator.log', 'emulator.stderr', 'run.log')}
        check()
        state.update(status='PREFIX_FULLCORE_SIX_CASE_SMOKE_PASS', fullcore_smoke_qualified=True,
                     inputs_unchanged=True, all_children_reaped=True, checks=checked, abi_layout=abi,
                     emu=record['emu'], runtime_inputs_sha256=runtime_inputs_sha, raw_logs_sha256=log_shas)
    except BaseException as error:
        state.update(status='FAILED', error=repr(error), fullcore_smoke_qualified=False)
        raise
    finally:
        state['finished'] = now(); save(out / 'result.json', state)
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--core-build', type=Path, required=True)
    p.add_argument('--core-result-sha256', required=True)
    p.add_argument('--source-sha256', required=True)
    p.add_argument('--contract-sha256', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--budget-seconds', type=int, default=1200)
    p.add_argument('--deadline-utc')
    args = p.parse_args()
    if args.execute and not args.deadline_utc:
        p.error('--execute requires --deadline-utc')
    run(args)
