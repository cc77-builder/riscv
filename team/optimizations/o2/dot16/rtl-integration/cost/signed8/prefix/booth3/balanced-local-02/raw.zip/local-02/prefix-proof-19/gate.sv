module Gate(input wire [18:0] a0, input wire [18:0] a1, input wire [18:0] a2, output wire [18:0] result);
VDotPrefixFinish19 actual(.rows_0(a0), .rows_1(a1), .rows_2(a2), .result(result));
endmodule
