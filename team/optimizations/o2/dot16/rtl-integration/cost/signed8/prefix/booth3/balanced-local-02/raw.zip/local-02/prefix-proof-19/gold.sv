module Gold(input wire [18:0] a0, input wire [18:0] a1, input wire [18:0] a2, output wire [18:0] result);
assign result=a0+a1+a2;
endmodule
