# prefix 真实父级闭合记录独立复核

**结论：所读原始记录内部一致，支持本次 `PREFIX_REAL_PARENT_PASS` 的有限父级功能结论；未发现应推翻该结论的不一致。** 此判断直接依据本次 result、两态生成/metadata/coverage记录和 checker 日志，不沿用准备阶段的源码审查结论。

主记录为 `result.json`，160,379 B，SHA256 `03eb17ce008ab0be25b9d46ddf53a237daa2ee912c817be801ba8a80c6deaa8d`。记录窗口为 **2026-11-07 23:27:08.814020—23:41:17.676913 UTC**，848.862893秒，小于1200秒预算；CPU affinity `[1]`、nice 5。

## 命令与回收

- 2条公共命令＋两态各47条，共 **96条**，labels唯一、时间有序且无重叠，单项均在自身预算内。最长 feature1 build 为257.221993秒，预算300秒。
- 共 **56个 exit 0、40个注错 exit 1**。两态各20类原观察负控，fault、feature、目标binary、日志及紧随的分类checker逐项对应；这些注错命令的 `expected_exit` 实际为 null，由随后携带 `--return-code 1` 的checker成功返回0来确认分类，不能写成runner直接设置 expected_exit=1。
- 每条均记录 `reaped=true`、`group_absent=true`。命令记录没有 `cleanup_complete` 字段，不把缺省解释为失败或自行补造该字段。
- 完整读取 `original-checker-tests.log`：59项均ok，14项NegativeGateTests＋45项TraceTests，末尾为 `Ran 59 tests … OK`。这是原checker自测，不能与父级事务数混为一类覆盖。

## 事务与覆盖闭合

| 项目 | feature0 | feature1 |
| --- | ---: | ---: |
| 原套件周期 / 分组 | 38,602 / 14 | 39,100 / 14 |
| 接受 | 14,781 | 14,931 |
| 响应＋取消＋复位丢弃 | 14,292＋426＋63 | 14,414＋446＋71 |
| 新增接受 | 16 | 166 |
| 新增响应＋取消＋复位丢弃 | 16＋0＋0 | 138＋20＋8 |
| metadata walking-one / zero | 577 / 577 | 577 / 577 |

两态总账及三个FU各自的接受/终止账均闭合。metadata audit、coverage原summary及result内嵌coverage逐项相符；两份audit与coverage引用的positive/metadata日志SHA相同。所有新增case的实际终止原因等于预期，latency等于记录周期差。feature1的64个混合stream均为2周期响应，63个相邻接受间隔均为1，并记录8个新增reset状态case。该结论限这些功能刺激，不扩写成任意阻塞条件下固定2周期或应用性能结论。

## 实际生成边界

根据新旧固定生成清单逐项比较，两态各有56个SV/V；恰好删除 Products/Reduce，新增CSA及对应Finish19/20，既有变化仅为 wrapper、LogPerf、extern；**其余各51件大小/SHA保持**。ClockGate、DIV及父级其他文件落在保持集合内。新清单各58项还包含资源表和filelist；资源内容的合法性来自已执行控制器的有限检查，本复核未另打开这两份清单文件所指的完整raw树。

两态boundary报告的SHA与result引用相符；新wrapper SHA分别为 `9e56153c…`、`fca9bf42…`，与生成清单一致。记录显示公开接口、102项有序非数据更新右值和941位shadow的有限比较通过；R为19/20位，符号分别扩展13/12位后与高96位零组成架构输出。feature1实际记录唯一 `fuOpType==9'h1` 条件、四条19位P row及正确20位符号扩展；CSA和Finish的SHA与已验证局部模块相同。

两态LogPerf均改变了三个对象标签和块顺序，但记录的逐块比较SHA、区域外SHA与既有v3规则相符；同时报错时日志顺序可能改变，不能称全部文本逐字不变。wrapper比较也明确仅覆盖接口、更新右值和封闭数据接线，不是所有if/clock guards或完整顺序formal证明。

## 身份与剩余范围

受测源对仍为 datapath `1d02d8a3…` / wrapper `912c1a03…`，上游prefix结果 `a0c4dd60…`。result的输入、生成物、完整overlay、基础classpath稳定及全部子进程回收字段均为true；这是本次执行记录的闭合声明，本复核未重扫原机器输入、类目录或实时进程。

仅 `parent_qualified=true`。fullcore、application、此次cost/core-cost/performance均为false；resident/cache/default未改，新增整核构建/运行均为0；原乘法 miter仍为 `UNKNOWN_EXTERNAL_TIMEOUT`。因此不能据本次结果宣称prefix已替换旧EMU、已完成整核/译码/退休验证、父级PPA或应用50%改善。

本次完整读取所给10份原件，并核对结果引用、生成清单、统计及范围；没有逐一打开全部原始执行日志、SV全文、binary或完整输入pins，也没有执行新测试。完整raw归档尚待主端处理，本复核不宣称ZIP或逐成员运输核验完成。除本REVIEW外，原件保持只读。
