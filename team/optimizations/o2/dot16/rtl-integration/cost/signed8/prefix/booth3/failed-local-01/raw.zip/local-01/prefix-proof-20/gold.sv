module Gold(input wire [19:0] a0, input wire [19:0] a1, input wire [19:0] a2, input wire [19:0] a3, input wire [19:0] a4, input wire [19:0] a5, output wire [19:0] result);
assign result=a0+a1+a2+a3+a4+a5;
endmodule
