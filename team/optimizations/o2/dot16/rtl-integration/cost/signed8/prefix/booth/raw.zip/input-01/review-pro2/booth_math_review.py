"""Finite arithmetic/heap checks only; not an RTL checker or implementation.

Compare the proposed 10-bit complemented Booth row with a 9-bit row
whose negation carry remains an independent heap bit.
"""
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/f9116701fd09/verification/prefix-pgroup-candidate-01/base/source')
DIGITS = (0, 1, 1, 2, -2, -1, -1, 0)
LIMITS = (63, 42, 28, 19, 13, 9, 6, 4, 3, 2)

def recode(raw_b):
    return [DIGITS[((raw_b << 1) >> (2*j)) & 7] for j in range(4)]

def row(a, digit, bits, negative_zero=False):
    # No local addition or truncation of the separate correction bit.
    magnitude = a * abs(digit)
    negate = int(digit < 0 or (digit == 0 and negative_zero))
    encoded = (magnitude & ((1 << bits)-1)) ^ (((1 << bits)-1) if negate else 0)
    biased_row = encoded ^ (1 << (bits-1))
    return biased_row, negate

def heap(bits, bias_target):
    width = bias_target.bit_length()
    cols = [0]*width
    for lane in range(8):
        for j in range(4):
            for k in range(bits):
                cols[2*j+k] += 1
            cols[2*j] += 1  # Separate negative correction bit.
    row_bias = (1 << (bits-1))*85*8
    correction = bias_target-row_bias
    assert correction >= 0
    for k in range(width):
        cols[k] += (correction >> k) & 1
    initial = cols[:]
    stages=[]
    for limit in LIMITS:
        nxt=[0]*width
        fas=has=0
        for k in range(width):
            remain=cols[k]
            while remain+nxt[k] > limit:
                full=(remain+nxt[k]-limit >= 2)
                count=3 if full else 2
                assert remain >= count
                remain-=count
                nxt[k]+=1
                if k+1<width: nxt[k+1]+=1
                fas+=full
                has+=not full
            nxt[k]+=remain
            assert nxt[k]<=limit
        if fas or has: stages.append({'limit':limit,'fa':fas,'ha':has,'max_height':max(nxt)})
        cols=nxt
    assert max(cols)<=2
    return {'width':width,'initial_bits':sum(initial),'initial_heights':initial,
            'bias_constant':correction,'bias_constant_hex':hex(correction),
            'active_levels':len(stages),'fa':sum(s['fa'] for s in stages),
            'ha':sum(s['ha'] for s in stages),'stages':stages,'final_heights':cols}

def main():
    records={}
    for bits in (9,10):
        count=0
        per_lane_bias=(1 << (bits-1))*85
        minimum=10**9; maximum=-10**9
        negative_zero_terms = 0
        for raw_b in range(256):
            b=raw_b if raw_b<128 else raw_b-256
            digits=recode(raw_b)
            assert sum(d << (2*j) for j,d in enumerate(digits))==b
            for a in range(-128,128):
                total=0
                for j,d in enumerate(digits):
                    r,n=row(a,d,bits)
                    assert r+n == a*d+(1 << (bits-1))
                    # The cheaper raw sign control b[2j+1] can encode 111
                    # as complemented zero plus one; both choices are exact.
                    triplet = ((raw_b << 1) >> (2*j)) & 7
                    rz,nz=row(a,d,bits,negative_zero=(triplet==7))
                    assert rz+nz == r+n
                    negative_zero_terms += (triplet==7)
                    total += (r+n) << (2*j)
                assert total == a*b+per_lane_bias
                minimum=min(minimum,total)
                maximum=max(maximum,total)
                count+=1
        records[str(bits)]={'signed8_pairs':count,'per_lane_bias':per_lane_bias,
                            'raw_sign_negative_zero_terms_checked':negative_zero_terms,
                            'per_lane_biased_min':minimum,'per_lane_biased_max':maximum,
                            'target_2pow19':heap(bits,1<<19)}
    # Eight-lane and sixteen-lane composition follows from additive identities.
    sum8_range=[8*(-128*127),8*(-128*-128)]
    sum16_range=[2*x for x in sum8_range]
    identity_checks=[]
    for low in (sum8_range[0], -1, 0, 1, sum8_range[1]):
        for high in (sum8_range[0], -1, 0, 1, sum8_range[1]):
            for dot16 in (False,True):
                true=low+(high if dot16 else 0)
                current=((low+(1<<19))+((high if dot16 else 0)+(1<<19)))&((1<<20)-1)
                alt=(((low+(1<<18))+((high if dot16 else 0)+(1<<18)))&((1<<20)-1))^(1<<19)
                assert current==alt==(true&((1<<20)-1))
                identity_checks.append([low,high,dot16])
    files={n:{'bytes':len((BASE/n).read_bytes()),'sha256':hashlib.sha256((BASE/n).read_bytes()).hexdigest()}
           for n in ('VDotDatapath.scala','VDotElastic.scala')}
    print(json.dumps({'status':'FINITE_ARITHMETIC_AND_COUNT_MODEL_PASS',
                      'scope':'No RTL elaboration/simulation/EDA or new qualification',
                      'sources':files,'rows':records,'sum8_range':sum8_range,'sum16_range':sum16_range,
                      'alternative_9bit_row_19bit_heap':heap(9,1<<18),
                      'composed_mode_corner_checks':len(identity_checks),
                      'bad_local_9bit_add_counterexample':{'a':-128,'digit':-2,'row':511,'neg':1,
                          'correct_biased_term':512,'wrong_truncated_term':(511+1)&511},
                      'bad_zero_high_half_counterexample':{'dot8_low_true_sum':0,
                          'wrong_signed20_with_high_rows_zero':-(1<<19),'correct_result':0},
                      'caveat':'Count model matches fixed schedule only; not mapped area, timing or switching power.'},indent=2))

if __name__=='__main__': main()
