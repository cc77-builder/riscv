# FA 同一映射点：显式名称双射后的有限 STA 续接

合同 `dot16-fa-explicit-bijection-sta-resume-v1`。只对既有 prefix feature1 的同一 FA_X1 映射网表补足一次可解析 STA；不重新综合、ABC、Yosys 序列化或回读，不改官方程序、RTL、旧 FAILED 或生产默认。

## 实际输入与失败保留

原 `local-01/result.json` 476d893b… 为 incomplete STA FAILED；原 OpenSTA 2.0.17 对 concat-LHS 的语法错误使旧时序报告不合格。第一次 `serialization-01/result.json` 861ccfa4… 保持原图比较 FAILED，三个前置命令实际 rc0/reaped/group_absent，未进入 STA。现有 readback 的差异由领域专家独立限定诊断确定，root 继续使用原严格 circuit() 函数，不删字段或静默忽略名称。

控制器固定绑定 15 个既闭合文件的完整 SHA，以及 serialization inputs 中全部 original/generated pins；执行前后重查。这包括原图7117718b…、split图f391cf3a…、回读图dca75eff…、原序列化实现82738e4c…、原 timing.tcl20940006…和实际 mapped.v **2,177,588 B / b1557c027795810779995e60032c3493fcb53d3f194a2cce76e516bad01d8e23**。实际生成/回读脚本、日志、退出与回收记录一起保留；旧文件只读。

## 完整图与唯一名称规则

对原图每一个 cell 名，只将以 `$` 开始的名字加一个字面前导反斜杠；其他名字保持。必须证明该规则无碰撞并覆盖双方全部6150 cell，5196个改名（3518 ABC、1678 DFF）、954个FA不改名。完整映射 SHA 为9d8441a6…，不能对所有字符串做 lstrip、模糊匹配、只看统计数量或删除常量。

仅将回读 design.cells 的键按该完整双射逆命名，然后调用固定原 circuit()：220顶层端口的名称/方向/宽度/offset/upto/signed及位序，全部6150 cell的type/parameters/port directions/width，10729个网、26529端点及0/1/x/z常量均严格比较。拒绝 memories/processes/init 属性；原图与 split 图也按未经重命名的同一函数比较。原图及逆映射图完整 SHA 必须同为4bf4c350…；不改变图比较实现。

成功只证明已映射 JSON 在这一个显式双射下保持完整终端图、以及实际所用序列化文本完成 STA。原RTL到完整映射网表的等价仍未测试，不能把该结果写成新的FU/父级/整核或应用资格。

## 同条件 STA 与实际边界

新输出固定 `sta-resume-01`，先复制实际既有 mapped.v 并核字节完全相同。原 timing.tcl 仅把七处输入/报告目录路径替换为新输出，并完整反替换证明；原库 Nangate45 TT 1.1V/25°C、1ns、5K_hvratio_1_1、clock uncertainty/transition各.05ns、I/O delay .1ns、input transition .05ns、load5fF均保持。顶层220端口/2888位、1678DFF、954FA保持，计面积来自真实库。使用原 cost helper，实际 STA 不能有 Error/not found，必须唯一完成标志、五类路径存在、setup常量警告按实际设计核对；面积/五类时序与原D1000作同条件差值。所有路径满足才可说该局部1ns setup通过；不把Library area units写成实测芯片面积。

该映射输入继续对应原prefix：128位架构接口、两64位各8个signed8乘积、P两19位行与feature1 20位输出；上升沿E0接收/E1推进/E2最早响应、无阻塞II1，P/R两槽及同步高有效valid reset不改。本次不执行它的功能仿真，不转授新映射网表的二值/X/复位或物理核频率结论。

## 预算与停止

默认 plan-only，只进行输入/完整图核查，不启动EDA。仅明确 `--execute` 才在新目录运行一次原STA，CPU3单核nice5、STA≤30s、总≤60s，宿主外层120s含回收。与CPU1 K288回归隔离，总预算≤4核。原进程组须不存在，新输出须不存在；固定process helper管理子进程组、信号、TERM/KILL/reap，输入最终变化令FAILED。任何未解释图差异、语法错误、路径缺失、常量警告错误、超时或回收问题都保留失败，不自动续接、改门槛或重开映射扫描。

source-02预算澄清：execute入口开始计总60s且不重置；STA的30s截止在Popen前固定，并受同一总截止限制；最终输入检查和结果落盘后再次核总时限，超时写FAILED并非零退出。原source-01与plan仅准备、没有STA运行，完整保留。
