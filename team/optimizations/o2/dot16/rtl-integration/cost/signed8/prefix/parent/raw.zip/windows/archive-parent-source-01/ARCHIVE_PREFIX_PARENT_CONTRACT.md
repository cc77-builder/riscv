# Prefix real-parent 闭合证据归档合同

## 范围

`archive_prefix_parent.py` 仅运输已闭合 `parent-01` 的原始证据，不启动 checker、构建、guest、EDA 或其他子进程。原 `PREFIX_REAL_PARENT_PASS` / `parent_qualified=true` 仅按原 result 保存；本次不新增功能资格。该 parent 记录的 fullcore、application、cost、core-cost、performance 均为 false；上游乘法 miter 仍为 `UNKNOWN_EXTERNAL_TIMEOUT`，不因归档成功改变。上游独立成本结果不由本 parent 记录重新判定。

WSL 根为 `/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main`；Windows 根为 `D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runs\dot16-prefix-20261107-main`，挂载为 `/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main`。

只完整读取以下三根，命名空间互相隔离：

| 原目录 | ZIP 路径前缀 |
|---|---|
| WSL `parent-01` | `wsl/parent-01/` |
| Windows `parent-source-01` | `windows/parent-source-01/` |
| Windows **新建** `archive-parent-source-01` | `windows/archive-parent-source-01/` |

不使用已有 local 归档的 `archive-source-01`。输出固定为全新的 Windows `archive-parent-01`，与三输入根分离。原 parent 整树均保留：两份实际 binary、生成 RTL/C++、checker/harness 源、classes、全部正例/注错/检查日志、边界/覆盖/577-bit 审计、输入及 classpath 清单、空目录以及 `.o/.a`。**零省略、零删除**；不额外读取旧 local、旧 parent、活动 forward 或整棵 runs。

## 来源与 pin

原 result：160379 B，SHA256 `03eb17ce008ab0be25b9d46ddf53a237daa2ee912c817be801ba8a80c6deaa8d`；inputs：178536 B，SHA256 `96b3e9e7a7679a7a38f258068c58ba5055205d757be47bc763dc967779d4a609`；final-artifact-pins：34607 B，SHA256 `44b2264e379031be9d77fe8007b6673dacd475d6ca79b419e70969789d8a0ade`。

原 inputs 的 893 项 originals 中，3 项位于 Windows `parent-source-01/source-review/prefix-parent-v1/`：`prefix_parent.py`、`parent_binding.py`、`PARENT_CONTRACT.md`；逐一核对原 pin 并绑定对应执行 snapshot。其余 **890 项**只保留原路径/SHA，不打开、resolve、复制或重新 hash。22 项 snapshots、177 项 final pins 均必须严格落于本 `parent-01`。两份各 58 项 generated manifest、5 个新 harness class、两份 binary 及审计引用的四个完整 raw log 均交叉绑定。

共 214 个去重内部 pin、231 个原长度检查。原 classpath-before、runtime-classpath、observed-input-pins 清单作为 parent 内部完整文件运输并核其实际记录的 SHA，不解引用外部缓存。census 仅描述顶层 103 文件/5 目录；不能据此声称已知递归总量。实际成员/体量由归档首次扫描记录。

新 `archive-parent-source-01` 至少包含：

- `archive_prefix_parent.py`：实际执行的助手本体。
- `archive-census.json`：37846 B，SHA256 `c4ce6902ae27af20c184349b6f695391f4c31901b44c6831ad83bdd2f5d45098`。
- `host-receipt.json`：3552 B，SHA256 `1ff510c99e11af6d178032dff6d26c8f457601b1488932d323560f81a6fc33f6`。

合同、REVIEW 和有限自检可同放；它们是运输辅助材料，不赋予历史执行资格。原 host 固定为 `0250d6044ba18f5fd71831ae3131d2ce.e40fda7c58fb6656b3580c4529f40a2f`。从已保存回执核 succeeded/exit0/cleanup，且 launch 身份、terminal 摘要与 result 一致；不重查 PID、不重放 operation。96 条既有命令全部 finished/reaped/group_absent；56 条 exit0，40 条注错 exit1，其中注错原 expected_exit 为 null，不能把这些预期失败丢弃或改成成功。

时间字段保持其来源语义：`source_evidence.host_finished` 取自原 host `updated_at=2026-11-07T23:41:18.6873119Z`，是闭合回执更新时间，不是独立测得的进程停止时刻。原 inner started/finished 分别为 `2026-11-07T23:27:08.814020+00:00`、`2026-11-07T23:41:17.676913+00:00`；outer 原回执 duration 为 852131 ms，host started_at 为 `2026-11-07T23:27:06.503066Z`，分别记录，不互相替代。

## 运输、资源与执行

沿成熟助手原样复用扫描、流式 SHA、完整 ZIP 成员/重名/空目录检查、逐成员 CRC/SHA 读回、原树 after-scan 及全部原文件长度/SHA 复核。reject symlink/nonregular，所有来源只读。成功输出 `raw.zip`（含 `ARCHIVE-MANIFEST.json`）和 `audit.json`；失败保留部分产物及原件，写 `archive-failure.json`。未知/失败不得伪称归档完成。

单 Python 进程，实际设置并核实 affinity `{1}`、absolute nice5；600 s SIGALRM/deadline，SIGINT/SIGTERM 进入原失败保留路径。主端安排唯一辅助 worker 的时序。资源声明仅三根 read、新 `archive-parent-01` write，以及既有 Python/标准库 read，不因原依赖清单存在而扩大读取授权。

计划 CLI，尚未执行：

```bash
python3 -B /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main/archive-parent-source-01/archive_prefix_parent.py \
  --runs /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-prefix-20261107-main \
  --sources /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main \
  --output /mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/dot16-prefix-20261107-main/archive-parent-01
```

云端自检只证明代码/捕获元数据的一致性；完整本机文件、实际 ZIP 和原树稳定性要由随后真实归档的回执及 audit 证明。
