#!/usr/bin/env python3
"""Prove the complete VDotCarrySaveRows binary combinational identity.

This deliberately small SV subset accepts only the fixed interface, scalar
partial products, paired FA/HA equations, and two explicit 19-bit concatenations.
It never invokes an HDL tool and does not qualify any wrapper or sequential FU.
"""
import argparse
from collections import Counter, defaultdict, deque
import hashlib
import itertools
import json
from pathlib import Path
import re
import sys


class Invalid(ValueError):
    pass


def need(ok, message):
    if not ok:
        raise Invalid(message)


TOKEN = re.compile(
    r"(?P<space>[ \t\r\n\f\v]+)|(?P<literal>1'b[01])|"
    r"(?P<identifier>[A-Za-z_][A-Za-z_0-9]*)|(?P<number>0|[1-9][0-9]*)|"
    r"(?P<punct>[\[\](){},:;=~&^|])", re.DOTALL)
IDENTIFIER = re.compile(r'[A-Za-z_][A-Za-z_0-9]*\Z')
PP = re.compile(r'pp_([0-7])_([0-7])_([0-7])\Z')
CELL = re.compile(r'([sc])_(0|[1-9][0-9]*)_(0|[1-9][0-9]*)_(0|[1-9][0-9]*)\Z')
ONE, ZERO = "1'b1", "1'b0"
HEADER = """module VDotCarrySaveRows(
 input wire [63:0] vs1, input wire [63:0] vs2,
 output wire [18:0] row0, output wire [18:0] row1
);"""


def lex(text):
    tokens, pos = [], 0
    while pos < len(text):
        match = TOKEN.match(text, pos)
        need(match is not None, 'unknown SV text at byte ' + str(pos))
        if match.lastgroup != 'space':
            tokens.append(match[0])
        pos = match.end()
    return tokens


class Parser:
    def __init__(self, text):
        self.tokens, self.pos = lex(text), 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else ''

    def take(self, expected=None):
        got = self.peek()
        need(bool(got) and (expected is None or got == expected),
             f'expected {expected!r}, got {got!r}, token {self.pos}')
        self.pos += 1
        return got

    def name(self):
        name = self.take()
        need(IDENTIFIER.fullmatch(name) is not None, 'expected identifier: ' + name)
        return name

    def expression(self, minimum=0):
        if self.peek() == '~':
            self.take('~'); left = ('~', self.expression(4))
        elif self.peek() == '(':
            self.take('('); left = self.expression(); self.take(')')
        else:
            name = self.take()
            need(name in (ZERO, ONE) or IDENTIFIER.fullmatch(name), 'invalid expression atom: ' + name)
            if self.peek() == '[':
                need(name in ('vs1', 'vs2'), 'only operand bit selects are allowed')
                self.take('['); index = self.take()
                need(re.fullmatch(r'0|[1-9][0-9]*', index), 'literal bit index required')
                self.take(']'); left = ('bit', name, int(index))
            else:
                left = ('leaf', name)
        precedence = {'|': 1, '^': 2, '&': 3}
        while self.peek() in precedence and precedence[self.peek()] >= minimum:
            op = self.take()
            left = (op, left, self.expression(precedence[op] + 1))
        return left

    def module(self):
        for token in lex(HEADER):
            self.take(token)
        declarations, assignments = set(), {}
        while self.peek() != 'endmodule':
            statement = self.take()
            need(statement in ('wire', 'assign'), 'unknown SV statement: ' + statement)
            name = self.name()
            if statement == 'wire':
                need(name not in declarations, 'duplicate declaration: ' + name)
                declarations.add(name); self.take(';')
                continue
            need(name not in assignments, 'multiple drivers: ' + name)
            self.take('=')
            if self.peek() == '{':
                self.take('{'); bits = [self.expression()]
                while self.peek() == ',':
                    self.take(','); bits.append(self.expression())
                self.take('}'); expression = ('concat', *bits)
            else:
                expression = self.expression()
            self.take(';'); assignments[name] = expression
        self.take('endmodule')
        need(self.pos == len(self.tokens), 'extra module or text after endmodule')
        need(assignments.keys() == declarations | {'row0', 'row1'}, 'complete exact declaration/driver coverage')
        need(not declarations.intersection({'vs1', 'vs2', 'row0', 'row1'}), 'port redeclaration')
        return declarations, assignments


def scalar(node):
    need(node[0] == 'leaf' and node[1] != ZERO, 'arithmetic input must be a scalar wire or one')
    return node[1]


def xor_inputs(node):
    if node[0] == '^':
        return xor_inputs(node[1]) + xor_inputs(node[2])
    return [scalar(node)]


def boolean_leaves(node):
    if node[0] == 'leaf':
        return {scalar(node)}
    need(node[0] in ('~', '&', '^', '|'), 'invalid carry Boolean expression')
    return set().union(*(boolean_leaves(child) for child in node[1:]))


def evaluate(node, values):
    if node[0] == 'leaf':
        return values[node[1]]
    a = evaluate(node[1], values)
    if node[0] == '~':
        return 1 ^ a
    b = evaluate(node[2], values)
    return {'&': a & b, '^': a ^ b, '|': a | b}[node[0]]


def dag_check(dependencies):
    outgoing, degree = defaultdict(list), {}
    for name, parents in dependencies.items():
        degree[name] = len(parents)
        for parent in parents:
            need(parent in dependencies, 'undefined internal input: ' + parent)
            outgoing[parent].append(name)
    ready = deque(name for name, size in degree.items() if size == 0)
    visited = 0
    while ready:
        parent = ready.popleft(); visited += 1
        for child in outgoing[parent]:
            degree[child] -= 1
            if degree[child] == 0:
                ready.append(child)
    need(visited == len(dependencies), 'cycle in complete internal DAG')


def prove(raw):
    declarations, assignments = Parser(raw.decode('ascii')).module()
    expected_pp = {f'pp_{lane}_{i}_{j}' for lane in range(8) for i in range(8) for j in range(8)}
    need({name for name in declarations if PP.fullmatch(name)} == expected_pp, 'exact 512 partial-product coverage')
    weights, levels, dependencies, cells = {}, {}, {}, {}
    complemented = 0
    for name in declarations:
        match = PP.fullmatch(name)
        if match:
            lane, i, j = map(int, match.groups())
            expected = ('&', ('bit', 'vs1', 8 * lane + i), ('bit', 'vs2', 8 * lane + j))
            if (i == 7) != (j == 7):
                expected = ('~', expected); complemented += 1
            need(assignments[name] == expected, 'exact lane/bit/sign partial product: ' + name)
            weights[name], levels[name], dependencies[name] = i + j, -1, set()
        else:
            match = CELL.fullmatch(name)
            need(match is not None, 'unrecognized internal wire: ' + name)
            kind, level, column, number = match.groups()
            key = int(level), int(column), int(number)
            need(key[1] < 19, 'compressor source column outside the 19-bit heap')
            cells.setdefault(key, {})[kind] = name
            levels[name] = key[0]
    inputs, kinds = {}, Counter()
    for key, pair in cells.items():
        need(set(pair) == {'s', 'c'}, 'unpaired sum/carry: ' + str(key))
        s, c = assignments[pair['s']], assignments[pair['c']]
        terms = xor_inputs(s)
        need(len(terms) in (2, 3) and len(set(terms)) == len(terms), 'FA/HA requires distinct arithmetic input slots')
        need(boolean_leaves(c) == set(terms), 'sum/carry input-set mismatch: ' + str(key))
        # A literal one is also varied as an independent local input here.
        # Proving the stronger generic identity includes its actual value one.
        for bits in itertools.product((0, 1), repeat=len(terms)):
            values = dict(zip(terms, bits))
            need(sum(bits) == evaluate(s, values) + 2 * evaluate(c, values), 'FA/HA truth-table identity: ' + str(key))
        inputs[key] = terms; kinds['FA' if len(terms) == 3 else 'HA'] += 1
        for name in pair.values():
            dependencies[name] = set(terms) - {ONE}
    dag_check(dependencies)
    uses, constants = Counter(), Counter()
    for key in sorted(cells):
        level, column, _ = key
        for term in inputs[key]:
            if term == ONE:
                constants[column] += 1
            else:
                need(levels[term] < level, 'same/future layer input (new carry or sum): ' + term)
                need(weights[term] == column, 'compressor input weight mismatch: ' + term)
                uses[term] += 1
        weights[cells[key]['s']] = column
        weights[cells[key]['c']] = column + 1
    rows = {}
    for name in ('row0', 'row1'):
        concat = assignments[name]
        need(concat[0] == 'concat' and len(concat) == 20, 'explicit complete 19-bit output concat: ' + name)
        rows[name] = []
        for bit, expression in zip(range(18, -1, -1), concat[1:]):
            need(expression[0] == 'leaf', 'output concat entries must be scalar atoms')
            term = expression[1]; rows[name].append(term)
            if term == ZERO:
                continue
            if term == ONE:
                constants[bit] += 1
            else:
                need(term in weights and weights[term] == bit, 'final concat bit weight mismatch: ' + term)
                uses[term] += 1
    need(constants == Counter({18: 1, 11: 1}), 'exact arithmetic correction tokens at bits 18 and 11')
    dropped = []
    for name in sorted(declarations):
        if uses[name] == 0 and name.startswith('c_') and weights[name] >= 19:
            dropped.append(name)
        else:
            need(uses[name] == 1, f'exactly one arithmetic destination: {name}, found {uses[name]}')
    per_lane_bias = sum(1 << (i + j) for i in range(8) for j in range(8) if (i == 7) != (j == 7))
    correction = sum(count * (1 << bit) for bit, count in constants.items())
    need(8 * per_lane_bias + correction == 1 << 19, 'derived signed-product correction identity')
    minimum, maximum = 8 * (-128 * 127), 8 * (-128 * -128)
    need(-(1 << 18) <= minimum <= maximum < (1 << 18), 'exact dot8 range fits signed 19 bits')
    return dict(
        status='CSA_STRUCTURAL_EQUIVALENCE_PASS', all_inputs_equivalent=True, combinational_identity_proved=True,
        module='VDotCarrySaveRows',
        proof_domain='All 2^128 binary operand assignments; four-state X/Z behavior is not claimed.',
        parsed_entire_module=True, scalar_wires=len(declarations), partial_products=512,
        complemented_partial_products=complemented, full_adders=kinds['FA'], half_adders=kinds['HA'],
        local_boolean_cases=8 * kinds['FA'] + 4 * kinds['HA'],
        layers=sorted({key[0] for key in cells}),
        all_internal_nodes_acyclic=True, only_earlier_layer_inputs=True,
        arithmetic_destinations='Each pp/s/c consumed once, or an unconsumed carry of weight >=19 discarded modulo 2^19.',
        discarded_carries=dropped, correction_tokens_by_bit={str(k): constants[k] for k in sorted(constants)},
        per_lane_complement_bias=per_lane_bias, total_correction=correction,
        heap_identity='complemented_partial_product_heap + correction = signed_dot8 + 2^19',
        result_identity='signed19((row0 + row1) mod 2^19) = signed_dot8',
        exact_signed_dot8_range=[minimum, maximum], rows_msb_to_lsb=rows,
        wrapper_binding_verified=False, sequential_fu_qualified=False,
        real_parent_qualified=False, full_core_qualified=False, application_qualified=False, performance_qualified=False,
        required_external_binding=['Actual generated SV SHA and wrapper instance count.',
            'Low/high 64-bit operand slices and full two-row P-register saves.',
            'Accepted-request high-row mode masking and post-P modulo19-before-signed decode.',
            'Feature1 signed20 combination and architectural sign/zero extension.'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rtl', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    need(not args.output.exists() and not args.output.is_symlink(), 'fresh JSON output required')
    identity, result, code = {}, {}, 0
    try:
        raw = args.rtl.read_bytes()
        identity = dict(path=str(args.rtl.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        result = prove(raw)
        need(args.rtl.read_bytes() == raw, 'RTL changed during verification')
    except (Invalid, UnicodeError, OSError, RecursionError) as error:
        code = 1
        result = dict(status='CSA_STRUCTURAL_EQUIVALENCE_REJECTED', all_inputs_equivalent=False,
                      error=str(error), combinational_identity_proved=False,
                      wrapper_binding_verified=False, sequential_fu_qualified=False, performance_qualified=False)
    result['rtl'] = identity
    result['rtl_sha256'] = identity.get('sha256')
    verifier = Path(__file__).read_bytes()
    result['verifier'] = dict(bytes=len(verifier), sha256=hashlib.sha256(verifier).hexdigest())
    with args.output.open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(status=result['status'], output=str(args.output), rtl=identity, exit_code=code)))
    return code


if __name__ == '__main__':
    sys.exit(main())
