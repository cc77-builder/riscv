# CSA 两次失败与一次固定续接的运输归档审查

## 入口与未执行状态

`archive_csa.py` 复用已实际成功的 `archive_rwidth.py` 的 Python 标准库 ZIP_DEFLATED(level 6)、完整成员 CRC/SHA、输入前后 SHA 与目录库存核验；只修改 CSA 的目录和已记录证据适配。**本 helper 尚未运行归档，未调用本机、构建、EDA、guest 或原检查器。**

八个输入根为 `--runs/local-01/02/03` 三个独立目录、`--sources/source-01/02/03/04` 四个独立目录及 `archive-source-01`。所有实际文件均保留，只有下述对象缓存可运输省略。最后一个输入根由 root 放入此 helper、原 host receipts 和独立审查说明；整个目录按原字节收录，不猜 receipt 文件名或外壳，也不把保存回执称为重查进程。

```text
python3 -B archive-source-01/archive_csa.py
  --runs <WSL runs/dot16-csa-20261107-main>
  --sources <Windows 同名 runs 根的 /mnt/d/... 路径>
  --output <全新 archive-01>
  --local-03-result-sha256 <闭合后取得的实际 result.json 64位小写SHA256>
```

`--local-03-result-sha256` 必填，没有默认 PASS、默认成本或占位哈希。root 核实原 operation 终态和清理回执后才执行。CPU1、绝对 nice5、总600秒固定；不启动子进程。输出须全新且与八个输入根互不包含，实际 helper 必须在 archive-source-01 内。失败保留已有 ZIP 与 `archive-failure.json`，原件不删改。

## 三次运行分别记录

- local-01 固定 result SHA `cb12d0f14f985d97947f4d1c6f19a7b5e4696f6b0099eff756db77825fd44766`。按实际 v2 FAILED 的六条命令核对：编译、四套生成 rc=0，结构检查 rc=1，逐命令 finished/reaped/group_absent。该失败记录没有成功路径才写入的顶层 all_children_reaped 或 final-artifact-pins.json；不能据此要求补造字段或宣称运行成功。
- local-02 固定 v3 result **103298 B / `84b752a19a62d6e436d347cdd1273110c6530bd6024c41eecd58fbd8574e450d`**，明确 FAILED：前六条命令 exit0，第七 miter 外部120秒超时、没有 exit_code，cleanup/reaped/group_absent 已记录。FU/cost 为空。原 result、输入清单、20个 class 清单、classpath、结构报告和 SAT 原输入/日志均按已取得的实际 SHA 保留；不改写该失败结果。
- local-03 只适配 `dot16-fused-signed8-csa-continuation-v4`。固定 source04 controller SHA `668ebba4cefe28419bb63634c73e4435868751960661612105bd1c25c1b29b22` 与合同 SHA `baf2de180b12560240e488ce9936f4608c47681792b79efcd3f034456a67bf78`，必须由参数绑定实际终态 result。允许 FAILED 或 `CSA_REUSED_GENERATION_ARITHMETIC_FU_AND_COST_COMPLETE`，拒绝 RUNNING；成功时核26条新FU/cost命令，失败时只核实际命令前缀和子进程闭合，不补造后续输出。
- `generation_reused`、每套 generated 的 `reused_from`、固定 predecessor result/path、6项复用及1项未重试分别记录。若写入 miter 字段，必须原样为 `UNKNOWN_EXTERNAL_TIMEOUT`、retried=false、solver_equivalence_proved=false；缺字段时保持 null，不从运输推定结论。所有运行都保留原 parent/fullcore/application/core-cost 未授予和生产未修改范围。

## 必收身份与源对应

分别读取并核对 inputs.snapshots、原两次 overlay-classes、result.generated 的四文件 SV 清单及 resource/filelist、已记录 FU binary、已记录 mapped.v/json，以及 result 的候选/原始 Scala 身份。local-03 的 generated 只能引用 local-02 对应四套目录，文件清单、字节数、SHA和相对 manifest SHA必须逐项相同；新目录中的实际字节另核完整运输 SHA，不称为新编译或新生成。

local-03 的 `reused-overlay-classes.json` 必须精确等于 local-02 原20个绝对 class 路径/哈希映射。成功 `final-artifact-pins.json` 中，允许越出 local-03 的唯一对象就是这20个已经核实的原 class；它们在 manifest/pin库存中仍归 **local-02**，另标记被 local-03 复用，不能计成新编译产物。其余 final pins 必须留在 local-03，包括全部新快照、复用清单、新目录SV、原样复制的结构报告和gold/gate/prove/log、完整FU binary、映射脚本/ABC。mapped 网表仍按 result.cost_results 的独立 SHA检查。

五份 predecessor 快照须与 local-02 已记录 result/inputs/class清单/controller/合同身份相同。已有组合结构证明和miter原件的复制只证明运输/复用身份；原报告仍引用原local-02路径，新的 `arithmetic_structure_proof_reused_from` 必须如实记录，未知solver状态不被提升。

全部原命令日志必须入包。已完成 cost 条目对应的脚本、ABC、五类 STA 路径及 setup-checks 均保留；失败阶段只要实际存在的部分产物也全部收录，缺失的后续阶段不补造。未被执行器持久化 pin 的部分产物取得运输 SHA，明确不补造执行资格。

source-02→local-01、source-03→local-02、source-04→local-03。每组的 csa.py、CSA_CONTRACT.md、VDotDatapath.scala、VDotElastic.scala、source-derivation.json、verify_csa.py 六文件必须与实际 inputs.originals 和同名执行快照同时一致。source-04严格为这六文件加 controller-derivation.json，共七份；最后一份未被controller执行pin/快照，只完整保存。source-01作为未由这三次运行执行的先前源版本完整保存；原source02/03的其他 selftest/reviews/derivation 亦保留，不因文件存在就称为已执行输入。三次核心Scala身份相同。

所有归档根内被 originals 清单引用的文件也须存在且匹配。外部 Rwidth/signed8 baseline、库、工具链、classpath 原清单完整保留，用来定位外部输入；不读取、重新哈希或复制这些外部字节。

## 省略、完整性与资格

只允许省略三个 local 目录的 fu-feature0/obj 或 fu-feature1/obj 下没有必收 pin 的 `.o/.a`，逐项列路径、大小、SHA和可重建原因；原件仍保留并核前后不变。实际 `VVDotElasticFuTestTop` 完整二进制、全部生成 C++/头文件、SV、源码、.d、日志、JSON、映射/STA及失败/负控证据都收录。

ZIP 全部文件/目录成员清单、每个文件的完整 CRC/SHA 与嵌入 manifest 原字节必须一致；结束前再次扫描八根库存和保留/省略原件。成功只表示 `CSA_RAW_ARCHIVE_VERIFIED`：运输完整，原 FAILED/UNKNOWN_EXTERNAL_TIMEOUT和未授予资格保持不变。host cleanup仍由root按原operation回执核实，本helper不重新查询活跃进程。

## 当前审查范围

编写依据为cloud已有v3/v4控制器、实际local-01 result、local-02完整终态inspection/metadata，以及已成功Rwidth运输实现。已做Python AST、已知6/7条命令前缀和新26条命令接口、全部固定local02元数据SHA及source04源码/合同SHA核对；ZIP写入/成员CRC-SHA/库存复核代码段与成功Rwidth版本逐字节一致。独立原生审查已核三运行delta，未见旧class归属、相对manifest、七文件源对应或UNKNOWN记录上的具体阻塞。

没有读取本机或在途local-03，不执行main、扫描真实归档树或生成ZIP。本版只增加固定第三次续接、20个class的跨运行归属及新source04七文件，不增加通用resume功能。完整归档行为与local-03真实终态身份仍待root闭合后审查、冻结并执行。
