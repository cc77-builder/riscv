# 融合 signed8 部分积的 P 级表示实验 v1

合同：`dot16-fused-signed8-csa-local-v1`。本合同冻结一款固定结构，不做压缩树参数搜索。实际资格以真实生成、证明、FU 和同约束 cost 原件为准；创建源码不是验证通过。

## 基线、接口与流水

直接表示基线为本轮 R19/R20：wrapper `70dcc27381d3e7226eeff333c943d35b982ec1fdd37b75b680060a13aaf94e2a`，datapath `50522c0cd2700f7f852872049533bc31f79ce811ad2ed53da2c1d333cece45e2`，真实 local-01 result `f42f7285ff8a357877c546d433251b1dc8c8eef66ee9218c9e3b2c002ca0a261`。其 dot16 面积为 21040.866，r2r/i2r arrival 为 1.189326/1.209418 ns，名义 1 ns 未满足。旧 signed8 local-03 的 product 全输入证明只作为固定对照身份，不能自动转给新 CSA。

保持原 128 位输入与输出、字节序、指令与合法性要求、完整 control/perf、P/R 两槽、ready/valid、redirect/kill、同步高有效 valid 复位。数据和 metadata 不增加复位。上升沿 E0 接收，E1 P→R，E2 最早响应，连续无阻塞 II=1。所有 accepted/move 使能及输出高96位零保持。source-derivation.json 的七项精确变更须逆向恢复 R19/R20 wrapper 全部字节；旧 datapath 的2925字节原样保留，新增模块只由新 wrapper 采用。

## 算术与微架构

每个 half 处理8对 signed8，共512个1位部分积。只有 `(i==7) xor (j==7)` 的14项/product取反；取反后的加权 heap 等于该乘积加32512。八份 heap 加 bit18 与 bit11，恰等于真实8项和加2^19。固定列阈值为 `[63,42,28,19,13,9,6,4,3,2]`；超额至少2使用FA，超额1使用HA；每层只消耗前层已有位，新carry只流入下一层下一列。全部运算按模2^19解释，不能把中间heap当作不溢出的有符号和。

P保存两行unsigned19，而不是逐项16位乘积。P后先作两行无符号加法并取低19位，再解释为SInt19；8项和范围为[-130048,131072]，故这个有符号解释精确。dot16对两个SInt19作加宽到20位的加法，范围[-260096,262144]。dot8模式在同一个accept边沿把高half的两行都置零，P后不再注入常数，不读取后来输入的模式。不能分别把行符号扩展后求和，不能把half的第19位carry带入dot16结果，也不能只清高half一行。

## 证明、运行与公平比较

1. 从已固定的完整classpath编译真实Scala覆盖源，生成cost/FU × feature0/1。应形成真实CSA模块、wrapper、公共top与外部声明文件；不假设未实例化的旧Products/Reduce仍会被生成。每个feature的两个消费者必须使用同一实际CSA字节，检查feature0一个、feature1两个实例以及低/高64位连接和P保存/后P解码。
2. 对实际emitted CSA全文做严格独立结构验证：完整语法白名单、全部512项覆盖及符号、无额外驱动或语句、FA/HA无约束真值恒等、严格DAG/层级、各算术token恰一次去向、列权守恒、修正常数和最终concat位序。配合确定的signed范围，这构成该实际组合模块的全输入compositional等价；不得称作全FU顺序SAT。
3. 同时对实际CSA加模和，与固定signed8 Products/Reduce/SignedByteProduct原件作一次有界的独立SAT miter。超时保留UNKNOWN及完整日志，不更换输入或扩预算重跑；明确反例必须阻断并解释与结构证明的冲突。完整结构证明可独立成立算术结论；求解器UNKNOWN不冒充solver PASS。
4. 保留原两态完整FU C++、vectors、coverage门和identity/wen/high/cancel观察负控，不修改检查器或向量。必须实际lint/build/运行/分类并回收进程；这些测试与组合证明各有适用范围。真实wrapper连接核对、源码逆向身份和FU行为检查共同绑定新的P表示；不声称已完成整个FU的顺序形式化。
5. 使用原完整common-FU边界、Nangate45库、ABC约束与名义1ns五类STA模板，只做一次匹配映射。报告相对R19/R20的新增收益，另列旧原始基线；不重复计入signed8或R收窄收益。实际DFF/cell数与面积均由生成后网表测得。目标仍为面积约20000及改善关键路径，未达目标照实记录；不把综合估计当布局布线或整核PPA。
6. 一个CPU1、absolute nice5、单worker、有限总预算，复用原成熟进程回收。输入、源码快照、完整classpath和生成文件前后核验；新目录、失败原件保留。生产默认、常驻源码/缓存和正在运行的完整N/P目标不修改。

只有本次实际完成层级可授予资格。新parent、整核、完整应用和core cost都保持pending；若候选无可信面积/最差路径收益，不扩昂贵验证，不重复树搜索。该PPA实验不自动改变当前固定频率EMU的应用周期结论。
