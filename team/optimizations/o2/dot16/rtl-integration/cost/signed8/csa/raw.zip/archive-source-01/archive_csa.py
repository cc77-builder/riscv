#!/usr/bin/env python3
"""Archive CLOSED CSA local-01/02 and the fixed local-03 continuation.

Derived from the successfully used archive_rwidth.py. No checker, build, EDA,
guest or external baseline input is executed/read. Original files stay in place.
The local-03 result SHA must be supplied only after the actual operation closes.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import sys
import time
import zipfile

LOCAL1_RESULT_SHA = 'cb12d0f14f985d97947f4d1c6f19a7b5e4696f6b0099eff756db77825fd44766'
LOCAL2_RESULT_SHA = '84b752a19a62d6e436d347cdd1273110c6530bd6024c41eecd58fbd8574e450d'
SOURCE3_CONTROLLER_SHA = '07d93e73072304a64b7bc415820b2856a27b2d74a01e649a2e141f78e8adf0f7'
SOURCE4_CONTROLLER_SHA = '668ebba4cefe28419bb63634c73e4435868751960661612105bd1c25c1b29b22'
SOURCE4_CONTRACT_SHA = 'baf2de180b12560240e488ce9936f4608c47681792b79efcd3f034456a67bf78'
COMPLETE = 'CSA_REUSED_GENERATION_ARITHMETIC_FU_AND_COST_COMPLETE'
LOCAL2_PINS = {
    'inputs.json': '612f760a4d593a1899e7079c98a4fde5b2d14e702435cb09ffc1425e5f981616',
    'overlay-classes.json': 'd76cd45beda440ecc8fdc64ced5dc796e19c1e8641d7ebd7e8e12c8e401e242a',
    'classpath-before.json': 'd9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902',
    'arithmetic-structure.json': '9483d70f24876e7c89281e559d3d062355c0787e38a7f3fd7ab9cf36d3cd8ad6',
    'actual-csa-independent-miter.log': 'a9175ff5e52888f37d8cf8eeeb1673f6975e32cc8e08687be91f3db2cc845b2b',
    'prove.ys': 'a530cc27b2bd446913d16d3e3b673350224839c53645a5495331cf8ee0b9ccb1',
    'gate.sv': 'fced35a0f4d64fdd036d670246d29ea84124ebeca8a0062fbd01ae0e173082f5',
    'gold.sv': '5a8c5a6f316ba97295751d4a356c4397df8b4dbb9872dd8a4fe15c59a2c7a198',
}
BINARY = 'VVDotElasticFuTestTop'
FAULTS = ('identity', 'wen', 'high', 'cancel')
EXEC_SOURCE_NAMES = {'csa.py', 'CSA_CONTRACT.md', 'VDotDatapath.scala',
                     'VDotElastic.scala', 'source-derivation.json', 'verify_csa.py'}
SOURCE_IDENTITIES = {
    'VDotDatapath.scala': ('candidate_source_sha256', '62ace0342070bc2a40f57b999c8aa94d376543a4cc79d455cf69e6083742488c'),
    'original-VDotDatapath.scala': ('original_source_sha256', '161df70403fd131a3adf445230ed637dc7ad7c619d05c0a890aa8aa1791546d8'),
    'VDotElastic.scala': ('candidate_wrapper_sha256', '4a525d2e8ead5cc10a193d9724342162af4ffebd130c58ad7c606093849ac1c8'),
    'original-VDotElastic.scala': ('original_wrapper_sha256', '63911b937a526b97ddaa67e34526fd19bbd2fa2801eadfda10ae6c2fa4b9fe9e'),
}
OUT_OF_SCOPE = ('parent_qualified', 'fullcore_qualified', 'application_performance_qualified',
                'core_cost_qualified', 'resident_modified', 'original_cache_modified', 'production_default_changed')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def sha_argument(value):
    if len(value) != 64 or any(x not in '0123456789abcdef' for x in value):
        raise argparse.ArgumentTypeError('expected 64 lowercase hexadecimal SHA256 characters')
    return value


def command_labels():
    labels = ['compile-source-overlay'] + [f'generate-{kind}-{feature}'
        for feature in (0, 1) for kind in ('cost', 'fu')]
    labels += ['actual-csa-structure', 'actual-csa-independent-miter']
    for feature in (0, 1):
        labels += [f'fu-{feature}-{step}' for step in ('lint', 'build', 'positive')]
        labels += [f'fu-{feature}-{action}-{fault}' for fault in FAULTS for action in ('inject', 'check')]
    labels += [f'{step}-{feature}' for feature in (0, 1) for step in ('map', 'sta')]
    return labels


def recorded_evidence(run, result_sha, contract, predecessor_record=None):
    need(sha(run / 'result.json') == result_sha, 'fixed actual closed result: ' + run.name)
    result, inputs = read(run / 'result.json'), read(run / 'inputs.json')
    continuation = run.name == 'local-03'
    previous = run.parent / 'local-02'
    complete = result['status'] == COMPLETE
    need(result['contract'] == contract and result['status'] in ('FAILED', COMPLETE) and result['finished'],
         'actual terminal result, never RUNNING: ' + run.name)
    need(all(result[name] is False for name in OUT_OF_SCOPE) and
         result['new_core_builds'] == result['new_core_runs'] == 0,
         'unchanged original qualification and mutation boundary')
    full_labels = command_labels()[7:] if continuation else command_labels()
    labels = [row['label'] for row in result['commands']]
    need(len(full_labels) == (26 if continuation else 33) and labels == full_labels[:len(labels)],
         'recorded command prefix and order')
    for row in result['commands']:
        need(row.get('reaped') is True and row.get('group_absent') is True and row.get('finished'),
             'recorded command child closure: ' + run.name + '/' + row['label'])
    if run.name == 'local-01':
        need(result['status'] == 'FAILED' and labels == full_labels[:6] and
             [row['exit_code'] for row in result['commands']] == [0, 0, 0, 0, 0, 1],
             'fixed failed first attempt, six closed commands')
    if run.name == 'local-02':
        need((run / 'result.json').stat().st_size == 103298 and result['status'] == 'FAILED' and
             labels == full_labels[:7] and not result['fu_results'] and not result['cost_results'] and
             all(row.get('exit_code') == 0 and row['expected_exit'] == 0 for row in result['commands'][:6]),
             'fixed failed second attempt, six completed stages and no FU/cost')
        last = result['commands'][-1]
        need(last['budget_seconds'] == 120 and last['expected_exit'] is None and
             'exit_code' not in last and last.get('cleanup_complete') is True,
             'fixed original externally timed-out miter; never a solver PASS')
    if continuation:
        need(predecessor_record is not None and result['generation_reused'] is True and
             result['predecessor'] == dict(path=str(previous), result_sha256=LOCAL2_RESULT_SHA,
                status='FAILED', commands_reused=6, commands_not_retried=1,
                source_generation_and_structure_only=True), 'exact fixed continuation provenance')
    if complete:
        need(labels == full_labels and all(result.get(name) is True for name in
             ('all_children_reaped', 'inputs_unchanged', 'generated_inputs_unchanged',
              'original_classpath_unchanged', 'arithmetic_equivalent', 'fu_qualified',
              'wrapper_post_p_decode_review_completed')), 'completed original local qualification')
        for row in result['commands']:
            injected = '-inject-' in row['label']
            unchecked_exit = injected
            need(type(row['exit_code']) is int and row['exit_code'] == (1 if injected else 0) and
                 row['expected_exit'] == (None if unchecked_exit else 0),
                 'completed original command exit: ' + row['label'])
    else:
        need(result['arithmetic_equivalent'] is False and result['fu_qualified'] is False,
             'failed result retains its unqualified state')

    pins, groups, sizes = {}, {}, {}
    def pin(path, digest, group, size=None):
        path = Path(path)
        need(path.is_absolute() and '..' not in path.parts and path.is_relative_to(run),
             'local recorded pin: ' + str(path))
        need(isinstance(digest, str) and len(digest) == 64 and
             all(x in '0123456789abcdef' for x in digest), 'recorded SHA256')
        need(path not in pins or pins[path] == digest, 'consistent recorded pin')
        pins[path] = digest
        groups.setdefault(group, set()).add(path)
        if size is not None:
            need(type(size) is int and size >= 0 and (path not in sizes or sizes[path] == size),
                 'consistent recorded size')
            sizes[path] = size
    pin(run / 'result.json', result_sha, 'terminal_result')
    for path, digest in inputs['snapshots'].items():
        pin(path, digest, 'snapshots')
    class_manifest = run / ('reused-overlay-classes.json' if continuation else 'overlay-classes.json')
    classes = read(class_manifest) if class_manifest.is_file() else {}
    need(not complete or bool(classes), 'completed overlay class inventory')
    reused_classes = {}
    if continuation:
        if classes:
            need(classes == predecessor_record['classes'] and len(classes) == 20,
                 'exact predecessor classes, not new compilation')
            reused_classes = classes
    else:
        for path, digest in classes.items():
            need(Path(path).is_relative_to(run / 'overlay-classes'), 'recorded overlay class scope')
            pin(path, digest, 'overlay_classes')
        if run.name == 'local-02':
            need(len(classes) == 20, 'fixed predecessor has twenty compiled classes')
            for name, digest in LOCAL2_PINS.items():
                pin(run / name, digest, 'fixed_predecessor_artifacts')
    generated = result['generated']
    ordered_consumers = [(f, k) for f in (0, 1) for k in ('cost', 'fu')]
    need([(row['feature'], row['kind']) for row in generated] == ordered_consumers[:len(generated)] and
         (not complete or len(generated) == 4), 'actual generated consumer prefix')
    for row in generated:
        rtl = run / f"{row['kind']}-feature{row['feature']}" / 'rtl'
        top = 'CommonFuCostTop' if row['kind'] == 'cost' else 'VDotElasticFuTestTop'
        names = {'VDotElastic.sv', 'VDotCarrySaveRows.sv', top + '.sv', 'extern_modules.sv'}
        need(len(row['files']) == 4 and {Path(x['path']).name for x in row['files']} == names,
             'complete recorded generated SV inventory')
        if continuation:
            prior = next(item for item in predecessor_record['result']['generated']
                         if item['feature'] == row['feature'] and item['kind'] == row['kind'])
            need(row['generation_reused'] is True and
                 row['reused_from'] == str(previous / f"{row['kind']}-feature{row['feature']}" / 'rtl') and
                 row['files'] == prior['files'] and
                 row['resource_manifest_sha256'] == prior['resource_manifest_sha256'] and
                 row['filelist_sha256'] == prior['filelist_sha256'],
                 'new directory contains exactly the recorded predecessor SV and relative manifests')
        for item in row['files']:
            rel = PurePosixPath(item['path'])
            need(not rel.is_absolute() and '..' not in rel.parts and (run / rel).parent == rtl,
                 'relative generated source path')
            pin(run / rel, item['sha256'], 'generated_sv', item['bytes'])
        pin(rtl / 'firrtl_black_box_resource_files.f', row['resource_manifest_sha256'], 'resource_manifests')
        pin(rtl / 'filelist.f', row['filelist_sha256'], 'filelists')
    for name in ('fu_results', 'cost_results'):
        need([row['feature'] for row in result[name]] == [0, 1][:len(result[name])] and
             (not complete or len(result[name]) == 2), 'actual completed feature prefix: ' + name)
    for row in result['fu_results']:
        need(row['passed'] is True and row['faults'] == list(FAULTS), 'recorded FU stage and fault inventory')
        pin(run / f"fu-feature{row['feature']}" / 'obj' / BINARY, row['binary_sha256'], 'fu_binaries')
    for row in result['cost_results']:
        folder = run / f"cost-feature{row['feature']}" / 'mapped'
        pin(folder / 'mapped.v', row['mapped_sha256'], 'mapped_outputs')
        pin(folder / 'mapped.json', row['mapped_json_sha256'], 'mapped_outputs')
    for name, (key, digest) in SOURCE_IDENTITIES.items():
        need(result[key] == digest, 'fixed CSA source identity: ' + name)
        pin(run / 'source-snapshot' / name, digest, 'source_identity')
    if run.name == 'local-02':
        pin(run / 'source-snapshot' / 'csa.py', SOURCE3_CONTROLLER_SHA, 'source_identity')
    if continuation:
        pin(run / 'source-snapshot' / 'csa.py', SOURCE4_CONTROLLER_SHA, 'source_identity')
        pin(run / 'source-snapshot' / 'CSA_CONTRACT.md', SOURCE4_CONTRACT_SHA, 'source_identity')
        for target, original in (
            ('predecessor-result.json', 'result.json'), ('predecessor-inputs.json', 'inputs.json'),
            ('predecessor-overlay-classes.json', 'overlay-classes.json'),
            ('predecessor-csa.py', 'source-snapshot/csa.py'),
            ('predecessor-CSA_CONTRACT.md', 'source-snapshot/CSA_CONTRACT.md')):
            original_pin = predecessor_record['pins'].get(previous / original)
            need(original_pin is not None, 'predecessor snapshot has recorded original identity')
            pin(run / 'source-snapshot' / target, original_pin, 'predecessor_snapshot_copies')
        miter = result.get('independent_miter')
        need(not complete or miter is not None, 'completed continuation records unresolved old miter')
        if miter is not None:
            need(miter['status'] == 'UNKNOWN_EXTERNAL_TIMEOUT' and miter['retried'] is False and
                 miter['solver_equivalence_proved'] is False and miter['counterexample_found'] is False and
                 miter['reused_from'] == str(previous) and
                 miter['log_sha256'] == LOCAL2_PINS['actual-csa-independent-miter.log'] and
                 result['arithmetic_structure_proof_reused_from'] == str(previous / 'arithmetic-structure.json') and
                 result['arithmetic_structure_proof'] == predecessor_record['result']['arithmetic_structure_proof'],
                 'retain exact reused proof and unresolved solver outcome')
            for name in ('arithmetic-structure.json', 'actual-csa-independent-miter.log', 'gold.sv', 'gate.sv', 'prove.ys'):
                pin(run / name, LOCAL2_PINS[name], 'reused_proof_artifacts')

    final_path = run / 'final-artifact-pins.json'
    final_pins = read(final_path) if final_path.is_file() else {}
    need(not complete or bool(final_pins), 'successful CSA persists final artifact pins')
    recorded_before_final = dict(pins)
    final_reused_classes = {}
    for path, digest in final_pins.items():
        p = Path(path)
        if p.is_relative_to(run):
            pin(p, digest, 'persisted_final_artifact_pins')
        else:
            need(continuation and path in reused_classes and reused_classes[path] == digest,
                 'only exact predecessor class paths may occur outside this run in final pins')
            final_reused_classes[path] = digest
    if complete:
        need(final_reused_classes == reused_classes and len(final_reused_classes) == 20,
             'final pins retain all twenty predecessor classes under their original identity')
        for path, digest in recorded_before_final.items():
            if path not in groups.get('terminal_result', set()) | groups.get('mapped_outputs', set()):
                need(final_pins.get(str(path)) == digest, 'successful final pins cover original recorded input/output')
        expected_final = [run / name for name in ('reused-overlay-classes.json', 'arithmetic-structure.json',
                          'actual-csa-independent-miter.log', 'gold.sv', 'gate.sv', 'prove.ys')]
        expected_final += [run / f'cost-feature{feature}' / 'mapped' / name
                          for feature in (0, 1) for name in ('abc.constr', 'map.ys', 'timing.tcl')]
        need(all(str(path) in final_pins for path in expected_final), 'full proof and mapping-input final pins')
    return result, inputs, pins, groups, sizes, labels, bool(final_pins), classes, reused_classes


def scan(roots, pinned):
    kept, omitted, directories = {}, {}, set()
    for root in roots:
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        directories.add(root.name + '/')
        for path in sorted(root.rglob('*')):
            mode = path.lstat().st_mode
            need(not stat.S_ISLNK(mode), 'archive tree contains a link: ' + str(path))
            rel = path.relative_to(root); name = root.name + '/' + rel.as_posix()
            if stat.S_ISDIR(mode):
                directories.add(name + '/')
                continue
            need(stat.S_ISREG(mode), 'regular archive input: ' + str(path))
            is_cache = (root.name in ('local-01', 'local-02', 'local-03') and len(rel.parts) >= 3 and
                        rel.parts[0] in ('fu-feature0', 'fu-feature1') and rel.parts[1] == 'obj' and
                        path.suffix in ('.o', '.a') and path not in pinned)
            if is_cache:
                omitted[name] = dict(bytes=path.stat().st_size, sha256=sha(path),
                    reason='Rebuildable Verilator object/static-library cache only; original retained.')
            else:
                need(name not in kept, 'unique archive name')
                kept[name] = path
    return kept, omitted, directories


def main(a):
    need(sys.dont_write_bytecode, '-B required; frozen source inputs stay read-only')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(all(p.is_absolute() and p == p.resolve() for p in (a.runs, a.sources, a.output)), 'canonical absolute paths')
    runs, sources, out = a.runs, a.sources, a.output
    roots = [runs / f'local-0{i}' for i in (1, 2, 3)] + [sources / f'source-0{i}' for i in (1, 2, 3, 4)]
    archive_source = sources / 'archive-source-01'; roots.append(archive_source)
    need(all(p.is_dir() and not p.is_symlink() and p == p.resolve() for p in roots), 'eight canonical real input roots')
    need(not out.exists() and all(not out.is_relative_to(p) and not p.is_relative_to(out) for p in roots),
         'fresh output separate from all eight input trees')
    need(Path(__file__).resolve().is_relative_to(archive_source), 'actual helper is included in archive-source-01')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone archive owns its finite timer')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 600
    handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM)}
    def interrupted(sig, _frame):
        raise InterruptedError('archive signal/deadline ' + str(sig))
    try:
        for sig in handlers:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 600)
        records, pinned, sizes, groups = {}, {}, {}, {}
        for name, digest, contract in (
            ('local-01', LOCAL1_RESULT_SHA, 'dot16-fused-signed8-csa-local-v2'),
            ('local-02', LOCAL2_RESULT_SHA, 'dot16-fused-signed8-csa-local-v3'),
            ('local-03', a.local_03_result_sha256, 'dot16-fused-signed8-csa-continuation-v4')):
            result, inputs, local_pins, local_groups, local_sizes, labels, final_present, classes, reused_classes = \
                recorded_evidence(runs / name, digest, contract, records.get('local-02'))
            pinned.update(local_pins); sizes.update(local_sizes)
            groups.update({name + '/' + key: value for key, value in local_groups.items()})
            if reused_classes:
                need(all(pinned.get(Path(path)) == digest for path, digest in reused_classes.items()),
                     'reused classes belong to the already recorded local-02 pins')
                groups['local-02/classes_reused_by_local-03'] = {Path(path) for path in reused_classes}
            records[name] = dict(result=result, inputs=inputs, labels=labels, result_sha=digest,
                                 pin_count=len(local_pins), final_pins_present=final_present, pins=local_pins,
                                 classes=classes, reused_classes=reused_classes)
        files, omitted, directories = scan(roots, pinned)
        inventory = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
        by_path = {path: inventory[name] for name, path in files.items()}
        need(all(p in by_path and by_path[p]['sha256'] == digest for p, digest in pinned.items()),
             'every recorded snapshot/generated/mapped/binary/class/proof pin included unchanged')
        need(all(by_path[p]['bytes'] == size for p, size in sizes.items()), 'all recorded generated lengths')
        evidence = {}
        for name, record in records.items():
            result, inputs = record['result'], record['inputs']
            need(all(name + '/' + label + '.log' in files for label in record['labels']),
                 'all original positive/negative/failed command logs retained: ' + name)
            for cost in result['cost_results']:
                for filename in ('abc.constr', 'map.ys', 'timing.tcl', 'r2r.rpt', 'i2r.rpt',
                                 'r2o.rpt', 'i2o.rpt', 'ready.rpt', 'setup-checks.rpt'):
                    need(f"{name}/cost-feature{cost['feature']}/mapped/{filename}" in files,
                         'all completed mapping/STA inputs and reports retained')
            archived_originals = {}
            for path, digest in inputs['originals'].items():
                p = Path(path)
                if any(p.is_relative_to(root) for root in roots):
                    need(p in by_path and by_path[p]['sha256'] == digest,
                         'archived original input matches execution pin')
                    archived_originals[path] = digest
            source_scope = {key: result[key] for key in
                ('arithmetic_equivalent', 'fu_qualified', *OUT_OF_SCOPE, 'new_core_builds', 'new_core_runs')}
            evidence[name] = dict(result_sha256=record['result_sha'], result_bytes=inventory[name + '/result.json']['bytes'],
                status=result['status'], contract=result['contract'], error=result.get('error'),
                commands=len(result['commands']), exit_histogram=dict(Counter(str(row.get('exit_code', 'unrecorded'))
                    for row in result['commands'])), recorded_commands_closed=True,
                top_level_all_children_reaped=result.get('all_children_reaped'),
                original_inputs=len(inputs['originals']), archived_original_inputs=len(archived_originals),
                recorded_pins=record['pin_count'], final_artifact_pins_present=record['final_pins_present'],
                original_qualification=source_scope,
                independent_miter_status=result.get('independent_miter', {}).get('status'),
                generation_reused=result.get('generation_reused', False), predecessor=result.get('predecessor'),
                arithmetic_structure_proof_reused_from=result.get('arithmetic_structure_proof_reused_from'),
                reused_class_count=len(record['reused_classes']),
                reused_class_owner='local-02' if record['reused_classes'] else None,
                generated_origin=[dict(feature=row['feature'], kind=row['kind'],
                    generation_reused=row.get('generation_reused', False), reused_from=row.get('reused_from'))
                    for row in result['generated']],
                pin_policy='Persisted execution pins checked; all other existing files retained with transport hashes. Missing failed-stage outputs are not invented.')
        source_audit = {}
        for source_name, run_name in (('source-01', None), ('source-02', 'local-01'),
                                     ('source-03', 'local-02'), ('source-04', 'local-03')):
            source = sources / source_name
            source_files = {name[len(source_name) + 1:]: info for name, info in inventory.items()
                            if name.startswith(source_name + '/')}
            need(run_name is None or EXEC_SOURCE_NAMES <= set(source_files),
                 'complete executed core source set: ' + source_name)
            if source_name == 'source-04':
                need(set(source_files) == EXEC_SOURCE_NAMES | {'controller-derivation.json'},
                     'seven actual continuation source files')
            rows = []
            for filename, info in sorted(source_files.items()):
                original_pin = snapshot_pin = None
                if run_name is not None:
                    inputs = records[run_name]['inputs']
                    original_pin = inputs['originals'].get(str(source / filename))
                    snapshot = runs / run_name / 'source-snapshot' / filename
                    snapshot_pin = inputs['snapshots'].get(str(snapshot))
                    if filename in EXEC_SOURCE_NAMES:
                        need(original_pin == snapshot_pin == info['sha256'] and
                             snapshot in by_path and by_path[snapshot]['sha256'] == info['sha256'],
                             'source equals executed original and snapshot: ' + source_name + '/' + filename)
                execution_pinned = original_pin is not None
                rows.append(dict(name=filename, **info, original_input_pin=original_pin,
                    snapshot_pin=snapshot_pin, execution_pinned=execution_pinned,
                    scope='Original execution input and matching snapshot.' if filename in EXEC_SOURCE_NAMES and run_name else
                          'Retained source/review/derivation; no execution qualification inferred from transport.'))
            source_audit[source_name] = dict(execution_run=run_name, files=rows)
        manifest = dict(schema=1, evidence=evidence, source_files=source_audit,
            recorded_pin_counts={key: len(value) for key, value in groups.items()},
            files=inventory, directories=sorted(directories), omitted=omitted,
            omissions_deleted=False, all_existing_original_sources_and_logs_included=True,
            external_dependencies='Original inputs/classpath/baseline manifests retained; no external input bytes read, copied or rehashed.',
            receipts='archive-source-01 is retained in full; host receipt filenames/schema are not guessed or reinterpreted.',
            scope='ZIP transport integrity only; FAILED stays FAILED and UNKNOWN stays UNKNOWN. No new correctness, performance, parent, full-core or PPA qualification.',
            cpu_affinity=[1], nice=5, budget_seconds=600)
        raw_manifest = encoded(manifest)
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in sorted(directories):
                z.writestr(name, b'')
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            expected = set(files) | directories | {'ARCHIVE-MANIFEST.json'}
            need(len(z.namelist()) == len(expected) and set(z.namelist()) == expected, 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name in directories:
                need(z.getinfo(name).is_dir() and z.getinfo(name).file_size == 0 and z.read(name) == b'', 'exact directory member')
            for name, record in inventory.items():
                need(not z.getinfo(name).is_dir() and z.getinfo(name).file_size == record['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == record['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted, after_directories = scan(roots, pinned)
        need(after == files and after_omitted == omitted and after_directories == directories, 'closed tree inventory unchanged')
        need(all(path.stat().st_size == inventory[name]['bytes'] and sha(path) == inventory[name]['sha256']
                 for name, path in after.items()), 'all retained source bytes unchanged')
        audit = dict(status='CSA_RAW_ARCHIVE_VERIFIED', started=started, finished=stamp(),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive), files=len(files),
            members=len(expected), directories=len(directories), raw_kept_bytes=sum(x['bytes'] for x in inventory.values()),
            recorded_pins_verified=len(pinned), recorded_pin_counts=manifest['recorded_pin_counts'],
            omitted_files=len(omitted), omitted_bytes=sum(x['bytes'] for x in omitted.values()),
            member_crc_and_sha_verified=True, retained_files_unchanged=True, omitted_originals_unchanged=True,
            source_membership_unchanged=True, original_files_deleted=False,
            original_recorded_child_closures_checked=True, live_processes_requeried=False,
            external_dependencies_rehashed=False, original_validators_rerun=False,
            new_builds=0, new_eda_runs=0, new_guest_runs=0, source_evidence=evidence, source_files=source_audit,
            qualification='Transport integrity only; all three original result scopes and predecessor class ownership preserved.')
        need(time.monotonic() < deadline, 'complete archive within total budget')
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error),
            started=started, finished=stamp(), original_files_retained=True, new_guest_runs=0, new_eda_runs=0)))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('runs', 'sources', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--local-03-result-sha256', type=sha_argument, required=True)
    main(parser.parse_args())
