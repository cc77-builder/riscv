#!/usr/bin/env python3
"""Synthetic parser/proof tests only. Does not generate or qualify Scala RTL."""
import argparse
import hashlib
import json
from pathlib import Path
import verify_csa as verifier


def fixture(correction_bits=(18, 11)):
    # Independent fixture schedule: one HA per occupied column, then Wallace
    # rounds consuming every old triple. This is not the Scala Dadda schedule.
    # SV has no comments: the strict parser rejects all comments, including
    # synthesis pragmas. Fixture identity is in this file, names and JSON.
    lines = [verifier.HEADER]
    columns = [[] for _ in range(19)]
    cells = []

    def wire(name, expr):
        lines.extend([f'wire {name};', f'assign {name} = {expr};'])

    for i in range(8):
        for j in range(8):
            for lane in range(8):
                name = f'pp_{lane}_{i}_{j}'
                term = f'(vs1[{8 * lane + i}] & vs2[{8 * lane + j}])'
                wire(name, '~' + term if (i == 7) != (j == 7) else term)
                columns[i + j].append(name)
    for bit in correction_bits:
        columns[bit].insert(0, "1'b1")
    level = 0
    while level == 0 or max(map(len, columns)) > 2:
        following = [[] for _ in range(19)]
        for column, old in enumerate(columns):
            used, number = 0, 0
            while len(old) - used >= (2 if level == 0 else 3):
                count = 2 if level == 0 else 3
                terms = old[used:used + count]
                x, y = terms[:2]
                s, c = f's_{level}_{column}_{number}', f'c_{level}_{column}_{number}'
                wire(s, ' ^ '.join(terms))
                carry = f'{x} & {y}' if count == 2 else f'({x} & {y}) | (({x} ^ {y}) & {terms[2]})'
                wire(c, carry)
                cells.append(dict(s=s, c=c, level=level, column=column, terms=terms, carry=carry))
                following[column].append(s)
                if column < 18:
                    following[column + 1].append(c)
                used += count; number += 1
                if level == 0:
                    break
            following[column].extend(old[used:])
        columns = following; level += 1
        assert level < 40
    rows = [[columns[bit][row] if len(columns[bit]) > row else "1'b0" for bit in range(18, -1, -1)]
            for row in range(2)]
    for row, atoms in enumerate(rows):
        lines.append(f'assign row{row} = ' + '{' + ', '.join(atoms) + '};')
    lines.append('endmodule')
    return ('\n'.join(lines) + '\n').encode(), cells, rows


def replace_once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def replace_cell(text, cell, terms, carry=None):
    result = replace_once(text, f"assign {cell['s']} = " + ' ^ '.join(cell['terms']) + ';',
                          f"assign {cell['s']} = " + ' ^ '.join(terms) + ';')
    if carry is None:
        x, y = terms[:2]
        carry = f'{x} & {y}' if len(terms) == 2 else f'({x} & {y}) | (({x} ^ {y}) & {terms[2]})'
    return replace_once(result, f"assign {cell['c']} = {cell['carry']};", f"assign {cell['c']} = {carry};")


def run_tests():
    raw, cells, rows = fixture()
    base = raw.decode()
    proved = verifier.prove(raw)
    assert proved['half_adders'] > 0 and proved['full_adders'] > 0
    # Literals intentionally occupy repeated textual positions in carry logic,
    # but the independent arithmetic input count remains exactly two tokens.
    assert base.count("1'b1") > 2
    cases = []

    def bad(name, text, reason):
        try:
            verifier.prove(text.encode())
        except verifier.Invalid as error:
            assert reason in str(error), (name, str(error), reason)
            cases.append(dict(name=name, rejected=True, reason=str(error)))
        else:
            raise AssertionError('negative fixture unexpectedly proved: ' + name)

    bad('missing_partial_product', base.replace('wire pp_0_0_0;\nassign pp_0_0_0 = (vs1[0] & vs2[0]);\n', ''),
        '512 partial-product')
    bad('wrong_signed_cross_term', replace_once(base, 'assign pp_0_7_0 = ~(vs1[7] & vs2[0]);',
        'assign pp_0_7_0 = (vs1[7] & vs2[0]);'), 'lane/bit/sign')
    bad('wrong_sign_times_sign', replace_once(base, 'assign pp_0_7_7 = (vs1[7] & vs2[7]);',
        'assign pp_0_7_7 = ~(vs1[7] & vs2[7]);'), 'lane/bit/sign')
    bad('wrong_lane_bit', replace_once(base, 'assign pp_0_0_0 = (vs1[0] & vs2[0]);',
        'assign pp_0_0_0 = (vs1[8] & vs2[0]);'), 'lane/bit/sign')
    row0 = 'assign row0 = {' + ', '.join(rows[0]) + '};'
    bad('wrong_correction_bit', fixture((17, 11))[0].decode(),
        'correction tokens')
    ha0 = next(c for c in cells if c['level'] == 0 and c['column'] == 0)
    bad('duplicate_input_slot', replace_cell(base, ha0, [ha0['terms'][0]] * 2), 'distinct arithmetic input slots')
    # Replace only arithmetic uses of pp_2_0_0 by pp_5_0_0. Both have weight 0,
    # so only the global exact-once accounting exposes the duplication/loss.
    duplicate = '\n'.join(line if line.startswith(('wire ', 'assign pp_')) else
                          line.replace('pp_2_0_0', 'pp_5_0_0') for line in base.split('\n'))
    bad('duplicate_global_arithmetic_use', duplicate, 'exactly one arithmetic destination')
    bad('wrong_weight', replace_cell(base, ha0, ['pp_0_0_1', ha0['terms'][1]]), 'weight mismatch')
    ha1 = next(c for c in cells if c['level'] == 0 and c['column'] == 1)
    bad('same_layer_new_carry', replace_cell(base, ha1, [ha0['c'], ha1['terms'][1]]), 'same/future layer')
    bad('cycle', replace_cell(base, ha0, [ha0['s'], ha0['terms'][1]]), 'cycle in complete internal DAG')
    fa = next(c for c in cells if len(c['terms']) == 3)
    x, y, z = fa['terms']
    bad('wrong_full_adder_truth_table', replace_once(base, f"assign {fa['c']} = {fa['carry']};",
        f"assign {fa['c']} = ({x} | {y}) | (({x} ^ {y}) & {z});"), 'truth-table identity')
    bad('foreign_carry_input', replace_once(base, f"assign {ha0['c']} = {ha0['carry']};",
        f"assign {ha0['c']} = pp_2_0_0 & {ha0['terms'][1]};"), 'input-set mismatch')
    wrong = list(rows[0]); indices = [i for i, value in enumerate(wrong) if value.startswith(('s_', 'c_', 'pp_'))]
    i, j = indices[:2]; wrong[i], wrong[j] = wrong[j], wrong[i]
    bad('output_concat_bit_swap', replace_once(base, row0, 'assign row0 = {' + ', '.join(wrong) + '};'),
        'concat bit weight mismatch')
    bad('multiple_driver', base.replace('endmodule', 'assign pp_0_0_0 = (vs1[0] & vs2[0]);\nendmodule'), 'multiple drivers')
    bad('missing_driver', replace_once(base, 'assign pp_0_0_0 = (vs1[0] & vs2[0]);\n', ''), 'driver coverage')
    bad('unrecognized_unused_wire', base.replace('endmodule', "wire hidden;\nassign hidden = 1'b1;\nendmodule"),
        'unrecognized internal wire')
    bad('unknown_statement', base.replace('endmodule', 'always (vs1) row0 = row1;\nendmodule'), 'unknown SV statement')
    bad('conditional_compilation', '`ifdef X\n' + base + '`endif\n', 'unknown SV text')
    bad('extra_module', base + 'module unrelated(); endmodule\n', 'extra module')
    bad('line_comment_tool_pragma', '// synopsys translate_off\n' + base, 'unknown SV text')
    bad('block_comment_tool_pragma', '/* synthesis translate_off */\n' + base, 'unknown SV text')
    return dict(status='SYNTHETIC_FIXTURE_SELFTEST_PASS', actual_generated_rtl_qualified=False,
                fixture_kind='Independent HA-first/Wallace schedule; not the candidate Scala schedule.',
                fixture_sha256=hashlib.sha256(raw).hexdigest(), fixture_bytes=len(raw),
                positive=dict(full_adders=proved['full_adders'], half_adders=proved['half_adders'],
                              local_boolean_cases=proved['local_boolean_cases'],
                              arithmetic_one_tokens=2, textual_ones=base.count("1'b1")),
                negatives=cases)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    result = run_tests()
    with args.output.open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
