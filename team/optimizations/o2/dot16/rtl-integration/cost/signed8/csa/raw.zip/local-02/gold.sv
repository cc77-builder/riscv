module Gold(input wire [63:0] a, input wire [63:0] b, output wire [31:0] result);
wire [15:0] p0;
wire [15:0] p1;
wire [15:0] p2;
wire [15:0] p3;
wire [15:0] p4;
wire [15:0] p5;
wire [15:0] p6;
wire [15:0] p7;
wire [127:0] wide;
VDotProducts products(.io_vs1({64'h0,a}), .io_vs2({64'h0,b}), .io_products_0(p0), .io_products_1(p1), .io_products_2(p2), .io_products_3(p3), .io_products_4(p4), .io_products_5(p5), .io_products_6(p6), .io_products_7(p7));
VDotReduce reduce(.io_products_0(p0), .io_products_1(p1), .io_products_2(p2), .io_products_3(p3), .io_products_4(p4), .io_products_5(p5), .io_products_6(p6), .io_products_7(p7), .io_result(wide));
assign result=wide[31:0];
endmodule
