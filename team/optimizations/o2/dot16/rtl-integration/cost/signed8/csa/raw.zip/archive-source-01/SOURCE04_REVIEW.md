# source04 固定 CSA 续接：实现有限审查

时间：2026-11-07 19:48:22 UTC  
审查者：`/root/whole2_code_review`

## 结论

**GO（静态实现审查），未发现需要阻断 source04 首次实际运行的具体问题。** 范围仅为固定前序复用、身份闭合、状态表达及保留的FU/cost执行入口；不预报本次FU或成本PASS。

审查对象：

- csa.py：38503B，SHA `668ebba4cefe28419bb63634c73e4435868751960661612105bd1c25c1b29b22`。
- CSA_CONTRACT.md：6308B，SHA `baf2de180b12560240e488ce9936f4608c47681792b79efcd3f034456a67bf78`。
- controller-derivation.json：15803B，SHA `13b9c81f958f7933f7d0f637ac749febbf466862832e79df03ddd925755a7fae`。

## 独立核对结果

1. **窄派生属实。** 17项逆变换每项均唯一命中，完整恢复34059B的v3代码，SHA精确为 `07d93e73072304a64b7bc415820b2856a27b2d74a01e649a2e141f78e8adf0f7`。原26命令的FU/cost阶段6389B逐字节相等，SHA `a82e5e6bbb4e398d257d849880aa0b6d1766d56955ce279e4ec3e7cece4f07f4`；command超时/回收函数也逐字节相等。只做AST读取/解析，没有导入或执行候选。

2. **前序异常形态固定且兼容实际回执。** result/input/classes/classpath/proof/log/原SAT输入/source03代码合同均有固定SHA。7条有序命令、前6条exit0、全部回收、第7条120s精确TimeoutExpired受到检查。实际最后记录确实没有exit_code键，满足本实现判据。旧FAILED保留，进程组若仍存在只拒绝，不kill其他进程。

3. **前序末尾未运行的审计有补齐路径。** 旧inputs的originals/snapshots、完整overlay清单成员、四套SV及manifest全部在本次inputs落盘前pin。新preflight仍核完整原classpath；末尾联合pins/snapshots/class_pins/generated_pins及classpath覆盖旧输入、旧类文件和新副本。跳过compile后class_pins已从固定原清单初始化，未发现尾部变量断点。

4. **新副本是真正后段输入。** 四套SV逐文件核原长度/SHA，复制后再核SHA；相对manifest原样复制，原封闭文件集合、manifest、top、实例、P/R表达式和R宽度检查保留。四CSA字节相等。FU使用新目录SV与新obj目录；map/STA继续按原模板将输入/输出置换到新目录。

5. **组合证明复用与SAT UNKNOWN没有混写。** 完整结构报告原字节复制并pin，内容还须等于原result中的结构字段；checker SHA与新CSA SHA重新绑定，三个更强编码不变量再次核对。miter记录固定 `UNKNOWN_EXTERNAL_TIMEOUT`，带 `solver_equivalence_proved=false`、来源和retried=false。没有compile/generate/checker/SAT新子进程。

6. **实际执行与资格记录分离。** commands只列本次实际26项，前6项复用及1项未重试单独记录。positive coverage、四类负控、同约束cost/STA及回收主体未改。全部最终pin、classpath、总预算审计通过后才设置整体arithmetic/FU资格；parent/core/app继续false。

## 已排除的疑点与适用边界

设计初评的“绝对路径manifest迁移”疑点已由实际元数据排除：8份文本逐一核长度和SHA，token全部相对。当前实现可以直接保留原字节及原解析检查，无需额外路径机制。

原结构report和prove.ys中的旧绝对来源路径有意保留；它们在本次仅作为原始证据，不被重新执行。实际复制后的SV和消费路径另行绑定。

本记录只确认静态入口与已取得的前序证据相容。没有执行source04、生成、EDA、guest或FU测试；首跑若在实际输入核验或后段工具处失败，应保留本次真实失败结果。旧local02回执不应被改称成功。

