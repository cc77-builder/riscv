# CSA source04 / local03 续接：有限设计审查

时间：2026-11-07 19:44:54 UTC  
审查者：`/root/whole2_code_review`

## 结论

**设计 GO；source04 尚未提供，本结论不是实现或实际运行 GO。** 已完成且身份相同的生成、四wrapper绑定及结构证明可复用。保持 local02 FAILED 原件，SAT明确记录 `UNKNOWN_EXTERNAL_TIMEOUT`，后段执行原有22条FU命令与4条成本命令，是当前更简单的推进方法。没有理由因这一明确超时重新编译/生成前6项或延长SAT。

本次只读设计、现有v3源码及采集元数据；没有生成、EDA、guest或修改候选。

## 核实来源与当前事实

读取 `source-review/csa-candidate-v3/csa.py` 全文，34059B，SHA `07d93e73072304a64b7bc415820b2856a27b2d74a01e649a2e141f78e8adf0f7`。读取同目录 `local02-metadata.json`、`local02-terminal-inspection.json`。后者为原文件采集记录，不冒充完整原result字节；source04仍须直接pin原件。

采集记录中的原result为103298B，SHA `84b752a19a62d6e436d347cdd1273110c6530bd6024c41eecd58fbd8574e450d`。前6条命令分别为compile、4次generate、structure，均exit0/reaped/group_absent；第7条miter由外层120s抛出TimeoutExpired，cleanup_complete/reaped/group_absent均true，无正常exit_code。FU与cost结果列表均为空，末尾最终审计未到达。

对采集记录中内嵌完整文本重新计算了长度和SHA，结构报告、SAT日志、prove.ys、gate.sv、gold.sv均与原件元数据吻合。SAT日志确实已经进入求解（39622变量、111869子句），没有成功或反例终态；不能将外层120s终止称作solver内部60s正常超时。

关键身份入口：

| 原件 | SHA-256 |
|---|---|
| inputs.json | `612f760a4d593a1899e7079c98a4fde5b2d14e702435cb09ffc1425e5f981616` |
| overlay-classes.json | `d76cd45beda440ecc8fdc64ced5dc796e19c1e8641d7ebd7e8e12c8e401e242a` |
| classpath-before.json | `d9a3071fc4f2cb1fb6766bcf3d3efdc0571bfc09986bace0b432b3b82d445902` |
| arithmetic-structure.json | `9483d70f24876e7c89281e559d3d062355c0787e38a7f3fd7ab9cf36d3cd8ad6` |
| actual-csa-independent-miter.log | `a9175ff5e52888f37d8cf8eeeb1673f6975e32cc8e08687be91f3db2cc845b2b` |

实际CSA仍为 `68227036423ff34235b275546dc7d2341fb5e890857e1b9098f4bc070f9545f6`。已取得的结构报告绑定checker `e6924e…`，477FA/17HA，无discarded carry，row0/row1最高位分别为常量1/0。四wrapper身份及表达式与独立实际审查一致；这不是把旧不同输入的PASS迁移给新RTL。

## 实现时真正需要闭合的点

1. **只接受这一精确前序失败形态。** 固定result原始SHA、7个有序命令及前6项成功/全部回收事实；第7项必须正是指定miter的外层超时。保留完整日志和没有SUCCESS/FAIL/ERROR终态的边界，不把其他工具错误、实际反例或任意FAILED归类为可续接。UNKNOWN_EXTERNAL_TIMEOUT始终不是solver PASS。

2. **补做前序未到达的最终身份核验。** v3的异常绕过末尾全pins/classpath检查，所以“前6项成功”不能自动推出输入全程资格闭合。按已提出的方案，在local03入口和末尾重核前序originals、snapshots、overlay class文件、原classpath、生成文件、结构报告及日志等固定身份；新输入副本也前后核验。旧result保持FAILED，不补写其inputs_unchanged=true。

3. **复制必须绑定真正被后段消费的四套SV。** fresh local03中的SV集合、各文件长度/SHA、top、resource/filelist与原记录闭合；重用现有wrapper_binding、R宽度及四CSA字节相等检查。结构报告的原rtl.path可以保留local02来源，由新字段明确映射到相同SHA的local03副本，不改写原报告来制造新证明。

4. **状态与实际命令账本分开。** local03的commands只记录实际执行的26项；复用的前6项及已结束的miter作为带原result/日志SHA的来源记录。最终arithmetic_equivalent的依据是已有严格组合结构证明加相同实际wrapper绑定，FU资格依赖本次完整两态FU及负控；parent/core/app资格继续false。不能把旧阶段布尔值直接当作本次全部完成。

5. **跳过前段后仍须初始化原尾部依赖。** 原末尾使用class_pins、generated_pins、cp_old/cp_paths等。它们要分别指向已固定前序证据和本次新副本/产物，不能因不执行compile而遗漏变量，也不能只对新目录做最终审计。原输入目录只读，obj、mapped、tmp、日志全部留在fresh local03；后段argv和映射模板必须实际指向新SV。

这些都是原续接设计应表达清楚的身份与状态连接，不要求新增测试矩阵或更换证明方法。

## 已排除的路径疑点

最初提出“原resource manifest可能包含local02绝对路径”的条件性风险。实际补读已排除：8份manifest内嵌文本均自核SHA匹配，所有token相对，其中resource精确为 `VDotCarrySaveRows.sv\n`。因此逐字节复制后仍可直接执行原有解析/闭合集合检查，无需重写manifest、另建映射机制或增加运行入口。

## 最简实现建议与后续边界

固定一个predecessor的一次性复用分支即可：保留现有前置输入核验，复制四套原始SV与manifest，绑定已有结构报告和明确的UNKNOWN miter来源，然后进入原FU/cost尾部。overlay classes只需作为只读来源证据核验，后段不使用Java，无需重新编译或复制成另一套缓存。

后段原有coverage、四类负控、进程回收、同库/同约束映射、端口/面积/五类STA及最终pin门保持。共26项来自每feature的lint/build/positive与4组inject+check（11×2），再加map/STA（2×2）。

source04提供后仅需审窄diff与这些连接点；本设计审查不预报FU、成本或完整工程PASS。

