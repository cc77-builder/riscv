# CSA 四份实际 wrapper：post-P / capture 有限审查

记录时间：2026-11-07 19:25:57 UTC  
审查者：`/root/whole2_code_review`

## 结论

**GO，四份指定 SHA 的实际 post-P、P 捕获、非法置零与 R 位宽核对通过；未发现反例。** 这只闭合实际 wrapper 表达式与前一源码论证之间的对应，不授予 CSA 算术结构 PASS、FU 执行 PASS、整核或 PPA 资格。首次 attempt 的 FAILED 回执保持原样。

已完整读取两份 feature0 wrapper，读取两份 feature1 与对应 feature0 的全文件差异，以不遗漏的差异闭合全部四份实际文件。没有生成、EDA、guest，也没有修改候选。

## 实际身份

| 消费者 | 字节数 | SHA-256 |
|---|---:|---|
| cost feature0 | 28218 | `310ed575756929bbcbaae38967f3bb78837668ef0efd9b2d7777c8d31b843e51` |
| cost feature1 | 28918 | `50ea2a5ee280e45e4b9762f051f8092ce19366d66e3a96a8e7addf811d7ea295` |
| FU feature0 | 12544 | `e782a1c059c12ca60fde7486c5f0134cc1d111e47ba46ce167d3d4d372a35b81` |
| FU feature1 | 13255 | `cb315f9a947d6afed0b6a599fc6573285c1e3b8163e3005efdc6ae4e3b6b0642` |

目录为 `source-review/csa-attempt1`。同目录 result.json 为99071字节、SHA `cb12d0f14f985d97947f4d1c6f19a7b5e4696f6b0099eff756db77825fd44766`，包含四消费者 binding，status仍为FAILED。

## 实际数据通路

feature0 的R唯一赋值为：

```verilog
rPacket_res_data <= pCtrl_exceptionVec_2 ? 19'h0 : pRows_0_0 + pRows_0_1;
```

两个P行与R均19位。普通无符号加法的低19位正是模2^19的结果，后续按结果位18恢复符号，因此不需要额外的$signed。

feature1 的R唯一赋值为：

```verilog
rPacket_res_data <=
  pCtrl_exceptionVec_2
    ? 20'h0
    : {pRows_1_1[18], pRows_1_1} + {pRows_1_0[18], pRows_1_0}
      + {pRows_0_1[18], pRows_0_1} + {pRows_0_0[18], pRows_0_0};
```

四项都显式复制原19位行的符号位，形成20位补码。各项、零分支及R目的地同为20位，所以即使concat在SV中为unsigned，低20位加法仍与所需有符号和的位模式一致。逆序重排不影响同宽模加结果；不能仅因未出现$signed而拒绝。

上述位模式与真实signed8和的对应，仍依赖实际CSA完整结构证明及“无高carry舍弃、row0[18]=1、row1[18]=0”三个额外不变量，本审查不替代它们。

## 实际捕获、非法零与时序条件

四份wrapper的数据更新均为posedge下的非阻塞赋值：

- 全部P行位于同一个 `if (_pValid_T_2)` 中，条件严格为 `io_in_ready_0 & io_in_valid`。ready再由 `(~liveP | rReady) & ~io_flush_valid & ~reset` 限定。
- feature1高两行在该同一accept块中分别保存 `isDot16 ? _highProducts_rowX : 19'h0`。dot8的两行均为零，没有残留旧高半或后P模式读取。
- R数据唯一赋值位于 `if (move)`，move为 `liveP & rReady`，与保存ctrl/perf的更新同块。非法选择信号是旧P的 `pCtrl_exceptionVec_2`。
- valid复位为0；liveP/liveR受reset及对应kill屏蔽。未捕获P不能产生首次有效R；同边沿move和新accept同时发生时，非阻塞语义使R仍取旧P。
- cost版把move/illegalInput实现为模块级wire；FU版局部automatic logic在对应posedge/accept块中求值。这是当前消费者降低方式的差别，不改变上述使能与数据关系。

R实际宽度为feature0的19位和feature1的20位。输出分别用13份bit18或12份bit19补到32位，然后拼接高96位零。四份文件都对应 `{96'h0, _GEN, rPacket_res_data}`，非法R为全零，所以输出也全零。

本地没有原Rwidth实际SV副本，不能声称已与它逐字节比较。已知对应依据是此前七项Scala精确逆恢复、回执中的四份non-data binding，以及本次对完整实际guard和数据块的独立读取；本地另有的R32旧SV未冒充Rwidth基线。

## 最小 controller 检查建议

直接复用现有compact去空白函数，对提取出的唯一 `rPacket_res_data` RHS按feature精确比较上面两个实际表达式即可。相同feature的cost和FU表达式相同，不需要通用SV求值器，也不必一般化加法重排。

同时保留实际R声明宽度、输出符号复制和单一输出赋值的既有检查。P捕获和R更新的guard绑定必须保留：仅比较RHS不证明它在正确的时刻写入。当前四份guard已独立核实；若后续生成出现不同结构，应先审查，不能忽略未知形态。

可更新的资格仅是这四个SHA的actual post-P/capture review completed。完整算术、FU及后续成本仍按本次真实执行结果记录。

