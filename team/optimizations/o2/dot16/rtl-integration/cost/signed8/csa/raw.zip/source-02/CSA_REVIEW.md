# VDotCarrySaveRows 独立结构验证器

## 交付与当前结论

`verify_csa.py` 只读取 `--rtl` 指定的完整 SV 字节，以独立解析器证明一个 `VDotCarrySaveRows` 组合模块的二值算术恒等式。它不导入 Scala 生成器，不读取生成器的列清单或预期压缩树，也不调用 HDL/EDA 工具。此次只在云端 scratch 实现并自测，尚未据此声称实际 Scala/firtool 输出通过。

入口：

```text
python3 -B verify_csa.py --rtl /absolute/path/VDotCarrySaveRows.sv --output /fresh/directory/structure-proof.json
```

输出父目录须已经存在，JSON 文件必须不存在；不会覆盖旧结果。通过时退出 0、状态为 `CSA_STRUCTURAL_EQUIVALENCE_PASS`、`all_inputs_equivalent=true`，顶层 `rtl_sha256` 为输入完整 SHA-256；拒绝时退出 1，状态为 `CSA_STRUCTURAL_EQUIVALENCE_REJECTED`、`all_inputs_equivalent=false` 并记录原因。结果也记录输入字节数/路径和验证器自身的完整 SHA-256。证明后重新读输入核对未变。输入只读，不启动进程，不写编译缓存。

## 完整解析和算术闭环

解析器接受固定的单模块接口：两个 64 位无符号输入、两个 19 位无符号输出。模块内部只允许单个标量 wire 声明、单驱动连续赋值、限定的按位 Boolean 表达式和两个显式的 19 项 concat。除正常 ASCII 空白外，每个字符和每个语句均须被消费。**所有 SV 注释均拒绝**，以免把 synthesis/synopsys 等工具指令误当无语义空白；候选实际 inlineText 本来没有注释，无需通用注释支持。未知模块、实例、always、initial、宏/条件编译、属性、其他操作符、多驱动、漏声明、漏驱动及多余文本也不能通过。它是针对已知 inline 语法的窄验证器，不接受任意等价改写的 SystemVerilog。

1. **512 个部分积**：每个 lane 的完整 8×8 集合必须存在，实际 vs1/vs2 位索引必须精确对应同一 lane。只有 `(i==7) xor (j==7)` 的 14 个交叉符号项取反；bit7×bit7 为正。每个部分积的权重从 `i+j` 独立确定。
2. **实际 FA/HA 配对**：同一命名坐标的 sum/carry 必须成对且各有唯一驱动。sum 必须是两个或三个不同算术输入槽的 XOR；carry 的全部输入只能且必须来自同一组槽。针对全部 4/8 个 Boolean 输入组合证明 `x+y(+z)=sum+2*carry`。carry 文本里同一信号多次出现不重复计为算术消费。
3. **常量语义**：字面值 `1'b1` 如进入加法器，按一个算术输入槽计数。在局部真值表里，将该槽与其他输入同样穷尽，证明更强的通用 FA/HA 恒等式，再取真实值 1；因此整个 sum/carry 中相同的该槽始终一致。此窄语法有意接受生成器的未化简 FA/HA 模板，不尝试认可常量折叠后的其他表达式。输出填充 `1'b0` 不计入算术 heap。
4. **DAG、层和权重**：对完整内部依赖图独立检查无环。每个算术输入必须来自更早层，可以跨多层前传，不能回吃本层新生成的 carry 或 sum。输入权重必须相同，sum 保持该权重，carry 为下一列；命名列必须与实际输入推导的权重一致。
5. **完整去向和最终输出**：每个 pp 和产生的 sum/carry 恰有一个算术去向，只有权重达到 19 的 carry 可以被舍弃。两个实际 concat 按从 bit18 到 bit0 的位置核对每个信号的真实权重。多用、漏用、错位、未知 wire 都拒绝。所有算术 one 槽和直接输出 one 的整体计数必须恰为 bit18 一次、bit11 一次。

## 为什么它能证明全部二值输入

设一个 lane 的有符号输入为 `a,b`。将 14 个负的交叉项 `-p*2^(i+j)` 换成 `(1-p)*2^(i+j)`，增加的常量为：

```text
2 * 2^7 * (1 + 2 + ... + 2^6) = 32512
```

因此八个 lane 的原始反相 heap 等于 `S + 8*32512`，其中 `S` 是真实八项 signed8 乘积之和。再加上实际核实的两个 one：

```text
8*32512 + 2^18 + 2^11 = 524288 = 2^19
```

每个局部加法器在所有输入下保持加权整数和，完整单次消费和 concat 权重绑定使这些局部恒等式能够组合。舍弃的 carry 均为 `2^19` 的倍数，所以：

```text
(row0 + row1) mod 2^19 = S mod 2^19
```

真实八项和的紧界为 `[-130048,131072]`，落在 signed19 的 `[-262144,262143]` 范围内。因此先取模 19 位再作 signed19 解释，唯一得到真实的 `S`。这是一项对全部 `2^128` 二值输入成立的组合结构证明；不声称覆盖 X/Z 四态仿真语义。

## 自测证据与限制

`test_verify_csa.py` 独立构造一棵 HA 起始、随后 Wallace 三元压缩的 **synthetic fixture**，不复制候选 Scala 的 Dadda 高度调度。正例含 489 个 FA、15 个 HA，3972 项局部真值检查；文本出现三次 one，但只有两个算术 one 输入槽，直接检验了不能按文本次数计常量。

`csa-fixture-selftest-03.json` 记录最终无注释语法下正例通过及 21 个针对性负例被拒绝：漏部分积、错符号、错 lane、错常量列、局部/全局重复消费、错权重、同层回吃 carry、环、错误 FA 真值、carry 漏/混输入、concat 错位、多驱动、漏驱动、漏网 wire、未知语句、条件编译、额外模块，以及单行/块注释工具指令。fixture 的身份通过生成器说明、文件名和自测 JSON 标识，SV 正文不含注释。

首次自测在测试构造阶段误以为 bit18 的 one 必须直接留在 row0，实际 fixture 可将其压缩；该次退出 1，没有写成功 JSON。已将负控改为独立生成错误的 bit17 校正，并保留 `csa-fixture-selftest-01-failure.txt`。这是 fixture 断言修正，验证器逻辑未因此放宽。第二次自测及旧 CLI 结果也保留为语法收紧前的记录；最终版本以第三次自测和 `synthetic-proof-no-comments.json` 为准。

**实际消费者绑定仍由主代理核对**：生成 SV 的字节身份；feature0/1 实例数量；低/高 64 位源切片；两个 row 的完整 P 寄存保存；接受请求时高半模式屏蔽；P 后先做 19 位取模、再解释有符号；feature1 两个 signed19 合为 signed20；最后的 32 位符号扩展和高 96 位清零。验证器结果明确保留 wrapper、顺序 FU、real-parent、整核、应用和性能资格为 false。

固定 baseline Products+Reduce 的实际 SAT miter 是主代理的独立交叉检查。这个脚本不会把 miter 超时变成 PASS，也不替代真实反例的处理。
