module Gate(input wire [63:0] a, input wire [63:0] b, output wire [31:0] result);
wire [18:0] u,v;
wire [18:0] sum19=u+v;
VDotCarrySaveRows rows(.vs1(a),.vs2(b),.row0(u),.row1(v));
assign result={{13{sum19[18]}},sum19};
endmodule
