ClockGate.sv
VDotSignedByteProduct.sv
