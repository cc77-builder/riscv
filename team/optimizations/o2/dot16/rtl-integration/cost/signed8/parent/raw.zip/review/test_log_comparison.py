"""Pure-function checks against retained review evidence; no controller run.

The original LogPerf bytes are reconstructed only in memory from the exact
attempt1 file and three recorded label reversals, then checked against the
original SHA. Only need(), LOG_OBJECT_MESSAGES and the comparator are loaded.
"""

import ast
import hashlib
import itertools
from pathlib import Path
import re
import unittest


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ORIGINAL_SHA = '6117e093dc353242609fccbde1dac8b4fd477bcb9f1416768db08ea4471dc857'
PINS = {
    'inline-parent-candidate-v2/inline_parent.py': 'cc6a0d5250c18bac174c6ed7413d657091bca64f4bd07ed13b6b3507be078acc',
    'inline-parent-candidate-v2/PARENT_CONTRACT.md': 'cb28933f3f67166898f77d98b3780e4a37d9fc96b29126b7fdc9b473a81ceff2',
    'inline-parent-attempt1/LogPerfEndpoint.sv': '9b0f55b3e6cb0377730c167364756f9987734a8c0d5b2b4cefc10a4fc540285a',
    'inline-parent-attempt2/LogPerfEndpoint.sv': 'af8d1156ca43cef0d18acfb823c826fd7a3366649266fb1cb9c10f43d2fe0b83',
}
CLASSES = ('xiangshan.backend.fu.wrapper.VFDivSqrt',
           'xiangshan.backend.exu.ExeUnitImp', 'xiangshan.backend.fu.wrapper.VIDiv')
OLD_LABELS = (b'7c8f9c2e', b'53dad875', b'8ce3f27')


def pure_comparator(path):
    tree = ast.parse(path.read_bytes())
    selected = [node for node in tree.body
                if (isinstance(node, ast.FunctionDef) and
                    node.name in ('need', 'compare_log_object_labels')) or
                (isinstance(node, ast.Assign) and len(node.targets) == 1 and
                 isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'LOG_OBJECT_MESSAGES')]
    if len(selected) != 3:
        raise AssertionError('three exact pure-function dependencies')
    namespace = {'hashlib': hashlib, 're': re}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace['compare_log_object_labels']


def reconstructed_reference(attempt1):
    raw = attempt1
    for before, after in ((b'VFDivSqrt@3ce53f6a', b'VFDivSqrt@7c8f9c2e'),
                          (b'ExeUnitImp@dab48d3', b'ExeUnitImp@53dad875'),
                          (b'VIDiv@7c048b30', b'VIDiv@8ce3f27')):
        if raw.count(before) != 1:
            raise AssertionError('one exact recorded label reversal')
        raw = raw.replace(before, after, 1)
    if len(raw) != 1891 or hashlib.sha256(raw).hexdigest() != ORIGINAL_SHA:
        raise AssertionError('reconstruction must match the complete original bytes SHA')
    return raw


class LogComparisonTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        originals = {name: (ROOT/name).read_bytes() for name in PINS}
        for name, pin in PINS.items():
            if hashlib.sha256(originals[name]).hexdigest() != pin:
                raise AssertionError('unchanged evidence ' + name)
        cls.old_source = originals['inline-parent-candidate-v2/inline_parent.py']
        cls.actual1 = originals['inline-parent-attempt1/LogPerfEndpoint.sv']
        cls.actual2 = originals['inline-parent-attempt2/LogPerfEndpoint.sv']
        cls.reference = reconstructed_reference(cls.actual1)
        cls.compare = staticmethod(pure_comparator(HERE/'inline_parent.py'))
        cls.old_compare = staticmethod(pure_comparator(ROOT/'inline-parent-candidate-v2/inline_parent.py'))
        first = cls.reference.index(b'      if ((`PRINTF_COND_) & ')
        last = cls.reference.index(b'    end // always @(posedge)\n', first)
        lines = cls.reference[first:last].splitlines(keepends=True)
        if len(lines) != 12:
            raise AssertionError('the pinned reference has exactly three four-line blocks')
        cls.blocks = {name: b''.join(lines[i * 4:(i + 1) * 4]) for i, name in enumerate(CLASSES)}
        for name, block in cls.blocks.items():
            if block.count(name.encode()) != 1:
                raise AssertionError('independent test block class identity')
        cls.prefix, cls.suffix = cls.reference[:first], cls.reference[last:]

    def reject(self, candidate):
        with self.assertRaises(ValueError):
            self.compare(candidate, self.reference)

    def test_exact_original(self):
        record = self.compare(self.reference, self.reference)
        self.assertTrue(record['diagnostic_text_byte_exact'])
        self.assertFalse(record['block_order_changed'])
        self.assertFalse(record['simultaneous_error_log_order_may_differ'])
        self.assertEqual(record['changed_labels'], 0)

    def test_retained_actual_attempts(self):
        for raw, order in ((self.actual1, CLASSES),
                           (self.actual2, (CLASSES[0], CLASSES[2], CLASSES[1]))):
            with self.subTest(order=order):
                record = self.compare(raw, self.reference)
                self.assertEqual(record['old_sha256'], ORIGINAL_SHA)
                self.assertEqual(record['old_order'], list(CLASSES))
                self.assertEqual(record['new_order'], list(order))
                self.assertEqual(record['changed_labels'], 3)
                self.assertEqual(record['simultaneous_error_log_order_may_differ'], order != CLASSES)
                self.assertTrue(record['complete_same_class_blocks_equal_after_labels'])
                self.assertTrue(record['outside_region_bytes_equal'])
                self.assertFalse(record['diagnostic_text_byte_exact'])
                self.assertFalse(record['real_rtl_modified'])

    def test_v2_still_rejects_actual_attempt2_order(self):
        with self.assertRaisesRegex(ValueError, 'differs only in the three exact diagnostic object labels'):
            self.old_compare(self.actual2, self.reference)

    def test_all_six_permutations_with_label_length_changes(self):
        changed = {}
        for name, old_label, new_label in zip(CLASSES, OLD_LABELS, (b'a', b'12345678', b'0')):
            changed[name] = self.blocks[name].replace(b'@' + old_label + b': ', b'@' + new_label + b': ', 1)
        baseline = self.compare(self.reference, self.reference)['comparison_sha256']
        for order in itertools.permutations(CLASSES):
            with self.subTest(order=order):
                candidate = self.prefix + b''.join(changed[name] for name in order) + self.suffix
                record = self.compare(candidate, self.reference)
                self.assertEqual(record['new_order'], list(order))
                self.assertEqual(record['comparison_sha256'], baseline)
                self.assertEqual(record['block_order_changed'], order != CLASSES)

    def test_missing_or_duplicate_class(self):
        for order in ((CLASSES[0], CLASSES[1]), (*CLASSES, CLASSES[0])):
            with self.subTest(order=order):
                self.reject(self.prefix + b''.join(self.blocks[name] for name in order) + self.suffix)

    def test_noncontiguous_blocks(self):
        for gap in (b'\n', b'      // gap\n', b'      $display("extra");\n'):
            with self.subTest(gap=gap):
                self.reject(self.prefix + self.blocks[CLASSES[0]] + gap +
                            self.blocks[CLASSES[1]] + self.blocks[CLASSES[2]] + self.suffix)

    def test_prefix_and_suffix_mutations(self):
        for before, after in ((b'posedge clock', b'negedge clock'),
                              (b'endmodule\n', b'endmodule // extra\n')):
            with self.subTest(before=before):
                self.reject(self.reference.replace(before, after, 1))

    def test_block_content_mutations(self):
        edits = ((b'& x1_bore &', b'& x1_bore_1 &'),
                 (b'& ~reset)', b'& reset)'),
                 (b"$fwrite(32'h80000002,", b"$fwrite(32'h80000003,"),
                 (b'Vfdiv OpType not supported', b'Vfdiv OpType unsupported'),
                 (b'fuOutValidOH %b', b'fuOutValidOH %d'),
                 (b"64'h0);", b"64'h1);"),
                 (b"64'h0, x2_bore);", b"64'h0, x1_bore);"),
                 (b'      if ((', b'      if  (('),
                 (b'VFDivSqrt@', b'UnexpectedClass@'))
        for before, after in edits:
            with self.subTest(before=before):
                self.reject(self.reference.replace(before, after, 1))

    def test_invalid_labels(self):
        for label in (b'', b'123456789', b'ABCDEF', b'12-34'):
            with self.subTest(label=label):
                self.reject(self.reference.replace(b'@7c8f9c2e:', b'@' + label + b':', 1))

    def test_added_fourth_independent_block(self):
        extra = (b'      if (x1_bore)\n'
                 b'        $fwrite(32\'h80000002, "extra");\n')
        self.reject(self.prefix + b''.join(self.blocks[name] for name in CLASSES) + extra + self.suffix)

    def test_modified_reference_cannot_expand_known_block_templates(self):
        changed = self.reference.replace(b"64'h0);", b"64'h1);", 1)
        with self.assertRaises(ValueError):
            self.compare(changed, changed)

    def test_only_comparator_and_contract_version_changed(self):
        new_text = (HERE/'inline_parent.py').read_text()
        old_text = self.old_source.decode()
        def function_text(text):
            nodes = [node for node in ast.parse(text).body
                     if isinstance(node, ast.FunctionDef) and node.name == 'compare_log_object_labels']
            self.assertEqual(len(nodes), 1)
            return ast.get_source_segment(text, nodes[0])
        restored = new_text.replace(function_text(new_text), function_text(old_text), 1)
        restored = restored.replace("CONTRACT = 'dot16-inline-signed8-real-parent-v3'",
                                    "CONTRACT = 'dot16-inline-signed8-real-parent-v2'", 1)
        self.assertEqual(restored.encode(), self.old_source)
        for name, pin in PINS.items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(), pin)


if __name__ == '__main__':
    unittest.main(verbosity=2)
