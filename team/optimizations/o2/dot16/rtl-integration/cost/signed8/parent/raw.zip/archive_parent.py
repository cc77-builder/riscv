#!/usr/bin/env python3
"""Archive three CLOSED signed8-parent attempts; never run checkers or guests.

Run on WSL with --runs <WSL run root>, --sources <mounted Windows run root>,
--receipts <JSON object keyed parent-01/02/03 with raw structuredContent>, and
--output <fresh directory>. All original files remain in place. External
dependencies are referenced by their original manifests, not reread or copied.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

SUCCESS_SHA = 'a122603c7979c66d44dd79ba7a9f11c1cf5538231797d887c743986e136b124f'
OPS = ('392e8638ed4d39e3565a6f02a5c44bf1', '7e52b450a060167eaa43b017e6228d99',
       'fa72a5671a2746cf324188a86c330a45')
OP_PREFIX = '49cbde030e5643f0cccfca5cec8a79c1.'
FAULTS = ('identity', 'rob', 'high', 'metadata', 'wen', 'stall', 'route', 'double',
          'clock', 'occupancy', 'kill_p', 'kill_r', 'survivor', 'duplicate',
          'missing', 'reset', 'perf_input', 'perf_swap', 'perf_parent', 'perf_cross')
BINARY = 'VVDotElasticParentTestTop'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def scan(roots):
    kept, omitted = {}, {}
    for root in roots:
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        for path in sorted(root.rglob('*')):
            need(not path.is_symlink(), 'archive tree contains a link: ' + str(path))
            if path.is_dir():
                continue
            need(path.is_file(), 'regular archive input: ' + str(path))
            rel = path.relative_to(root)
            name = root.name + '/' + rel.as_posix()
            is_obj = (root.name in ('parent-01', 'parent-02', 'parent-03') and len(rel.parts) >= 3
                      and rel.parts[0] in ('feature0', 'feature1') and rel.parts[1] == 'obj')
            if is_obj and rel.parts[2:] != (BINARY,) and path.suffix != '.log':
                omitted[name] = dict(bytes=path.stat().st_size, reason='Verilator build cache; original retained')
            else:
                need(name not in kept, 'unique archive name')
                kept[name] = path
    return kept, omitted


def main(a):
    runs, sources, receipts = (p.resolve() for p in (a.runs, a.sources, a.receipts))
    out = a.output.resolve()
    need(a.output.is_absolute() and a.output == out and not out.exists(), 'fresh absolute output without links')
    roots = [base / (prefix + f'{i:02}') for i in (1, 2, 3)
             for base, prefix in ((runs, 'parent-'), (sources, 'parent-source-'))]
    need(all(out != p and not out.is_relative_to(p) and not p.is_relative_to(out) for p in roots),
         'archive output separate from all six input trees')
    outer = read(receipts)
    need(set(outer) == {'parent-01', 'parent-02', 'parent-03'}, 'exact three outer receipts')
    audits, frozen = [], {}
    labels = ['original-checker-tests', 'compile-parent-harness']
    for f in (0, 1):
        labels += [f'generate-parent-{f}'] + [f'parent-{f}-{s}' for s in
                    ('lint', 'build', 'positive', 'positive-replay', 'metadata-replay', 'coverage')]
        labels += [f'parent-{f}-{action}-{fault}' for fault in FAULTS for action in ('inject', 'check')]
    for i in (1, 2, 3):
        name, run = f'parent-{i:02}', runs / f'parent-{i:02}'
        result = read(run / 'result.json')
        success = i == 3
        need(result['contract'] == f'dot16-inline-signed8-real-parent-v{i}', 'attempt contract identity')
        need(result['status'] == ('INLINE_SIGNED8_REAL_PARENT_PASS' if success else 'FAILED')
             and result['parent_qualified'] is success and result.get('finished'), 'terminal original result')
        if success:
            need(sha(run / 'result.json') == SUCCESS_SHA and result['all_children_reaped'] is True,
                 'fixed completed parent-03')
        need([r['label'] for r in result['commands']] ==
             (labels if success else labels[:2] + ['generate-parent-0']), 'original exact command inventory')
        for row in result['commands']:
            need(row.get('reaped') is True and row.get('group_absent') is True and row.get('finished')
                 and type(row.get('exit_code')) is int, 'recorded complete child closure')
            need(row['expected_exit'] is None or row['exit_code'] == row['expected_exit'], 'recorded expected exit')
        receipt = outer[name]
        shell = receipt['shell']['result']
        need(receipt['operation_id'] == OP_PREFIX + OPS[i - 1]
             and receipt['status'] == ('succeeded' if success else 'failed')
             and shell['exit_code'] == (0 if success else 1) and shell['cleanup_complete'] is True
             and shell['timed_out'] is False and shell['cancelled'] is False
             and shell['stdout_truncated'] is False and shell['stderr_truncated'] is False,
             'complete original outer receipt with full stdout/stderr')
        inputs, observed = read(run / 'inputs.json'), read(run / 'observed-input-pins.json')
        need(inputs['originals'] == observed['files']
             and set(observed['resolved_targets']) == set(observed['files']), 'consistent original input manifests')
        groups = [inputs['snapshots']]
        final_path = run / 'final-artifact-pins.json'
        if success:
            groups.append(read(final_path))
            need([r['feature'] for r in result['parent_results']] == [0, 1], 'both recorded parent features')
            for row in result['parent_results']:
                binary = run / f"feature{row['feature']}" / 'obj' / BINARY
                need(row['checks_completed'] is True and row['faults'] == list(FAULTS)
                     and groups[-1][str(binary)] == row['binary_sha256'], 'actual qualified binary binding')
        for group in groups:
            for path, digest in group.items():
                p = Path(path)
                need(p.is_absolute() and p == p.resolve() and p.is_relative_to(run), 'local snapshot/artifact scope')
                need(p not in frozen or frozen[p] == digest, 'consistent frozen artifact pin')
                frozen[p] = digest
        audits.append(dict(attempt=name, result_sha256=sha(run / 'result.json'), status=result['status'],
                           error=result.get('error'), commands=len(result['commands']),
                           exit_histogram=dict(Counter(str(r['exit_code']) for r in result['commands'])),
                           original_inputs=len(inputs['originals']), snapshots=len(inputs['snapshots']),
                           final_pins_present=final_path.exists(), operation_id=receipt['operation_id']))
    files, omitted = scan(roots)
    extras = {'operation-receipts.json': receipts, 'archive_parent.py': Path(__file__).resolve()}
    for path in a.extra:
        name = 'review/' + path.name
        need(name not in extras, 'unique extra evidence name')
        extras[name] = path.resolve()
    need(not set(files) & set(extras), 'unique supplemental names')
    files.update(extras)
    inventory = {n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}
    by_path = {p: inventory[n]['sha256'] for n, p in files.items()}
    need(all(by_path.get(p) == h for p, h in frozen.items()), 'all frozen snapshots/artifacts included unchanged')
    for i in (1, 2, 3):
        for name in ('inline_parent.py', 'PARENT_CONTRACT.md'):
            need(inventory[f'parent-source-{i:02}/{name}']['sha256'] ==
                 inventory[f'parent-{i:02}/source-snapshot/{name}']['sha256'], 'original source equals executed snapshot')
        for path, digest in read(runs / f'parent-{i:02}' / 'inputs.json')['originals'].items():
            p = Path(path)
            if p in by_path:
                need(by_path[p] == digest, 'archived original input matches execution pin')
    manifest = dict(schema=1, attempts=audits, files=inventory, omitted=omitted,
                    omissions_deleted=False, external_dependencies='Retained input/classpath manifests; bytes not copied or rehashed.',
                    scope='Archive integrity only; original receipts retain their original qualification scope.')
    raw_manifest = encoded(manifest)
    out.mkdir(parents=True)
    try:
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            need(len(z.namelist()) == len(files) + 1 and set(z.namelist()) == set(files) | {'ARCHIVE-MANIFEST.json'},
                 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name, expected in inventory.items():
                need(z.getinfo(name).file_size == expected['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == expected['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted = scan(roots)
        after.update(extras)
        need(after == files and after_omitted == omitted, 'closed tree inventory unchanged during archive')
        need(all(p.stat().st_size == inventory[n]['bytes'] and sha(p) == inventory[n]['sha256']
                 for n, p in after.items()), 'all retained source bytes unchanged during archive')
        audit = dict(status='PARENT_RAW_ARCHIVE_VERIFIED', at=datetime.now(timezone.utc).isoformat(),
                     attempts=audits, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive),
                     members=len(files) + 1, frozen_output_pins_verified=len(frozen), omitted_files=len(omitted),
                     member_crc_and_sha_verified=True, retained_files_unchanged=True,
                     original_receipt_closures_checked=True, live_processes_requeried=False,
                     external_dependencies_rehashed=False, checkers_rerun=False,
                     new_builds=0, new_guest_runs=0)
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2))
    except BaseException as error:
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error))))
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ('runs', 'sources', 'receipts', 'output'):
        parser.add_argument('--' + arg, type=Path, required=True)
    parser.add_argument('--extra', type=Path, action='append', default=[])
    main(parser.parse_args())
