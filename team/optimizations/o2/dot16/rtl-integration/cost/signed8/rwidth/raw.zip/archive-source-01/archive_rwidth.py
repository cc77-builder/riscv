#!/usr/bin/env python3
"""Archive CLOSED R19/R20 local-01 with complete ZIP member verification.

No checker, build, EDA, guest or external baseline input is executed/read.
Existing input manifests identify dependencies; original files stay in place.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import stat
import sys
import time
import zipfile

RESULT_SHA = 'f42f7285ff8a357877c546d433251b1dc8c8eef66ee9218c9e3b2c002ca0a261'
RESULT_BYTES = 193611
CONTRACT = 'dot16-signed8-result-width-local-v1'
STATUS = 'SIGNED8_RESULT_WIDTH_GENERATED_FU_AND_COST_COMPLETE'
BINARY = 'VVDotElasticFuTestTop'
FAULTS = ('identity', 'wen', 'high', 'cancel')
SOURCE_NAMES = {'rwidth.py', 'RWIDTH_CONTRACT.md', 'VDotDatapath.scala', 'VDotElastic.scala',
                'source-derivation.json', 'controller-derivation.json'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1 << 20), b''):
        value.update(block)
    return value.hexdigest()


def sha(path):
    with Path(path).open('rb') as stream:
        return stream_sha(stream)


def read(path):
    return json.loads(Path(path).read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def recorded_evidence(run):
    need((run / 'result.json').stat().st_size == RESULT_BYTES and sha(run / 'result.json') == RESULT_SHA,
         'fixed actual closed local-01 result')
    result, inputs = read(run / 'result.json'), read(run / 'inputs.json')
    classes = read(run / 'overlay-classes.json')
    need(result['contract'] == CONTRACT and result['status'] == STATUS and result['finished'] and
         result['all_children_reaped'] is True and result['inputs_unchanged'] is True and
         result['generated_inputs_unchanged'] is True and result['original_classpath_unchanged'] is True and
         result['arithmetic_equivalent'] is True and result['fu_qualified'] is True, 'completed original local evidence')
    scope = ('parent_qualified', 'fullcore_qualified', 'application_performance_qualified', 'core_cost_qualified',
             'resident_modified', 'original_cache_modified', 'production_default_changed')
    need(all(result[name] is False for name in scope) and result['new_core_builds'] == result['new_core_runs'] == 0,
         'unchanged original qualification and mutation boundary')
    labels = ['compile-source-overlay'] + [f'generate-{kind}-{feature}' for feature in (0, 1) for kind in ('cost', 'fu')]
    for feature in (0, 1):
        labels += [f'fu-{feature}-{step}' for step in ('lint', 'build', 'positive')]
        labels += [f'fu-{feature}-{action}-{fault}' for fault in FAULTS for action in ('inject', 'check')]
    labels += [f'{step}-{feature}' for feature in (0, 1) for step in ('map', 'sta')]
    need(len(labels) == 31 and [row['label'] for row in result['commands']] == labels, 'original complete 31-command inventory')
    for row in result['commands']:
        negative = '-inject-' in row['label']
        need(row['reaped'] is True and row['group_absent'] is True and row['finished'] and
             type(row['exit_code']) is int and row['exit_code'] == (1 if negative else 0) and
             row['expected_exit'] == (None if negative else 0), 'original command exit and closure: ' + row['label'])
    pins, groups, sizes = {}, {}, {}
    def pin(path, digest, group, size=None):
        path = Path(path)
        need(path.is_absolute() and path.is_relative_to(run), 'local recorded output pin: ' + str(path))
        need(len(digest) == 64 and all(x in '0123456789abcdef' for x in digest), 'recorded SHA256')
        need(path not in pins or pins[path] == digest, 'consistent recorded output pin')
        pins[path] = digest
        groups.setdefault(group, set()).add(path)
        if size is not None:
            need(type(size) is int and size >= 0 and (path not in sizes or sizes[path] == size), 'consistent recorded size')
            sizes[path] = size
    for path, digest in inputs['snapshots'].items():
        pin(path, digest, 'snapshots')
    for path, digest in classes.items():
        need(Path(path).is_relative_to(run / 'overlay-classes'), 'recorded overlay class scope')
        pin(path, digest, 'overlay_classes')
    need(classes and {(r['feature'], r['kind']) for r in result['generated']} ==
         {(f, k) for f in (0, 1) for k in ('cost', 'fu')} and len(result['generated']) == 4, 'all four generated consumers')
    for row in result['generated']:
        rtl = run / f"{row['kind']}-feature{row['feature']}" / 'rtl'
        top = 'CommonFuCostTop' if row['kind'] == 'cost' else 'VDotElasticFuTestTop'
        names = {'VDotElastic.sv', 'VDotProducts.sv', 'VDotReduce.sv', 'VDotSignedByteProduct.sv', top + '.sv', 'extern_modules.sv'}
        need(len(row['files']) == 6 and {Path(x['path']).name for x in row['files']} == names, 'complete generated SV inventory')
        for item in row['files']:
            rel = PurePosixPath(item['path'])
            need(not rel.is_absolute() and '..' not in rel.parts and (run / rel).parent == rtl, 'relative generated source path')
            pin(run / rel, item['sha256'], 'generated_sv', item['bytes'])
        pin(rtl / 'firrtl_black_box_resource_files.f', row['resource_manifest_sha256'], 'resource_manifests')
        pin(rtl / 'filelist.f', row['filelist_sha256'], 'filelists')
    need([x['feature'] for x in result['fu_results']] == [0, 1] and
         [x['feature'] for x in result['cost_results']] == [0, 1], 'both FU and cost features')
    for row in result['fu_results']:
        need(row['passed'] is True and row['faults'] == list(FAULTS), 'original FU completion and negative inventory')
        pin(run / f"fu-feature{row['feature']}" / 'obj' / BINARY, row['binary_sha256'], 'fu_binaries')
    for row in result['cost_results']:
        folder = run / f"cost-feature{row['feature']}" / 'mapped'
        pin(folder / 'mapped.v', row['mapped_sha256'], 'mapped_outputs')
        pin(folder / 'mapped.json', row['mapped_json_sha256'], 'mapped_outputs')
    for name, key in (('VDotDatapath.scala', 'candidate_source_sha256'),
                      ('original-VDotDatapath.scala', 'original_source_sha256'),
                      ('VDotElastic.scala', 'candidate_wrapper_sha256'),
                      ('original-VDotElastic.scala', 'original_wrapper_sha256')):
        pin(run / 'source-snapshot' / name, result[key], 'source_identity')
    return result, inputs, pins, groups, sizes, labels


def scan(roots, pinned):
    kept, omitted, directories = {}, {}, set()
    for root in roots:
        need(root.is_dir() and not root.is_symlink(), 'real input tree: ' + str(root))
        directories.add(root.name + '/')
        for path in sorted(root.rglob('*')):
            mode = path.lstat().st_mode
            need(not stat.S_ISLNK(mode), 'archive tree contains a link: ' + str(path))
            rel = path.relative_to(root); name = root.name + '/' + rel.as_posix()
            if stat.S_ISDIR(mode):
                directories.add(name + '/')
                continue
            need(stat.S_ISREG(mode), 'regular archive input: ' + str(path))
            is_cache = (root.name == 'local-01' and len(rel.parts) >= 3 and
                        rel.parts[0] in ('fu-feature0', 'fu-feature1') and rel.parts[1] == 'obj' and
                        path.suffix in ('.o', '.a') and path not in pinned)
            if is_cache:
                omitted[name] = dict(bytes=path.stat().st_size, sha256=sha(path),
                    reason='Rebuildable Verilator object/static-library cache only; original retained.')
            else:
                need(name not in kept, 'unique archive name')
                kept[name] = path
    return kept, omitted, directories


def main(a):
    need(sys.dont_write_bytecode, '-B required; frozen source inputs stay read-only')
    os.sched_setaffinity(0, {1}); os.setpriority(os.PRIO_PROCESS, 0, 5)
    need(all(p.is_absolute() and p == p.resolve() for p in (a.runs, a.sources, a.output)), 'canonical absolute paths')
    runs, sources, out = a.runs, a.sources, a.output
    run, source, archive_source = runs / 'local-01', sources / 'source-01', sources / 'archive-source-01'
    roots = [run, source, archive_source]
    need(all(p.is_dir() and not p.is_symlink() and p == p.resolve() for p in roots), 'three canonical real input roots')
    need(not out.exists() and all(not out.is_relative_to(p) and not p.is_relative_to(out) for p in roots),
         'fresh output separate from all three input trees')
    need(Path(__file__).resolve().is_relative_to(archive_source), 'actual helper is included in archive-source-01')
    need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), 'standalone archive owns its finite timer')
    out.mkdir(parents=True)
    started, deadline = stamp(), time.monotonic() + 600
    handlers = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM)}
    def interrupted(sig, _frame):
        raise InterruptedError('archive signal/deadline ' + str(sig))
    try:
        for sig in handlers:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 600)
        result, inputs, pinned, groups, sizes, labels = recorded_evidence(run)
        files, omitted, directories = scan(roots, pinned)
        inventory = {name: dict(bytes=path.stat().st_size, sha256=sha(path)) for name, path in files.items()}
        by_path = {path: inventory[name] for name, path in files.items()}
        need(all(p in by_path and by_path[p]['sha256'] == digest for p, digest in pinned.items()),
             'every recorded snapshot/generated/mapped/binary/class pin included unchanged')
        need(all(by_path[p]['bytes'] == size for p, size in sizes.items()), 'all recorded generated lengths')
        need(all('local-01/' + label + '.log' in files for label in labels), 'all original positive/negative/failed-exit command logs retained')
        for feature in (0, 1):
            for name in ('abc.constr', 'map.ys', 'timing.tcl', 'r2r.rpt', 'i2r.rpt', 'r2o.rpt', 'i2o.rpt', 'ready.rpt', 'setup-checks.rpt'):
                need(f'local-01/cost-feature{feature}/mapped/{name}' in files, 'all mapping/STA inputs and reports retained')
        source_names = {name[len('source-01/'):] for name in files if name.startswith('source-01/')}
        need(source_names == SOURCE_NAMES, 'six actual source-01 files')
        source_audit = []
        for name in sorted(SOURCE_NAMES):
            path = source / name; observed = inventory['source-01/' + name]
            original_pin = inputs['originals'].get(str(path))
            snapshot = run / 'source-snapshot' / name
            snapshot_pin = inputs['snapshots'].get(str(snapshot))
            if name != 'controller-derivation.json':
                need(original_pin == snapshot_pin == observed['sha256'] and
                     by_path[snapshot]['sha256'] == observed['sha256'], 'source equals executed original/snapshot: ' + name)
                scope = 'Byte-identical to the original execution input pin and executed snapshot.'
            else:
                need(original_pin is None and snapshot_pin is None, 'supplemental controller derivation was not execution-pinned')
                scope = 'Supplemental derivation document; preserved completely, but not pinned or snapshotted by the executed controller.'
            source_audit.append(dict(name=name, **observed, original_input_pin=original_pin,
                snapshot_pin=snapshot_pin, execution_pinned=original_pin is not None, scope=scope))
        archived_originals = {}
        for path, digest in inputs['originals'].items():
            p = Path(path)
            if p in by_path:
                need(by_path[p]['sha256'] == digest, 'archived original input matches execution pin')
                archived_originals[path] = digest
        source_scope = {name: result[name] for name in ('arithmetic_equivalent', 'fu_qualified', 'parent_qualified',
            'fullcore_qualified', 'application_performance_qualified', 'core_cost_qualified', 'new_core_builds', 'new_core_runs')}
        evidence = dict(result_sha256=RESULT_SHA, status=result['status'], commands=len(result['commands']),
            exit_histogram=dict(Counter(str(x['exit_code']) for x in result['commands'])),
            original_inputs=len(inputs['originals']), archived_original_inputs=len(archived_originals),
            recorded_output_pin_counts={k: len(v) for k, v in groups.items()}, recorded_output_pins=len(pinned),
            source_files=source_audit, original_qualification=source_scope,
            generated_pin_policy='Only persisted snapshot/class/result pins are execution identities; other fully retained files receive transport hashes.')
        manifest = dict(schema=1, evidence=evidence, files=inventory, directories=sorted(directories), omitted=omitted,
            omissions_deleted=False, all_original_sources_and_logs_included=True,
            external_dependencies='Original inputs/classpath/baseline manifests retained; no external input bytes read, copied or rehashed.',
            scope='ZIP transport integrity only; no new correctness, performance, parent, full-core or PPA qualification.',
            cpu_affinity=[1], nice=5, budget_seconds=600)
        raw_manifest = encoded(manifest)
        archive = out / 'raw.zip'
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in sorted(directories):
                z.writestr(name, b'')
            for name, path in files.items():
                z.write(path, name)
            z.writestr('ARCHIVE-MANIFEST.json', raw_manifest)
        with zipfile.ZipFile(archive) as z:
            expected = set(files) | directories | {'ARCHIVE-MANIFEST.json'}
            need(len(z.namelist()) == len(expected) and set(z.namelist()) == expected, 'exact ZIP member inventory without duplicates')
            need(z.read('ARCHIVE-MANIFEST.json') == raw_manifest, 'exact archived manifest')
            for name in directories:
                need(z.getinfo(name).is_dir() and z.getinfo(name).file_size == 0 and z.read(name) == b'', 'exact directory member')
            for name, record in inventory.items():
                need(not z.getinfo(name).is_dir() and z.getinfo(name).file_size == record['bytes'], 'complete member size')
                with z.open(name) as stream:
                    need(stream_sha(stream) == record['sha256'], 'ZIP CRC and full member SHA: ' + name)
        after, after_omitted, after_directories = scan(roots, pinned)
        need(after == files and after_omitted == omitted and after_directories == directories, 'closed tree inventory unchanged')
        need(all(path.stat().st_size == inventory[name]['bytes'] and sha(path) == inventory[name]['sha256']
                 for name, path in after.items()), 'all retained source bytes unchanged')
        audit = dict(status='RWIDTH_RAW_ARCHIVE_VERIFIED', started=started, finished=stamp(),
            archive_bytes=archive.stat().st_size, archive_sha256=sha(archive), files=len(files),
            members=len(expected), directories=len(directories), raw_kept_bytes=sum(x['bytes'] for x in inventory.values()),
            recorded_output_pins_verified=len(pinned), recorded_output_pin_counts=evidence['recorded_output_pin_counts'],
            omitted_files=len(omitted), omitted_bytes=sum(x['bytes'] for x in omitted.values()),
            member_crc_and_sha_verified=True, retained_files_unchanged=True, omitted_originals_unchanged=True,
            source_membership_unchanged=True, original_files_deleted=False,
            original_recorded_child_closures_checked=True, live_processes_requeried=False,
            external_dependencies_rehashed=False, original_validators_rerun=False,
            new_builds=0, new_eda_runs=0, new_guest_runs=0, source_qualification=source_scope,
            source_files=source_audit, controller_derivation_execution_pinned=False,
            qualification='Transport integrity only; original result scopes preserved.')
        need(time.monotonic() < deadline, 'complete archive within total budget')
        (out / 'audit.json').write_bytes(encoded(audit))
        print(json.dumps(audit, indent=2), flush=True)
    except BaseException as error:
        signal.setitimer(signal.ITIMER_REAL, 0)
        (out / 'archive-failure.json').write_bytes(encoded(dict(status='FAILED', error=repr(error),
            started=started, finished=stamp(), original_files_retained=True, new_guest_runs=0, new_eda_runs=0)))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('runs', 'sources', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    main(parser.parse_args())
