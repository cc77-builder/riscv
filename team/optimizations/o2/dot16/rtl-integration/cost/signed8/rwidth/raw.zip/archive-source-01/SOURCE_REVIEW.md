# R20/R19 候选提交前限定审查

## 结论

**当前固定候选无实质启动阻塞，也未发现无关判据放宽。** 可按 root 既定范围执行一次独立、受控的真实源码生成/FU/cost 验证。本结论不是编译、仿真、综合、父级或整核通过记录。

本审查只读取云端候选及既有固定证据，用标准库做全文逆向、SHA 和 Python AST 检查；只写本审查文件。没有修改 candidate，没有运行其控制器，没有调用本机工具、编译器、EDA 或 guest。

## 审查身份及逆向结果

| 文件 | 当前 SHA256 |
| --- | --- |
| `VDotElastic.scala`，8782 B | `70dcc27381d3e7226eeff333c943d35b982ec1fdd37b75b680060a13aaf94e2a` |
| `original-VDotElastic.scala`，8575 B | `63911b937a526b97ddaa67e34526fd19bbd2fa2801eadfda10ae6c2fa4b9fe9e` |
| `VDotDatapath.scala`，2925 B | `50522c0cd2700f7f852872049533bc31f79ce811ad2ed53da2c1d333cece45e2` |
| `rwidth.py`，25006 B | `c9f6bec3c1dd41732d5d590478abbb659b2b4ae59b6d079f38eeac082a0d5aa6` |
| `source-derivation.json` | `fd4b197700123bf7d2ed8b0291c9bc19ab36df7f4922fa85b7b019551789ac3d` |
| `controller-derivation.json` | `0219b6e032ee2561a538d4f102ad5b2070c792af9e1d70aaf2061d25117af248` |
| `RWIDTH_CONTRACT.md` | `a2e465090be7d7fa86fad9e7453e9780eeed7fd6a5213a5961043bbe043d05e0` |

独立按变更表逆序恢复：

- Scala 的 5 项变更全部唯一匹配；恢复结果与提供的原源码逐字节相等，得到 8575 B、SHA `63911b93…`，没有额外末尾 LF。
- controller 的 17 项变更按记录数量匹配；恢复原脚本为 22421 B、SHA `301d49f50f07c6f8bc208040fa60df64fc5eb965a329c3c7a4fc46ce97631bae`，与固定 local03 控制器身份相同。新脚本及恢复脚本均仅通过 `ast.parse` 检查，未 import/执行。

## Scala 语义核对

- **第 40、52 行：** `storedResultBits` 是 elaboration 时的 Scala Int，分别为 20/19；只改变 R 数据字段，P products、控制和 perf bundle 不变。
- **第 85–87 行：** 明确使用 `rPacket.res.data.asSInt` 接到 `Wire(SInt(32.W))`，再 `asUInt` 拼接高 96 位零。这保留负结果低 32 位的符号扩展，没有把窄值直接零扩展。
- **第 146–148 行：** 原非法谓词、`when(move)` 和 R 控制/perf 同拍转移保留。Mux 两个分支都是 `storedResultBits` 位：非法零，或原 32 位结果的低 19/20 位，没有混合 UInt/SInt 造成额外扩展的分支。
- 原输出表达式分别为 `sext32(sum19)`／`sext32(sum20)`，因此保存低位后重建恒等。开态 dot8 仍在 P 把高八项写零；非法 op/VL/配置仍由已保存非法位写零。结论不以有限测试值或软件输入范围代替原表达式。
- ready/valid、kill/reset、P 接收和替换、`move`、R 反压保持、所有观察 handle 的类型与含义均未改。R 数据无新增复位；R valid 只有经原 move 才产生，因此第一次写入后的表示等价足够覆盖有效响应。E2/II1 的控制路径保持原样。
- stalled/heldResponse 仍观察完整外部输出 bundle，外部数据宽度还是 128 位；没有把内部窄寄存器直接作为新的外部响应。

## 控制器应变检查及原判据

### 变化准确且有替代条件

1. **第 247–254 行：** 从原 `VDotElastic.sv` 字节相等列表移除的是本次有意改变的 wrapper；`VDotReduce.sv` 和公共 top 仍逐字节比较原件。四套实际生成的 wrapper 必须各有且只有一个对应 `reg [18:0]`／`reg [19:0] rPacket_res_data` 声明。其新语义仍由完整两态 FU 测试确认，不只凭正则授予资格。
2. **第 313–315 行：** 原 DFF 完全相等没有被无条件删掉，而是替换为精确的 `原值−13`／`原值−12`。当前原 nominal 两点分别 1742、1870，因此目标分别是 1729、1858。这个数量检查不单独证明功能，但不放宽当前源码限定。
3. **第 86–105、250–266 行：** 不重复 product SAT 的前提是固定 local03 result SHA、完成状态和原算术证明成立，并先核实其四套原 Products/inline multiplier/Reduce 的各自 SHA，再与四套新生成字节完全相等。复用只覆盖相同算术子模块，未称已完成新 wrapper 的顺序形式化。结果中的表示等价依据对此另有明确说明。

### 没有发现其他验证被删减

完整原 classpath 身份、cache/源输入前后检查、真实 Scala 编译和 overlay 优先级、四套 SV 文件清单及 BlackBox 资源清单、两态 Verilator lint/build、原完整 vectors/C++/coverage 门、四类负控和原拒错检查器均保留。

原同接口 map/STA 模板仍做路径替换逆向；ABC 约束原字节、库/工具身份、独立面积求和、全部公共端口、五类路径、STA 错误/缺路径拒绝、常量端点检查和负 slack 的真实记录均保留。没有把负 slack 当成功时序，也没有以面积改善替代 FU 完整通过。

串行 CPU1、总 deadline、每条命令预算、进程组 TERM/KILL/reap 和末次全部 pins/classpath/预算检查继承原流程。`os.nice(5)` 改为 `setpriority(...,5)` 是明示的 absolute nice5，并非新增并发。整体 `arithmetic_equivalent` / `fu_qualified` 仍只在末次检查后置真；parent/core/application 资格保持 false。

## 基线与数值字段

`old_cost['results'][feature]` 仍指固定旧 nominal 成本：面积 feature0=17246.376、feature1=24017.406，DFF=1742/1870。signed8 local03 的固定 `cost_results` 顺序确为 feature0、feature1，面积分别 15734.698、21147.798，DFF 同样 1742/1870。

因此第 325 行 `area_delta_from_signed8` 与第 326 行 `area_delta_from_matched_original` 的参照正确且分开；没有把 signed8 增益重新算到 R 位宽改动上。`result_storage_bits` 的 19/20 与真实生成位宽检查一致。

## 不提前授予的结论

源码静态检查不能保证工具一定产生预期 DFF 数，也不能预报面积目标或时序通过。如果实际输出拒绝某个固定条件，应保留该次原始回执再判断；本审查没有要求自动放松它。新 wrapper 的父执行单元、整核及完整应用资格仍须由对应实际运行取得。

候选入口：`/workspace/scratch/f9116701fd09/source-review/r20-candidate/`。
