# R19/R20 local-01 运输归档审查

## 范围与执行状态

`archive_rwidth.py` 复用 `archive_parent.py` 的 ZIP_DEFLATED(level 6)、完整成员 CRC/SHA、原文件前后核验流程。只准备脚本，**尚未执行归档或本机操作**；不运行原验证器、构建、EDA 或 guest。

三个输入根固定为 `--runs/local-01`、`--sources/source-01`、`--sources/archive-source-01`。最后一根由 root 放入实际 helper、原 host receipt 及本说明，全部按原字节收录，不假设 receipt 文件名或 JSON 外壳。输出必须全新且与输入互不包含；脚本本身必须位于已冻结的 archive-source-01。

接口：

```text
python3 -B archive-source-01/archive_rwidth.py
  --runs <WSL dot16-rwidth-20261107-main>
  --sources <Windows 旧 runs 根的 /mnt/d/... 路径>
  --output <fresh archive-01>
```

固定 CPU1、绝对 nice5、总 600 秒；只使用 Python 标准库，不启动子进程。中断/超时保留已生成 ZIP 和 archive-failure.json，由外层工具保存退出与清理回执。

## 原证据与身份闭包

实际 result.json 固定为 193,611 B / SHA
`f42f7285ff8a357877c546d433251b1dc8c8eef66ee9218c9e3b2c002ca0a261`。
核对原 31 条命令及其正常/注入退出码、结束时间、reaped/group_absent；原 FU/算术资格与 parent/fullcore/application/core-cost 等未授予范围分别保留，不扩资格。

实际控制器没有持久化 final-artifact-pins.json，helper 不假定其存在。必收 pin 来自：

- inputs.json 全部 snapshots；
- overlay-classes.json 全部 class；
- result.generated 的 24 个 SV、4 个资源清单及 4 个 filelist；
- 两态 cost_results 的 mapped.v / mapped.json；
- 两态 fu_results 的完整 `VVDotElasticFuTestTop`；
- result 中候选/原始 Scala 身份与对应快照。

以上每个 pin 都必须实际进入 ZIP 且 SHA 一致；有记录的长度也核对。所有 31 份原日志、映射脚本/约束、五类 STA 路径及 setup-checks 报告均完整保存。没有持久化执行 pin 的其他文件仅获得本次运输 SHA，不补造执行身份。

source-01 六文件中，rwidth.py、RWIDTH_CONTRACT.md、两份候选 Scala、source-derivation.json 必须同时匹配 inputs.originals 和同名执行快照。**controller-derivation.json 未被原 rwidth controller pin 或快照**：保留全部内容及运输 SHA，manifest/audit 单列 execution_pinned=false，不能称为已执行证明。

外部 signed8 baseline、库、工具链和旧输入只保留原 inputs/classpath 清单与原结果引用，不读取、重新哈希或打包它们。

## 省略与原件保护

仅允许省略 fu-feature0/obj 和 fu-feature1/obj 内没有必收 pin 的 `.o/.a` 可重建缓存，并列路径、大小、SHA 和原因。完整 FU binary、全部源码（包括生成 C++/头文件）、SV、.d、日志、JSON、报告、失败/负控证据及未知文件都保留。原件不删改。

ZIP 验证覆盖完整文件/目录库存、每个文件的全字节 SHA 和 CRC、嵌入 manifest 原字节。归档后复扫库存，重核保留文件 SHA；被省略缓存的原件也按大小/SHA复核未变。成功仅写 `RWIDTH_RAW_ARCHIVE_VERIFIED`，含明确运输资格边界。

## 已做检查与未运行范围

已通过 Python AST 检查；根据实际提供的摘要核对 31 条命令的次序/退出码与四组各六份 SV 的布局。未声称完整 local-01 内容已在 scratch 重新验证：完整 result、inputs、classes、二进制、映射网表及 ZIP 行为仍由 root 实际执行时逐项核验。未调用本机工具，也未修改原归档 helper。
