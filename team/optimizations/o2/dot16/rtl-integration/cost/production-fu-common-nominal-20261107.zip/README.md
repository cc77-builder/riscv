# Production FU nominal cost evidence, 2026-11-07

This archive preserves the completed frontend failure, new CommonFuCostTop generation and two-point mapping/STA attempt from the same independent engineering round. Files under raw/ are byte-for-byte copies of the PC run directories; archive-manifest.json records each member's SHA256 and length. No full dependency cache or third-party liberty library is duplicated. Their identities are in the raw input manifests; generated RTL and mapped netlists permit direct reinspection.

The two files under proposals/ are the unexecuted v1 direct-leaf proposal superseded after the frontend probe. Do not treat that controller as having produced nominal-01. The executed v2 controller/contract snapshots are under raw/nominal-01/source-snapshot/; generation sources are under raw/generation-01/source-snapshot/.

Frontend probe: parser exit 1 on unchanged automatic declaration, not a functional counterexample. Generation: 8 commands exit 0/reaped, old four SV files reproduced exactly. Nominal: 4 commands exit 0/reaped, new points use the same complete production FU interface and library/constraints. Neither point meets nominal 1 ns. Functional qualification of this new top, parent/core cost, power and application performance remain false.

Original raw root: /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-production-cost-20261107-main

See the adjacent RESULT.md for interpretation and reproducibility boundaries.
