# 已验证生产 FU 生成物：dot16 开关两点成本合同

合同ID：`dot16-tested-fu-generated-cost-v1`。工程范围：[WORK6707165287](https://github.com/cc77-builder/riscv/issues/2#issuecomment-6707165287)。本合同只准备一次有限综合/STA，不预先宣称成本结果。入口：[run.py](run.py)。

## 1. 目标与输入身份

问题是：在相同输入来源、直接 FU 端口和工具条件下，启用 dot16 对这份生产 FU 生成物增加多少面积，哪些 setup 路径改变？软件 whole2、whole8、N 不改变硬件，不能为每个软件候选重复综合。

复用 `dot16-production-20261106-0014-pro2/flag0-02` 与 `flag1-01`，不重新 elaboration 或重跑功能仿真。原 FU 正测、四项 observation fault、433 项源/126 项依赖清单、源不变和退出/回收原件先核字节身份；两侧源码清单及依赖清单SHA分别相同：

- 源清单：`80637d38348fbecd928f6442fd0c69fab763a918ac8da8642a5a3667dacdc9c2`。
- 依赖清单：`de4cf9023b946028d6c50594e5faa2ef3d59d4d6031859e2ae84622819cf47ba`。
- 旧完整验证索引：`68616f2ff1fa9bff16b46a807c4c9dd615d8ed1ddc2841ec91e7caefb73aac59`。

两侧保持相同六路径候选、O2/T14配置，只改变 dot16 feature。feature0 是同一候选源码下关闭 dot16 的 FU，不能称为未经修改的官方基线。功能证据见 [VALIDATION_CONTRACT.md](../VALIDATION_CONTRACT.md)、[VALIDATION_RESULT.md](../VALIDATION_RESULT.md)。

| 生成物 | feature0 | feature1 |
| --- | --- | --- |
| VDotElastic.sv | `f28ac5bc52d2e0736b3733f8a69756daf860480b72812472abad0bc1306eba2d` | `c15778eb5c7089af40422b7002fde00d552dd7274b88cecb5f132d15e984ed1e` |
| VDotProducts.sv | 两侧 `0c1e566dd820f80382c64b98a74882ff400e5cb63cd511bcd19831759597178a` | 相同 |
| VDotReduce.sv | 两侧 `ed09c5ac8ca7a0a910ac8d51000ef1de8f01dadca4bec544467d1678ebeaaf85` | 相同 |

2026-11-07 的只读取证已核两侧全部四个 SV（含同SHA的测试top）及原状态、源/依赖/生成物清单与归档相符；正式新运行在使用前再核，不自动继承新工具执行资格。原目录全程只读，新输出不得嵌入原 FU 证据或仓库。

## 2. 实际硬件边界

顶层是现有 `VDotElastic`，只读原 `VDotElastic.sv`、`VDotProducts.sv`、`VDotReduce.sv`；`VDotElasticFuTestTop.sv` 仅保留来源证据，不参与面积。

测试top并非透明重命名：它将vecWen/v0Wen绑定为互补输入，并关联两个64位perf通道。直接选择leaf保留其独立输入，不加wrapper、tie-off或case analysis。两侧全部模块头逐字相同，映射后还核全部端口名称/方向/宽度/offset一致；保留 `pipelineStatus` 与两路perf输入/输出。

这份leaf仍来自原FU harness的elaboration。直接选leaf不等于新生成完全独立、未经上下文裁剪的FuncUnit；结论限定为**已验证生产FU生成物、当前直接端口边界**，不授予父级或整核成本。

| 项目 | 实际约束 |
| --- | --- |
| 时钟 | 单一 `clock` 上升沿 |
| 复位 | `reset` 高有效；posedge内部同步清pValid/rValid，也组合抑制握手；不宣称所有数据寄存器均复位 |
| 数据接口 | 两个128位源、128位结果；保留ROB、flush、ready-valid、合法性/异常、写使能与metadata |
| 算术 | dot8使用低8对signed8；feature1允许dot16完整16对，和需signed20，低32位符号扩展、高96位零 |
| 行为延迟/吞吐 | 沿既有FU约定：无反压/取消时E0接受、E1结果寄存、E2可见响应，II=1；这不是整核IPC或应用周期 |

两侧以 `-DSYNTHESIS` 读入相同的未经编辑生成物，正常综合优化未使用的断言观察逻辑；不手工删除RTL。

## 3. 同条件两点流程

固定现有 Nangate45 typical 库 SHA `8d540a4d4cf6d09d27c87ad067857a9c0c2eeb023ab7a56e058cd3113db4e9b1`，以及已使用过的实际 Yosys/ABC/OpenSTA 二进制SHA。工具原路径与身份由入口常量和新结果记录；不安装或替换环境。

| 设置 | 本次固定值 |
| --- | --- |
| 映射 | 同一proc/opt、flatten、dfflibmap及ABC流程；全部单元须映射至固定Liberty |
| ABC目标/驱动/负载 | 1000 ps、BUF_X1、5 fF |
| STA时钟 | 1.0 ns |
| uncertainty / clock transition | 0.05 / 0.05 ns |
| 最大input / output delay | 0.1 / 0.1 ns |
| input transition / output load | 0.05 ns / 5 fF |
| wire-load | `5K_hvratio_1_1`，top模式 |
| 必报路径 | i2r、r2r、r2o、i2o、ready；实际起终点、arrival、slack |
| 探索点 | 仅feature0、feature1；不扩parent、频率或负载矩阵 |

面积按Liberty单元area与cell histogram重新求和，并与Yosys stat交叉核对；同时记录总cell和DFF数。面积单位保留为库area单位，不能凭此输出整核面积或功耗。

复用固定团队 `cost_helpers.py` 中的库面积/路径/恒定端点解析，以及 `run_fu.py` 的进程组控制。所有工具、helper、输入和快照在运行前固定，复制后立即核对，结束再次核一致。

正常情况下原 `mapped.v` 直接用于STA。若出现同版本OpenSTA在已保留旧实验中明确不支持的拼接赋值左值 `assign {`，只对新输出调用既有O4 `canonical.emit/bind`；Yosys重读后须证明全部端口、cell histogram和完整驱动拓扑一致，再用于STA。保留原mapped.v；不使用只适用于旧原型 `io_result` 的特定符号扩展替换，也不改RTL。

STA退出0仍不足以接受：要求唯一完成标记、无Tcl Error或unbound object、五类路径实际存在；setup-check中的未约束端点只能是已由映射图证明的恒定端点。**负slack是有效结果，必须保留；工具完成不能写成1ns时序通过。**

## 4. 有限资源和进程闭合

本轮安排CPU1、nice5、单线程串行，共享现有四核集合中的CPU1；所有子进程继承affinity/priority，数值库线程环境固定为1。不向运行N小试的CPU0追加计算，不更改四臂或N的任何资源/profile、冻结输入或期限。

入口总工作预算最高900秒，每个外部命令最高300秒并受剩余总预算限制；Windows外层计划1200秒，留出TERM/KILL/reap及回执余量。正常尽早结束，不自动延期、重试、换工具或增加矩阵。

每条命令创建独立进程组，实时记录argv/PID/预算；退出或异常时沿成熟helper执行必要TERM/KILL、wait/reap，确认进程组消失。只清理本命令创建的进程组，不能结束原EMU或其他Agent进程。失败保留原输出、状态和日志；超时只说明本次资源内未完成，不能判RTL功能错误。

实际运行前再读Issue和相关进程占用；新运行单独登记RUN并固定新输出，不能把本合同本身当成已启动作业。

## 5. 交付与结论

每侧保留原SV、原资格依据、映射脚本/日志/JSON/网表、必要表示转换及图证明、STA脚本/原报告/解析结果。总入口记录全部命令、真实起止时间、资源/清理、完整输入SHA和两侧结果。相关原始成功或失败证据归档至本叶，不覆盖历史。

有效比较只有本次同条件 `A(feature1)-A(feature0)` 及对应比例。旧O4、独立算术原型、parent及整核成本只能分别保留历史范围，不能和本次直接相减。STA数据到达时间含该类I/O延迟，不随意相加或倒数为整核频率。

本轮可以成立的是生成FU边界的pre-layout面积/setup时序记录。功耗、布局布线、父级/整核面积、完整应用性能和综合ASIC PPA资格均不由此获得。本补证不成为在途N或四臂的新增验收门槛。

复现形式：

```bash
python3 -B team/optimizations/o2/dot16/rtl-integration/cost/run.py \
  --repo /absolute/controller/repository \
  --fu-root /absolute/runs/dot16-production-20261106-0014-pro2 \
  --output /absolute/new/generated-fu-cost \
  --library /absolute/NangateOpenCellLibrary_typical.lib \
  --cpu 1 --budget-seconds 900
```

固定输入不符时停止取证，不改常量以沿用旧资格；发生具体环境或表示兼容问题先评估最窄方案，若需要重装、反复补丁或扩大设计边界则延后。
