set -euo pipefail
source team/scripts/activate.sh
/usr/bin/bash /home/lizufan/riscv-tools/bin/mill --no-server -j 1 -Djvm-xmx=8G -Djvm-xss=16m xiangshan.test.compile
