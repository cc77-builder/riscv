set -euo pipefail
source /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/scripts/activate.sh
export AM_HOME=/home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am
/usr/bin/make -C /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/source-snapshot ARCH=riscv64-xs MARCH=rv64gcv -o am -o klib SMOKE_OBJ_ROOT=/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/objects BINARY=/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/dot16-core-smoke -j1
riscv64-linux-gnu-gcc -c -march=rv64gc -mabi=lp64d /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/source-snapshot/boot-flash.S -o /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/boot-flash.o
riscv64-linux-gnu-objcopy -O binary -j .text /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/boot-flash.o /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/boot-flash.bin
riscv64-linux-gnu-nm --defined-only /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/dot16-core-smoke.elf > /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/image-01/symbols.txt
riscv64-linux-gnu-gcc --version
