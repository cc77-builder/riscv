set -euo pipefail
source team/scripts/activate.sh
export PATH=/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/dot16-fullcore-20261106-pro2/build-01/tools:"$PATH"
/usr/bin/make emu CONFIG=MinimalConfig NUM_CORES=1 EMU_THREADS=1 JVM_XMX=8G JVM_XSS=16m OPT_FAST=-O3 OPT_SLOW=-O0 EMU_TRACE=0 WITH_CHISELDB=0 WITH_CONSTANTIN=0 WITH_ROLLINGDB=0 NO_DIFF=0 SHELL=/usr/bin/bash CXX=/usr/bin/x86_64-linux-gnu-g++-11 CC=/usr/bin/x86_64-linux-gnu-gcc-11 'TIME_CMD=/usr/bin/time -avp -o '"'"'$(TIMELOG)'"'"'' -j3
