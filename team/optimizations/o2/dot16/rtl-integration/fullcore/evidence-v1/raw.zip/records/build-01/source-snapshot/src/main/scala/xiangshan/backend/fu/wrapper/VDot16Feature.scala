package xiangshan.backend.fu.wrapper

/** An opt-in ISA candidate, selected only when elaborating an elastic build.
  * The same accessor gates instruction decode, vector classification and FU.
  * No cached environment value or run-time enable is part of the hardware.
  */
object VDot16Feature {
  def enabled: Boolean = {
    val selected = sys.env.get("VDOT_DOT16") match {
      case None | Some("0") => false
      case Some("1") => true
      case _ => throw new IllegalArgumentException("VDOT_DOT16 must be 0 or 1")
    }
    if (selected) {
      require(VDotO2.enabled, "VDOT_DOT16=1 requires VDOT_O2_ELASTIC=1")
    }
    selected
  }
}
