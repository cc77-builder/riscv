# R2-S1：向量累加与对等 RVV

本模块检验一个独立假设：在输出向量寄存器中保留 INT32 部分和，可减少逐块向量到标量搬移及标量累加，并改善完整 GEMV 性能。候选以同一硬件上的新 S0 为对照；采用与否由真实整核结果决定。

## 边界与比较合同

- 形状为 4×8、8×32、16×64、4×13，每个形状保留 basic/reuse、core/endtoend、三组固定数据，以及原主机黄金值、全部 128 位输出、CSR、退休和 scratch 检查。
- S1 vdot 用临时向量接收 dot8 部分和，在 e32/VL4 下累加到对应输出寄存器。输出清零属于测量窗口。4×13 的剩余五项仍走原标量尾部，没有混入 S2。
- 对等 RVV 将宽归约的 scalar seed 和目的设为当前输出寄存器，使用 tu 保留已经清零的高 96 位；所有候选均遵守 v16..v31 scratch 预算，无 spill。
- S0/S1 都使用固定 8 KiB 函数槽，入口地址逐对相等，防止候选长度改变后续函数地址。S0 指令主体与冻结 O3 完全相同，但由于布局不同，必须重新测量；不复用旧 S2 周期。
- core 与 endtoend 延续 O3 定义。endtoend 保留原配置与输出存储；同一布局、同一输入、同一测量与退休检查。不能将 core 周期解释为应用性能。
- 硬件使用合并提交 6d2abe403b07c297b8830a7d4f06e370b0a8e070 的已有 minimal/VLEN128 EMU；实际源码、依赖、生成物及二进制由原 merged_screen 门禁核验。没有新 RTL、频率、面积或功耗结论。

## 证据层级

candidate.py 独立生成 S0/S1，不修改冻结 S2 candidate 或原黄金值。gate.py 在原 ELF 审核和有限指令模型上只增加严格的无掩码 e32 vadd；未知指令仍拒绝。重新生成逐字节核对 snapshot、manifest、汇编与头文件，实际链接 ELF 必须与独立 GNU 汇编相等。

experiment.py 使用私有模块实例把新生成门禁接入原 fullcore/merged 运行器。原 UART、CSR、精确退休、致命错误、reference 路径、O2 排空和提交数条件不变。所有镜像绑定相同源码、AM、库和工具链；结束前再次核验完整硬件来源及输入，最终计数通过后才写 PASS。

主机测试是实际 GNU 汇编指令的有限模型测试，不是 NEMU/RTL 协同仿真。test_candidate.py 包含三数据集、INT8 极值及漏清零、错误累加宽度、掩码、错误寄存器、错误归约种子、tail-agnostic、CSR 漏恢复、跨行读取和构建身份漂移负测。

## 整核计划与决策

构建 52 个真实 AM 镜像：4 个 smoke，加上 2 variants ×8 shards ×3 datasets 的 48 个正式镜像。运行 57 次单进程 EMU：1 次新建负控、4 次正常 smoke（包括负控后的新进程恢复）、48 次正式运行、4 次重放。768 个正式测量窗口来自每镜像的 2 software ×2 methods ×4 measured repeats；warmup 和重放不混入正式样本。

同一 shard/dataset 内交替 S0/S1 顺序。重放要求每个窗口的 cycles/instret 精确一致。结果同时报告 S0/S1 各方法，并从 S0/S1 × basic/reuse 中选最快合格 RVV 分母，保留退化组合。正确性失败即不采用；只有可重复的完整窗口收益才支持对应形状的选择。此筛选不替代 MERGE-REG、历史 B0/H1、完整 T17 或 PPA 验收。

## 运行

配置 JSON 仅包含 am_home、cross_prefix、hardware_source、build_record、build_driver、reference、flash；本机路径写 runtime.local.json，不进入共享配置。AM 固定提交与库来源由构建收据记录。构建只使用已准备的私有 AM 库。

```sh
python3 -B team/optimizations/o2/r2-vector-accum/test_candidate.py
python3 -B team/optimizations/o2/r2-vector-accum/experiment.py --action build --repo "$REPO" --config "$CONFIG" --output "$BUILD"
python3 -B team/optimizations/o2/r2-vector-accum/experiment.py --action run --repo "$REPO" --config "$CONFIG" --build "$BUILD" --output "$RUN" --operation-id "$OPERATION_ID"
```

输出目录必须不存在。本脚本不支持断点续跑；run 可以消费已完成且身份仍一致的 BUILD，不能把重新构建或新建运行描述成恢复。state.json 保存真实进程与结果位置，build.json 保存源码快照、命令、依赖及产物。运行期间保护其实际输入，结束后按 Issue 规则释放。

当前结果见本目录后续保存的实际实验记录；没有运行证据的层级必须记为 NOT_TESTED。
