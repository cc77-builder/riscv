"""S1 fairness diagnosis: test the S2 metadata exception with real AM linking.

This does not alter the frozen S2 candidate or qualify a new S2 runtime screen.
All generated source changes and command receipts remain in a new probe root.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import sys

repo = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s1-20261023-2100')
root = Path('/home/lizufan/riscv-lab/r2-s1-20261023-2100/layout-s2-feasibility-probe-01')
sys.path.insert(0, str(repo / 'team/optimizations/o2/r2-vector-accum'))
import gate as g
import experiment as a

cfg = a.config(repo / a.S1 / 'runtime.local.json', repo)
f = a.legacy_f
g.verify_sources(repo)
tools = {key: shutil.which(cfg['cross_prefix'] + key) for key in
         ('gcc', 'ld', 'ar', 'objcopy', 'objdump', 'readelf')}
tools['make'] = shutil.which('make')
g.require(all(tools.values()), 'GNU tools missing')
toolchain = {key: dict(path=p, sha256=g.sha(p)) for key, p in tools.items()}
am = Path(cfg['am_home'])
libraries = {str(am / p): g.sha(am / p) for p in
             ('am/build/am-riscv64-xs.a', 'libs/klib/build/klib-riscv64-xs.a')}
env = dict(os.environ)
for key in ('CFLAGS', 'CPPFLAGS', 'CXXFLAGS', 'ASFLAGS', 'LDFLAGS', 'CC_OPT', 'MAKEFLAGS', 'MFLAGS',
            'CC', 'AS', 'LD', 'OBJCOPY', 'OBJDUMP', 'ARCH', 'MARCH', 'LIBS', 'PREBUILD'):
    env.pop(key, None)
env.update(AM_HOME=str(am), LINUX_GNU_TOOLCHAIN='1')
state = dict(started=f.now(), status='BUILDING', contract='s1-fairness-s2-layout-feasibility-probe-v1',
             new_emu_runs=0, scope='Real AM link and bounded metadata feasibility only; not S2 adoption')
g.save(root / 'state.json', state)
results = []
try:
    for shard in (6, 7):
        paths = []
        for variant in ('s0', 's2'):
            out = root / f's{shard:02}-{variant}'
            out.mkdir()
            snapshot = out / 'source/repo'
            for rel in sorted(g.PINNED):
                dest = snapshot / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(repo / rel, dest)
            for name in ('main.c', 'Makefile', 'fixed-layout.ld'):
                shutil.copyfile(snapshot / g.O3 / name, out / 'source' / name)
            generator = g.load('probe_original_s2_' + variant + str(shard), snapshot / g.REL / 'candidate.py')
            manifest = generator.generate(snapshot, out / 'data', variant, 0, shard, 'performance')
            shutil.copyfile(out / 'data/manifest.json', out / 'data/original-manifest.json')
            shutil.copyfile(out / 'data/kernels.S', out / 'data/original-kernels.S')
            source = (out / 'data/kernels.S').read_text()
            g.require(source.startswith('.option norvc\n.text\n') and source.count('.balign 4096') == 8,
                      'frozen assembly shape')
            source = source.replace('.option norvc\n.text\n', '.option norvc\n.option norelax\n.text\n', 1)
            source = source.replace('.balign 4096', '.balign 8192')
            (out / 'data/kernels.S').write_text(source)
            manifest['original_contract'] = manifest['contract']
            manifest['contract'] = state['contract']
            manifest['files'] = {n: g.sha(out / 'data' / n) for n in ('kernels.S', 'cases.h')}
            manifest['probe_layout_changes'] = ['insert .option norelax', 'eight .balign 4096 -> 8192']
            g.save(out / 'data/manifest.json', manifest)
            record = dict(started=f.now(), variant=variant, shard=shard, commands=[],
                          toolchain=toolchain, external_files=libraries,
                          frozen_sources={rel: g.sha(snapshot / rel) for rel in sorted(g.PINNED)})
            argv = [tools['make'], '-C', str(out / 'source'), 'ARCH=riscv64-xs', 'MARCH=rv64gcv',
                    'CROSS_COMPILE=' + tools['gcc'][:-3], 'T13_DATA=' + str(out / 'data'),
                    'T13_OBJ_ROOT=' + str(out / 'objects'), 'BINARY=' + str(out / 'vdot-perf'),
                    '-o', 'am', '-o', 'klib', '-j1', 'image']
            record['commands'].append(f.command(argv, repo, out / 'make-command', env))
            argv = [tools['gcc'], '-march=rv64gcv', '-mabi=lp64d', '-mno-relax', '-c',
                    str(out / 'data/kernels.S'), '-o', str(out / 'kernels-reference.o')]
            record['commands'].append(f.command(argv, repo, out / 'reference-command', env))
            checked = g.original.inspect(out / 'vdot-perf.elf', out / 'vdot-perf.bin',
                                         out / 'kernels-reference.o', manifest, g.auditor(repo))
            elf = g.ELF((out / 'vdot-perf.elf').read_bytes())
            ref = g.ELF((out / 'kernels-reference.o').read_bytes())
            g.require(ref.named['.text'][5] == 32768 and
                      not any(s[1] in (4, 9) and s[5] for s in ref.sections), 'probe object layout')
            checked['finite_model'] = g.semantic_check(elf, manifest, repo)
            record.update(finished=f.now(), status='PROBE_ELF_AND_MODEL_PASS_NOT_RUNTIME',
                          artifacts={n: g.sha(out / n) for n in
                                     ('vdot-perf.elf', 'vdot-perf.bin', 'kernels-reference.o', 'data/manifest.json')})
            g.save(out / 'elf-validation.json', checked)
            g.save(out / 'build.json', record)
            paths.append(out)
        elfs = [g.ELF((p / 'vdot-perf.elf').read_bytes()) for p in paths]
        binaries = [(p / 'vdot-perf.bin').read_bytes() for p in paths]
        allocated = [{n: [s[i] for i in (1, 2, 3, 5, 8)] for n, s in sorted(e.named.items()) if s[2] & 2}
                     for e in elfs]
        entries = [g.original.RAM + (i + 1) * 8192 for i in range(4)]
        for e in elfs:
            g.require([e.symbols[f't13_kernel_{i}'][0] for i in range(4)] == entries and
                      e.named['.text'][3] == g.original.RAM and e.named['.text'][5] == 40960,
                      'probe fixed text layout')
            g.require(e.symbols['cases'][:2] == (0x80120000, 1104 * 4), 'probe fixed case ABI')
        g.require(allocated[0] == allocated[1] and len(binaries[0]) == len(binaries[1]),
                  'probe allocated extent differs')
        # Allow changes only in vdot slots 0 and 2. RVV slots remain exact bytes.
        def vdot_slot(offset):
            return 8192 <= offset < 16384 or 24576 <= offset < 32768
        differences = [(i, b0, b1) for i, (b0, b1) in enumerate(zip(*binaries))
                       if b0 != b1 and not vdot_slot(i)]
        wanted = [(0x120024, 4, 8), (0x1208c4, 4, 8)]
        g.require(differences == wanted, 'unexpected non-vdot-slot differences')
        for i in (0, 2):
            offset = 0x120000 + 1104 * i + 36
            g.require([struct.unpack_from('<I', b, offset)[0] for b in binaries] == [4, 8],
                      'wrong exact dots values')
        results.append(dict(shard=shard, main_addresses=[e.symbols['main'][0] for e in elfs],
                            allocated_sections=allocated[0], non_vdot_slot_differences=differences,
                            rvv_slots_identical=True, main_bytes_identical=elfs[0].symbol_data('main') == elfs[1].symbol_data('main'),
                            linked_static_and_model_pass=True, new_emu_runs=0))
    for name, sha in libraries.items():
        g.require(g.sha(name) == sha, 'protected AM library changed')
    g.verify_sources(repo)
    state.update(status='TWO_SCOPE_FIXED_LAYOUT_METADATA_FEASIBILITY_PASS_NOT_RUNTIME', pairs=results)
except BaseException as exc:
    state.update(status='FAILED', error=repr(exc))
    raise
finally:
    state['finished'] = f.now()
    g.save(root / 'state.json', state)
print(json.dumps({k: v for k, v in state.items() if k != 'pairs'}, indent=2))
print(json.dumps([{k: v for k, v in row.items() if k != 'allocated_sections'} for row in results], indent=2))
