
#ifndef __DIFFTEST_QUERY_H__
#define __DIFFTEST_QUERY_H__

#include <cstdint>
#include "diffstate.h"
#include "query.h"

#ifdef CONFIG_DIFFTEST_QUERY

class QueryStats: public QueryStatsBase {
public:
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_InstrCommit;
  Query* query_LoadEvent;
  Query* query_TrapEvent;
  Query* query_ArchIntRegState;
  Query* query_ArchFpRegState;
  Query* query_ArchVecRegState;
  Query* query_ArchEvent;
  Query* query_CriticalErrorEvent;
  Query* query_CSRState;
  Query* query_DebugMode;
  Query* query_TriggerCSRState;
  Query* query_VecCSRState;
  Query* query_FpCSRState;
  Query* query_HCSRState;
  Query* query_NonRegInterruptPendingEvent;
  Query* query_MhpmeventOverflowEvent;
  Query* query_SyncAIAEvent;
  Query* query_SyncCustomMflushpwrEvent;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_IntWriteback;
  Query* query_FpWriteback;
  Query* query_FpWriteback;
  Query* query_FpWriteback;
  Query* query_FpWriteback;
  Query* query_FpWriteback;
  Query* query_FpWriteback;
  Query* query_VecWriteback;
  Query* query_VecWriteback;
  Query* query_VecWriteback;
  Query* query_VecWriteback;
  Query* query_VecWriteback;
  Query* query_VecWriteback;
  Query* query_VecV0Writeback;
  Query* query_VecV0Writeback;
  Query* query_VecV0Writeback;
  Query* query_VecV0Writeback;
  Query* query_VecV0Writeback;
  Query* query_VecV0Writeback;
  Query* query_RefillEvent;
  Query* query_RefillEvent;
  Query* query_L2TLBEvent;
  Query* query_L2TLBEvent;
  Query* query_AtomicEvent;
  Query* query_LrScEvent;
  Query* query_CMOInvalEvent;
  Query* query_SbufferEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_StoreEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  Query* query_L1TLBEvent;
  QueryStats(char *path): QueryStatsBase(path) {
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    RefillEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    InstrCommit_init();
    LoadEvent_init();
    TrapEvent_init();
    ArchIntRegState_init();
    ArchFpRegState_init();
    ArchVecRegState_init();
    ArchEvent_init();
    CriticalErrorEvent_init();
    CSRState_init();
    DebugMode_init();
    TriggerCSRState_init();
    VecCSRState_init();
    FpCSRState_init();
    HCSRState_init();
    NonRegInterruptPendingEvent_init();
    MhpmeventOverflowEvent_init();
    SyncAIAEvent_init();
    SyncCustomMflushpwrEvent_init();
    IntWriteback_init();
    IntWriteback_init();
    IntWriteback_init();
    IntWriteback_init();
    IntWriteback_init();
    IntWriteback_init();
    IntWriteback_init();
    IntWriteback_init();
    FpWriteback_init();
    FpWriteback_init();
    FpWriteback_init();
    FpWriteback_init();
    FpWriteback_init();
    FpWriteback_init();
    VecWriteback_init();
    VecWriteback_init();
    VecWriteback_init();
    VecWriteback_init();
    VecWriteback_init();
    VecWriteback_init();
    VecV0Writeback_init();
    VecV0Writeback_init();
    VecV0Writeback_init();
    VecV0Writeback_init();
    VecV0Writeback_init();
    VecV0Writeback_init();
    RefillEvent_init();
    RefillEvent_init();
    L2TLBEvent_init();
    L2TLBEvent_init();
    AtomicEvent_init();
    LrScEvent_init();
    CMOInvalEvent_init();
    SbufferEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    StoreEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
    L1TLBEvent_init();
  }
  
  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void InstrCommit_init() {
    const char* createSql = " CREATE TABLE InstrCommit(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SKIP INT NOT NULL," \
      "ISRVC INT NOT NULL," \
      "RFWEN INT NOT NULL," \
      "FPWEN INT NOT NULL," \
      "VECWEN INT NOT NULL," \
      "V0WEN INT NOT NULL," \
      "WPDEST INT NOT NULL," \
      "WDEST INT NOT NULL," \
      "OTHERWPDEST_0 INT NOT NULL," \
      "OTHERWPDEST_1 INT NOT NULL," \
      "OTHERWPDEST_2 INT NOT NULL," \
      "OTHERWPDEST_3 INT NOT NULL," \
      "OTHERWPDEST_4 INT NOT NULL," \
      "OTHERWPDEST_5 INT NOT NULL," \
      "OTHERWPDEST_6 INT NOT NULL," \
      "OTHERWPDEST_7 INT NOT NULL," \
      "OTHERV0WEN_0 INT NOT NULL," \
      "OTHERV0WEN_1 INT NOT NULL," \
      "OTHERV0WEN_2 INT NOT NULL," \
      "OTHERV0WEN_3 INT NOT NULL," \
      "OTHERV0WEN_4 INT NOT NULL," \
      "OTHERV0WEN_5 INT NOT NULL," \
      "OTHERV0WEN_6 INT NOT NULL," \
      "OTHERV0WEN_7 INT NOT NULL," \
      "PC INT NOT NULL," \
      "INSTR INT NOT NULL," \
      "ROBIDX INT NOT NULL," \
      "LQIDX INT NOT NULL," \
      "SQIDX INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISSTORE INT NOT NULL," \
      "NFUSED INT NOT NULL," \
      "SPECIAL INT NOT NULL);";
    const char* insertSql = "INSERT INTO InstrCommit (STEP,COREID,MY_INDEX,VALID,SKIP,ISRVC,RFWEN,FPWEN,VECWEN,V0WEN,WPDEST,WDEST,OTHERWPDEST_0,OTHERWPDEST_1,OTHERWPDEST_2,OTHERWPDEST_3,OTHERWPDEST_4,OTHERWPDEST_5,OTHERWPDEST_6,OTHERWPDEST_7,OTHERV0WEN_0,OTHERV0WEN_1,OTHERV0WEN_2,OTHERV0WEN_3,OTHERV0WEN_4,OTHERV0WEN_5,OTHERV0WEN_6,OTHERV0WEN_7,PC,INSTR,ROBIDX,LQIDX,SQIDX,ISLOAD,ISSTORE,NFUSED,SPECIAL) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_InstrCommit = new Query(mem_db, createSql, insertSql);
  }

  void LoadEvent_init() {
    const char* createSql = " CREATE TABLE LoadEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PADDR INT NOT NULL," \
      "OPTYPE INT NOT NULL," \
      "ISATOMIC INT NOT NULL," \
      "ISLOAD INT NOT NULL," \
      "ISVLOAD INT NOT NULL);";
    const char* insertSql = "INSERT INTO LoadEvent (STEP,COREID,MY_INDEX,VALID,PADDR,OPTYPE,ISATOMIC,ISLOAD,ISVLOAD) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_LoadEvent = new Query(mem_db, createSql, insertSql);
  }

  void TrapEvent_init() {
    const char* createSql = " CREATE TABLE TrapEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "HASTRAP INT NOT NULL," \
      "CYCLECNT INT NOT NULL," \
      "INSTRCNT INT NOT NULL," \
      "HASWFI INT NOT NULL," \
      "CODE INT NOT NULL," \
      "PC INT NOT NULL);";
    const char* insertSql = "INSERT INTO TrapEvent (STEP,COREID,HASTRAP,CYCLECNT,INSTRCNT,HASWFI,CODE,PC) " \
      " VALUES (?,?,?,?,?,?,?,?);";
    query_TrapEvent = new Query(mem_db, createSql, insertSql);
  }

  void ArchIntRegState_init() {
    const char* createSql = " CREATE TABLE ArchIntRegState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALUE_0 INT NOT NULL," \
      "VALUE_1 INT NOT NULL," \
      "VALUE_2 INT NOT NULL," \
      "VALUE_3 INT NOT NULL," \
      "VALUE_4 INT NOT NULL," \
      "VALUE_5 INT NOT NULL," \
      "VALUE_6 INT NOT NULL," \
      "VALUE_7 INT NOT NULL," \
      "VALUE_8 INT NOT NULL," \
      "VALUE_9 INT NOT NULL," \
      "VALUE_10 INT NOT NULL," \
      "VALUE_11 INT NOT NULL," \
      "VALUE_12 INT NOT NULL," \
      "VALUE_13 INT NOT NULL," \
      "VALUE_14 INT NOT NULL," \
      "VALUE_15 INT NOT NULL," \
      "VALUE_16 INT NOT NULL," \
      "VALUE_17 INT NOT NULL," \
      "VALUE_18 INT NOT NULL," \
      "VALUE_19 INT NOT NULL," \
      "VALUE_20 INT NOT NULL," \
      "VALUE_21 INT NOT NULL," \
      "VALUE_22 INT NOT NULL," \
      "VALUE_23 INT NOT NULL," \
      "VALUE_24 INT NOT NULL," \
      "VALUE_25 INT NOT NULL," \
      "VALUE_26 INT NOT NULL," \
      "VALUE_27 INT NOT NULL," \
      "VALUE_28 INT NOT NULL," \
      "VALUE_29 INT NOT NULL," \
      "VALUE_30 INT NOT NULL," \
      "VALUE_31 INT NOT NULL);";
    const char* insertSql = "INSERT INTO ArchIntRegState (STEP,COREID,VALUE_0,VALUE_1,VALUE_2,VALUE_3,VALUE_4,VALUE_5,VALUE_6,VALUE_7,VALUE_8,VALUE_9,VALUE_10,VALUE_11,VALUE_12,VALUE_13,VALUE_14,VALUE_15,VALUE_16,VALUE_17,VALUE_18,VALUE_19,VALUE_20,VALUE_21,VALUE_22,VALUE_23,VALUE_24,VALUE_25,VALUE_26,VALUE_27,VALUE_28,VALUE_29,VALUE_30,VALUE_31) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_ArchIntRegState = new Query(mem_db, createSql, insertSql);
  }

  void ArchFpRegState_init() {
    const char* createSql = " CREATE TABLE ArchFpRegState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALUE_0 INT NOT NULL," \
      "VALUE_1 INT NOT NULL," \
      "VALUE_2 INT NOT NULL," \
      "VALUE_3 INT NOT NULL," \
      "VALUE_4 INT NOT NULL," \
      "VALUE_5 INT NOT NULL," \
      "VALUE_6 INT NOT NULL," \
      "VALUE_7 INT NOT NULL," \
      "VALUE_8 INT NOT NULL," \
      "VALUE_9 INT NOT NULL," \
      "VALUE_10 INT NOT NULL," \
      "VALUE_11 INT NOT NULL," \
      "VALUE_12 INT NOT NULL," \
      "VALUE_13 INT NOT NULL," \
      "VALUE_14 INT NOT NULL," \
      "VALUE_15 INT NOT NULL," \
      "VALUE_16 INT NOT NULL," \
      "VALUE_17 INT NOT NULL," \
      "VALUE_18 INT NOT NULL," \
      "VALUE_19 INT NOT NULL," \
      "VALUE_20 INT NOT NULL," \
      "VALUE_21 INT NOT NULL," \
      "VALUE_22 INT NOT NULL," \
      "VALUE_23 INT NOT NULL," \
      "VALUE_24 INT NOT NULL," \
      "VALUE_25 INT NOT NULL," \
      "VALUE_26 INT NOT NULL," \
      "VALUE_27 INT NOT NULL," \
      "VALUE_28 INT NOT NULL," \
      "VALUE_29 INT NOT NULL," \
      "VALUE_30 INT NOT NULL," \
      "VALUE_31 INT NOT NULL);";
    const char* insertSql = "INSERT INTO ArchFpRegState (STEP,COREID,VALUE_0,VALUE_1,VALUE_2,VALUE_3,VALUE_4,VALUE_5,VALUE_6,VALUE_7,VALUE_8,VALUE_9,VALUE_10,VALUE_11,VALUE_12,VALUE_13,VALUE_14,VALUE_15,VALUE_16,VALUE_17,VALUE_18,VALUE_19,VALUE_20,VALUE_21,VALUE_22,VALUE_23,VALUE_24,VALUE_25,VALUE_26,VALUE_27,VALUE_28,VALUE_29,VALUE_30,VALUE_31) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_ArchFpRegState = new Query(mem_db, createSql, insertSql);
  }

  void ArchVecRegState_init() {
    const char* createSql = " CREATE TABLE ArchVecRegState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALUE_0 INT NOT NULL," \
      "VALUE_1 INT NOT NULL," \
      "VALUE_2 INT NOT NULL," \
      "VALUE_3 INT NOT NULL," \
      "VALUE_4 INT NOT NULL," \
      "VALUE_5 INT NOT NULL," \
      "VALUE_6 INT NOT NULL," \
      "VALUE_7 INT NOT NULL," \
      "VALUE_8 INT NOT NULL," \
      "VALUE_9 INT NOT NULL," \
      "VALUE_10 INT NOT NULL," \
      "VALUE_11 INT NOT NULL," \
      "VALUE_12 INT NOT NULL," \
      "VALUE_13 INT NOT NULL," \
      "VALUE_14 INT NOT NULL," \
      "VALUE_15 INT NOT NULL," \
      "VALUE_16 INT NOT NULL," \
      "VALUE_17 INT NOT NULL," \
      "VALUE_18 INT NOT NULL," \
      "VALUE_19 INT NOT NULL," \
      "VALUE_20 INT NOT NULL," \
      "VALUE_21 INT NOT NULL," \
      "VALUE_22 INT NOT NULL," \
      "VALUE_23 INT NOT NULL," \
      "VALUE_24 INT NOT NULL," \
      "VALUE_25 INT NOT NULL," \
      "VALUE_26 INT NOT NULL," \
      "VALUE_27 INT NOT NULL," \
      "VALUE_28 INT NOT NULL," \
      "VALUE_29 INT NOT NULL," \
      "VALUE_30 INT NOT NULL," \
      "VALUE_31 INT NOT NULL," \
      "VALUE_32 INT NOT NULL," \
      "VALUE_33 INT NOT NULL," \
      "VALUE_34 INT NOT NULL," \
      "VALUE_35 INT NOT NULL," \
      "VALUE_36 INT NOT NULL," \
      "VALUE_37 INT NOT NULL," \
      "VALUE_38 INT NOT NULL," \
      "VALUE_39 INT NOT NULL," \
      "VALUE_40 INT NOT NULL," \
      "VALUE_41 INT NOT NULL," \
      "VALUE_42 INT NOT NULL," \
      "VALUE_43 INT NOT NULL," \
      "VALUE_44 INT NOT NULL," \
      "VALUE_45 INT NOT NULL," \
      "VALUE_46 INT NOT NULL," \
      "VALUE_47 INT NOT NULL," \
      "VALUE_48 INT NOT NULL," \
      "VALUE_49 INT NOT NULL," \
      "VALUE_50 INT NOT NULL," \
      "VALUE_51 INT NOT NULL," \
      "VALUE_52 INT NOT NULL," \
      "VALUE_53 INT NOT NULL," \
      "VALUE_54 INT NOT NULL," \
      "VALUE_55 INT NOT NULL," \
      "VALUE_56 INT NOT NULL," \
      "VALUE_57 INT NOT NULL," \
      "VALUE_58 INT NOT NULL," \
      "VALUE_59 INT NOT NULL," \
      "VALUE_60 INT NOT NULL," \
      "VALUE_61 INT NOT NULL," \
      "VALUE_62 INT NOT NULL," \
      "VALUE_63 INT NOT NULL);";
    const char* insertSql = "INSERT INTO ArchVecRegState (STEP,COREID,VALUE_0,VALUE_1,VALUE_2,VALUE_3,VALUE_4,VALUE_5,VALUE_6,VALUE_7,VALUE_8,VALUE_9,VALUE_10,VALUE_11,VALUE_12,VALUE_13,VALUE_14,VALUE_15,VALUE_16,VALUE_17,VALUE_18,VALUE_19,VALUE_20,VALUE_21,VALUE_22,VALUE_23,VALUE_24,VALUE_25,VALUE_26,VALUE_27,VALUE_28,VALUE_29,VALUE_30,VALUE_31,VALUE_32,VALUE_33,VALUE_34,VALUE_35,VALUE_36,VALUE_37,VALUE_38,VALUE_39,VALUE_40,VALUE_41,VALUE_42,VALUE_43,VALUE_44,VALUE_45,VALUE_46,VALUE_47,VALUE_48,VALUE_49,VALUE_50,VALUE_51,VALUE_52,VALUE_53,VALUE_54,VALUE_55,VALUE_56,VALUE_57,VALUE_58,VALUE_59,VALUE_60,VALUE_61,VALUE_62,VALUE_63) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_ArchVecRegState = new Query(mem_db, createSql, insertSql);
  }

  void ArchEvent_init() {
    const char* createSql = " CREATE TABLE ArchEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "INTERRUPT INT NOT NULL," \
      "EXCEPTION INT NOT NULL," \
      "EXCEPTIONPC INT NOT NULL," \
      "EXCEPTIONINST INT NOT NULL," \
      "HASNMI INT NOT NULL," \
      "VIRTUALINTERRUPTISHVICTLINJECT INT NOT NULL);";
    const char* insertSql = "INSERT INTO ArchEvent (STEP,COREID,VALID,INTERRUPT,EXCEPTION,EXCEPTIONPC,EXCEPTIONINST,HASNMI,VIRTUALINTERRUPTISHVICTLINJECT) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_ArchEvent = new Query(mem_db, createSql, insertSql);
  }

  void CriticalErrorEvent_init() {
    const char* createSql = " CREATE TABLE CriticalErrorEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "CRITICALERROR INT NOT NULL);";
    const char* insertSql = "INSERT INTO CriticalErrorEvent (STEP,COREID,VALID,CRITICALERROR) " \
      " VALUES (?,?,?,?);";
    query_CriticalErrorEvent = new Query(mem_db, createSql, insertSql);
  }

  void CSRState_init() {
    const char* createSql = " CREATE TABLE CSRState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "PRIVILEGEMODE INT NOT NULL," \
      "MSTATUS INT NOT NULL," \
      "SSTATUS INT NOT NULL," \
      "MEPC INT NOT NULL," \
      "SEPC INT NOT NULL," \
      "MTVAL INT NOT NULL," \
      "STVAL INT NOT NULL," \
      "MTVEC INT NOT NULL," \
      "STVEC INT NOT NULL," \
      "MCAUSE INT NOT NULL," \
      "SCAUSE INT NOT NULL," \
      "SATP INT NOT NULL," \
      "MIP INT NOT NULL," \
      "MIE INT NOT NULL," \
      "MSCRATCH INT NOT NULL," \
      "SSCRATCH INT NOT NULL," \
      "MIDELEG INT NOT NULL," \
      "MEDELEG INT NOT NULL);";
    const char* insertSql = "INSERT INTO CSRState (STEP,COREID,PRIVILEGEMODE,MSTATUS,SSTATUS,MEPC,SEPC,MTVAL,STVAL,MTVEC,STVEC,MCAUSE,SCAUSE,SATP,MIP,MIE,MSCRATCH,SSCRATCH,MIDELEG,MEDELEG) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_CSRState = new Query(mem_db, createSql, insertSql);
  }

  void DebugMode_init() {
    const char* createSql = " CREATE TABLE DebugMode(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "DEBUGMODE INT NOT NULL," \
      "DCSR INT NOT NULL," \
      "DPC INT NOT NULL," \
      "DSCRATCH0 INT NOT NULL," \
      "DSCRATCH1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO DebugMode (STEP,COREID,DEBUGMODE,DCSR,DPC,DSCRATCH0,DSCRATCH1) " \
      " VALUES (?,?,?,?,?,?,?);";
    query_DebugMode = new Query(mem_db, createSql, insertSql);
  }

  void TriggerCSRState_init() {
    const char* createSql = " CREATE TABLE TriggerCSRState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "TSELECT INT NOT NULL," \
      "TDATA1 INT NOT NULL," \
      "TINFO INT NOT NULL);";
    const char* insertSql = "INSERT INTO TriggerCSRState (STEP,COREID,TSELECT,TDATA1,TINFO) " \
      " VALUES (?,?,?,?,?);";
    query_TriggerCSRState = new Query(mem_db, createSql, insertSql);
  }

  void VecCSRState_init() {
    const char* createSql = " CREATE TABLE VecCSRState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VSTART INT NOT NULL," \
      "VXSAT INT NOT NULL," \
      "VXRM INT NOT NULL," \
      "VCSR INT NOT NULL," \
      "VL INT NOT NULL," \
      "VTYPE INT NOT NULL," \
      "VLENB INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecCSRState (STEP,COREID,VSTART,VXSAT,VXRM,VCSR,VL,VTYPE,VLENB) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_VecCSRState = new Query(mem_db, createSql, insertSql);
  }

  void FpCSRState_init() {
    const char* createSql = " CREATE TABLE FpCSRState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "FCSR INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpCSRState (STEP,COREID,FCSR) " \
      " VALUES (?,?,?);";
    query_FpCSRState = new Query(mem_db, createSql, insertSql);
  }

  void HCSRState_init() {
    const char* createSql = " CREATE TABLE HCSRState(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VIRTMODE INT NOT NULL," \
      "MTVAL2 INT NOT NULL," \
      "MTINST INT NOT NULL," \
      "HSTATUS INT NOT NULL," \
      "HIDELEG INT NOT NULL," \
      "HEDELEG INT NOT NULL," \
      "HCOUNTEREN INT NOT NULL," \
      "HTVAL INT NOT NULL," \
      "HTINST INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "VSSTATUS INT NOT NULL," \
      "VSTVEC INT NOT NULL," \
      "VSEPC INT NOT NULL," \
      "VSCAUSE INT NOT NULL," \
      "VSTVAL INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "VSSCRATCH INT NOT NULL);";
    const char* insertSql = "INSERT INTO HCSRState (STEP,COREID,VIRTMODE,MTVAL2,MTINST,HSTATUS,HIDELEG,HEDELEG,HCOUNTEREN,HTVAL,HTINST,HGATP,VSSTATUS,VSTVEC,VSEPC,VSCAUSE,VSTVAL,VSATP,VSSCRATCH) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_HCSRState = new Query(mem_db, createSql, insertSql);
  }

  void NonRegInterruptPendingEvent_init() {
    const char* createSql = " CREATE TABLE NonRegInterruptPendingEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "PLATFORMIRPMEIP INT NOT NULL," \
      "PLATFORMIRPMTIP INT NOT NULL," \
      "PLATFORMIRPMSIP INT NOT NULL," \
      "PLATFORMIRPSEIP INT NOT NULL," \
      "PLATFORMIRPSTIP INT NOT NULL," \
      "PLATFORMIRPVSEIP INT NOT NULL," \
      "PLATFORMIRPVSTIP INT NOT NULL," \
      "FROMAIAMEIP INT NOT NULL," \
      "FROMAIASEIP INT NOT NULL," \
      "LOCALCOUNTEROVERFLOWINTERRUPTREQ INT NOT NULL);";
    const char* insertSql = "INSERT INTO NonRegInterruptPendingEvent (STEP,COREID,VALID,PLATFORMIRPMEIP,PLATFORMIRPMTIP,PLATFORMIRPMSIP,PLATFORMIRPSEIP,PLATFORMIRPSTIP,PLATFORMIRPVSEIP,PLATFORMIRPVSTIP,FROMAIAMEIP,FROMAIASEIP,LOCALCOUNTEROVERFLOWINTERRUPTREQ) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_NonRegInterruptPendingEvent = new Query(mem_db, createSql, insertSql);
  }

  void MhpmeventOverflowEvent_init() {
    const char* createSql = " CREATE TABLE MhpmeventOverflowEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "MHPMEVENTOVERFLOW INT NOT NULL);";
    const char* insertSql = "INSERT INTO MhpmeventOverflowEvent (STEP,COREID,VALID,MHPMEVENTOVERFLOW) " \
      " VALUES (?,?,?,?);";
    query_MhpmeventOverflowEvent = new Query(mem_db, createSql, insertSql);
  }

  void SyncAIAEvent_init() {
    const char* createSql = " CREATE TABLE SyncAIAEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "MTOPEI INT NOT NULL," \
      "STOPEI INT NOT NULL," \
      "VSTOPEI INT NOT NULL," \
      "HGEIP INT NOT NULL);";
    const char* insertSql = "INSERT INTO SyncAIAEvent (STEP,COREID,VALID,MTOPEI,STOPEI,VSTOPEI,HGEIP) " \
      " VALUES (?,?,?,?,?,?,?);";
    query_SyncAIAEvent = new Query(mem_db, createSql, insertSql);
  }

  void SyncCustomMflushpwrEvent_init() {
    const char* createSql = " CREATE TABLE SyncCustomMflushpwrEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "L2FLUSHDONE INT NOT NULL);";
    const char* insertSql = "INSERT INTO SyncCustomMflushpwrEvent (STEP,COREID,VALID,L2FLUSHDONE) " \
      " VALUES (?,?,?,?);";
    query_SyncCustomMflushpwrEvent = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void IntWriteback_init() {
    const char* createSql = " CREATE TABLE IntWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO IntWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_IntWriteback = new Query(mem_db, createSql, insertSql);
  }

  void FpWriteback_init() {
    const char* createSql = " CREATE TABLE FpWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_FpWriteback = new Query(mem_db, createSql, insertSql);
  }

  void FpWriteback_init() {
    const char* createSql = " CREATE TABLE FpWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_FpWriteback = new Query(mem_db, createSql, insertSql);
  }

  void FpWriteback_init() {
    const char* createSql = " CREATE TABLE FpWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_FpWriteback = new Query(mem_db, createSql, insertSql);
  }

  void FpWriteback_init() {
    const char* createSql = " CREATE TABLE FpWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_FpWriteback = new Query(mem_db, createSql, insertSql);
  }

  void FpWriteback_init() {
    const char* createSql = " CREATE TABLE FpWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_FpWriteback = new Query(mem_db, createSql, insertSql);
  }

  void FpWriteback_init() {
    const char* createSql = " CREATE TABLE FpWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA INT NOT NULL);";
    const char* insertSql = "INSERT INTO FpWriteback (STEP,COREID,ADDRESS,DATA) " \
      " VALUES (?,?,?,?);";
    query_FpWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecWriteback_init() {
    const char* createSql = " CREATE TABLE VecWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecWriteback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecWriteback_init() {
    const char* createSql = " CREATE TABLE VecWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecWriteback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecWriteback_init() {
    const char* createSql = " CREATE TABLE VecWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecWriteback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecWriteback_init() {
    const char* createSql = " CREATE TABLE VecWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecWriteback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecWriteback_init() {
    const char* createSql = " CREATE TABLE VecWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecWriteback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecWriteback_init() {
    const char* createSql = " CREATE TABLE VecWriteback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecWriteback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecWriteback = new Query(mem_db, createSql, insertSql);
  }

  void VecV0Writeback_init() {
    const char* createSql = " CREATE TABLE VecV0Writeback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecV0Writeback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecV0Writeback = new Query(mem_db, createSql, insertSql);
  }

  void VecV0Writeback_init() {
    const char* createSql = " CREATE TABLE VecV0Writeback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecV0Writeback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecV0Writeback = new Query(mem_db, createSql, insertSql);
  }

  void VecV0Writeback_init() {
    const char* createSql = " CREATE TABLE VecV0Writeback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecV0Writeback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecV0Writeback = new Query(mem_db, createSql, insertSql);
  }

  void VecV0Writeback_init() {
    const char* createSql = " CREATE TABLE VecV0Writeback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecV0Writeback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecV0Writeback = new Query(mem_db, createSql, insertSql);
  }

  void VecV0Writeback_init() {
    const char* createSql = " CREATE TABLE VecV0Writeback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecV0Writeback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecV0Writeback = new Query(mem_db, createSql, insertSql);
  }

  void VecV0Writeback_init() {
    const char* createSql = " CREATE TABLE VecV0Writeback(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "ADDRESS INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO VecV0Writeback (STEP,COREID,ADDRESS,DATA_0,DATA_1) " \
      " VALUES (?,?,?,?,?);";
    query_VecV0Writeback = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void RefillEvent_init() {
    const char* createSql = " CREATE TABLE RefillEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "IDTFR INT NOT NULL);";
    const char* insertSql = "INSERT INTO RefillEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,IDTFR) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_RefillEvent = new Query(mem_db, createSql, insertSql);
  }

  void L2TLBEvent_init() {
    const char* createSql = " CREATE TABLE L2TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "VALIDIDX_0 INT NOT NULL," \
      "VALIDIDX_1 INT NOT NULL," \
      "VALIDIDX_2 INT NOT NULL," \
      "VALIDIDX_3 INT NOT NULL," \
      "VALIDIDX_4 INT NOT NULL," \
      "VALIDIDX_5 INT NOT NULL," \
      "VALIDIDX_6 INT NOT NULL," \
      "VALIDIDX_7 INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PBMT INT NOT NULL," \
      "G_PBMT INT NOT NULL," \
      "PPN_0 INT NOT NULL," \
      "PPN_1 INT NOT NULL," \
      "PPN_2 INT NOT NULL," \
      "PPN_3 INT NOT NULL," \
      "PPN_4 INT NOT NULL," \
      "PPN_5 INT NOT NULL," \
      "PPN_6 INT NOT NULL," \
      "PPN_7 INT NOT NULL," \
      "PERM INT NOT NULL," \
      "LEVEL INT NOT NULL," \
      "PF INT NOT NULL," \
      "PTEIDX_0 INT NOT NULL," \
      "PTEIDX_1 INT NOT NULL," \
      "PTEIDX_2 INT NOT NULL," \
      "PTEIDX_3 INT NOT NULL," \
      "PTEIDX_4 INT NOT NULL," \
      "PTEIDX_5 INT NOT NULL," \
      "PTEIDX_6 INT NOT NULL," \
      "PTEIDX_7 INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "GVPN INT NOT NULL," \
      "G_PERM INT NOT NULL," \
      "G_LEVEL INT NOT NULL," \
      "S2PPN INT NOT NULL," \
      "GPF INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L2TLBEvent (STEP,COREID,MY_INDEX,VALID,VALIDIDX_0,VALIDIDX_1,VALIDIDX_2,VALIDIDX_3,VALIDIDX_4,VALIDIDX_5,VALIDIDX_6,VALIDIDX_7,SATP,VPN,PBMT,G_PBMT,PPN_0,PPN_1,PPN_2,PPN_3,PPN_4,PPN_5,PPN_6,PPN_7,PERM,LEVEL,PF,PTEIDX_0,PTEIDX_1,PTEIDX_2,PTEIDX_3,PTEIDX_4,PTEIDX_5,PTEIDX_6,PTEIDX_7,VSATP,HGATP,GVPN,G_PERM,G_LEVEL,S2PPN,GPF,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_L2TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L2TLBEvent_init() {
    const char* createSql = " CREATE TABLE L2TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "VALIDIDX_0 INT NOT NULL," \
      "VALIDIDX_1 INT NOT NULL," \
      "VALIDIDX_2 INT NOT NULL," \
      "VALIDIDX_3 INT NOT NULL," \
      "VALIDIDX_4 INT NOT NULL," \
      "VALIDIDX_5 INT NOT NULL," \
      "VALIDIDX_6 INT NOT NULL," \
      "VALIDIDX_7 INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PBMT INT NOT NULL," \
      "G_PBMT INT NOT NULL," \
      "PPN_0 INT NOT NULL," \
      "PPN_1 INT NOT NULL," \
      "PPN_2 INT NOT NULL," \
      "PPN_3 INT NOT NULL," \
      "PPN_4 INT NOT NULL," \
      "PPN_5 INT NOT NULL," \
      "PPN_6 INT NOT NULL," \
      "PPN_7 INT NOT NULL," \
      "PERM INT NOT NULL," \
      "LEVEL INT NOT NULL," \
      "PF INT NOT NULL," \
      "PTEIDX_0 INT NOT NULL," \
      "PTEIDX_1 INT NOT NULL," \
      "PTEIDX_2 INT NOT NULL," \
      "PTEIDX_3 INT NOT NULL," \
      "PTEIDX_4 INT NOT NULL," \
      "PTEIDX_5 INT NOT NULL," \
      "PTEIDX_6 INT NOT NULL," \
      "PTEIDX_7 INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "GVPN INT NOT NULL," \
      "G_PERM INT NOT NULL," \
      "G_LEVEL INT NOT NULL," \
      "S2PPN INT NOT NULL," \
      "GPF INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L2TLBEvent (STEP,COREID,MY_INDEX,VALID,VALIDIDX_0,VALIDIDX_1,VALIDIDX_2,VALIDIDX_3,VALIDIDX_4,VALIDIDX_5,VALIDIDX_6,VALIDIDX_7,SATP,VPN,PBMT,G_PBMT,PPN_0,PPN_1,PPN_2,PPN_3,PPN_4,PPN_5,PPN_6,PPN_7,PERM,LEVEL,PF,PTEIDX_0,PTEIDX_1,PTEIDX_2,PTEIDX_3,PTEIDX_4,PTEIDX_5,PTEIDX_6,PTEIDX_7,VSATP,HGATP,GVPN,G_PERM,G_LEVEL,S2PPN,GPF,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_L2TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void AtomicEvent_init() {
    const char* createSql = " CREATE TABLE AtomicEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "MASK INT NOT NULL," \
      "CMP_0 INT NOT NULL," \
      "CMP_1 INT NOT NULL," \
      "FUOP INT NOT NULL," \
      "OUT_0 INT NOT NULL," \
      "OUT_1 INT NOT NULL);";
    const char* insertSql = "INSERT INTO AtomicEvent (STEP,COREID,VALID,ADDR,DATA_0,DATA_1,MASK,CMP_0,CMP_1,FUOP,OUT_0,OUT_1) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?);";
    query_AtomicEvent = new Query(mem_db, createSql, insertSql);
  }

  void LrScEvent_init() {
    const char* createSql = " CREATE TABLE LrScEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SUCCESS INT NOT NULL);";
    const char* insertSql = "INSERT INTO LrScEvent (STEP,COREID,VALID,SUCCESS) " \
      " VALUES (?,?,?,?);";
    query_LrScEvent = new Query(mem_db, createSql, insertSql);
  }

  void CMOInvalEvent_init() {
    const char* createSql = " CREATE TABLE CMOInvalEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL);";
    const char* insertSql = "INSERT INTO CMOInvalEvent (STEP,COREID,VALID,ADDR) " \
      " VALUES (?,?,?,?);";
    query_CMOInvalEvent = new Query(mem_db, createSql, insertSql);
  }

  void SbufferEvent_init() {
    const char* createSql = " CREATE TABLE SbufferEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA_0 INT NOT NULL," \
      "DATA_1 INT NOT NULL," \
      "DATA_2 INT NOT NULL," \
      "DATA_3 INT NOT NULL," \
      "DATA_4 INT NOT NULL," \
      "DATA_5 INT NOT NULL," \
      "DATA_6 INT NOT NULL," \
      "DATA_7 INT NOT NULL," \
      "DATA_8 INT NOT NULL," \
      "DATA_9 INT NOT NULL," \
      "DATA_10 INT NOT NULL," \
      "DATA_11 INT NOT NULL," \
      "DATA_12 INT NOT NULL," \
      "DATA_13 INT NOT NULL," \
      "DATA_14 INT NOT NULL," \
      "DATA_15 INT NOT NULL," \
      "DATA_16 INT NOT NULL," \
      "DATA_17 INT NOT NULL," \
      "DATA_18 INT NOT NULL," \
      "DATA_19 INT NOT NULL," \
      "DATA_20 INT NOT NULL," \
      "DATA_21 INT NOT NULL," \
      "DATA_22 INT NOT NULL," \
      "DATA_23 INT NOT NULL," \
      "DATA_24 INT NOT NULL," \
      "DATA_25 INT NOT NULL," \
      "DATA_26 INT NOT NULL," \
      "DATA_27 INT NOT NULL," \
      "DATA_28 INT NOT NULL," \
      "DATA_29 INT NOT NULL," \
      "DATA_30 INT NOT NULL," \
      "DATA_31 INT NOT NULL," \
      "DATA_32 INT NOT NULL," \
      "DATA_33 INT NOT NULL," \
      "DATA_34 INT NOT NULL," \
      "DATA_35 INT NOT NULL," \
      "DATA_36 INT NOT NULL," \
      "DATA_37 INT NOT NULL," \
      "DATA_38 INT NOT NULL," \
      "DATA_39 INT NOT NULL," \
      "DATA_40 INT NOT NULL," \
      "DATA_41 INT NOT NULL," \
      "DATA_42 INT NOT NULL," \
      "DATA_43 INT NOT NULL," \
      "DATA_44 INT NOT NULL," \
      "DATA_45 INT NOT NULL," \
      "DATA_46 INT NOT NULL," \
      "DATA_47 INT NOT NULL," \
      "DATA_48 INT NOT NULL," \
      "DATA_49 INT NOT NULL," \
      "DATA_50 INT NOT NULL," \
      "DATA_51 INT NOT NULL," \
      "DATA_52 INT NOT NULL," \
      "DATA_53 INT NOT NULL," \
      "DATA_54 INT NOT NULL," \
      "DATA_55 INT NOT NULL," \
      "DATA_56 INT NOT NULL," \
      "DATA_57 INT NOT NULL," \
      "DATA_58 INT NOT NULL," \
      "DATA_59 INT NOT NULL," \
      "DATA_60 INT NOT NULL," \
      "DATA_61 INT NOT NULL," \
      "DATA_62 INT NOT NULL," \
      "DATA_63 INT NOT NULL," \
      "MASK INT NOT NULL);";
    const char* insertSql = "INSERT INTO SbufferEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA_0,DATA_1,DATA_2,DATA_3,DATA_4,DATA_5,DATA_6,DATA_7,DATA_8,DATA_9,DATA_10,DATA_11,DATA_12,DATA_13,DATA_14,DATA_15,DATA_16,DATA_17,DATA_18,DATA_19,DATA_20,DATA_21,DATA_22,DATA_23,DATA_24,DATA_25,DATA_26,DATA_27,DATA_28,DATA_29,DATA_30,DATA_31,DATA_32,DATA_33,DATA_34,DATA_35,DATA_36,DATA_37,DATA_38,DATA_39,DATA_40,DATA_41,DATA_42,DATA_43,DATA_44,DATA_45,DATA_46,DATA_47,DATA_48,DATA_49,DATA_50,DATA_51,DATA_52,DATA_53,DATA_54,DATA_55,DATA_56,DATA_57,DATA_58,DATA_59,DATA_60,DATA_61,DATA_62,DATA_63,MASK) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query_SbufferEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void StoreEvent_init() {
    const char* createSql = " CREATE TABLE StoreEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "ADDR INT NOT NULL," \
      "DATA INT NOT NULL," \
      "MASK INT NOT NULL," \
      "PC INT NOT NULL," \
      "ROBIDX INT NOT NULL);";
    const char* insertSql = "INSERT INTO StoreEvent (STEP,COREID,MY_INDEX,VALID,ADDR,DATA,MASK,PC,ROBIDX) " \
      " VALUES (?,?,?,?,?,?,?,?,?);";
    query_StoreEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  void L1TLBEvent_init() {
    const char* createSql = " CREATE TABLE L1TLBEvent(" \
      "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
      "STEP INT NOT NULL," \
      "COREID INT NOT NULL," \
      "MY_INDEX INT NOT NULL," \
      "VALID INT NOT NULL," \
      "SATP INT NOT NULL," \
      "VPN INT NOT NULL," \
      "PPN INT NOT NULL," \
      "VSATP INT NOT NULL," \
      "HGATP INT NOT NULL," \
      "S2XLATE INT NOT NULL);";
    const char* insertSql = "INSERT INTO L1TLBEvent (STEP,COREID,MY_INDEX,VALID,SATP,VPN,PPN,VSATP,HGATP,S2XLATE) " \
      " VALUES (?,?,?,?,?,?,?,?,?,?);";
    query_L1TLBEvent = new Query(mem_db, createSql, insertSql);
  }

  
  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void InstrCommit_write(uint8_t coreid, uint8_t index, DifftestInstrCommit* packet) {
    query_InstrCommit->write(37, query_step, coreid, index, packet->valid, packet->skip, packet->isRVC, packet->rfwen, packet->fpwen, packet->vecwen, packet->v0wen, packet->wpdest, packet->wdest, packet->otherwpdest[0], packet->otherwpdest[1], packet->otherwpdest[2], packet->otherwpdest[3], packet->otherwpdest[4], packet->otherwpdest[5], packet->otherwpdest[6], packet->otherwpdest[7], packet->otherV0Wen[0], packet->otherV0Wen[1], packet->otherV0Wen[2], packet->otherV0Wen[3], packet->otherV0Wen[4], packet->otherV0Wen[5], packet->otherV0Wen[6], packet->otherV0Wen[7], packet->pc, packet->instr, packet->robIdx, packet->lqIdx, packet->sqIdx, packet->isLoad, packet->isStore, packet->nFused, packet->special);
  }

  void LoadEvent_write(uint8_t coreid, uint8_t index, DifftestLoadEvent* packet) {
    query_LoadEvent->write(9, query_step, coreid, index, packet->valid, packet->paddr, packet->opType, packet->isAtomic, packet->isLoad, packet->isVLoad);
  }

  void TrapEvent_write(uint8_t coreid, DifftestTrapEvent* packet) {
    query_TrapEvent->write(8, query_step, coreid, packet->hasTrap, packet->cycleCnt, packet->instrCnt, packet->hasWFI, packet->code, packet->pc);
  }

  void ArchIntRegState_write(uint8_t coreid, DifftestArchIntRegState* packet) {
    query_ArchIntRegState->write(34, query_step, coreid, packet->value[0], packet->value[1], packet->value[2], packet->value[3], packet->value[4], packet->value[5], packet->value[6], packet->value[7], packet->value[8], packet->value[9], packet->value[10], packet->value[11], packet->value[12], packet->value[13], packet->value[14], packet->value[15], packet->value[16], packet->value[17], packet->value[18], packet->value[19], packet->value[20], packet->value[21], packet->value[22], packet->value[23], packet->value[24], packet->value[25], packet->value[26], packet->value[27], packet->value[28], packet->value[29], packet->value[30], packet->value[31]);
  }

  void ArchFpRegState_write(uint8_t coreid, DifftestArchFpRegState* packet) {
    query_ArchFpRegState->write(34, query_step, coreid, packet->value[0], packet->value[1], packet->value[2], packet->value[3], packet->value[4], packet->value[5], packet->value[6], packet->value[7], packet->value[8], packet->value[9], packet->value[10], packet->value[11], packet->value[12], packet->value[13], packet->value[14], packet->value[15], packet->value[16], packet->value[17], packet->value[18], packet->value[19], packet->value[20], packet->value[21], packet->value[22], packet->value[23], packet->value[24], packet->value[25], packet->value[26], packet->value[27], packet->value[28], packet->value[29], packet->value[30], packet->value[31]);
  }

  void ArchVecRegState_write(uint8_t coreid, DifftestArchVecRegState* packet) {
    query_ArchVecRegState->write(66, query_step, coreid, packet->value[0], packet->value[1], packet->value[2], packet->value[3], packet->value[4], packet->value[5], packet->value[6], packet->value[7], packet->value[8], packet->value[9], packet->value[10], packet->value[11], packet->value[12], packet->value[13], packet->value[14], packet->value[15], packet->value[16], packet->value[17], packet->value[18], packet->value[19], packet->value[20], packet->value[21], packet->value[22], packet->value[23], packet->value[24], packet->value[25], packet->value[26], packet->value[27], packet->value[28], packet->value[29], packet->value[30], packet->value[31], packet->value[32], packet->value[33], packet->value[34], packet->value[35], packet->value[36], packet->value[37], packet->value[38], packet->value[39], packet->value[40], packet->value[41], packet->value[42], packet->value[43], packet->value[44], packet->value[45], packet->value[46], packet->value[47], packet->value[48], packet->value[49], packet->value[50], packet->value[51], packet->value[52], packet->value[53], packet->value[54], packet->value[55], packet->value[56], packet->value[57], packet->value[58], packet->value[59], packet->value[60], packet->value[61], packet->value[62], packet->value[63]);
  }

  void ArchEvent_write(uint8_t coreid, DifftestArchEvent* packet) {
    query_ArchEvent->write(9, query_step, coreid, packet->valid, packet->interrupt, packet->exception, packet->exceptionPC, packet->exceptionInst, packet->hasNMI, packet->virtualInterruptIsHvictlInject);
  }

  void CriticalErrorEvent_write(uint8_t coreid, DifftestCriticalErrorEvent* packet) {
    query_CriticalErrorEvent->write(4, query_step, coreid, packet->valid, packet->criticalError);
  }

  void CSRState_write(uint8_t coreid, DifftestCSRState* packet) {
    query_CSRState->write(20, query_step, coreid, packet->privilegeMode, packet->mstatus, packet->sstatus, packet->mepc, packet->sepc, packet->mtval, packet->stval, packet->mtvec, packet->stvec, packet->mcause, packet->scause, packet->satp, packet->mip, packet->mie, packet->mscratch, packet->sscratch, packet->mideleg, packet->medeleg);
  }

  void DebugMode_write(uint8_t coreid, DifftestDebugMode* packet) {
    query_DebugMode->write(7, query_step, coreid, packet->debugMode, packet->dcsr, packet->dpc, packet->dscratch0, packet->dscratch1);
  }

  void TriggerCSRState_write(uint8_t coreid, DifftestTriggerCSRState* packet) {
    query_TriggerCSRState->write(5, query_step, coreid, packet->tselect, packet->tdata1, packet->tinfo);
  }

  void VecCSRState_write(uint8_t coreid, DifftestVecCSRState* packet) {
    query_VecCSRState->write(9, query_step, coreid, packet->vstart, packet->vxsat, packet->vxrm, packet->vcsr, packet->vl, packet->vtype, packet->vlenb);
  }

  void FpCSRState_write(uint8_t coreid, DifftestFpCSRState* packet) {
    query_FpCSRState->write(3, query_step, coreid, packet->fcsr);
  }

  void HCSRState_write(uint8_t coreid, DifftestHCSRState* packet) {
    query_HCSRState->write(19, query_step, coreid, packet->virtMode, packet->mtval2, packet->mtinst, packet->hstatus, packet->hideleg, packet->hedeleg, packet->hcounteren, packet->htval, packet->htinst, packet->hgatp, packet->vsstatus, packet->vstvec, packet->vsepc, packet->vscause, packet->vstval, packet->vsatp, packet->vsscratch);
  }

  void NonRegInterruptPendingEvent_write(uint8_t coreid, DifftestNonRegInterruptPendingEvent* packet) {
    query_NonRegInterruptPendingEvent->write(13, query_step, coreid, packet->valid, packet->platformIRPMeip, packet->platformIRPMtip, packet->platformIRPMsip, packet->platformIRPSeip, packet->platformIRPStip, packet->platformIRPVseip, packet->platformIRPVstip, packet->fromAIAMeip, packet->fromAIASeip, packet->localCounterOverflowInterruptReq);
  }

  void MhpmeventOverflowEvent_write(uint8_t coreid, DifftestMhpmeventOverflowEvent* packet) {
    query_MhpmeventOverflowEvent->write(4, query_step, coreid, packet->valid, packet->mhpmeventOverflow);
  }

  void SyncAIAEvent_write(uint8_t coreid, DifftestSyncAIAEvent* packet) {
    query_SyncAIAEvent->write(7, query_step, coreid, packet->valid, packet->mtopei, packet->stopei, packet->vstopei, packet->hgeip);
  }

  void SyncCustomMflushpwrEvent_write(uint8_t coreid, DifftestSyncCustomMflushpwrEvent* packet) {
    query_SyncCustomMflushpwrEvent->write(4, query_step, coreid, packet->valid, packet->l2FlushDone);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void IntWriteback_write(uint8_t coreid, uint8_t address, DifftestIntWriteback* packet) {
    query_IntWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void FpWriteback_write(uint8_t coreid, uint8_t address, DifftestFpWriteback* packet) {
    query_FpWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void FpWriteback_write(uint8_t coreid, uint8_t address, DifftestFpWriteback* packet) {
    query_FpWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void FpWriteback_write(uint8_t coreid, uint8_t address, DifftestFpWriteback* packet) {
    query_FpWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void FpWriteback_write(uint8_t coreid, uint8_t address, DifftestFpWriteback* packet) {
    query_FpWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void FpWriteback_write(uint8_t coreid, uint8_t address, DifftestFpWriteback* packet) {
    query_FpWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void FpWriteback_write(uint8_t coreid, uint8_t address, DifftestFpWriteback* packet) {
    query_FpWriteback->write(4, query_step, coreid, address, packet->data);
  }

  void VecWriteback_write(uint8_t coreid, uint8_t address, DifftestVecWriteback* packet) {
    query_VecWriteback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecWriteback_write(uint8_t coreid, uint8_t address, DifftestVecWriteback* packet) {
    query_VecWriteback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecWriteback_write(uint8_t coreid, uint8_t address, DifftestVecWriteback* packet) {
    query_VecWriteback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecWriteback_write(uint8_t coreid, uint8_t address, DifftestVecWriteback* packet) {
    query_VecWriteback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecWriteback_write(uint8_t coreid, uint8_t address, DifftestVecWriteback* packet) {
    query_VecWriteback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecWriteback_write(uint8_t coreid, uint8_t address, DifftestVecWriteback* packet) {
    query_VecWriteback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecV0Writeback_write(uint8_t coreid, uint8_t address, DifftestVecV0Writeback* packet) {
    query_VecV0Writeback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecV0Writeback_write(uint8_t coreid, uint8_t address, DifftestVecV0Writeback* packet) {
    query_VecV0Writeback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecV0Writeback_write(uint8_t coreid, uint8_t address, DifftestVecV0Writeback* packet) {
    query_VecV0Writeback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecV0Writeback_write(uint8_t coreid, uint8_t address, DifftestVecV0Writeback* packet) {
    query_VecV0Writeback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecV0Writeback_write(uint8_t coreid, uint8_t address, DifftestVecV0Writeback* packet) {
    query_VecV0Writeback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void VecV0Writeback_write(uint8_t coreid, uint8_t address, DifftestVecV0Writeback* packet) {
    query_VecV0Writeback->write(5, query_step, coreid, address, packet->data[0], packet->data[1]);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void RefillEvent_write(uint8_t coreid, uint8_t index, DifftestRefillEvent* packet) {
    query_RefillEvent->write(14, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->idtfr);
  }

  void L2TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL2TLBEvent* packet) {
    query_L2TLBEvent->write(43, query_step, coreid, index, packet->valid, packet->valididx[0], packet->valididx[1], packet->valididx[2], packet->valididx[3], packet->valididx[4], packet->valididx[5], packet->valididx[6], packet->valididx[7], packet->satp, packet->vpn, packet->pbmt, packet->g_pbmt, packet->ppn[0], packet->ppn[1], packet->ppn[2], packet->ppn[3], packet->ppn[4], packet->ppn[5], packet->ppn[6], packet->ppn[7], packet->perm, packet->level, packet->pf, packet->pteidx[0], packet->pteidx[1], packet->pteidx[2], packet->pteidx[3], packet->pteidx[4], packet->pteidx[5], packet->pteidx[6], packet->pteidx[7], packet->vsatp, packet->hgatp, packet->gvpn, packet->g_perm, packet->g_level, packet->s2ppn, packet->gpf, packet->s2xlate);
  }

  void L2TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL2TLBEvent* packet) {
    query_L2TLBEvent->write(43, query_step, coreid, index, packet->valid, packet->valididx[0], packet->valididx[1], packet->valididx[2], packet->valididx[3], packet->valididx[4], packet->valididx[5], packet->valididx[6], packet->valididx[7], packet->satp, packet->vpn, packet->pbmt, packet->g_pbmt, packet->ppn[0], packet->ppn[1], packet->ppn[2], packet->ppn[3], packet->ppn[4], packet->ppn[5], packet->ppn[6], packet->ppn[7], packet->perm, packet->level, packet->pf, packet->pteidx[0], packet->pteidx[1], packet->pteidx[2], packet->pteidx[3], packet->pteidx[4], packet->pteidx[5], packet->pteidx[6], packet->pteidx[7], packet->vsatp, packet->hgatp, packet->gvpn, packet->g_perm, packet->g_level, packet->s2ppn, packet->gpf, packet->s2xlate);
  }

  void AtomicEvent_write(uint8_t coreid, DifftestAtomicEvent* packet) {
    query_AtomicEvent->write(12, query_step, coreid, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->mask, packet->cmp[0], packet->cmp[1], packet->fuop, packet->out[0], packet->out[1]);
  }

  void LrScEvent_write(uint8_t coreid, DifftestLrScEvent* packet) {
    query_LrScEvent->write(4, query_step, coreid, packet->valid, packet->success);
  }

  void CMOInvalEvent_write(uint8_t coreid, DifftestCMOInvalEvent* packet) {
    query_CMOInvalEvent->write(4, query_step, coreid, packet->valid, packet->addr);
  }

  void SbufferEvent_write(uint8_t coreid, uint8_t index, DifftestSbufferEvent* packet) {
    query_SbufferEvent->write(70, query_step, coreid, index, packet->valid, packet->addr, packet->data[0], packet->data[1], packet->data[2], packet->data[3], packet->data[4], packet->data[5], packet->data[6], packet->data[7], packet->data[8], packet->data[9], packet->data[10], packet->data[11], packet->data[12], packet->data[13], packet->data[14], packet->data[15], packet->data[16], packet->data[17], packet->data[18], packet->data[19], packet->data[20], packet->data[21], packet->data[22], packet->data[23], packet->data[24], packet->data[25], packet->data[26], packet->data[27], packet->data[28], packet->data[29], packet->data[30], packet->data[31], packet->data[32], packet->data[33], packet->data[34], packet->data[35], packet->data[36], packet->data[37], packet->data[38], packet->data[39], packet->data[40], packet->data[41], packet->data[42], packet->data[43], packet->data[44], packet->data[45], packet->data[46], packet->data[47], packet->data[48], packet->data[49], packet->data[50], packet->data[51], packet->data[52], packet->data[53], packet->data[54], packet->data[55], packet->data[56], packet->data[57], packet->data[58], packet->data[59], packet->data[60], packet->data[61], packet->data[62], packet->data[63], packet->mask);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void StoreEvent_write(uint8_t coreid, uint8_t index, DifftestStoreEvent* packet) {
    query_StoreEvent->write(9, query_step, coreid, index, packet->valid, packet->addr, packet->data, packet->mask, packet->pc, packet->robidx);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

  void L1TLBEvent_write(uint8_t coreid, uint8_t index, DifftestL1TLBEvent* packet) {
    query_L1TLBEvent->write(10, query_step, coreid, index, packet->valid, packet->satp, packet->vpn, packet->ppn, packet->vsatp, packet->hgatp, packet->s2xlate);
  }

};
#endif // CONFIG_DIFFTEST_QUERY
#endif // __DIFFTEST_QUERY_H__

