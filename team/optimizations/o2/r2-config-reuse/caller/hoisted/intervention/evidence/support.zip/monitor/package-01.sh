#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
cd "$root/checkout/source"
test "$(git rev-parse HEAD)" = 1a9dd38e6a2d634aa56c07ba6b2b6f23228208ae
test -z "$(git status --porcelain=v1)"
python3 -B - <<'PY'
from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path('/home/lizufan/riscv-lab/context-intervention-20261026-0000')
repo=root/'checkout/source'
module=repo/'team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention'
monitor=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    assert not p.exists(),p
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
evidence=module/'evidence'
evidence.mkdir(exist_ok=False)
assert not (module/'RESULT.md').exists()
shutil.copyfile(monitor/'delivery-inputs-01/RESULT.md',module/'RESULT.md')
assert sha(module/'RESULT.md')=='4acdc7d9bf1b53607123d2a60fd5205e1b55b278a2bd727ee1772f788eed4333'
qualified=evidence/'qualified-v1';qualified.mkdir()
for name in ('payload.zip','archive-manifest.json','original-audit.json'):
    shutil.copyfile(root/'archive-01'/name,qualified/name)
    assert sha(root/'archive-01'/name)==sha(qualified/name)
manifest=json.loads((qualified/'archive-manifest.json').read_text())
assert manifest['payload_sha256']==sha(qualified/'payload.zip')=='0cb9bf31f29863f0b0485000808ad75b2f44f9c97eaf318e575eefb1fc645686'
for src,dst in (('checks-run-01.json','checks.json'),('archive-audit-01.json','audit-linux.json'),('independent-audit-01.json','audit-isolated.json')):
    shutil.copyfile(root/src,evidence/dst)
    assert sha(root/src)==sha(evidence/dst)
assert (evidence/'audit-linux.json').read_bytes()==(evidence/'audit-isolated.json').read_bytes()
files=[]
for role in ('build-01','build-02'):
    folder=root/role
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink(),path
        if not path.is_file() or '__pycache__' in path.parts:continue
        rel=path.relative_to(folder)
        if rel.parts[0]=='objects' or str(rel)=='vdot-perf.txt':continue
        files.append((role+'/'+rel.as_posix(),path))
logs=('checkout-command.log','checks-source-command-01.log','build-command-01.log',
      'build-command-02.log','checks-build-command-02.log','build-command-03.log',
      'checks-build-command-03.log','run-command-01.log','checks-run-command-01.log',
      'pack-command-01.log','archive-audit-command-01.log','independent-checkout-command.log',
      'independent-audit-command-01.log','source-index-check.json','harness-review-02.txt',
      'checks-source-01.json','checks-build-02.json','checks-build-03.json')
files.extend(('native-support/'+name,root/name) for name in logs)
scripts=('prepare-01.sh','build-01.sh','build-02.sh','pre-run-02.sh','build-03.sh',
         'campaign-01.sh','collect-01.sh','source-commit-01.sh','independent-01.sh','package-01.sh')
files.extend(('monitor/'+name,monitor/name) for name in scripts)
files.extend(('monitor/'+name+'/SHA256SUMS',monitor/name/'SHA256SUMS') for name in ('payload-v1','payload-v2','payload-v3'))
files.append(('receipts/operations.json',monitor/'delivery-inputs-01/operations.json'))
rows=[];payload=evidence/'support.zip'
assert len({name for name,_ in files})==len(files)
with zipfile.ZipFile(payload,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in files:
        assert path.is_file() and not path.is_symlink(),path
        raw=path.read_bytes()
        info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
        info.create_system=3;info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,raw,compresslevel=9)
        digest=hashlib.sha256(raw).hexdigest()
        assert sha(path)==digest
        rows.append(dict(path=name,raw_bytes=len(raw),raw_sha256=digest))
with zipfile.ZipFile(payload) as archive:
    assert archive.namelist()==[row['path'] for row in rows]
    for row in rows:
        raw=archive.read(row['path'])
        assert len(raw)==row['raw_bytes'] and hashlib.sha256(raw).hexdigest()==row['raw_sha256']
save(evidence/'support-manifest.json',dict(format='intervention-support-zip-v1',
    scope='Original unqualified/superseded builds and supporting commands/receipts; not extra runtime qualification',
    files=rows,raw_bytes=sum(row['raw_bytes'] for row in rows),stored_bytes=payload.stat().st_size,
    payload_sha256=sha(payload),original_sources_rechecked=True,decoded_members_checked=True))
save(evidence/'locations.json',dict(
    operation_id='20261026-LiZufan001-context-intervention-0000',
    github_login='LiZufan001',executor='Pro main Agent; two read-only agent reviews',
    base_commit='537cc2ea28e98ede1e72c1d2d7767613de9f6356',
    implementation_commit='1a9dd38e6a2d634aa56c07ba6b2b6f23228208ae',
    specified_source='D:/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022',
    specified_source_head_unchanged='ff58e519091f273c4bc177f5e82cfbbfaf102cc5',
    native_root=str(root),source=str(repo),independent_source=str(root/'independent/source'),
    native_store='/home/lizufan/riscv-lab/r0-native-store-20261025-1541/store',
    native_store_pin='cd4463660686079d365705bfd8f37a86c73161d4',
    windows_monitor='D:/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000',
    windows_transfer='D:/Projects/competitions/2026-10-CIE-RISCV-XiangShan/transfer-context-intervention-20261026-0000.git',
    build=str(root/'build-03'),run=str(root/'run-01'),archive=str(root/'archive-01'),
    build_attempts={'build-01':'ELF target table missing; rejected; no EMU',
                    'build-02':'GNU/path/checks pass; superseded audit binding before first EMU',
                    'build-03':'final source binding; same BIN as build-02; used for all three EMUs'},
    campaign_state=json.loads((root/'run-01/state.json').read_text()),
    campaign_operation='5fd964b57b5d723cbd7734df067a76d3.24e2fe9e195e039b89cf47734bc809f7',
    campaign_shell_exit_code=0,campaign_cleanup_complete=True,
    independent_audit_operation='5fd964b57b5d723cbd7734df067a76d3.fbfffd438177f03c3b703b7d84af83c3',
    independent_audit_exit_code=0,independent_audit_report_sha256=sha(root/'independent-audit-01.json'),
    original_emu_runs=3,post_run_new_emu_runs=0,cpu_budget=4,
    current_task_emu_remaining=False,
    source_files={p.name:sha(p) for p in module.iterdir() if p.is_file() and p.name!='RESULT.md'}))
for path in module.rglob('*'):
    if path.is_file():path.chmod(0o644)
print(json.dumps(dict(primary_files=len(manifest['files']),primary_stored_bytes=manifest['stored_bytes'],
    support_files=len(rows),support_raw_bytes=sum(row['raw_bytes'] for row in rows),
    support_stored_bytes=payload.stat().st_size,support_sha256=sha(payload),
    support_manifest_sha256=sha(evidence/'support-manifest.json'),
    published_files=[p.relative_to(module).as_posix() for p in sorted(module.rglob('*')) if p.is_file()]),indent=2))
PY
git status --porcelain=v1
