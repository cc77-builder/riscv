#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
repo="$root/checkout/source"
entry="$repo/team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention/intervention.py"
cd "$repo"
test ! -e "$root/run-01"
test "$(sha256sum "$root/build-03/vdot-perf.bin" | cut -d' ' -f1)" = 62fd9eab3a5e20883b86ca6f0b44e63149c2ced09349e7dcca8d7a3a2056f470
python3 -B "$entry" --repo "$repo" --action run --build "$root/build-03" --output "$root/run-01" --operation-id 20261026-LiZufan001-context-intervention-0000 >"$root/run-command-01.log" 2>&1
python3 -B "$entry" --repo "$repo" --action checks --build "$root/build-03" --run "$root/run-01" --output "$root/checks-run-01.json" >"$root/checks-run-command-01.log" 2>&1
python3 -B "$entry" --repo "$repo" --action pack --build "$root/build-03" --run "$root/run-01" --output "$root/archive-01" >"$root/pack-command-01.log" 2>&1
python3 -B "$entry" --repo "$repo" --action audit-archive --archive "$root/archive-01" --output "$root/archive-audit-01.json" >"$root/archive-audit-command-01.log" 2>&1
cat "$root/run-01/state.json" "$root/checks-run-01.json" "$root/archive-audit-01.json"
