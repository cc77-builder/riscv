#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
cd "$root/checkout/source"
git status --porcelain=v1
ps -eo pid,ppid,comm,pcpu,etimes --sort=-pcpu | head -n 18
python3 -B - <<'PY'
from pathlib import Path
import json,re,hashlib
root=Path('/home/lizufan/riscv-lab/context-intervention-20261026-0000')
build=root/'build-02'
value=json.loads((build/'elf-validation.json').read_text())
print(json.dumps({key:value[key] for key in ('status','contract','image_sha256','paths','symbols')},indent=2))
log=(build/'disassemble-command/stdout.log').read_text()
pieces=[]
for name in ('main','take','initialize'):
    match=re.search(r'(?m)^[0-9a-f]+ <'+name+r'>:\n.*?(?=\n[0-9a-f]+ <|\Z)',log,re.S)
    assert match, name
    pieces.append(match.group(0))
raw='\n\n'.join(pieces)+'\n'
p=root/'harness-review-02.txt'
assert not p.exists()
p.write_text(raw)
print(raw)
print('harness_review_sha256',hashlib.sha256(raw.encode()).hexdigest())
PY
