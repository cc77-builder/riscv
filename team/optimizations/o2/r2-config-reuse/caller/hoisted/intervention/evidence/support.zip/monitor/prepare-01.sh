#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
store=/home/lizufan/riscv-lab/r0-native-store-20261025-1541/store
prep=/home/lizufan/riscv-lab/r0-native-store-20261025-1541/development/source/team/scripts/prepare-native-source.py
bundle=/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000/current.bundle
test ! -e "$root"
mkdir "$root"
sha256sum "$bundle" "$prep"
python3 -B "$prep" checkout --store "$store" --mode shared --output "$root/checkout" --threads 2 >"$root/checkout-command.log" 2>&1
cd "$root/checkout/source"
git bundle verify "$bundle"
git fetch --no-tags --no-auto-gc --no-write-fetch-head "$bundle" refs/heads/round-source:refs/heads/work/context-intervention-20261026-0000
git switch work/context-intervention-20261026-0000
test "$(git rev-parse HEAD)" = 537cc2ea28e98ede1e72c1d2d7767613de9f6356
git merge-base --is-ancestor cd4463660686079d365705bfd8f37a86c73161d4 HEAD
git rev-parse HEAD 'HEAD^{tree}'
git status --porcelain=v1
cat .git/objects/info/alternates
rg --files team/optimizations/o2/r2-config-reuse/caller/hoisted -g '*.py' -g '*.c' -g '*.h' -g '*.md'
rg --files /home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326 /home/lizufan/riscv-lab/t17-clean-20261024-0854 -g '*identity*.json' -g '*configuration*.json'
