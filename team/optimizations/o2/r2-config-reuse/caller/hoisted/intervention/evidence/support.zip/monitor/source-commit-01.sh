#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
repo="$root/checkout/source"
rel=team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention
cd "$repo"
test "$(git rev-parse HEAD)" = 537cc2ea28e98ede1e72c1d2d7767613de9f6356
test -z "$(git diff --cached --name-only)"
git config --local user.name LiZufan001
git config --local user.email 128899229+LiZufan001@users.noreply.github.com
for name in intervention.py audit.py checks.py main.c CONTRACT.md; do chmod 0644 "$rel/$name"; done
git add -- "$rel/intervention.py" "$rel/audit.py" "$rel/checks.py" "$rel/main.c" "$rel/CONTRACT.md"
git diff --cached --check
python3 -B - <<'PY'
import hashlib,json,subprocess
from pathlib import Path
prefix='team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention/'
want={prefix+n for n in ('intervention.py','audit.py','checks.py','main.c','CONTRACT.md')}
paths=set(subprocess.check_output(['git','diff','--cached','--name-only','-z']).decode().rstrip('\0').split('\0'))
assert paths==want,(paths,want)
rows=[]
for record in subprocess.check_output(['git','ls-files','--stage','-z','--',prefix]).split(b'\0'):
    if not record:continue
    meta,path=record.split(b'\t',1);mode,oid,stage=meta.split()
    name=path.decode();assert name in want and mode==b'100644' and stage==b'0'
    raw=Path(name).read_bytes();blob=subprocess.check_output(['git','cat-file','blob',oid.decode()])
    assert raw==blob
    rows.append(dict(path=name,mode=mode.decode(),blob=oid.decode(),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
out=Path('/home/lizufan/riscv-lab/context-intervention-20261026-0000/source-index-check.json')
assert not out.exists();out.write_text(json.dumps(dict(status='SOURCE_INDEX_EXACT_PASS',files=rows),indent=2)+'\n')
PY
git commit -m "Add bounded single-image predecessor intervention and audits"
git rev-parse HEAD 'HEAD^{tree}'
git -c pack.threads=2 bundle create "$root/candidate-code.bundle" 537cc2ea28e98ede1e72c1d2d7767613de9f6356..HEAD
git bundle verify "$root/candidate-code.bundle"
git status --porcelain=v1
