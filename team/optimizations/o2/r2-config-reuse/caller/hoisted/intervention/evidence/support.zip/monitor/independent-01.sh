#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
store=/home/lizufan/riscv-lab/r0-native-store-20261025-1541/store
prep=/home/lizufan/riscv-lab/r0-native-store-20261025-1541/development/source/team/scripts/prepare-native-source.py
base_bundle=/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000/current.bundle
test ! -e "$root/independent"
python3 -B "$prep" checkout --store "$store" --mode shared --output "$root/independent" --threads 2 >"$root/independent-checkout-command.log" 2>&1
cd "$root/independent/source"
git fetch --no-tags --no-auto-gc --no-write-fetch-head "$base_bundle" refs/heads/round-source:refs/heads/work/intervention-base
git fetch --no-tags --no-auto-gc --no-write-fetch-head "$root/candidate-code.bundle" HEAD:refs/heads/work/intervention-audit
git switch work/intervention-audit
test "$(git rev-parse HEAD)" = 1a9dd38e6a2d634aa56c07ba6b2b6f23228208ae
test -z "$(git status --porcelain=v1)"
python3 -B team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention/intervention.py --repo "$PWD" --action audit-archive --archive "$root/archive-01" --output "$root/independent-audit-01.json" >"$root/independent-audit-command-01.log" 2>&1
cmp "$root/archive-audit-01.json" "$root/independent-audit-01.json"
sha256sum "$root/independent-audit-01.json"
cat .git/objects/info/alternates
git status --porcelain=v1
