#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
repo="$root/checkout/source"
payload=/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000/payload-v1
module="$repo/team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention"
cd "$payload"
sha256sum -c SHA256SUMS
test ! -e "$module"
mkdir "$module"
for name in intervention.py audit.py checks.py main.c CONTRACT.md; do
  cp "$payload/$name" "$module/$name"
done
cd "$module"
sha256sum -c "$payload/SHA256SUMS"
cd "$repo"
test "$(git rev-parse HEAD)" = 537cc2ea28e98ede1e72c1d2d7767613de9f6356
python3 -B - <<'PY'
import json,shutil
from pathlib import Path
p=Path('team/optimizations/o2/repro/evidence/clean-reproduction-v1/reports/identity-02.json')
cfg=json.loads(p.read_text())['configuration']
print(json.dumps({k:cfg[k] for k in ('cross_prefix','am_home','hardware_source','reference','flash')},indent=2))
assert shutil.which(cfg['cross_prefix']+'gcc'), 'fixed configured cross compiler unavailable'
PY
python3 -B "$module/intervention.py" --repo "$repo" --action checks --output "$root/checks-source-01.json" >"$root/checks-source-command-01.log" 2>&1
python3 -B "$module/intervention.py" --repo "$repo" --action build --output "$root/build-01" >"$root/build-command-01.log" 2>&1
python3 -B "$module/intervention.py" --repo "$repo" --action checks --build "$root/build-01" --output "$root/checks-build-01.json" >"$root/checks-build-command-01.log" 2>&1
cat "$root/checks-build-01.json"
