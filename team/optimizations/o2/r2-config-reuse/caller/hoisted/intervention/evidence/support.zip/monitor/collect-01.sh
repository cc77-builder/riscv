#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
repo="$root/checkout/source"
monitor=/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000
python3 -B - <<'PY'
from pathlib import Path
import json,hashlib,shutil,os
root=Path('/home/lizufan/riscv-lab/context-intervention-20261026-0000')
out=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000/results-01')
out.mkdir(exist_ok=False)
validation=json.loads((root/'run-01/runs/recovery/validation.json').read_text())
summary={k:v for k,v in validation.items() if k not in ('targets','frontier_hashes')}
summary['targets']=[{k:v for k,v in row.items() if k not in ('transactions',)} for row in validation['targets']]
summary['transaction_latency_totals']={}
for row in validation['targets']:
    for key,count in row['latency_histogram'].items():
        summary['transaction_latency_totals'][key]=summary['transaction_latency_totals'].get(key,0)+count
reports={
 'validation-summary.json':summary,
 'run-receipts.json':[{k:v for k,v in r.items() if k not in ('files',)} for r in json.loads((root/'run-01/completed-runs.json').read_text())],
 'build-final.json':json.loads((root/'build-03/build.json').read_text()),
}
for name,value in reports.items():
    (out/name).write_text(json.dumps(value,indent=2)+'\n')
for name in ('checks-run-01.json','archive-audit-01.json','harness-review-02.txt'):
    shutil.copyfile(root/name,out/name)
for name in ('archive-manifest.json','original-audit.json'):
    shutil.copyfile(root/'archive-01'/name,out/name)
print(json.dumps({p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.iterdir()},indent=2))
print(json.dumps({'archive':str(root/'archive-01'), 'source':str(root/'checkout/source')},indent=2))
PY
cd "$repo"
git config user.name || true
git config user.email || true
git status --porcelain=v1
ps -C emu -o pid,ppid,etime,pcpu,comm || true
