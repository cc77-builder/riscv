#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
repo="$root/checkout/source"
payload=/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000/payload-v3
module="$repo/team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention"
cd "$payload"
sha256sum -c SHA256SUMS
test "$(sha256sum "$module/audit.py" | cut -d' ' -f1)" = 0a26c33d5c4504dfd12fa6cc5ba18df00a1dbeccdd6806a72c2b684a0b2f750d
cp "$payload/audit.py" "$module/audit.py"
cd "$module"
sha256sum -c "$payload/SHA256SUMS"
cd "$repo"
python3 -B "$module/intervention.py" --repo "$repo" --action build --output "$root/build-03" >"$root/build-command-03.log" 2>&1
cmp "$root/build-02/vdot-perf.bin" "$root/build-03/vdot-perf.bin"
python3 -B "$module/intervention.py" --repo "$repo" --action checks --build "$root/build-03" --output "$root/checks-build-03.json" >"$root/checks-build-command-03.log" 2>&1
cat "$root/checks-build-03.json"
sha256sum "$root/build-03/vdot-perf.elf" "$root/build-03/vdot-perf.bin" "$root/build-03/build.json"
