#!/usr/bin/env bash
set -euo pipefail
root=/home/lizufan/riscv-lab/context-intervention-20261026-0000
repo="$root/checkout/source"
payload=/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-context-intervention-20261026-0000/payload-v2
module="$repo/team/optimizations/o2/r2-config-reuse/caller/hoisted/intervention"
cd "$payload"
sha256sum -c SHA256SUMS
test "$(sha256sum "$module/intervention.py" | cut -d' ' -f1)" = 70b1fe3821b59893c1cd2e318139e92e3f3519d8d209dd589e131748d3bf8d4b
cp "$payload/intervention.py" "$module/intervention.py"
cd "$module"
sha256sum -c "$payload/SHA256SUMS"
cd "$repo"
python3 -B "$module/intervention.py" --repo "$repo" --action build --output "$root/build-02" >"$root/build-command-02.log" 2>&1
python3 -B "$module/intervention.py" --repo "$repo" --action checks --build "$root/build-02" --output "$root/checks-build-02.json" >"$root/checks-build-command-02.log" 2>&1
cat "$root/checks-build-02.json"
riscv64-linux-gnu-objdump -d -M no-aliases --disassemble=main --disassemble=take --disassemble=initialize "$root/build-02/vdot-perf.elf" >"$root/harness-disassembly-02.txt"
