$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import shutil,hashlib,subprocess,sys,os,json,datetime
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326');repo=root/'source'
module=Path('team/optimizations/o2/r2-config-reuse/caller/hoisted')
source=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s3-hoisted-20261025-0326')/module/'checks.py'
target=repo/module/'checks.py'
assert not target.exists()
assert hashlib.sha256(source.read_bytes()).hexdigest()=='d1ee95c80e5e11e0c63a2bd520b41de8f7fb11c0b094b78d76f4fa858f273399'
shutil.copyfile(source,target)
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
records=[]
for action in ('preflight','rejections'):
 argv=[sys.executable,'-B',str(target),action,'--root',str(root),'--output',str(root/(action+'-01.json'))]
 if action=='preflight':argv+=['--historical-build','/home/lizufan/riscv-lab/r2s3-caller-20261024-2025/build-v2-01']
 rec=dict(action=action,argv=argv,started=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (root/(action+'-01.log')).open('w') as log:p=subprocess.run(argv,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_code=p.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(rec)
 (root/'checks-launch-01.json').write_text(json.dumps(dict(checks_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),records=records),indent=2)+'\n')
 print(action,'EXIT',p.returncode,flush=True)
 if p.returncode:
  print((root/(action+'-01.log')).read_text()[-12000:]);sys.exit(p.returncode)
 result=json.loads((root/(action+'-01.json')).read_text())
 print(json.dumps(result),flush=True)
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE
