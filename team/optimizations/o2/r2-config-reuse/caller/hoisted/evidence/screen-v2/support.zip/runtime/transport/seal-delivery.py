"""One-use packaging receipt: run only after the complete screen has stopped.

This file is retained inside support.zip as provenance, not installed as a
second experiment engine. It never starts an EMU or changes original evidence.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import stat
import zipfile


def need(ok, why):
    if not ok:
        raise ValueError(why)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def meta(path):
    need(path.is_file() and not path.is_symlink(), "regular source file required")
    return dict(bytes=path.stat().st_size, sha256=sha(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--module", type=Path, required=True)
    parser.add_argument("--extra", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    root, module, extra, output = (p.resolve() for p in (args.runtime, args.module, args.extra, args.output))
    need(not output.exists() and not args.report.exists(), "new delivery outputs required")
    need(all(p != output and p not in output.parents for p in (root, module, extra)), "delivery must be outside inputs")
    state = read(root / "campaign-01.json")
    need(state["status"] == "COMPLETE" and state["active_command"] is None and state["active_pid"] is None,
         "campaign has not stopped")
    need(all(r["process_started"] and r["exit_code"] == 0 for r in state["commands"]), "incomplete campaign command")
    labels = state["completed"]
    all_labels = ("b4", "h4", "h0", "h1", "h2", "h3")
    first = read(root / "stage1-01.json")
    if first["decision"] == "CONTINUE_RVV_SCREEN":
        need(labels == list(all_labels), "expanded campaign inventory")
        decision = read(root / "selection-01.json")["decision"]
    else:
        need(first["decision"] == "STOP_SCREEN" and labels == ["b4", "h4"], "stopped campaign inventory")
        decision = "STOP_SCREEN"
    need(state["decision"] == decision and state["new_emu_runs"] == 3 * len(labels), "campaign decision/count")
    helpers = {name: sha(module / name) for name in ("screen.py", "checks.py", "SCREEN_CONTRACT.md", "recheck.py")}
    for name, pin in state["pins"].items():
        need(helpers[name] == pin, "frozen screen input changed")
    output.mkdir(parents=True)
    cases = []
    for label in labels:
        run_state = read(root / ("run-" + label + "-01/state.json"))
        need(run_state["status"] == "CALLER_CAMPAIGN_PASS" and run_state["new_emu_runs"] == 3 and
             run_state["active_pid"] is None and run_state["active_result"] is None, "run remains active")
        audit = read(root / ("archive-audit-" + label + "-01.json"))
        need(audit["status"] == "CALLER_ARCHIVE_RAW_AUDIT_PASS" and audit["original_emu_runs"] == 3 and
             audit["new_emu_runs"] == 0, "unverified individual archive")
        source = root / ("archive-" + label + "-01")
        files = ("archive-manifest.json", "original-audit.json", "payload.zip")
        need({p.name for p in source.iterdir()} == set(files), "unexpected archive content")
        manifest = read(source / "archive-manifest.json")
        need(manifest["payload_sha256"] == sha(source / "payload.zip") and
             manifest["stored_bytes"] == (source / "payload.zip").stat().st_size, "archive payload identity")
        target = output / label
        target.mkdir()
        details = {}
        for name in files:
            details[name] = meta(source / name)
            shutil.copyfile(source / name, target / name)
            need(meta(target / name) == details[name], "delivery copy changed bytes")
        cases.append(dict(label=label, path=label, files=details))
    entries, sources = [], {}

    def add(path, relative):
        need(relative not in sources, "duplicate support path")
        details = meta(path)
        sources[relative] = path
        entries.append(dict(path=relative, **details))

    for path in sorted(root.iterdir()):
        if path.is_file():
            need(path.suffix in (".json", ".log", ".py", ".ps1"), "unclassified runtime file")
            add(path, "runtime/" + path.name)
    for path in sorted(extra.rglob("*")):
        need(not path.is_symlink(), "linked extra provenance")
        if path.is_file():
            add(path, "runtime/transport/" + path.relative_to(extra).as_posix())
    for label in all_labels:
        if label in labels:
            continue
        build = root / ("build-" + label + "-01")
        for path in sorted(build.rglob("*")):
            need(not path.is_symlink(), "linked unrun build")
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            relative = path.relative_to(build)
            if relative.parts[0] == "objects" or str(relative) == "vdot-perf.txt":
                continue
            add(path, build.name + "/" + relative.as_posix())
    entries.sort(key=lambda item: item["path"])
    support_manifest = dict(format="hoisted-screen-support-v1", entries=entries)
    with zipfile.ZipFile(output / "support.zip", "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        def write(name, raw):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            archive.writestr(info, raw, compresslevel=9)
        write("manifest.json", (json.dumps(support_manifest, indent=2) + "\n").encode())
        for entry in entries:
            source = sources[entry["path"]]
            need(meta(source) == {k: entry[k] for k in ("bytes", "sha256")}, "source changed while packaging")
            write(entry["path"], source.read_bytes())
    index = dict(format="hoisted-screen-v2-evidence-1", operation_id=state["operation_id"],
                 source_base_commit=read(root / "build-b4-01/build.json")["source_commit"],
                 helpers=helpers, support=dict(path="support.zip", **meta(output / "support.zip")),
                 campaigns=cases, decision=decision, new_emu_runs=state["new_emu_runs"])
    (output / "index.json").write_text(json.dumps(index, indent=2) + "\n")
    report = dict(status="HOISTED_DELIVERY_PACKED", decision=decision, labels=labels,
                  index_sha256=sha(output / "index.json"), support_files=len(entries),
                  support_raw_bytes=sum(item["bytes"] for item in entries),
                  files=[dict(path=p.relative_to(output).as_posix(), **meta(p))
                         for p in sorted(output.rglob("*")) if p.is_file()],
                  original_emu_runs=state["new_emu_runs"], new_emu_runs=0)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
