$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import json,hashlib,subprocess,sys,os,datetime
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326');repo=root/'source'
module=repo/'team/optimizations/o2/r2-config-reuse/caller/hoisted'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pins={"screen.py":"03590ecfd5f75081a7de1c34214fb91e3fa2a0b435cf871454a60a487f41d9bd","SCREEN_CONTRACT.md":"0129a38620aaaf5dd7fd21ff60bc938d9f14b781f7556a57bb25ae38a5b83d18","checks.py":"d1ee95c80e5e11e0c63a2bd520b41de8f7fb11c0b094b78d76f4fa858f273399"}
for name,pin in pins.items():assert sha(module/name)==pin
preflight=read(root/'preflight-01.json');rejections=read(root/'rejections-01.json')
assert preflight['status']=='HOISTED_PREFLIGHT_PASS' and rejections['status']=='HOISTED_BINDING_REJECTIONS_PASS'
assert preflight['checker_sha256']==rejections['checker_sha256']==pins['checks.py']
for label,pin in preflight['build_records'].items():assert sha(root/('build-'+label+'-01/build.json'))==pin
heavy=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:comm=(p/'comm').read_text().strip()
 except OSError:continue
 if comm in ('emu','java','yosys','berkeley-abc','sta','cc1','cc1plus','verilator_bin'):heavy.append([int(p.name),comm])
assert not heavy,heavy
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
state_path=root/'campaign-01.json';assert not state_path.exists()
state=dict(operation_id='20261025-LiZufan001-r2s3-hoisted-0326',status='RUNNING',started=now(),pins=pins,affinity=sorted(os.sched_getaffinity(0)),
           preflight_sha256=sha(root/'preflight-01.json'),rejections_sha256=sha(root/'rejections-01.json'),
           active_command=None,active_pid=None,commands=[],completed=[],new_emu_runs=0)
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
def call(label,action,argv):
 for name,pin in pins.items():assert sha(module/name)==pin
 logpath=root/('launch-'+label+'-'+action+'-01.log');assert not logpath.exists()
 record=dict(label=label,action=action,argv=list(map(str,argv)),started=now(),log=str(logpath),process_started=False)
 state['commands'].append(record);state['active_command']=label+'/'+action;save()
 print('BEGIN',label,action,record['started'],flush=True)
 with logpath.open('w') as log:
  p=subprocess.Popen(list(map(str,argv)),cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  record.update(process_started=True,pid=p.pid);state['active_pid']=p.pid;save()
  code=p.wait()
 record.update(exit_code=code,finished=now(),log_sha256=sha(logpath));state['active_pid']=None;state['active_command']=None;save()
 print('END',label,action,code,record['finished'],flush=True)
 if code:
  print(logpath.read_text()[-12000:],flush=True)
  raise RuntimeError(label+'/'+action+' failed')
def screen(label,action,output,archive=None):
 caller='baseline' if label=='b4' else 'hoisted'
 args=[sys.executable,'-B',module/'screen.py','--caller',caller,'--rvv',label[1],'--repo',repo,'--action',action,'--output',output]
 if action=='audit-archive':args+=['--archive',archive]
 else:args+=['--build',root/('build-'+label+'-01')]
 if action in ('audit','selftest','pack'):args+=['--run',root/('run-'+label+'-01')]
 if action=='run':args+=['--operation-id','20261025-LiZufan001-r2s3-hoisted-0326']
 call(label,action,args)
def run(label):
 screen(label,'run',root/('run-'+label+'-01'))
 screen(label,'audit',root/('audit-'+label+'-01.json'))
 if label in ('b4','h4'):screen(label,'selftest',root/('selftest-'+label+'-01.json'))
 state['completed'].append(label);state['new_emu_runs']=sum(read(root/('run-'+l+'-01/state.json'))['new_emu_runs'] for l in state['completed']);save()
try:
 save()
 run('b4');run('h4')
 call('matrix','stage1',[sys.executable,'-B',module/'checks.py','stage1','--root',root,'--output',root/'stage1-01.json'])
 decision=read(root/'stage1-01.json')['decision'];state['stage1']=decision;save()
 print('STAGE1',json.dumps(read(root/'stage1-01.json')),flush=True)
 if decision=='CONTINUE_RVV_SCREEN':
  for label in ('h0','h1','h2','h3'):run(label)
  call('matrix','selection',[sys.executable,'-B',module/'checks.py','selection','--root',root,'--output',root/'selection-01.json'])
  state['decision']=read(root/'selection-01.json')['decision']
 else:state['decision']='STOP_SCREEN'
 for label in state['completed']:
  archive=root/('archive-'+label+'-01')
  screen(label,'pack',archive)
  screen(label,'audit-archive',root/('archive-audit-'+label+'-01.json'),archive)
 state.update(status='COMPLETE',finished=now());save()
 print(json.dumps(dict(status=state['status'],decision=state['decision'],completed=state['completed'],new_emu_runs=state['new_emu_runs'],finished=state['finished'])),flush=True)
except BaseException as exc:
 state.update(status='FAILED',error=repr(exc),finished=now())
 state['new_emu_runs']=sum(read(p)['new_emu_runs'] for p in root.glob('run-*-01/state.json'));save()
 raise
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE
