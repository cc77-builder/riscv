$ErrorActionPreference='Stop'
$git='D:\Programs\Git\cmd\git.exe'
$old='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\working-r3-reduce-20261025-0202'
$new='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\working-r2s3-hoisted-20261025-0326'
$run='D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\runtime-r2s3-hoisted-20261025-0326'
if((Test-Path -LiteralPath $new) -or (Test-Path -LiteralPath $run)){throw 'hoisted outputs already exist'}
& $git -C $old worktree add -b 'local/r2s3-hoisted-20261025-0326' $new '2329b79610d25d2f242391847ecd5b70e1bbace9'
if($LASTEXITCODE -ne 0){throw 'new worktree failed'}
New-Item -ItemType Directory -Path $run | Out-Null
$bundle=Join-Path $run 'source.bundle'
& $git -C $new -c pack.threads=4 bundle create $bundle HEAD ^6ffe7f94839b08df8de2558c35d482e1b90288e8
if($LASTEXITCODE -ne 0){throw 'new source bundle failed'}
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import subprocess,os,json,datetime
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326')
base=Path('/home/lizufan/riscv-lab/r3-reduce-20261025-0202/baseline')
src=root/'source'
root.mkdir()
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
commands=[]
def call(args):
 with (root/'setup.log').open('a') as log:p=subprocess.run(list(map(str,args)),stdout=log,stderr=log)
 commands.append(dict(argv=list(map(str,args)),exit_code=p.returncode))
 if p.returncode:raise RuntimeError('source preparation failed')
try:
 call(['git','clone','--shared','--no-checkout',base,src])
 call(['git','-C',src,'fetch','/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-r2s3-hoisted-20261025-0326/source.bundle','HEAD'])
 call(['git','-C',src,'checkout','--detach','FETCH_HEAD'])
 head=subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
 assert head=='2329b79610d25d2f242391847ecd5b70e1bbace9'
 assert not subprocess.check_output(['git','-C',src,'status','--porcelain=v1','--untracked-files=normal'],text=True).strip()
 processes=[]
 for d in Path('/proc').iterdir():
  if not d.name.isdigit() or int(d.name)==os.getpid():continue
  try:comm=(d/'comm').read_text().strip()
  except OSError:continue
  if comm in ('emu','java','yosys','berkeley-abc','sta','cc1','cc1plus','verilator_bin'):processes.append(dict(pid=int(d.name),comm=comm))
 assert not processes,processes
 print(json.dumps(dict(status='READY',head=head,source=str(src),heavy_processes=processes)))
finally:
 (root/'setup.json').write_text(json.dumps(dict(commands=commands,finished=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE
