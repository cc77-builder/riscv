$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
root=Path("/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326")
repo=root/'source';module=repo/'team/optimizations/o2/r2-config-reuse/caller/hoisted'
delivery=Path("/home/lizufan/riscv-lab/r2s3-hoisted-delivery-20261025-0405")
windows=Path("/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runtime-r2s3-hoisted-delivery-20261025-0405")
windows_module=Path("/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s3-hoisted-20261025-0326")/'team/optimizations/o2/r2-config-reuse/caller/hoisted'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
campaign=read(root/'campaign-01.json')
assert campaign['status']=='COMPLETE' and campaign['active_command'] is None and campaign['active_pid'] is None
for name,pin in campaign['pins'].items():assert sha(module/name)==pin
heavy=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
 try:comm=(proc/'comm').read_text().strip()
 except OSError:continue
 if comm in ('emu','java','yosys','berkeley-abc','sta','cc1','cc1plus','verilator_bin'):heavy.append([int(proc.name),comm])
assert not heavy,heavy
assert not delivery.exists()
assert (windows/'transport/campaign-receipt.json').is_file()
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
delivery.mkdir()
shutil.copytree(windows/'transport',delivery/'transport')
for p in (windows/'transport').rglob('*'):
 if p.is_file():assert sha(p)==sha(delivery/'transport'/p.relative_to(windows/'transport'))
rechecker=windows_module/'recheck.py'
assert sha(rechecker)=='d4483a8e6e01c59f8fe2e05ba98c7542a9a77861494ff827805ba92499015a77'
assert not (module/'recheck.py').exists()
shutil.copyfile(rechecker,module/'recheck.py')
assert sha(module/'recheck.py')==sha(rechecker)
state=dict(operation_id=campaign['operation_id'],status='RUNNING',started=now(),commands=[],new_emu_runs=0)
state_path=delivery/'delivery-state-01.json'
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
def command(label,argv):
 log=delivery/(label+'-01.log');assert not log.exists()
 rec=dict(label=label,argv=list(map(str,argv)),started=now(),process_started=False)
 state['commands'].append(rec);save()
 print('BEGIN',label,rec['started'],flush=True)
 with log.open('w') as stream:
  p=subprocess.Popen(list(map(str,argv)),cwd=repo,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  rec.update(pid=p.pid,process_started=True);save();code=p.wait()
 rec.update(exit_code=code,finished=now(),log_sha256=sha(log));save()
 print('END',label,code,rec['finished'],flush=True)
 if code:
  print(log.read_text()[-14000:],flush=True)
  raise RuntimeError(label+' failed')
try:
 save()
 command('pack',[sys.executable,'-B',delivery/'transport/seal-delivery.py','--runtime',root,'--module',module,'--extra',delivery/'transport','--output',delivery/'screen-v2','--report',delivery/'pack-01.json'])
 command('matrix-recheck',[sys.executable,'-B',module/'recheck.py','audit',delivery/'screen-v2','--output',delivery/'matrix-recheck-01.json'])
 report=read(delivery/'matrix-recheck-01.json');assert report['status']=='HOISTED_MATRIX_RECHECK_PASS'
 assert report['new_emu_runs']==0 and report['original_emu_runs']==campaign['new_emu_runs']
 assert not (windows/'export').exists()
 export=windows/'export';export.mkdir()
 shutil.copytree(delivery/'screen-v2',export/'screen-v2')
 for name in ('pack-01.json','matrix-recheck-01.json'):
  shutil.copyfile(delivery/name,export/name)
 rows=[]
 for p in sorted((delivery/'screen-v2').rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(delivery);target=export/rel
  assert target.stat().st_size==p.stat().st_size and sha(target)==sha(p)
  rows.append(dict(path=rel.as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
 state.update(status='COMPLETE',finished=now(),decision=campaign['decision'],copied_files=rows,source_pins=campaign['pins'],index_sha256=sha(delivery/'screen-v2/index.json'),recheck_sha256=sha(delivery/'matrix-recheck-01.json'))
 save()
 shutil.copyfile(state_path,export/'delivery-state-01.json')
 print(json.dumps(dict(status=state['status'],decision=state['decision'],index_sha256=state['index_sha256'],recheck_sha256=state['recheck_sha256'],files=len(rows),stored_bytes=sum(r['bytes'] for r in rows),new_emu_runs=0)),flush=True)
except BaseException as exc:
 state.update(status='FAILED',error=repr(exc),finished=now());save();raise

PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE