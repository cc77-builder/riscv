$ErrorActionPreference='Stop'
$cmd=@'
python3 - <<'PY'
from pathlib import Path
import json,hashlib,shutil,subprocess,os,sys,datetime
root=Path('/home/lizufan/riscv-lab/r2s3-hoisted-20261025-0326');repo=root/'source'
module=Path('team/optimizations/o2/r2-config-reuse/caller/hoisted')
win=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s3-hoisted-20261025-0326')
pins={"screen.py":"03590ecfd5f75081a7de1c34214fb91e3fa2a0b435cf871454a60a487f41d9bd","SCREEN_CONTRACT.md":"0129a38620aaaf5dd7fd21ff60bc938d9f14b781f7556a57bb25ae38a5b83d18"}
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
commands=[]
for name,pin in pins.items():
 src=win/module/name;dst=repo/module/name
 assert hashlib.sha256(src.read_bytes()).hexdigest()==pin
 assert not dst.exists()
 shutil.copyfile(src,dst);assert hashlib.sha256(dst.read_bytes()).hexdigest()==pin
for label,caller,choice in [('b4','baseline',4),('h4','hoisted',4),('h0','hoisted',0),('h1','hoisted',1),('h2','hoisted',2),('h3','hoisted',3)]:
 out=root/('build-'+label+'-01')
 argv=[sys.executable,'-B',str(repo/module/'screen.py'),'--caller',caller,'--rvv',str(choice),'--repo',str(repo),'--action','build','--output',str(out)]
 rec=dict(label=label,argv=argv,started=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (root/('build-'+label+'-01.log')).open('w') as log:
  p=subprocess.run(argv,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_code=p.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
 commands.append(rec);(root/'build-launch-01.json').write_text(json.dumps(dict(pins=pins,commands=commands),indent=2)+'\n')
 print(label,'BUILD_EXIT',p.returncode,flush=True)
 if p.returncode:
  print((root/('build-'+label+'-01.log')).read_text()[-12000:]);sys.exit(p.returncode)
 print(json.dumps(json.loads((out/'elf-validation.json').read_text())),flush=True)
PY
'@
& wsl.exe -d Ubuntu-22.04 -- bash -lc $cmd
exit $LASTEXITCODE
