/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/objects/timers.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/timers.S
