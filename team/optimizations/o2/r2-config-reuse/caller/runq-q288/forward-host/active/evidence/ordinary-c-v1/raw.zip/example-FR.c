#include "boundary.h"

static float fp[288], xs[9], y[3][288], ws[3][288 * 9];
static int8_t x[288], packed[3][288 * 288];
static _Alignas(16) struct caller_slot slots[3][8];

void project_qkv(void) {
    struct q288_context projection[3];
    for (unsigned i = 0; i < 3; ++i) {
        projection[i] = (struct q288_context){
            .packed = packed[i], .x = x,
            .weight_scale = ws[i], .input_scale = xs,
            .y = y[i], .slots = slots[i], .entry = 0
        };
    }
    struct qkv_context qkv = {
        .fp = fp, .x = x, .xs = xs,
        .projection = { &projection[0], &projection[1], &projection[2] },
        .kernel = q288_fused_rvv4
    };
    qkv_boundary(&qkv);
}

#include <stddef.h>
_Static_assert(offsetof(struct qkv_context,fp)==0,"assembly field fp");
_Static_assert(offsetof(struct qkv_context,x)==8,"assembly field x");
_Static_assert(offsetof(struct qkv_context,xs)==16,"assembly field xs");
_Static_assert(offsetof(struct qkv_context,projection)==24,"assembly field projection");
_Static_assert(offsetof(struct qkv_context,kernel)==48,"assembly field kernel");
_Static_assert(sizeof(struct q288_context)==56,"projection ABI");
_Static_assert(sizeof(struct caller_slot)==16,"full slot ABI");
