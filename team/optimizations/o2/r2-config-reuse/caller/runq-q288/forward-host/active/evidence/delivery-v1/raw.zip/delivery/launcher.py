"""One-use evidence delivery driver for the closed 20261026 active-consumer round.

It changes supplementary auditors only, then runs bounded independent host jobs.
The 132 measured source files are checked before/after; no EMU is started.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,hashlib,importlib.util,json,os,shutil,subprocess,sys,zipfile,datetime
Q=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288')
PACKAGE_SHA='55dd3cf378a5cdc3d1ee02ae0a9aff5e763dbb5db5e25181c8662c5f28d400b5'
HOST_SHA='0fa2f707274aa90a8e45839966e0caf849a2d80ec370292ffee75020d9239d91'
def need(ok,why):
    if not ok:raise ValueError(why)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def doc(path):return json.loads(path.read_text())

def deliver(repo,root,stage,out):
    need(not out.exists() and all(not out.is_relative_to(p) for p in (repo,root,stage)),'new independent delivery output')
    state=doc(root/'target-campaign-01/state.json')
    need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['new_emu_runs']==3 and
         state['active_pid'] is None and state['active_result'] is None,'actual target campaign already closed')
    for name in ('negative','recovery','replay'):
        r=doc(root/'target-campaign-01/runs'/name/'result.json')
        need(r['process_started'] is True and r['exit_code']==int(name=='negative') and not r.get('timed_out'),
             'completed actual target process '+name)
    live=[]
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            try:argv=(p/'cmdline').read_bytes().split(b'\0')
            except (FileNotFoundError,PermissionError):continue
            if argv and argv[0].endswith(b'/emu'):live.append(int(p.name))
    need(not live,'no competing actual EMU when starting archive jobs')
    build=root/'target-build-03';pins=doc(build/'build.json')['software_files']
    def fixed():need(len(pins)==132 and all(sha(repo/n)==pin for n,pin in pins.items()),'all 132 frozen runtime inputs unchanged')
    fixed()
    status=subprocess.run(['git','status','--porcelain=v1','--untracked-files=no'],cwd=repo,capture_output=True,check=True)
    need(not status.stdout,'no unrelated tracked working-tree edits before installation')
    package=stage/'supplemental-files-06.json';need(sha(package)==PACKAGE_SHA,'exact reviewed supplemental transport')
    incoming=doc(package)['files']
    need(set(incoming)=={'archive.py','target/archive.py','target/timing.py','README.md','.gitattributes'},'exact scoped installation')
    active=repo/Q/'forward-host/active';old=doc(stage/'target-files-05.json')['archive.py'].encode()
    checked=[]
    for name,entry in incoming.items():
        raw=entry['text'].encode();dest=active/name
        need(dest.relative_to(repo).as_posix() not in pins,'supplement is outside the frozen runtime closure: '+name)
        need(len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'transport bytes '+name)
        if name=='target/archive.py':need(dest.read_bytes()==old,'unchanged owned preliminary archive adapter')
        else:need(not dest.exists(),'new scoped file '+name)
        checked.append((dest,raw))
    out.mkdir(parents=True)
    shutil.copyfile(__file__,out/'launcher.py');shutil.copyfile(package,out/package.name)
    (out/'source-before').mkdir();(out/'source-before/target-archive.py').write_bytes(old)
    record=dict(status='INSTALLING_SUPPLEMENTAL',started=now(),source_files=pins,launcher_sha256=sha(__file__),
                package_sha256=PACKAGE_SHA,campaign_state_sha256=sha(root/'target-campaign-01/state.json'),new_emu_runs=0)
    save(out/'delivery-state.json',record)
    try:
        installed=[]
        for dest,raw in checked:
            temporary=dest.with_name(dest.name+'.ppa-1933-install')
            with temporary.open('xb') as f:f.write(raw)
            os.replace(temporary,dest)
            expected=hashlib.sha256(raw).hexdigest();need(sha(dest)==expected,'installed supplemental bytes')
            installed.append(dict(path=dest.relative_to(repo).as_posix(),sha256=expected,bytes=len(raw)))
        fixed();save(out/'installed-supplemental.json',installed)
        host_path=repo/Q/'fused/target/host_audit.py';need(sha(host_path)==HOST_SHA,'unchanged durable host helper')
        spec=importlib.util.spec_from_file_location('active_delivery_durable_host',host_path)
        host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')}
        jobs={}
        def call(name,cpus,script,args,seconds):
            argv=['taskset','-c',cpus,sys.executable,'-I','-B',str(script),*[str(v) for v in args]]
            result=host.durable_child(argv,cwd=out,env=env,seconds=seconds,out=out/'jobs'/name)
            jobs[name]=dict(exit_code=result.returncode,receipt_sha256=sha(out/'jobs'/name/'command.json'))
            need(result.returncode==0,'host job failed; raw receipt retained: '+name)
            print(name+' PASS',flush=True)
            return result
        def parallel(tasks):
            with ThreadPoolExecutor(max_workers=2) as pool:
                pending=[pool.submit(call,*task) for task in tasks]
                errors=[]
                for f in pending:
                    try:f.result()
                    except BaseException as error:errors.append(repr(error))
                need(not errors,'independent host job failures: '+repr(errors))
        record['status']='PACKING';save(out/'delivery-state.json',record)
        parallel([
          ('active-pack','0',active/'archive.py',['--action','pack','--repo',repo,'--run',root,'--output',out/'active-archive-01'],1200),
          ('target-pack','1-3',active/'target/archive.py',['--action','pack','--build',build,'--run',root/'target-campaign-01','--output',out/'target-archive-01'],1800)])
        # Launch the active replay from the two archived files, outside the checkout.
        auditor=out/'active-auditor';auditor.mkdir()
        am=doc(out/'active-archive-01/manifest.json')
        with zipfile.ZipFile(out/'active-archive-01/raw.zip') as z:
            for name,pin in am['auditor_sources'].items():
                raw=z.read('auditor/'+name);need(hashlib.sha256(raw).hexdigest()==pin,'sealed standalone launcher')
                (auditor/name).write_bytes(raw)
        record['status']='ACTIVE_REPLAY_AND_SUPPORT';save(out/'delivery-state.json',record)
        parallel([
          ('active-replay','0',auditor/'archive.py',['--action','replay','--archive',out/'active-archive-01','--output',out/'active-replay-01'],1500),
          ('target-support','1-3',active/'target/archive.py',['--action','support','--support-root',root,'--stage',stage,'--output',out/'target-support-01'],900)])
        # Full source-closure replays are sequential: at most one temporary source workspace.
        record['status']='TARGET_FRESH_SOURCE_AUDIT';save(out/'delivery-state.json',record)
        call('target-fresh-audit','0-3',active/'target/archive.py',
             ['--action','audit-snapshot','--archive',out/'target-archive-01','--output',out/'target-audit-01'],1800)
        record['status']='RETIREMENT_COORDINATES';save(out/'delivery-state.json',record)
        call('target-timing','0',active/'target/timing.py',
             ['--archive',out/'target-archive-01','--qualification',out/'target-audit-01/result.json','--output',out/'target-timing-01'],600)
        fixed()
        need(all(sha(repo/item['path'])==item['sha256'] for item in installed),'all supplemental inputs unchanged')
        need(sha(host_path)==HOST_SHA,'durable host helper unchanged')
        result=dict(status='ACTIVE_CONSUMER_EVIDENCE_DELIVERY_PASS',started=record['started'],finished=now(),
            jobs=jobs,source_files=pins,new_emu_runs=0,temporary_source_workspaces_run_sequentially=True,
            active_replay_status=doc(out/'active-replay-01/result.json')['status'],
            target_replay_status=doc(out/'target-audit-01/result.json')['status'],
            target_timing_status=doc(out/'target-timing-01/result.json')['status'],
            selection=doc(out/'target-audit-01/result.json')['selection'])
        save(out/'result.json',result);record.update(status='PASS',finished=result['finished'],jobs=jobs)
        save(out/'delivery-state.json',record);return result
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error))
        save(out/'delivery-state.json',record);raise

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('repo','run','stage','output'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();os.sched_setaffinity(0,[0,1,2,3])
    r=deliver(a.repo.resolve(),a.run.resolve(),a.stage.resolve(),a.output.resolve())
    print(json.dumps({k:r[k] for k in ('status','started','finished','new_emu_runs')},indent=2))
