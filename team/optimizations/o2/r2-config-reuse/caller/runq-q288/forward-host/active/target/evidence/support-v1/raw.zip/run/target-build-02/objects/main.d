/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/objects/main.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/main.c \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/boundary.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/q288.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/split.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/caller.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/active-consumer-20261026-1933/target-build-02/source/data.h
