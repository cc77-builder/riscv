"""Copy closed active-consumer evidence into new, scoped repository paths.

Original run directories are preserved. Repeated host state bytes are represented
by exact member hashes in the already sealed original archive; command receipts,
fresh compilation outputs and full comparison manifests remain independently saved.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,zipfile

Q=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288')
def need(ok,why):
    if not ok:raise ValueError(why)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def doc(p):return json.loads(Path(p).read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def publish(repo,run,delivery,api,out):
    need(not out.exists() and all(not out.is_relative_to(p) for p in (repo,run,delivery,api)),
         'new publication proof outside every source and evidence input')
    dr=doc(delivery/'result.json');ar=doc(api/'result.json')
    need(dr['status']=='ACTIVE_CONSUMER_EVIDENCE_DELIVERY_PASS','complete actual archive/replay delivery')
    need(ar['status']=='ACTIVE_QKV_DOCUMENTED_C_LINK_PASS','complete actual documented C link proof')
    ds=doc(delivery/'delivery-state.json');aps=doc(api/'state.json')
    need(ds['status']=='PASS' and ds['finished']==dr['finished'] and aps['status']=='PASS'
         and aps['finished']==ar['finished'],'consistent completed delivery and API receipts')
    pins=doc(run/'target-build-03/build.json')['software_files']
    need(len(pins)==132 and dr['source_files']==pins and all(sha(repo/n)==h for n,h in pins.items()),
         'all measured sources unchanged before publication')
    need(all(sha(repo/n)==h for n,h in ar['source_files'].items()),'actual documented C source identities')
    target_audit=doc(delivery/'target-audit-01/result.json')
    timing=doc(delivery/'target-timing-01/result.json')
    host_replay=doc(delivery/'active-replay-01/result.json')
    need(target_audit['status']=='ACTUAL_QKV_TARGET_ARCHIVE_FRESH_SOURCE_AUDIT_PASS'
         and target_audit['selection']==dr['selection'],'current complete target source audit')
    target_manifest_sha=sha(delivery/'target-archive-01/archive-manifest.json')
    need(target_audit['archive_manifest_sha256']==target_manifest_sha
         and timing['archive_manifest_sha256']==target_manifest_sha,'audit and timing refer to the exact published target archive')
    target_manifest=doc(delivery/'target-archive-01/archive-manifest.json')
    history_dir=delivery/'target-archive-01/history';history=doc(history_dir/'manifest.json')
    need(sha(history_dir/'manifest.json')==target_manifest['historical_git']['manifest_sha256']
         and sha(history_dir/'objects.pack')==history['pack_sha256']==target_manifest['historical_git']['pack_sha256']
         and (history_dir/'objects.pack').stat().st_size==history['pack_bytes']
         and sha(history_dir/'commands.json')==history['command_sha256'],'complete original Git provenance transport')
    need(all(sha(repo/n)==h for n,h in target_manifest['adapter_sources'].items()),'current qualified target archive adapters')
    original_audit=doc(delivery/'target-archive-01/original-audit.json')
    need(original_audit['status']=='ACTUAL_QKV_TARGET_RAW_EVIDENCE_AUDIT_PASS'
         and all(target_audit[k]==v for k,v in original_audit.items() if k!='status'),
         'published original audit agrees with its fresh-source recomputation')
    need(timing['status']=='ACTUAL_QKV_RETIREMENT_COORDINATES_PASS' and timing['source_files']==pins
         and timing['qualification_sha256']==sha(delivery/'target-audit-01/result.json'),
         'current qualified retirement coordinate result')
    need(host_replay['status']=='ACTIVE_FORWARD_ARCHIVED_SOURCE_REPLAY_PASS'
         and host_replay['full_state_bytes_identical'] is True,'current complete host replay proof')
    need(all(sha(delivery/'jobs'/name/'command.json')==job['receipt_sha256'] and job['exit_code']==0
             for name,job in dr['jobs'].items()),'current complete delivery job receipts')
    need(doc(run/'target-campaign-01/state.json')['status']=='SPLIT_CAMPAIGN_PASS','target campaign closed')
    active=repo/Q/'forward-host/active'
    need(timing['auditor_sha256']==sha(active/'target/timing.py'),'published timing auditor identity')
    targets=[active/'evidence/active-v1',active/'evidence/ordinary-c-v1',active/'evidence/delivery-v1',
             active/'target/evidence/target-v1',active/'target/evidence/support-v1',active/'target/evidence/timing-v1']
    need(all(not p.exists() for p in targets),'every evidence destination is new')
    for directory,filename in ((delivery/'active-archive-01','manifest.json'),
                               (delivery/'target-archive-01','archive-manifest.json'),
                               (delivery/'target-support-01','manifest.json')):
        m=doc(directory/filename);payload=directory/('payload.zip' if filename=='archive-manifest.json' else 'raw.zip')
        need(sha(payload)==m['payload_sha256'],'current source archive payload '+str(directory))
    out.mkdir(parents=True);shutil.copyfile(__file__,out/'publication.py')
    record=dict(status='COPYING',started=now(),new_emu_runs=0,source_files=pins,
                original_run_root=str(run),delivery_root=str(delivery),api_proof_root=str(api),copied=[])
    save(out/'state.json',record);bundles={}
    def copy(source,dest):
        need(source.is_file() and not source.is_symlink() and not dest.exists(),'new byte-preserving file copy')
        need(source.stat().st_size<95000000,'Git-host-sized evidence member; preserve input if separate transport needed')
        expected=sha(source);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
        need(sha(source)==sha(dest)==expected,'source and destination bytes unchanged')
        record['copied'].append(dict(source=str(source),path=dest.relative_to(repo).as_posix(),
                                     bytes=dest.stat().st_size,sha256=expected))
    def copytree(source,dest):
        need(source.is_dir() and not source.is_symlink(),'existing regular source evidence directory')
        count=0
        for p in sorted(source.rglob('*')):
            need(not p.is_symlink(),'no source evidence symlink')
            if p.is_file() and '__pycache__' not in p.parts:copy(p,dest/p.relative_to(source));count+=1
        need(count>0,'nonempty required evidence directory')
    def seal(label,files,metadata=None):
        directory=out/label;directory.mkdir();rows=[]
        need(len({n for n,_ in files})==len(files),'unique proof archive member names')
        with zipfile.ZipFile(directory/'raw.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for name,p in sorted(files):
                need(p.is_file() and not p.is_symlink(),'regular retained proof file')
                raw=p.read_bytes();info=zipfile.ZipInfo(name,(2026,10,26,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,raw,compresslevel=9)
                rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
        with zipfile.ZipFile(directory/'raw.zip') as z:
            need(len(z.namelist())==len(rows) and set(z.namelist())=={r['path'] for r in rows},'proof archive inventory')
            for row in rows:
                raw=z.read(row['path']);need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],
                                            'proof archive reopened member '+row['path'])
        need(all(sha(p)==r['sha256'] for (_,p),r in zip(sorted(files),rows)),'proof source bytes remained unchanged')
        result=dict(format='active-consumer-proof-zip-v1',files=rows,raw_bytes=sum(r['bytes'] for r in rows),
                    stored_bytes=(directory/'raw.zip').stat().st_size,payload_sha256=sha(directory/'raw.zip'),
                    metadata=metadata or {},new_emu_runs=0)
        save(directory/'manifest.json',result);bundles[label]={k:result[k] for k in ('raw_bytes','stored_bytes','payload_sha256')}
        return directory
    try:
        host_dest=active/'evidence/active-v1'
        copytree(delivery/'active-archive-01',host_dest/'archive')
        # Keep original comparisons directly addressable without changing their bytes.
        for name in ('normal','corrupt-k','corrupt-v'):
            copy(run/'check-03'/name/'result.json',host_dest/'observations'/(name+'.json'))
        copy(run/'check-03/result.json',host_dest/'observations/suite.json')
        copy(run/'check-03/omit-output.stderr.log',host_dest/'observations/omit-output.stderr.log')
        copy(delivery/'active-replay-01/result.json',host_dest/'replay/result.json')
        original=doc(delivery/'active-archive-01/manifest.json')
        need(host_replay['original_payload_sha256']==original['payload_sha256'],
             'fresh replay is bound to this exact sealed original payload')
        members={r['path']:r for r in original['files']};replay=delivery/'active-replay-01';files=[];shared=[];temporary=[]
        with zipfile.ZipFile(delivery/'active-archive-01/raw.zip') as original_zip:
            for p in sorted(replay.rglob('*')):
                need(not p.is_symlink(),'no replay proof symlink')
                if not p.is_file() or '__pycache__' in p.parts:continue
                relative=p.relative_to(replay).as_posix()
                if p.suffix=='.o':
                    temporary.append(dict(path=relative,bytes=p.stat().st_size,sha256=sha(p),
                                          reason='rebuildable compilation intermediate retained at the original delivery path'))
                    continue
                member='check-03/'+relative[len('replay/'):] if relative.startswith('replay/') else ''
                if p.suffix in ('.bin','.elf') and member in members:
                    row=members[member];raw=original_zip.read(member)
                    need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],
                         'shared manifest member matches actual original ZIP bytes')
                    need(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'regenerated state equals original archive member')
                    shared.append(dict(path=relative,original_member=member,bytes=row['bytes'],sha256=row['sha256']))
                else:files.append((relative,p))
        compressed=seal('active-replay-proof',files,dict(original_payload_sha256=original['payload_sha256'],
            shared_original_members=shared,omitted_temporary_objects=temporary,
            full_regenerated_output_retained=str(replay),all_replay_comparisons_preserved=True))
        copytree(compressed,host_dest/'replay/proof')
        target_dest=active/'target/evidence/target-v1'
        copytree(delivery/'target-archive-01',target_dest/'archive')
        copytree(delivery/'target-audit-01',target_dest/'audit')
        for name in ('negative','recovery','replay'):
            copy(run/'target-campaign-01/runs'/name/'result.json',target_dest/'runs'/name/'result.json')
            validation=run/'target-campaign-01/runs'/name/'validation.json'
            if name!='negative':need(validation.is_file(),'required completed normal validation')
            if validation.exists():copy(validation,target_dest/'runs'/name/'validation.json')
        copy(run/'target-campaign-01/state.json',target_dest/'state.json')
        copytree(delivery/'target-support-01',active/'target/evidence/support-v1')
        copytree(delivery/'target-timing-01',active/'target/evidence/timing-v1')
        api_files=[(p.relative_to(api).as_posix(),p) for p in sorted(api.rglob('*'))
                   if p.is_file() and '__pycache__' not in p.parts]
        compressed=seal('ordinary-c-proof',api_files,dict(target_elf_sha256=ar['target_elf_sha256'],
            actual_status=ar['status'],new_runtime_or_performance_qualification=False))
        copytree(compressed,active/'evidence/ordinary-c-v1')
        copy(api/'result.json',active/'evidence/ordinary-c-v1/result.json')
        delivery_files=[('delivery/'+p.name,p) for p in sorted(delivery.iterdir()) if p.is_file()]
        for sub in ('jobs','source-before','receipts'):
            folder=delivery/sub
            if folder.exists():delivery_files.extend(('delivery/'+p.relative_to(delivery).as_posix(),p)
                for p in sorted(folder.rglob('*')) if p.is_file() and '__pycache__' not in p.parts)
        delivery_files.append(('publication.py',out/'publication.py'))
        compressed=seal('delivery-proof',delivery_files,dict(actual_status=dr['status'],
            original_evidence_roots_retained=[str(run),str(delivery)],
            reason='original and failed evidence plus exact compiled/run inputs; temporary source workspaces already retired'))
        copytree(compressed,active/'evidence/delivery-v1')
        need(all(sha(repo/n)==h for n,h in pins.items()),'all measured sources unchanged after publication')
        need(all(sha(repo/n)==h for n,h in ar['source_files'].items()),'documented C inputs unchanged after publication')
        need(all(sha(repo/row['path'])==row['sha256'] for row in record['copied']),'all published byte identities')
        record.update(status='ACTIVE_CONSUMER_EVIDENCE_PUBLICATION_PASS',finished=now(),bundles=bundles,
            copied_files=len(record['copied']),copied_bytes=sum(r['bytes'] for r in record['copied']),
            largest_file=max(record['copied'],key=lambda r:r['bytes']),original_evidence_retained=True)
        # Self-identification is outside the copied-file inventory to avoid a hash cycle.
        destination=active/'evidence/delivery-v1/publication.json'
        need(not destination.exists(),'new publication record')
        encoded=(json.dumps(record,indent=2)+'\n').encode()
        with destination.open('xb') as f:f.write(encoded)
        need(sha(destination)==hashlib.sha256(encoded).hexdigest(),'publication record bytes')
        save(out/'result.json',record)
        save(out/'state.json',{k:v for k,v in record.items() if k!='copied'})
        return record
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error))
        save(out/'state.json',record);save(out/'result.json',record);raise

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('repo','run','delivery','api','output'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();os.sched_setaffinity(0,[0])
    result=publish(a.repo.resolve(),a.run.resolve(),a.delivery.resolve(),a.api.resolve(),a.output.resolve())
    print(json.dumps({k:result[k] for k in ('status','copied_files','copied_bytes','largest_file','bundles')},indent=2))
