"""Compile the exact documented QKV consumer after the measured campaign closes.

One-use delivery proof. Reuse the existing source exporter, ELF reader and call
decoder; do not launch EMU or transfer target cycle qualification to this ELF.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil,sys,datetime,struct

Q=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288')
ELF_SHA='be7412fdc3d9c1f0dac167f6bbc61fac03eed2454f04652cd3ca321d9296d7d6'
HOST_SHA='0fa2f707274aa90a8e45839966e0caf849a2d80ec370292ffee75020d9239d91'
def need(ok,message):
    if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def load(name,p):
    s=importlib.util.spec_from_file_location(name,p)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def relocations(text):
    rows=[]
    for line in text.splitlines():
        fields=line.split()
        if len(fields)>=7 and fields[2].startswith('R_RISCV_'):
            rows.append(dict(offset=int(fields[0],16),kind=fields[2],value=int(fields[3],16),
                             symbol=fields[4],addend=(' '.join(fields[5:]))))
    return rows

def context_kernel_store(code,start,hi_pc,boundary,kernel,signed):
    """Bounded straight-line final basic block, stopping at the boundary call.

    Earlier loop state remains unknown. Only stack-relative addresses and known
    integer constants may prove the final kernel field; unsupported words fail.
    """
    words=[w for w, in struct.iter_unpack('<I',code)];hi=(hi_pc-start)//4
    block=1+max((i for i,w in enumerate(words[:hi]) if w&127 in (0x63,0x67,0x6f)),default=-1)
    for i,w in enumerate(words[:block]):
        op=w&127;pc=start+4*i
        if op==0x63:
            offset=((w>>31)<<12)|(((w>>7)&1)<<11)|(((w>>25)&63)<<5)|(((w>>8)&15)<<1)
            dest=pc+signed(offset,13)
        elif op==0x6f:
            need((w>>7)&31==0,'no earlier function call in the documented caller')
            offset=((w>>31)<<20)|(((w>>12)&255)<<12)|(((w>>20)&1)<<11)|(((w>>21)&1023)<<1)
            dest=pc+signed(offset,21)
        elif op==0x67:raise ValueError('unknown earlier indirect transfer in documented caller')
        else:continue
        need(start<=dest<=start+4*block and dest%4==0,'earlier control cannot skip into the final block')
    # Values are (SP coefficient, offset): absolute=(0,n), frame-relative=(1,n).
    # An unrelated literal equal to a chosen artificial SP cannot alias the frame.
    regs=[None]*32;regs[0]=(0,0);regs[2]=(1,0);memory={};stores=[]
    for i in range(block,len(words)):
        pc=start+4*i;w=words[i];op=w&127;rd=(w>>7)&31;a=(w>>15)&31;b=(w>>20)&31
        f3=(w>>12)&7;imm=signed(w>>20,12);sets=False;value=None
        if op in (0x37,0x17):value=(0,signed(w&0xfffff000,32)+(pc if op==0x17 else 0));sets=True
        elif op==0x13 and f3==0:value=None if regs[a] is None else (regs[a][0],regs[a][1]+imm);sets=True
        elif op==0x33 and f3==0 and w>>25==0:
            value=None if regs[a] is None or regs[b] is None else (regs[a][0]+regs[b][0],regs[a][1]+regs[b][1]);sets=True
            need(value is None or value[0] in (0,1),'only absolute or affine stack values in caller final block')
        elif op==0x23 and f3==3:
            offset=signed(((w>>25)<<5)|((w>>7)&31),12)
            need(regs[a] is not None and regs[a][0]==1,'proven stack-store address in caller final block')
            address=regs[a][1]+offset;value=regs[b]
            need(-4096<=address<=4096-8,'bounded stack store in caller final block')
            stores.append(dict(pc=pc,address=address,value=value))
            for j in range(8):memory[address+j]=(None if value is None or value[0]!=0 else (value[1]>>(8*j))&255,len(stores)-1)
        elif op in (0x67,0x6f):
            if op==0x67:
                need(f3==0 and regs[a] is not None and regs[a][0]==0,'resolved ordinary C indirect call word')
                dest=(regs[a][1]+imm)&~1
            else:
                offset=((w>>31)<<20)|(((w>>12)&255)<<12)|(((w>>20)&1)<<11)|(((w>>21)&1023)<<1)
                dest=pc+signed(offset,21)
            need(rd==1 and dest==boundary,'final block ends at the actual ordinary C boundary call')
            argument=regs[10]
            need(argument is not None and argument[0]==1 and -4096<=argument[1]<=4096-56,
                 'actual C context is proven stack-relative')
            ctx=argument[1];need(ctx%8==0,'naturally aligned context')
            raw=[memory.get(ctx+48+j,(None,None)) for j in range(8)]
            need(all(v is not None for v,_ in raw) and len({writer for _,writer in raw})==1,
                 'kernel field fully written by one final 64-bit store')
            stored=int.from_bytes(bytes(v for v,_ in raw),'little');writer=stores[raw[0][1]]
            need(stored==kernel and writer['address']==ctx+48,'selected kernel stored at actual a0 plus 48')
            return dict(call_pc=pc,context_address_relative_to_frame=ctx,
                        kernel_store_pc=writer['pc'],kernel_field_offset=48,kernel_value=stored,
                        final_basic_block_instructions=i-block+1,earlier_loop_values='unknown and not used to prove the kernel field')
        else:raise ValueError('unsupported word in caller final block '+hex(w))
        if sets and rd:
            if rd==2:need(value is not None and value[0]==1 and -4096<=value[1]<=0 and value[1]%16==0,
                          'bounded aligned caller stack')
            regs[rd]=value
        regs[0]=(0,0)
    raise ValueError('ordinary C boundary call not reached')

def check(repo,build,campaign,out):
    need(not out.exists() and all(not out.is_relative_to(p) for p in (repo,build,campaign)),
         'fresh API proof output outside inputs')
    state=json.loads((campaign/'state.json').read_text())
    need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None and state['new_emu_runs']==3,
         'measured campaign has actually closed')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:args=(p/'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError,PermissionError):continue
        need(not args or not args[0].endswith(b'/emu'),'no competing actual EMU')
    pins=json.loads((build/'build.json').read_text())['software_files']
    need(len(pins)==132 and all(sha(repo/n)==h for n,h in pins.items()),'unchanged measured source closure')
    need(sha(build/'vdot-perf.elf')==ELF_SHA,'qualified final target ELF')
    active=repo/Q/'forward-host/active';phased=repo/Q/'fused/phased';caller=(repo/Q).parent
    host_path=repo/Q/'fused/target/host_audit.py'
    need(sha(host_path)==HOST_SHA,'unchanged durable command helper')
    target=load('active_api_target',active/'target/run.py')
    api=load('active_api_existing_decoder',phased/'c_api_check.py')
    exporter=load('active_api_existing_exporter',phased/'export.py')
    host=load('active_api_durable_host',host_path)
    inputs=[active/'README.md',active/'target/boundary.h',active/'target/boundary.S',
            phased/'export.py',phased/'c_api_check.py',host_path,repo/Q/'q288.h',
            caller/'caller.h',caller/'split/split.h']
    source_pins={p.relative_to(repo).as_posix():sha(p) for p in inputs}
    gcc=shutil.which('riscv64-linux-gnu-gcc');nm=shutil.which('riscv64-linux-gnu-nm')
    readelf=shutil.which('riscv64-linux-gnu-readelf')
    need(gcc and nm and readelf,'native GNU RISC-V compiler and symbol/relocation tools')
    tool_pins={name:dict(path=p,sha256=sha(p)) for name,p in (('gcc',gcc),('nm',nm),('readelf',readelf))}
    out.mkdir(parents=True);shutil.copyfile(__file__,out/'proof.py')
    record=dict(status='STARTED',started=now(),new_emu_runs=0,source_files=source_pins,
                target_elf_sha256=ELF_SHA,toolchain=tool_pins)
    save(out/'state.json',record)
    try:
        for p in inputs:
            d=out/'source'/p.relative_to(repo);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
        text=(active/'README.md').read_text();need(text.count('```c\n')==1,'one exact documented C example')
        example=text.split('```c\n')[1].split('```',1)[0]
        need(example.count('.kernel = q288_tail_vdot')==1,'one explicit documented TA choice')
        layout='\n#include <stddef.h>\n'+''.join(
            f'_Static_assert(offsetof(struct qkv_context,{name})=={offset},"assembly field {name}");\n'
            for name,offset in (('fp',0),('x',8),('xs',16),('projection',24),('kernel',48)))
        layout+='_Static_assert(sizeof(struct q288_context)==56,"projection ABI");\n'
        layout+='_Static_assert(sizeof(struct caller_slot)==16,"full slot ABI");\n'
        exported=exporter.export(repo,out/'export','tail')
        original=target.g.ELF((build/'vdot-perf.elf').read_bytes())
        api.decoder_controls()
        base=[gcc,'-march=rv64gv','-mabi=lp64d','-mcmodel=medany','-mno-relax',
              '-fno-pic','-fno-pie','-fno-lto']
        cflags=['-std=c11','-O2','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin',
                '-fno-tree-vectorize','-fno-tree-slp-vectorize','-fno-fast-math','-ffp-contract=off',
                '-I'+str(active/'target'),'-I'+str(repo/Q),'-I'+str(caller),'-I'+str(caller/'split')]
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')}
        commands=[]
        def command(label,args):
            result=host.durable_child([str(a) for a in args],cwd=out,env=env,seconds=120,out=out/'jobs'/label)
            commands.append(dict(name=label,exit_code=result.returncode,
                                 receipt_sha256=sha(out/'jobs'/label/'command.json')))
            need(result.returncode==0,'GNU command '+label)
            return (out/'jobs'/label/'stdout.log').read_text()
        command('assemble-boundary',base+['-c',active/'target/boundary.S','-o',out/'boundary.o'])
        command('assemble-kernels',base+['-c',out/'export/q288-kernels.S','-o',out/'kernels.o'])
        rows=[]
        for method,kernel in (('TA','q288_tail_vdot'),('FR','q288_fused_rvv4')):
            source=out/('example-'+method+'.c')
            source.write_text(example.replace('.kernel = q288_tail_vdot','.kernel = '+kernel)+layout)
            obj=out/('consumer-'+method+'.o');elf_file=out/('consumer-'+method+'.elf')
            command('compile-'+method,base+cflags+['-c',source,'-o',obj])
            object_relocs=relocations(command('object-relocations-'+method,[readelf,'-Wr',obj]))
            choices=[r for r in object_relocs if r['symbol'] in exported['symbols']]
            need(len(choices)==1 and choices[0]['symbol']==kernel and choices[0]['kind']=='R_RISCV_PCREL_HI20'
                 and choices[0]['addend']=='+ 0','actual C object references precisely the selected kernel')
            command('link-'+method,base+['-static','-no-pie','-nostdlib','-nostartfiles',
                '-Wl,--build-id=none,--no-relax,--emit-relocs,-Ttext=0x80000000,-e,project_qkv',
                obj,out/'boundary.o',out/'kernels.o','-o',elf_file])
            undefined=command('undefined-'+method,[nm,'-u',elf_file]);need(not undefined.strip(),'no unresolved symbol')
            inventory=[line.split()[0] for line in command('defined-'+method,[nm,'--defined-only','-P',elf_file]).splitlines()]
            elf=target.g.ELF(elf_file.read_bytes());functions={}
            for name in [*exported['symbols'],'qkv_quantize','qkv_boundary']:
                need(inventory.count(name)==1,'one actual function definition '+name)
                raw=elf.symbol_data(name)
                need(raw==original.symbol_data(name),'complete qualified function bytes '+name)
                functions[name]=hashlib.sha256(raw).hexdigest()
            start,size=elf.symbols['project_qkv'][:2];calls=api.call_targets(elf,'project_qkv')
            external=[p for p in calls if not start<=p<start+size]
            need(external==[elf.symbols['qkv_boundary'][0]],'ordinary C actual boundary call')
            need(api.call_targets(elf,'qkv_boundary')==[elf.symbols['qkv_quantize'][0]],
                 'actual boundary direct call resolves to quantizer')
            final_relocs=relocations(command('final-relocations-'+method,[readelf,'-Wr',elf_file]))
            selected=[r for r in final_relocs if r['symbol'] in exported['symbols']]
            need(len(selected)==1 and selected[0]['symbol']==kernel and selected[0]['kind']=='R_RISCV_PCREL_HI20'
                 and selected[0]['value']==elf.symbols[kernel][0] and selected[0]['addend']=='+ 0',
                 'linked C relocation identifies exactly the intended kernel')
            hi=selected[0];lo=[r for r in final_relocs if r['kind']=='R_RISCV_PCREL_LO12_I'
                              and r['value']==hi['offset'] and r['addend']=='+ 0']
            need(len(lo)==1 and all(start<=r['offset']<start+size for r in (hi,lo[0])),
                 'one kernel pointer relocation pair inside documented caller')
            code=elf.symbol_data('project_qkv')
            high=struct.unpack_from('<I',code,hi['offset']-start)[0]
            low=struct.unpack_from('<I',code,lo[0]['offset']-start)[0]
            need(high&127==0x17 and low&0x707f==0x13 and (high>>7)&31!=0 and (low>>7)&31!=0 and
                 (high>>7)&31==(low>>15)&31,'actual AUIPC/ADDI kernel pointer materialization')
            pointer=hi['offset']+api.signed(high&0xfffff000,32)+api.signed(low>>20,12)
            need(pointer==elf.symbols[kernel][0],'resolved final machine kernel pointer')
            binding=context_kernel_store(code,start,hi['offset'],elf.symbols['qkv_boundary'][0],pointer,api.signed)
            need(elf.symbols['slots'][0]%16==0 and elf.symbols['slots'][1]==384,'three aligned complete slot arrays')
            rows.append(dict(method=method,explicit_kernel_source=kernel,elf_sha256=sha(elf_file),
                example_sha256=sha(source),actual_boundary_call=external[0],slots_address=elf.symbols['slots'][0],
                object_kernel_relocation=choices[0],final_kernel_relocation=hi,actual_kernel_pointer=pointer,
                actual_context_kernel_store=binding,
                slots_bytes=384,function_sha256=functions,unresolved_symbols=0,duplicate_exports=0))
        need(all(sha(repo/n)==h for n,h in {**pins,**source_pins}.items()),'all input sources unchanged')
        need(all(sha(d['path'])==d['sha256'] for d in tool_pins.values()),'toolchain unchanged')
        result=dict(status='ACTIVE_QKV_DOCUMENTED_C_LINK_PASS',started=record['started'],finished=now(),
                    methods=rows,source_files=source_pins,toolchain=tool_pins,commands=commands,
                    target_elf_sha256=ELF_SHA,measured_runtime_sources_checked=132,
                    new_emu_runs=0,new_target_runtime_qualification=False,new_performance_qualification=False,
                    scope='exact documented C example with only explicit TA/FR source choice and compile-time ABI assertions')
        save(out/'result.json',result);record.update(status='PASS',finished=result['finished']);save(out/'state.json',record)
        return result
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(out/'state.json',record);raise

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('repo','build','campaign','output'):p.add_argument('--'+n,type=Path,required=True)
    a=p.parse_args();os.sched_setaffinity(0,[0])
    result=check(a.repo.resolve(),a.build.resolve(),a.campaign.resolve(),a.output.resolve())
    print(json.dumps({k:result[k] for k in ('status','started','finished','new_emu_runs')},indent=2))
