/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-acc8-20261026-0528/build-01/objects/kernels.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-acc8-20261026-0528/build-01/source/kernels.S
