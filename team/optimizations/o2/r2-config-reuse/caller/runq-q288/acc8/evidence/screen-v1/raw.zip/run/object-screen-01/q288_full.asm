
/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-acc8-20261026-0528/object-screen-01/q288.o:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000084 <q288_full>:
  84:	00853783          	ld	a5,8(a0)
			54: R_RISCV_BRANCH	.L3
			60: R_RISCV_BRANCH	.L6
			6c: R_RISCV_BRANCH	.L8
			7c: R_RISCV_BRANCH	.L2
  88:	f4010113          	addi	sp,sp,-192
  8c:	09313c23          	sd	s3,152(sp)
  90:	09613023          	sd	s6,128(sp)
  94:	00053983          	ld	s3,0(a0)
  98:	01053b03          	ld	s6,16(a0)
  9c:	00f13023          	sd	a5,0(sp)

00000000000000a0 <.LVL14>:
  a0:	01853783          	ld	a5,24(a0)

00000000000000a4 <.LVL15>:
  a4:	0a913423          	sd	s1,168(sp)
  a8:	09413823          	sd	s4,144(sp)
  ac:	09513423          	sd	s5,136(sp)
  b0:	07713c23          	sd	s7,120(sp)
  b4:	07813823          	sd	s8,112(sp)
  b8:	00003bb7          	lui	s7,0x3
  bc:	00001c37          	lui	s8,0x1
  c0:	02853483          	ld	s1,40(a0)
  c4:	03053a83          	ld	s5,48(a0)
  c8:	02053a03          	ld	s4,32(a0)
  cc:	07913423          	sd	s9,104(sp)
  d0:	900c0c13          	addi	s8,s8,-1792 # 900 <.LLST9+0x308>
  d4:	880b8b93          	addi	s7,s7,-1920 # 2880 <.LLST9+0x2288>
  d8:	fffffcb7          	lui	s9,0xfffff
  dc:	0a113c23          	sd	ra,184(sp)
  e0:	0a813823          	sd	s0,176(sp)
  e4:	0b213023          	sd	s2,160(sp)
  e8:	07a13023          	sd	s10,96(sp)
  ec:	05b13c23          	sd	s11,88(sp)
  f0:	04813427          	fsd	fs0,72(sp)
  f4:	04913027          	fsd	fs1,64(sp)
  f8:	03213c27          	fsd	fs2,56(sp)
  fc:	03313827          	fsd	fs3,48(sp)
 100:	03413427          	fsd	fs4,40(sp)
 104:	03513027          	fsd	fs5,32(sp)
 108:	01613c27          	fsd	fs6,24(sp)
 10c:	01713827          	fsd	fs7,16(sp)
 110:	00f13423          	sd	a5,8(sp)

0000000000000114 <.LBB20>:
 114:	018989b3          	add	s3,s3,s8
 118:	017b0bb3          	add	s7,s6,s7
 11c:	700c8c93          	addi	s9,s9,1792 # fffffffffffff700 <.LLST9+0xfffffffffffff108>

0000000000000120 <.L12>:
 120:	f0000bd3          	fmv.w.x	fs7,zero
 124:	00013d83          	ld	s11,0(sp)
 128:	00813d03          	ld	s10,8(sp)
 12c:	217b8b53          	fmv.s	fs6,fs7
 130:	217b8ad3          	fmv.s	fs5,fs7
 134:	217b8a53          	fmv.s	fs4,fs7
 138:	217b89d3          	fmv.s	fs3,fs7
 13c:	217b8953          	fmv.s	fs2,fs7
 140:	217b84d3          	fmv.s	fs1,fs7
 144:	217b8453          	fmv.s	fs0,fs7
 148:	01998933          	add	s2,s3,s9

000000000000014c <.LBB22>:
 14c:	000b0413          	mv	s0,s6

0000000000000150 <.L13>:
 150:	00090513          	mv	a0,s2
 154:	000d8593          	mv	a1,s11
 158:	00048613          	mv	a2,s1
 15c:	000a80e7          	jalr	s5

0000000000000160 <.LVL20>:
 160:	0004ae03          	lw	t3,0(s1)
 164:	0104a303          	lw	t1,16(s1)
 168:	0204a883          	lw	a7,32(s1)
 16c:	0304a803          	lw	a6,48(s1)
 170:	0404a503          	lw	a0,64(s1)
 174:	0504a603          	lw	a2,80(s1)
 178:	0604a683          	lw	a3,96(s1)
 17c:	0704a703          	lw	a4,112(s1)
 180:	0fc42787          	flw	fa5,252(s0)
 184:	00042887          	flw	fa7,0(s0)
 188:	02442807          	flw	fa6,36(s0)
 18c:	04842387          	flw	ft7,72(s0)
 190:	06c42307          	flw	ft6,108(s0)
 194:	09042287          	flw	ft5,144(s0)
 198:	0b442207          	flw	ft4,180(s0)
 19c:	0d842187          	flw	ft3,216(s0)
 1a0:	d00e70d3          	fcvt.s.w	ft1,t3
 1a4:	d0037053          	fcvt.s.w	ft0,t1
 1a8:	d008f553          	fcvt.s.w	fa0,a7
 1ac:	d00875d3          	fcvt.s.w	fa1,a6
 1b0:	d0057653          	fcvt.s.w	fa2,a0
 1b4:	d00676d3          	fcvt.s.w	fa3,a2
 1b8:	d006f753          	fcvt.s.w	fa4,a3
 1bc:	d0077153          	fcvt.s.w	ft2,a4
 1c0:	1110f0d3          	fmul.s	ft1,ft1,fa7
 1c4:	11007053          	fmul.s	ft0,ft0,fa6
 1c8:	10f17153          	fmul.s	ft2,ft2,fa5
 1cc:	10757553          	fmul.s	fa0,fa0,ft7
 1d0:	1065f5d3          	fmul.s	fa1,fa1,ft6
 1d4:	10567653          	fmul.s	fa2,fa2,ft5
 1d8:	1046f6d3          	fmul.s	fa3,fa3,ft4
 1dc:	10377753          	fmul.s	fa4,fa4,ft3
 1e0:	000d2787          	flw	fa5,0(s10)

00000000000001e4 <.LVL21>:
 1e4:	10090913          	addi	s2,s2,256

00000000000001e8 <.LBE23>:
 1e8:	020d8d93          	addi	s11,s11,32

00000000000001ec <.LBB24>:
 1ec:	1017f0d3          	fmul.s	ft1,fa5,ft1

00000000000001f0 <.LVL23>:
 1f0:	1007f053          	fmul.s	ft0,fa5,ft0

00000000000001f4 <.LVL24>:
 1f4:	10a7f553          	fmul.s	fa0,fa5,fa0

00000000000001f8 <.LVL25>:
 1f8:	10b7f5d3          	fmul.s	fa1,fa5,fa1

00000000000001fc <.LVL26>:
 1fc:	10c7f653          	fmul.s	fa2,fa5,fa2

0000000000000200 <.LVL27>:
 200:	10d7f6d3          	fmul.s	fa3,fa5,fa3

0000000000000204 <.LVL28>:
 204:	10e7f753          	fmul.s	fa4,fa5,fa4

0000000000000208 <.LVL29>:
 208:	1027f7d3          	fmul.s	fa5,fa5,ft2

000000000000020c <.LVL30>:
 20c:	00147453          	fadd.s	fs0,fs0,ft1
 210:	0004f4d3          	fadd.s	fs1,fs1,ft0
 214:	00a97953          	fadd.s	fs2,fs2,fa0
 218:	00b9f9d3          	fadd.s	fs3,fs3,fa1
 21c:	00ca7a53          	fadd.s	fs4,fs4,fa2
 220:	00dafad3          	fadd.s	fs5,fs5,fa3
 224:	00eb7b53          	fadd.s	fs6,fs6,fa4
 228:	00fbfbd3          	fadd.s	fs7,fs7,fa5

000000000000022c <.LBE24>:
 22c:	004d0d13          	addi	s10,s10,4

0000000000000230 <.LVL39>:
 230:	00440413          	addi	s0,s0,4
 234:	f1391ee3          	bne	s2,s3,150 <.L13>
			234: R_RISCV_BRANCH	.L13

0000000000000238 <.LBE25>:
 238:	008a2027          	fsw	fs0,0(s4)

000000000000023c <.LVL40>:
 23c:	009a2227          	fsw	fs1,4(s4)
 240:	012a2427          	fsw	fs2,8(s4)
 244:	013a2627          	fsw	fs3,12(s4)
 248:	014a2827          	fsw	fs4,16(s4)
 24c:	015a2a27          	fsw	fs5,20(s4)
 250:	016a2c27          	fsw	fs6,24(s4)
 254:	017a2e27          	fsw	fs7,28(s4)

0000000000000258 <.LBE26>:
 258:	120b0b13          	addi	s6,s6,288
 25c:	018909b3          	add	s3,s2,s8
 260:	020a0a13          	addi	s4,s4,32
 264:	eb6b9ee3          	bne	s7,s6,120 <.L12>
			264: R_RISCV_BRANCH	.L12

0000000000000268 <.LBE27>:
 268:	0b813083          	ld	ra,184(sp)
 26c:	0b013403          	ld	s0,176(sp)
 270:	0a813483          	ld	s1,168(sp)

0000000000000274 <.LVL41>:
 274:	0a013903          	ld	s2,160(sp)

0000000000000278 <.LVL42>:
 278:	09813983          	ld	s3,152(sp)
 27c:	09013a03          	ld	s4,144(sp)
 280:	08813a83          	ld	s5,136(sp)

0000000000000284 <.LVL43>:
 284:	08013b03          	ld	s6,128(sp)
 288:	07813b83          	ld	s7,120(sp)

000000000000028c <.LVL44>:
 28c:	07013c03          	ld	s8,112(sp)
 290:	06813c83          	ld	s9,104(sp)
 294:	06013d03          	ld	s10,96(sp)
 298:	05813d83          	ld	s11,88(sp)
 29c:	04813407          	fld	fs0,72(sp)

00000000000002a0 <.LVL45>:
 2a0:	04013487          	fld	fs1,64(sp)

00000000000002a4 <.LVL46>:
 2a4:	03813907          	fld	fs2,56(sp)

00000000000002a8 <.LVL47>:
 2a8:	03013987          	fld	fs3,48(sp)

00000000000002ac <.LVL48>:
 2ac:	02813a07          	fld	fs4,40(sp)

00000000000002b0 <.LVL49>:
 2b0:	02013a87          	fld	fs5,32(sp)

00000000000002b4 <.LVL50>:
 2b4:	01813b07          	fld	fs6,24(sp)

00000000000002b8 <.LVL51>:
 2b8:	01013b87          	fld	fs7,16(sp)

00000000000002bc <.LVL52>:
 2bc:	0c010113          	addi	sp,sp,192

00000000000002c0 <.LVL53>:
 2c0:	00008067          	ret
