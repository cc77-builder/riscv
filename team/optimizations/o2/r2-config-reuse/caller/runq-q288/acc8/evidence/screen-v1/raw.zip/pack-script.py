import pathlib, json, hashlib, zipfile, shutil, datetime, os
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
root=pathlib.Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
run=root.parents[1]/'runs/runq-q288-acc8-20261026-0528'
baseline=root.parents[1]/'runs/runq-q288-20261026-0219/build-04'
module=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288'
out=module/'acc8/evidence/screen-v1'
def sha(data): return hashlib.sha256(data).hexdigest()
build=json.loads((run/'build-01/build.json').read_text())
for rel,pin in build['software_files'].items():
 assert sha((root/rel).read_bytes())==pin,('source changed',rel)
 assert sha((run/'build-01/source/repo'/rel).read_bytes())==pin,('snapshot changed',rel)
assert sha((baseline/'vdot-perf.elf').read_bytes())=='7f2c3d6de93f979cc252379a8fe2147e0d7ff121b0a38151f4604ee832884f26'
assert len(set(sha(p.read_bytes()) for p in [module/'acc8/q288.c',run/'build-01/source/q288.c',run/'host-01/positive/q288.c']))==1
assert json.loads((run/'comparison-01.json').read_text())['status']=='ACC8_STATIC_SCREEN_PASS'
assert json.loads((run/'host-01/result.json').read_text())['status']=='ACC8_HOST_ORACLE_AND_ROW_MUTANT_PASS'
assert json.loads((run/'elf-01/result.json').read_text())['status']=='ACC8_ACTUAL_ELF_REJECTIONS_PASS'
entries=[]
for p in sorted(run.rglob('*')):
 if '__pycache__' in p.parts:continue
 assert not p.is_symlink(),str(p)
 if p.is_file():entries.append(('run/'+p.relative_to(run).as_posix(),p))
for n in ['vdot-perf.elf','vdot-perf.bin','build.json','elf-validation.json','source/q288.c','source/manifest.json']:
 entries.append(('baseline/'+n,baseline/n))
entries.append(('pack-script.py',pathlib.Path(__file__)))
assert not out.exists(),str(out)
out.mkdir(parents=True)
manifest=[]
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in entries:
  data=p.read_bytes();z.writestr(name,data)
  manifest.append(dict(path=name,bytes=len(data),sha256=sha(data),source=str(p)))
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 assert z.namelist()==[e['path'] for e in manifest]
 for e in manifest:
  data=z.read(e['path']);assert len(data)==e['bytes'] and sha(data)==e['sha256'],e['path']
reports={
 'build.json':'build-01/build.json',
 'host.json':'host-01/result.json',
 'elf-rejections.json':'elf-01/result.json',
 'comparison.json':'comparison-01.json',
 'checks.json':'final-checks-01.json'
}
for dest,src in reports.items():shutil.copyfile(run/src,out/dest)
record=dict(status='ACC8_STATIC_EVIDENCE_BYTE_ARCHIVE_PASS',
 created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 contract=build['contract'],source_commit_at_build=build['source_commit'],
 source_binding='uncommitted candidate bytes and all dependencies pinned by build.json software_files; final containing commit is supplied by Git history',
 run_root=str(run),baseline_build=str(baseline),files=manifest,file_count=len(manifest),
 raw_bytes=sum(e['bytes'] for e in manifest),zip_bytes=(out/'raw.zip').stat().st_size,
 zip_sha256=sha((out/'raw.zip').read_bytes()),zip_all_members_readback_verified=True,
 current_and_snapshot_source_files_verified=len(build['software_files']),
 reports={n:dict(source=s,sha256=sha((out/n).read_bytes())) for n,s in reports.items()},
 candidate_elf_sha256=build['artifacts']['vdot-perf.elf'],candidate_bin_sha256=build['artifacts']['vdot-perf.bin'],
 baseline_elf_sha256=sha((baseline/'vdot-perf.elf').read_bytes()),
 new_emu_runs=0,target_runtime_qualified=False,application_performance_qualified=False,
 archive_validation_scope='byte inventory/hash round-trip only; not a fresh detached semantic audit or runtime qualification')
(out/'manifest.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('files','reports')},ensure_ascii=False))
