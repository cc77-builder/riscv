/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/objects/kernels.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/source/kernels.S
