
#include "q288.h"
#include <math.h>
void host_leaf(const int8_t *a,const int8_t *x,struct caller_slot *s) {
    for(unsigned r=0;r<8;++r) {
        int32_t total=0;
        for(unsigned k=0;k<32;++k) total+=(int32_t)a[r*32+k]*x[k];
        s[r].value=total;
        for(unsigned j=0;j<3;++j) s[r].high[j]=0;
    }
}
uint32_t host_fma_witness(void) {
    volatile uint32_t raw[4]={0x3d000000,0x3d000000,0x3d000001,0x3cfffffe};
    union { uint32_t u;float f; } a,b,c,d,result;
    a.u=raw[0];b.u=raw[1];c.u=raw[2];d.u=raw[3];
    float first=(-1.0f*a.f)*b.f;
    result.f=fmaf(c.f,d.f,first);
    return result.u;
}
