/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-03/objects/main.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-03/source/main.c \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-03/source/q288.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-03/source/split.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-03/source/caller.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-03/source/data.h
