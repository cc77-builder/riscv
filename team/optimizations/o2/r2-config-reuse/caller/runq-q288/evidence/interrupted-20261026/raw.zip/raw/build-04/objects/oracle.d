/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/objects/oracle.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/source/oracle.c \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/source/q288.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/source/split.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-20261026-0219/build-04/source/caller.h
