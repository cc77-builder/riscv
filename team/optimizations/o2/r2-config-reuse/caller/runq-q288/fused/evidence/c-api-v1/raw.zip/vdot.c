#include <stdalign.h>
#include "fused.h"

alignas(16) static int8_t packed[Q288_WEIGHTS];
alignas(16) static struct caller_slot slots[8];

void consumer_load_weights(const int8_t *weight) {
    struct q288_pack_context pack = {weight, packed};
    q288_pack(&pack);
}

void consumer_project(const int8_t *input, const float *weight_scale,
                      const float *input_scale, float *output) {
    struct q288_context q = {
        .packed = packed, .x = input,
        .weight_scale = weight_scale, .input_scale = input_scale,
        .y = output, .slots = slots, .entry = 0
    };
    q288_fused_vdot(&q);
}
