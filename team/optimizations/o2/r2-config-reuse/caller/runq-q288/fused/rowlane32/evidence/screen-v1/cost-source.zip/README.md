# Source-only declared decode-uop projection

Extract this archive into a new scratch directory outside the checkout. Run
`python3 uop_projection.py`; the included frozen sources require only Python 3.10+.
The output overwrites the included uop_projection_result.json deterministically.
It projects the complete source path and fixed T17 declared decode formulas.
It does not execute an ELF or model dispatch, register-file reads, cache or cycles.
Rowlane source SHA matches the separately GNU-built candidate; its 14361 macro
instructions and the retained FR 35670 were independently checked with the
actual-ELF finite model. GS32 is the exact read-only generator snapshot here.
The full results and split counts preserve the original analytical limits.

The MANIFEST.json lists original byte identities of all eight input files;
it does not include itself or this README. Official T17 files are unchanged
read-only evidence at 34bae6d4acceac939f958199dae53c14bc1f6183.
