# Row32 固定参考功能探针 v1

身份：`r2-s3-runq-rowlane32-reference-probe-v1`。这是原有限 ELF 筛选的独立补证，沿用 `r2-s3-runq-rowlane32-screen-v1` 的函数和数值合同；不覆盖或修改冻结的首轮结果。

## 范围与决策

目的只有一项：在现有未修改的 NEMU reference 中，检验完整 FR 和 rowlane32 函数能否从普通调用现场返回，产生原黄金结果，并满足实际 CSR/fflags 条件。该结果不提供香山全核、DiffTest、周期、完整应用或 PPA 资格。

固定八次调用：x0、x1、再次 x0、W/X 全 −128，每组依次运行 FR 和 rowlane32。原 K=M=288、GS32、VLEN128、严格逐组 binary32 顺序不变。两种权重布局分别保存；同一布局的 x0/x1/x0 复用相同 packed 地址。min/min 保留原 W/X 模16为12的字节对齐。Ws/Xs 直接复用原位模式，不合并尺度或重排浮点操作。

## 复用与身份

原 ELF 为 `fdb39f36e351c3907b3184d52233d1ee16c33e94b98b1317046823045a41ed22`。提取完整 FR 592B 与 rowlane32 836B，以 `.incbin` 嵌入新的独立裸机镜像；最后再次从新 ELF 提取并逐字节比较，不复制函数外 padding。

原实际机器字审查确认两函数各只有两条内部条件分支与末尾 ret，无 AUIPC、LUI、JAL、外部调用或代码位置导出的数据地址。上下文的六个指针使用新 ELF 中的数据地址；旧 entry 字段保留未读哨兵。新镜像有自己的 ELF/bin/hash，不能称为原整个 ELF 未改。

启动入口原样复用固定提交 `c981529dc6e493fb7deee8429b9ce05fd197497b` 的 `forward-host/stages/projection/entry.S`，SHA256 `7db6047a7dfea8a4a1cd98ba95b2845c03405d4fc8aee638463e241da6290531`。使用固定 AM 提交 `086a238062fdfb3281b745a537b361983d0154b5` 的原 Makefile/链接脚本和预建 am、klib，`-o am -o klib -j1`；不构建或改写官方库。启动入口只清 TLS；包装显式初始化全部被检查的输出、guard、状态和报告。

fixture 从原已冻结 source-snapshot 中的函数再现，全部 packed bytes 与原筛选记录对应。原 input manifest、GNU build record、numeric result、controls result、wrong-X ELF 都绑定既有 raw.zip 成员 SHA；导入前、构建后均核对。Y 使用原独立 C/Python 一致的288项黄金位模式，slots 使用同一原fixture的末组整数和及高96零。

## 执行与检查

复用现有 `reference-adapter-04/reference-runner`，SHA256 `567ab9b91e7596c6bf682b56baeb42b36334e307fb54657dfe730eb2e1d98b9d`。固定参考库 SHA256 `8af118e5519db7ef6001010a2d547707c5d47630412e80abfc3f343bfef987c9`。不使用 ctypes ABI 偏移、不 TO_REF 写寄存器、不修改或重建 reference，不绕过异常。

现有 runner 接口为 `runner so image out builtin max_calls wall_seconds dump_plan max_idle`。最多一次正常和一次既有 wrong-X 负控，单次最多1,000,000 API步/30秒/idle1；外层总观察上限120秒。按主端2026-11-06 01:39 UTC的资源协调，首次执行改用已释放的CPU0单核；CPU1保留FU、CPU2/3保留paired16，不启动EMU。每次使用新输出目录，保存原始stdout/stderr、终止原因、寄存器/CSR快照、五份RAM dump和实际命令/工具身份。失败不自动重试或覆盖。

正常检查全部Y位模式、八个完整slot、输出guard、全部观测输入/上下文字节、八次正常返回与成熟成功trap；读取实际VL/VTYPE/VSTART/VCSR/FRM/VLENB及fflags。要求返回 `(8,e8/m1/tu/mu,0,7,RNE,16B)`，同一finite输入下 FR 与 rowlane 的累计fflags相同。合法异常标志不要求为零。

负控直接复用已冻结 wrong-X 机器字替换新镜像内的候选函数，其他镜像字节保持。即使 runner GOOD TRAP，仍须由同一个完整RAM比较器拒绝原x0的row输出；FR、guard、输入、CSR和完整调用完成条件仍检查。

这是有限输入的参考功能证据。没有新增完整ABI poison测试、精确访问足迹仪器、NaN/Inf或非RNE覆盖。原有限模型对这些项目已经说明的验证边界继续单独保留。

## 当前草稿状态

此文随未执行源码草稿保存。GNU新镜像、NEMU正常与负控是否成功，只以对应新运行回执和检查结果为准。packing仅用于功能fixture准备，不计为目标机测时，不据此声称任何性能收益。
