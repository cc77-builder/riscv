"""Check existing fixed-runner dumps only. Does not execute any target code."""
from pathlib import Path
import argparse
import hashlib
import json
import struct


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def check(build, run, negative):
    info = json.loads((build/'build.json').read_text())
    need(info['status'] == 'ROWLANE32_FIXED_REFERENCE_IMAGE_BUILT_NOT_EXECUTED' and
         info['contract'] == 'r2-s3-runq-rowlane32-reference-probe-v1', 'fixed built-image identity')
    for name,digest in info['artifacts'].items():
        need(sha((build/name).read_bytes()) == digest, 'frozen build artifact: '+name)
    for name,digest in info['source_pins'].items():
        need(sha((build/'source'/name).read_bytes()) == digest, 'frozen generated source/input: '+name)
    ref = json.loads((run/'reference-result.json').read_text())
    need(ref['reason'] == 'good_trap' and ref['halt_ret'] == 0 and ref['halt_pc'] == info['trap_pc'],
         'actual runner reached the mature success trap')
    report_raw = (run/'report.bin').read_bytes()
    need(len(report_raw) == 64, 'complete report dump')
    report = struct.unpack('<8Q', report_raw)
    need(report == (0x524f574c414e4532,1,8,0,0x444f4e45,0,0,0), 'eight calls returned and wrapper completed')
    need((run/'inputs.bin').read_bytes() == (build/'source/fixture.bin').read_bytes(),
         'all observed packed/input/scale/padding bytes unchanged')
    need((run/'contexts.bin').read_bytes() == (build/'contexts-before.bin').read_bytes(),
         'all context bytes unchanged')
    outputs = (run/'outputs.bin').read_bytes(); state_raw = (run/'states.bin').read_bytes()
    need(len(outputs) == 8*1328 and len(state_raw) == 8*64, 'complete output/state dumps')
    states = list(struct.iter_unpack('<8Q', state_raw)); checks = []
    for i, case in enumerate(info['calls']):
        data = outputs[1328*i:1328*(i+1)]
        need(data[:16] == data[1168:1184] == data[1312:1328] == bytes([0xa5])*16,
             'untouched output/slot guards')
        expected = struct.pack('<288I', *case['golden_bits'])
        slots = bytes.fromhex(case['slots_hex'])
        y_ok = data[16:1168] == expected; slots_ok = data[1184:1312] == slots
        if not negative or case['method'] == 'unchanged_fr':
            need(y_ok, 'complete original independent C/Python Y bits')
            need(slots_ok, 'complete original final slots including high 96 bits')
        vl, vt, vs, vc, frm, flags, vlenb, mstatus = states[i]
        need((vl,vt,vs,vc,frm,vlenb) == (8,0,0,7,0,16), 'actual return vector/RNE contract')
        need(flags & ~31 == 0 and (mstatus >> 13) & 3 and (mstatus >> 9) & 3,
             'bounded observed flags and enabled FS/VS')
        checks.append(dict(case=case['case'], original_index=case['original_index'], method=case['method'],
                           output_sha256=sha(data[16:1168]), slots_sha256=sha(data[1184:1312]),
                           y_matches=y_ok, slots_match=slots_ok, fflags=flags,
                           vl=vl,vtype=vt,vstart=vs,vcsr=vc,frm=frm,vlenb=vlenb,mstatus=mstatus))
    if negative:
        need(not checks[1]['y_matches'] and checks[1]['case'] == 'x0',
             'original wrong-x-byte negative rejected specifically by full Y comparison')
    else:
        need(all(states[i][5] == states[i+1][5] for i in range(0,8,2)),
             'observed FR/row accumulated fflags agree for each identical finite case')
        need(checks[0]['output_sha256'] == checks[4]['output_sha256'] and
             checks[1]['output_sha256'] == checks[5]['output_sha256'], 'actual x0/x1/x0 reuse outputs')
        need(struct.unpack_from('<I',outputs,16)[0] == 0 and
             struct.unpack_from('<I',outputs,1328+16)[0] == 0, 'original strict FMA witness')
    result = dict(status='ROWLANE32_FIXED_NEMU_NEGATIVE_REJECTED' if negative else 'ROWLANE32_FIXED_NEMU_NORMAL_PASS',
                  build_sha256=sha((build/'build.json').read_bytes()), reference_result=ref, cases=checks,
                  observed_inputs_and_contexts_unchanged=True, output_guards_unchanged=True,
                  complete_abi_poison_screen=False, exact_read_write_footprint_instrumented=False,
                  nan_inf_or_non_rne_qualified=False, xiangshan_cycles_measured=False,
                  application_performance_qualified=False)
    path = run/'check.json'; need(not path.exists(), 'fresh checker receipt')
    path.write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', type=Path, required=True)
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--negative', action='store_true')
    a = p.parse_args()
    r = check(a.build.resolve(),a.run.resolve(),a.negative)
    print(json.dumps(dict(status=r['status'],cases=len(r['cases']),
                          fflags=[c['fflags'] for c in r['cases']], cycles_measured=False)))
