"""Fixed rowlane32 reference image; reuse original functions, fixtures and AM.

No NEMU loading or execution. No source/AM/EMU/NEMU rebuild. The caller must
coordinate one CPU before invoking the existing GNU target build.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
LEAF = Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/rowlane32')
ENTRY = LEAF.parent.parent/'forward-host/stages/projection/entry.S'
ELF_SHA = 'fdb39f36e351c3907b3184d52233d1ee16c33e94b98b1317046823045a41ed22'
ENTRY_SHA = '7db6047a7dfea8a4a1cd98ba95b2845c03405d4fc8aee638463e241da6290531'
FUNCTIONS = {
    'q288_fused_rvv4': (592, '66a12c0ec3cb7c0d1cdceadf04e4c658607438d83a2a958892100422343117ab'),
    'q288_rowlane32_i8': (836, 'f74b1a753a731dec5d803c9fca6afb1e1ca293737a85414f974b715d5912ea00'),
}
AM_REV = '086a238062fdfb3281b745a537b361983d0154b5'
ORIGINAL_RECORDS = {
    'input-sha256.json': '6f365e64fb0f408474bb6fecbd48bcfbfca88dfd956ff8db2ef1ad4b3fc6933b',
    'build-result.json': '307e821fde1a3a609de27c894084d9c4a104ab7550980125c1db80f46e074f06',
    'numeric/result.json': '8abb94c150adf4b2103443df7a10276ca847959098afd2d04fd7d182672513a3',
    'elf-controls/result.json': '6a26be3b8a78a3bdc6493843550d28f776f44b1920a749449cc6845eb55b4165',
    'elf-controls/wrong-x-byte.elf': '1c923319a7307cdccf3d20ca31ccb3acffbcc8a8cd6083dda6468b8feb843b8d',
}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def build(repo, original, am, out):
    need(not out.exists() and not out.is_relative_to(repo) and not out.is_relative_to(original)
         and not out.is_relative_to(am), 'fresh isolated output')
    need(sha((original/'rowlane32.elf').read_bytes()) == ELF_SHA, 'original whole ELF')
    snapshot = original/'source-snapshot'
    for name,digest in ORIGINAL_RECORDS.items():
        need(sha((original/name).read_bytes()) == digest, 'original frozen evidence record')
    for name,digest in json.loads((original/'input-sha256.json').read_text()).items():
        need(sha((snapshot/name).read_bytes()) == digest, 'original source snapshot before import')
    sys.path.insert(0, str(snapshot/LEAF))
    import screen as row
    row.verify_inputs(snapshot, original)
    helper, fp, _ = row.helpers(snapshot)
    need(sha((repo/ENTRY).read_bytes()) == ENTRY_SHA, 'unchanged mature entry')
    need(subprocess.check_output(['git','-C',str(am),'rev-parse','HEAD'], text=True).strip() == AM_REV,
         'fixed official AM revision')
    need(not subprocess.check_output(['git','-C',str(am),'status','--porcelain=v1','--untracked-files=no'],
                                    text=True).strip(), 'official AM tracked files unchanged')
    numeric = json.loads((original/'numeric/result.json').read_text())
    need(numeric['status'] == 'ROWLANE32_ACTUAL_ELF_NUMERIC_PASS' and numeric['elf_sha256'] == ELF_SHA,
         'original independent C/Python finite screen record')
    controls = json.loads((original/'elf-controls/result.json').read_text())
    control = next(c for c in controls['controls'] if c['name'] == 'wrong-x-byte')
    mutant_raw = (original/'elf-controls/wrong-x-byte.elf').read_bytes()
    need(sha(mutant_raw) == control['mutated_elf_sha256'], 'original real ELF negative control')
    out.mkdir(parents=True)
    source = out/'source'; source.mkdir()
    commands = []
    command = lambda argv: commands.append(helper.command(argv, out, len(commands)))
    for name in ('main.c', 'Makefile', 'build_probe.py', 'check_probe.py', 'PROBE.md'):
        shutil.copyfile(HERE/name, source/name)
    shutil.copyfile(repo/ENTRY, source/'entry.S')
    base = helper.fixtures(snapshot/row.Q/'generate.py')
    selected = (0, 1, 2, 4)  # x0, x1, x0 reuse, full-signed min/min.
    blob = bytearray(); objects = {}; calls = []; fixture_header = []

    def add(name, raw, offset_mod_16=0):
        if name in objects:
            need(objects[name]['raw'] == raw, 'shared immutable fixture identity')
            return name
        blob.extend(bytes([0x5a])*((-len(blob)) % 16 + offset_mod_16))
        offset = len(blob); blob.extend(raw)
        objects[name] = dict(offset=offset, length=len(raw), raw=raw, sha256=sha(raw))
        fixture_header.append(f'extern const unsigned char {name}[];')
        return name

    raw8 = lambda values: bytes(v & 255 for v in values)
    raw32 = lambda values: struct.pack('<'+'I'*len(values), *values)
    ws = add('probe_ws', raw32(base['weight_scale']))
    for index in selected:
        recorded = numeric['cases'][index]
        fixture = copy.deepcopy(base); dataset = recorded['dataset']
        if index == 4:
            fixture['weight'] = [-128]*82944
            fixture['inputs'][0] = [-128]*288
            fixture['packed'] = [-128]*82944
        align_w, align_x = recorded['byte_alignment']
        prefix = 'minmin' if index == 4 else 'base'
        x = add(f'probe_x_{prefix}_{dataset}', raw8(fixture['inputs'][dataset]), align_x)
        xs = add(f'probe_xs_{dataset}', raw32(fixture['input_scale'][dataset]))
        dots = [sum(fixture['weight'][r*288+k]*fixture['inputs'][dataset][k]
                    for k in range(256,288)) for r in range(280,288)]
        slots = b''.join(struct.pack('<I', v & 0xffffffff)+bytes(12) for v in dots)
        for kind, packed in (('unchanged_fr', fixture['packed']),
                             ('rowlane32_w8', row.generate.pack_q288(fixture['weight']))):
            packed_raw = raw8(packed)
            need(sha(packed_raw) == recorded['methods'][kind]['packed_sha256'], 'original packed input identity')
            w = add(f'probe_w_{prefix}_{kind}', packed_raw, align_w)
            calls.append(dict(case=recorded['case'], original_index=index, method=kind,
                              weight=w, x=x, ws=ws, xs=xs, golden_bits=recorded['golden_bits'],
                              slots_hex=slots.hex(), byte_alignment=recorded['byte_alignment']))
    need(len(calls) == 8, 'fixed eight calls')
    (source/'fixture.bin').write_bytes(blob)
    asm = ['.section .rodata.probe_inputs,"a",@progbits', '.balign 16',
           '.global probe_inputs_begin', 'probe_inputs_begin:', f'.incbin "{source/"fixture.bin"}"',
           '.global probe_inputs_end', 'probe_inputs_end:']
    for name, obj in objects.items():
        asm += [f'.global {name}', f'.set {name},probe_inputs_begin+{obj["offset"]}']
    (source/'fixture.S').write_text('\n'.join(asm)+'\n')
    fixture_header.append('const struct context probe_contexts[PROBE_CALLS] __attribute__((used,aligned(16))) = {')
    for i, c in enumerate(calls):
        fixture_header.append('  {'+f'(const int8_t *){c["weight"]}, (const int8_t *){c["x"]}, '
                              f'(const float *){c["ws"]}, (const float *){c["xs"]}, '
                              f'(float *)probe_outputs[{i}].y, &probe_outputs[{i}].slots[0][0], UINT64_C(0x81234560)'+'},')
    (source/'fixtures.h').write_text('\n'.join(fixture_header+['};','']))
    elf = fp.ELF((original/'rowlane32.elf').read_bytes())
    kernels = []
    for name, (length, digest) in FUNCTIONS.items():
        body = elf.symbol_data(name)
        need(len(body) == length and sha(body) == digest, 'complete original function')
        (source/(name+'.bin')).write_bytes(body)
        kernels += [f'.section .text.{name},"ax",@progbits', '.balign 64', f'.global {name}',
                    f'.type {name},@function', name+':', f'.incbin "{source/(name+".bin")}"', f'.size {name},.-{name}']
    (source/'kernels.S').write_text('\n'.join(kernels)+'\n')
    source_pins = {p.name:sha(p.read_bytes()) for p in source.iterdir() if p.is_file()}
    # Exact Makefile.app link inputs; do not search/build the official tree.
    archives = (am/'am/build/am-riscv64-xs.a', am/'libs/klib/build/klib-riscv64-xs.a')
    external = {str(p):sha(p.read_bytes()) for p in archives}
    for rel in ('Makefile.app','Makefile.compile','Makefile.check','am/arch/riscv64-xs.mk',
                'am/arch/isa/riscv64.mk','am/src/nemu/isa/riscv/boot/loader64.ld','am/src/nemu/ldscript/section.ld'):
        external[str(am/rel)] = sha((am/rel).read_bytes())
    cross = shutil.which('riscv64-linux-gnu-gcc'); make = shutil.which('make')
    need(cross and make, 'existing GNU tools')
    prefix = cross[:-3]
    toolpins = {n:dict(path=p, sha256=sha(Path(p).read_bytes())) for n,p in
                [('gcc',cross),('make',make)]+[(n,prefix+n) for n in ('ld','as','ar','nm','readelf','objdump','objcopy')]}
    clean_keys = ('CFLAGS','CPPFLAGS','CXXFLAGS','ASFLAGS','LDFLAGS','CC_OPT','MAKEFLAGS','MFLAGS',
                  'CC','AS','LD','OBJCOPY','OBJDUMP','ARCH','MARCH','LIBS','PREBUILD')
    clean = ['env',*[v for k in clean_keys for v in ('-u',k)], 'AM_HOME='+str(am),'LINUX_GNU_TOOLCHAIN=1']
    command([*clean,make,'--trace','--output-sync=target','-C',source,'ARCH=riscv64-xs','MARCH=rv64gv',
             'CROSS_COMPILE='+prefix,'PROBE_OBJ_ROOT='+str(out/'objects'),'BINARY='+str(out/'probe'),
             '-o','am','-o','klib','-j1','image'])
    command([prefix+'readelf','-W','-h','-A','-l','-s','-r',out/'probe.elf'])
    command([prefix+'objdump','-drwC',out/'probe.elf'])
    target = fp.ELF((out/'probe.elf').read_bytes()); image = (out/'probe.bin').read_bytes()
    need(struct.unpack_from('<H',target.raw,16)[0] == 2 and struct.unpack_from('<Q',target.raw,24)[0] == 0x80000000,
         'static executable and mature RAM entry')
    phoff = struct.unpack_from('<Q',target.raw,32)[0]
    phsize, phnum = struct.unpack_from('<HH',target.raw,54)
    need(all(struct.unpack_from('<I',target.raw,phoff+i*phsize)[0] not in (2,3) for i in range(phnum)),
         'no dynamic loader or runtime dynamic segment')
    for sec in target.sections:
        if not sec[2] & 2 or not sec[5]: continue
        need(0x80000000 <= sec[3] and sec[3]+sec[5] <= 0x88000000, 'allocated extent in RAM')
        if sec[1] != 8:
            off = sec[3]-0x80000000
            need(image[off:off+sec[5]] == target.raw[sec[4]:sec[4]+sec[5]], 'ELF/image allocated bytes')
        if sec[1] == 4:
            need(all(struct.unpack_from('<Q',target.raw,p+8)[0] & 0xffffffff == 0
                     for p in range(sec[4],sec[4]+sec[5],sec[9])), 'no allocated runtime relocation')
    function_proof = {}
    for name, (length, digest) in FUNCTIONS.items():
        need(target.symbol_data(name) == elf.symbol_data(name), 'relocated complete function bytes unchanged')
        function_proof[name] = dict(bytes=length, sha256=digest, old_address=elf.symbols[name][0],
                                    new_address=target.symbols[name][0])
    input_start = target.symbols['probe_inputs_begin'][0]
    need(target.symbols['probe_inputs_end'][0]-input_start == len(blob), 'complete embedded input extent')
    need(image[input_start-0x80000000:input_start-0x80000000+len(blob)] == blob, 'exact frozen packed/scale/input bytes')
    contexts = target.symbol_data('probe_contexts')
    need(len(contexts) == 8*56, 'complete context array')
    output_start = target.symbols['probe_outputs'][0]
    for i,c in enumerate(calls):
        expected_ptrs = tuple(target.symbols[c[key]][0] for key in ('weight','x','ws','xs'))
        expected = (*expected_ptrs, output_start+1328*i+16, output_start+1328*i+1184, 0x81234560)
        need(struct.unpack_from('<7Q',contexts,56*i) == expected, 'actual linked context pointers')
        need(tuple(p % 16 for p in expected_ptrs[:2]) == tuple(c['byte_alignment']), 'original byte alignment')
    plan = [('inputs.bin',input_start,len(blob))]
    for symbol, name, size in (('probe_contexts','contexts.bin',8*56),('probe_outputs','outputs.bin',8*1328),
                               ('probe_states','states.bin',8*64),('probe_report','report.bin',64)):
        address,length,_ = target.symbols[symbol]; need(length == size, 'fixed report/context extent')
        plan.append((name,address,size))
    (out/'dump-plan.txt').write_text(''.join(f'{name} {address:x} {size}\n' for name,address,size in plan))
    (out/'contexts-before.bin').write_bytes(contexts)
    bad_body = fp.ELF(mutant_raw).symbol_data('q288_rowlane32_i8')
    body_offset = target.symbols['q288_rowlane32_i8'][0]-0x80000000
    bad_image = bytearray(image); bad_image[body_offset:body_offset+len(bad_body)] = bad_body
    need(sum(a != b for a,b in zip(image,bad_image)) == 1, 'same frozen one-byte instruction-word control')
    (out/'bad-wrong-x-byte.bin').write_bytes(bad_image)
    for name,digest in source_pins.items(): need(sha((source/name).read_bytes()) == digest, 'generated input unchanged')
    for name,digest in external.items(): need(sha(Path(name).read_bytes()) == digest, 'official AM/archive unchanged')
    for name,digest in ORIGINAL_RECORDS.items():
        need(sha((original/name).read_bytes()) == digest, 'original frozen evidence unchanged across build')
    for tool in toolpins.values(): need(sha(Path(tool['path']).read_bytes()) == tool['sha256'], 'tool unchanged')
    need(not subprocess.check_output(['git','-C',str(am),'status','--porcelain=v1','--untracked-files=no'],
                                    text=True).strip(), 'official AM tracked files unchanged after link')
    row.verify_inputs(snapshot, original)
    result = dict(contract='r2-s3-runq-rowlane32-reference-probe-v1',
                  status='ROWLANE32_FIXED_REFERENCE_IMAGE_BUILT_NOT_EXECUTED',
                  original_elf_sha256=ELF_SHA, source_pins=source_pins, function_proof=function_proof,
                  am_home=str(am), am_revision=AM_REV, external=external, tools=toolpins, commands=commands,
                  cpu_affinity=sorted(os.sched_getaffinity(0)), calls=calls, dump_plan=plan,
                  fixture_sha256=sha(blob), negative_control=control,
                  fixture_objects={name:{k:v for k,v in obj.items() if k != 'raw'} for name,obj in objects.items()},
                  original_record_pins=ORIGINAL_RECORDS,
                  entry_pc=target.symbols['_start'][0], trap_pc=target.symbols['full_success_trap'][0],
                  artifacts={p.name:sha(p.read_bytes()) for p in out.iterdir() if p.is_file()},
                  reference_runs=0, emu_runs=0, performance_qualified=False)
    save(out/'build.json',result)
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('repo','original','am','output'): p.add_argument('--'+name, type=Path, required=True)
    a = p.parse_args()
    result = build(a.repo.resolve(),a.original.resolve(),a.am.resolve(),a.output.resolve())
    print(json.dumps({k:result[k] for k in ('status','function_proof','reference_runs','emu_runs')}))
