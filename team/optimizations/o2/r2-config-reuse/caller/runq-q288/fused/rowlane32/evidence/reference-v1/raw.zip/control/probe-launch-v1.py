"""One bounded, coordinated rowlane32 check through the existing command helper.

CPU0 released by main at 2026-11-06 01:39 UTC; Issue window required. No retry.
"""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import resource
import signal
import sys
import time

BASE = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
REPO = BASE/'checkout/source'
ROOT = BASE/'runs/rowlane32-20261106-0750'
OUT = ROOT/'reference-probe-01'
STAGE = REPO/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/forward-host/stages'
AM = Path('/home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am')
ADAPTER = BASE/'runs/forward-stages-20261027-0300/reference-adapter-04'
RUNNER = ADAPTER/'reference-runner'
SO = Path('/home/lizufan/riscv-lab/t17-clean-20261024-0854/support-01/nemu/reference/build/riscv64-nemu-interpreter-so')
BUNDLE = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/rowlane32-20261106-0750/probe-draft-v2.json')
PINS = {
    BUNDLE: 'c070032de17bb1188abc8121d7f444a32894313278a490420c4a69eda487ea53',
    RUNNER: '567ab9b91e7596c6bf682b56baeb42b36334e307fb54657dfe730eb2e1d98b9d',
    SO: '8af118e5519db7ef6001010a2d547707c5d47630412e80abfc3f343bfef987c9',
    ADAPTER/'inputs.json': 'afe4d1c3af44301e1ba30b3f63711dab5533b0ef7032edf656eaa781e5d7cade',
    STAGE/'check.py': '0c81b6620b2c417ef73a251899bbe3af0ec4749832dd76ad2631b3e6fbd1386f',
    STAGE/'generate.py': 'cac40ad6f5fc66d5c793683bf54fb3e411f7490c25468bc24c7bfc8be406e1e7',
}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(pins):
    for path,digest in pins.items(): need(sha(path) == digest, 'fixed actual input: '+str(path))


def interrupted(signum, frame):
    raise InterruptedError('signal '+str(signum))


def main():
    begin = time.monotonic()
    need(os.sched_getaffinity(0) == {0}, 'exact coordinated one-core affinity')
    need(sys.dont_write_bytecode, '-B protects frozen input snapshots')
    need(not OUT.exists(), 'fresh output; never replay an unknown operation')
    verify(PINS)
    bundle = json.loads(BUNDLE.read_text())
    need(set(bundle['files']) == {'main.c','Makefile','build_probe.py','check_probe.py','PROBE.md'}, 'fixed source bundle')
    OUT.mkdir()
    source = OUT/'source-inputs'; source.mkdir()
    for name,entry in bundle['files'].items():
        data = entry['text'].encode('utf-8')
        need(len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'], 'source bundle bytes')
        (source/name).write_bytes(data)
    (OUT/'source-bundle.json').write_bytes(BUNDLE.read_bytes())
    helpers = OUT/'existing-command-helper'; helpers.mkdir()
    for name in ('check.py','generate.py'): (helpers/name).write_bytes((STAGE/name).read_bytes())
    spec = importlib.util.spec_from_file_location('rowlane_existing_commands',helpers/'check.py')
    h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
    all_pins = dict(PINS)
    all_pins.update({p:sha(p) for p in source.iterdir()})
    all_pins.update({p:sha(p) for p in helpers.iterdir() if p.is_file()})
    all_pins[Path(__file__).resolve()] = sha(__file__)
    h.save(OUT/'runtime-inputs.json',{str(p):v for p,v in all_pins.items()})
    state = dict(contract='r2-s3-runq-rowlane32-reference-probe-v1', status='STARTED',started=h.now(),
                 cpu_affinity=[0],reference_runs_started=0,reference_runs_completed=0,emu_runs=0,
                 maximum_total_observation_seconds=120,results=[],performance_qualified=False)
    h.save(OUT/'state.json',state)
    for sig in (signal.SIGTERM,signal.SIGINT): signal.signal(sig,interrupted)
    soft,hard = resource.getrlimit(resource.RLIMIT_FSIZE)
    limit = min(64*1024*1024,hard) if hard != resource.RLIM_INFINITY else 64*1024*1024
    resource.setrlimit(resource.RLIMIT_FSIZE,(limit,hard))

    def command(argv,where,label,cap):
        left = 110-(time.monotonic()-begin)
        need(left > 1, 'stop before outer120s deadline')
        return h.command(argv,where,label,timeout=min(cap,left))

    try:
        build = OUT/'build'
        command([sys.executable,'-B',source/'build_probe.py','--repo',REPO,'--original',ROOT/'build-01',
                 '--am',AM,'--output',build],OUT,'build',20)
        record = json.loads((build/'build.json').read_text())
        all_pins[build/'build.json'] = sha(build/'build.json')
        for name,digest in record['artifacts'].items(): all_pins[build/name] = digest
        for name,digest in record['source_pins'].items(): all_pins[build/'source'/name] = digest
        h.save(OUT/'runtime-inputs.json',{str(p):v for p,v in all_pins.items()})
        for label,image,negative in (('normal','probe.bin',False),('wrong-x-byte','bad-wrong-x-byte.bin',True)):
            verify(all_pins)
            run = OUT/label; run.mkdir()
            argv = [RUNNER,SO,build/image,run,'builtin','1000000','30',build/'dump-plan.txt','1']
            state['reference_runs_started'] += 1; state['phase'] = label
            h.save(OUT/'state.json',state)
            command(argv,run,'reference',35)
            checker = [sys.executable,'-B',source/'check_probe.py','--build',build,'--run',run]
            if negative: checker.append('--negative')
            command(checker,run,'compare',3)
            checked = json.loads((run/'check.json').read_text())
            state['results'].append(dict(label=label,status=checked['status'],image_sha256=sha(build/image),
                                         check_sha256=sha(run/'check.json'),reference_result=checked['reference_result'],
                                         fflags=[c['fflags'] for c in checked['cases']]))
            state['reference_runs_completed'] += 1
            verify(all_pins); h.save(OUT/'state.json',state)
        state['status'] = 'ROWLANE32_EXISTING_REFERENCE_PROBE_PASS'
    except BaseException as error:
        state.update(status='FAILED',error=repr(error)); raise
    finally:
        state.update(finished=h.now(),elapsed_seconds=time.monotonic()-begin,
                     changed_inputs=[str(p) for p,v in all_pins.items() if not p.is_file() or sha(p) != v])
        if state['changed_inputs']:
            state.update(status='FAILED',input_identity_error=True)
        h.save(OUT/'state.json',state)
        print(json.dumps(state),flush=True)
    need(not state['changed_inputs'],'all reference/image/helper inputs stayed fixed')


if __name__ == '__main__':
    main()
