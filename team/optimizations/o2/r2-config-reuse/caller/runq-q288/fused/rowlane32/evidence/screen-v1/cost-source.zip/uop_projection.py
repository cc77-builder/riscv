"""Source-path projection through fixed T17 declared decode-uop formulas.

This does not execute an ELF and does not model dispatch/issue/cache/cycles.
VSET's declared count includes the decoder's extra operation, possibly a nop.
"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parent


def load(name, relative):
    path = ROOT / relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def project(source, expected):
    instructions, labels = [], {}
    for line in source.splitlines():
        line = line.split('#')[0].strip()
        if not line:
            continue
        if line.endswith(':'):
            labels[line[:-1]] = len(instructions)
        elif not line.startswith('.'):
            instructions.append(line)
    regs = defaultdict(int)
    registers = lambda s: regs[s] if s != 'zero' else 0
    modes, macro, uops, slices = Counter(), Counter(), Counter(), Counter()
    pc = 0
    vl, sew, lmul = None, None, None
    for _ in range(100000):
        line = instructions[pc]
        fields = re.split(r'[ ,]+', line)
        op, operands = fields[0], fields[1:]
        count = 1
        next_pc = pc + 1
        if op in ('vsetvli', 'vsetivli'):
            vl = int(operands[1]) if op == 'vsetivli' else registers(operands[1])
            sew, lmul = int(operands[2][1:]), int(operands[3][1:])
            assert vl <= 128 * lmul // sew
            count = 2
        elif op in ('vmv.v.v', 'vadd.vv', 'vfcvt.f.x.v', 'vfmul.vv', 'vfadd.vv', 'vsext.vf2'):
            count = lmul
        elif op in ('vmv.v.i', 'vfmul.vf'):
            count = lmul + 1
        elif op == 'vwmul.vv':
            count = 2 * lmul
            slices['vimac_compute'] += 2 * lmul
        elif op == 'vwmacc.vx':
            count = 2 * lmul + 1
            slices['vimac_compute'] += 2 * lmul
            slices['integer_scalar_broadcast'] += 1
        elif op == 'vwredsum.vs':
            count = 2 * lmul
            slices['integer_reduction'] += count
        elif op == 'vslideup.vi':
            count = {1: 1, 2: 3, 4: 10, 8: 36}[lmul] + 1
        elif op in ('vle8.v', 'vse32.v', 'vlse32.v', 'vsse32.v'):
            eew = 8 if op == 'vle8.v' else 32
            emul = max(1, eew * lmul // sew)
            count = emul + (2 if op in ('vlse32.v', 'vsse32.v') else 1)
        elif op == 'vs1r.v':
            count = 2
        elif op == 'li':
            regs[operands[0]] = int(operands[1])
            assert -2048 <= int(operands[1]) <= 2047
        elif op == 'mv':
            regs[operands[0]] = registers(operands[1])
        elif op == 'addi':
            regs[operands[0]] = registers(operands[1]) + int(operands[2])
            assert -2048 <= int(operands[2]) <= 2047
        elif op == 'bnez':
            if registers(operands[0]):
                next_pc = labels[operands[1]]
        elif op in ('ld', 'lb', 'flw', 'csrwi', 'ret'):
            pass
        else:
            raise ValueError('Unmodelled source operation: ' + line)
        macro[op] += 1
        uops[op] += count
        modes[f'{op}:vl{vl}:e{sew}:m{lmul}'] += 1
        if op == 'ret':
            break
        pc = next_pc
    else:
        raise ValueError('Source path budget exceeded')
    assert sum(macro.values()) == expected, (sum(macro.values()), expected)
    return dict(source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                source_path_instructions=sum(macro.values()),
                declared_decode_uops=sum(uops.values()),
                macro_instructions=dict(macro), declared_uops_by_operation=dict(uops),
                mode_counts=dict(modes), functional_slice_counts=dict(slices))


def main():
    fused = load('uop_fused_parent', 'layout_inputs/fused_generate.py')
    gs32 = load('uop_gs32', 'layout_inputs/gs32_generate.py')
    rowlane = load('uop_rowlane', 'rowlane32/generate.py')
    public = (ROOT / 'layout_inputs/public_gemv.S').read_text()
    assert hashlib.sha256(public.encode()).hexdigest() == fused.PUBLIC_SHA
    rows = {
        'fr': project(fused.function(public, 'rvv4'), 35670),
        'gs32_v2': project(gs32.function(fused, public), 20123),
        'rowlane32_w8_v1': project(rowlane.function(), 14361),
    }
    report = dict(identity='rowlane32-T17-declared-uop-source-projection-v1',
        hardware_commit='34bae6d4acceac939f958199dae53c14bc1f6183',
        scope='source path + fixed declared decode formulas; not actual ELF, dispatch, RF counts or cycles',
        warnings=['vset declared operations can include a nop; these are not all executing micro-ops',
                  'no uop bypass/merge/port/cache/timing model',
                  'old FR gathers use e32/m1/VL4, not m2',
                  'different layout and packing costs not represented by these counts'],
        rows=rows,
        source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (ROOT/'layout_inputs/T17_UopInfoGen.scala',ROOT/'layout_inputs/T17_VecDecoder.scala')},
        new_emu_runs=0,performance_qualified=False)
    (ROOT/'uop_projection_result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:{n:v[n] for n in ('source_path_instructions','declared_decode_uops','functional_slice_counts')}
                      for k,v in rows.items()},indent=2))


if __name__ == '__main__':
    main()
