/* Team-owned fixed eight-call reference probe, not an application benchmark. */
#include <stdint.h>
#include <stddef.h>

enum { PROBE_CALLS = 8 };
struct context {
  const int8_t *packed, *x;
  const float *ws, *xs;
  float *y;
  uint32_t *slots;
  uintptr_t unused_entry;
};
struct output {
  uint8_t before_y[16];
  uint32_t y[288];
  uint8_t between[16];
  uint32_t slots[8][4];
  uint8_t after_slots[16];
};
_Static_assert(sizeof(struct context) == 56, "fixed existing context ABI");
_Static_assert(sizeof(struct output) == 1328, "dump layout");
_Static_assert(offsetof(struct output, y) == 16, "Y offset");
_Static_assert(offsetof(struct output, slots) == 1184, "slots offset");

uint8_t team_tls_area[96] __attribute__((aligned(16)));
struct output probe_outputs[PROBE_CALLS] __attribute__((aligned(16)));
volatile uint64_t probe_states[PROBE_CALLS][8] __attribute__((aligned(16)));
volatile uint64_t probe_report[8] __attribute__((aligned(16)));
extern void q288_fused_rvv4(const struct context *);
extern void q288_rowlane32_i8(const struct context *);
#include "fixtures.h"

int team_forward_main(void) {
  /* The reused entry only clears TLS; establish every observed byte here. */
  volatile uint8_t *out = (volatile uint8_t *)probe_outputs;
  for (size_t i = 0; i < sizeof(probe_outputs); ++i) out[i] = 0xa5;
  for (unsigned i = 0; i < PROBE_CALLS; ++i)
    for (unsigned j = 0; j < 8; ++j) probe_states[i][j] = 0;
  for (unsigned j = 0; j < 8; ++j) probe_report[j] = 0;
  probe_report[0] = UINT64_C(0x524f574c414e4532);
  probe_report[1] = 1;
  uint64_t vlenb;
  __asm__ volatile("csrr %0,vlenb" : "=r"(vlenb));
  if (vlenb != 16) { probe_report[3] = vlenb; return 1; }
  for (unsigned i = 0; i < PROBE_CALLS; ++i) {
    __asm__ volatile("csrwi fcsr,0\ncsrwi vstart,3\ncsrwi vcsr,1" ::: "memory");
    if (i & 1) q288_rowlane32_i8(&probe_contexts[i]);
    else q288_fused_rvv4(&probe_contexts[i]);
    uint64_t vl, vt, vs, vc, frm, flags, ms;
    __asm__ volatile("csrr %0,vl\ncsrr %1,vtype\ncsrr %2,vstart\n"
                     "csrr %3,vcsr\ncsrr %4,frm\ncsrr %5,fflags\ncsrr %6,mstatus"
                     : "=r"(vl), "=r"(vt), "=r"(vs), "=r"(vc),
                       "=r"(frm), "=r"(flags), "=r"(ms) :: "memory");
    probe_states[i][0] = vl; probe_states[i][1] = vt;
    probe_states[i][2] = vs; probe_states[i][3] = vc;
    probe_states[i][4] = frm; probe_states[i][5] = flags;
    probe_states[i][6] = vlenb; probe_states[i][7] = ms;
    probe_report[2] = i + 1;
  }
  probe_report[4] = UINT64_C(0x444f4e45);
  return 0;
}
