from pathlib import Path
import base64
import hashlib
import io
import json
import os
import subprocess
import zipfile

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715')
MODULE=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target')
PARENT=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan')
HEAD='1eb68950468e86c5bb396cbeb9ec32d55f4b127f'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1])
    assert git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b''
    pins=json.loads((RUN/'build-02/build.json').read_text())['software_files']
    assert len(pins)==98 and all(sha((ROOT/name).read_bytes())==pin for name,pin in pins.items())
    payload=json.loads((PARENT/'fused-host-audit-delivery-142.json').read_text())
    assert set(payload['files'])=={'host_audit.py','HOST_AUDIT_CONTRACT.md'}
    assert sha((ROOT/MODULE/'archive.py').read_bytes())=='09bfd02664d17d04364876abd5ab8cd3cd17ce5e48d2d3c69f2e64977d9e495d'
    assert sha((ROOT/'team/optimizations/o2/r2-config-reuse/caller/fixed-weight/archive.py').read_bytes())=='2d7f69fc4b99d2f83ee276c7acc24f9a8db16e21b3a0521b7102aecd6cbba578'
    for name,content in payload['files'].items():
        path=ROOT/MODULE/name;assert not path.exists();path.write_text(content)
    attrs=ROOT/MODULE/'.gitattributes';assert not attrs.exists();attrs.write_text('*.zip binary\n*.pack binary\n')
    evidence=ROOT/MODULE/'evidence/host-audit-v1';assert not evidence.exists();evidence.mkdir(parents=True)
    raw=base64.b64decode(payload['controls']);assert sha(raw)==payload['controls_sha256']
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert set(z.namelist())==set(payload['members'])
        for name,v in payload['members'].items():
            b=z.read(name);assert len(b)==v['bytes'] and sha(b)==v['sha256']
    (evidence/'controls.zip').write_bytes(raw);save(evidence/'members.json',payload['members']);save(evidence/'result.json',payload['result'])
    assert payload['result']['adapter_sha256']==sha((ROOT/MODULE/'host_audit.py').read_bytes())
    save(evidence/'transfer.json',dict(status='HOST_RESOURCE_CONTROLS_BYTES_VERIFIED',new_emu_runs=0,
         controls_sha256=payload['controls_sha256'],member_count=len(payload['members']),
         scope='original cloud success/nonzero/timeout controls; no full target audit yet',frozen_sources_unchanged=True))
    assert all(sha((ROOT/name).read_bytes())==pin for name,pin in pins.items())
    git('add','--',str(MODULE))
    names=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1]
    assert all(n.startswith(MODULE.as_posix()+'/') and n not in pins for n in names)
    for name in names:assert git('show',':'+name)==(ROOT/name).read_bytes(),name
    subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
    subprocess.run(['git','commit','-m','Preserve frozen fused audit with durable host budget adapter'],cwd=ROOT,check=True)
    assert git('status','--porcelain')==b''
    result=dict(status='HOST_AUDIT_RESOURCE_ADAPTER_COMMITTED',head=git('rev-parse','HEAD').decode().strip(),
                frozen_sources_unchanged=True,new_emu_runs=0,full_audit_started=False,
                adapter_sha256=sha((ROOT/MODULE/'host_audit.py').read_bytes()))
    save(RUN/'host-audit-delivery-01.json',result);print(json.dumps(result))

if __name__=='__main__':main()
