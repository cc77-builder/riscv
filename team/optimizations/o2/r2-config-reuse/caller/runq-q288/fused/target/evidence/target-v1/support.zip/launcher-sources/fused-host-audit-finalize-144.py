from pathlib import Path
import base64,hashlib,json,os,subprocess
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
run=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715')
module=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target')
parent=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1])
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()=='1eb68950468e86c5bb396cbeb9ec32d55f4b127f'
assert git('diff','--cached','--name-only')==b''
payload=json.loads((parent/'fused-host-audit-delivery-142.json').read_text())
pins=json.loads((run/'build-02/build.json').read_text())['software_files']
assert len(pins)==98 and all(sha((root/n).read_bytes())==s for n,s in pins.items())
names=[str(module/n) for n in payload['files']]+[str(module/'.gitattributes')]+[str(module/'evidence/host-audit-v1'/n) for n in ('controls.zip','members.json','result.json','transfer.json')]
for n,t in payload['files'].items():assert (root/module/n).read_text()==t
assert sha((root/module/'evidence/host-audit-v1/controls.zip').read_bytes())==payload['controls_sha256']
assert (root/module/'.gitattributes').read_bytes()==b'*.zip binary\n*.pack binary\n'
assert all(n not in pins for n in names)
# target/ is ignored globally as a build directory; these seven named team
# source/evidence files extend the already tracked target module deliberately.
git('add','-f','--',*names)
changed=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1]
assert set(changed)==set(names)
for n in names:assert git('show',':'+n)==(root/n).read_bytes(),n
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','Preserve frozen fused audit with durable host budget adapter'],cwd=root,check=True)
assert git('status','--porcelain')==b''
record=dict(status='HOST_AUDIT_RESOURCE_ADAPTER_COMMITTED',head=git('rev-parse','HEAD').decode().strip(),frozen_sources_unchanged=True,new_emu_runs=0,full_audit_started=False,adapter_sha256=sha((root/module/'host_audit.py').read_bytes()),first_add_failure='global target/ build ignore; original ChatPC receipt retained',first_failed_operation='5fd964b57b5d723cbd7734df067a76d3.eb2507224955475516abe1a210038332',explicit_added_files=names)
p=run/'host-audit-delivery-01.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
