from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715')
OLD=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/runq-q288-acc8-target-20261026-0632')
ENGINE=ROOT/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target/run.py'
OPERATION='20261026-LiZufan001-fused-target-v1-0731'

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    old=json.loads((OLD/'campaign-01/state.json').read_text())
    closed=json.loads((OLD/'archive-driver-01.json').read_text())
    assert old['status']=='SPLIT_CAMPAIGN_PASS' and old['active_pid'] is None
    assert closed['status']=='ACC8_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED'
    pins=json.loads((RUN/'build-02/build.json').read_text())['software_files']
    assert len(pins)==98 and all(sha(ROOT/n)==v for n,v in pins.items()), '98 frozen fusion sources'
    assert sha(RUN/'build-02/vdot-perf.elf')=='e45105a5cd57289cfc5e031fc34ab86d799b02ba575438376e3df55662fbc801'
    assert sha(RUN/'build-02/vdot-perf.bin')=='c9783f1f64461cfb76906bf70948ab1e79c416d235d63d254c7a2e7c9af3ffb0'
    processes=[]
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():continue
        try:words=(entry/'cmdline').read_bytes().split(b'\0')
        except (PermissionError,FileNotFoundError,ProcessLookupError):continue
        if words and Path(os.fsdecode(words[0])).name in ('emu','verilator','sbt','java','cc1','riscv64-linux-gnu-gcc'):
            processes.append(dict(pid=int(entry.name),executable=os.fsdecode(words[0])))
    assert not processes, ('existing heavy work',processes)
    report=RUN/'campaign-driver-01.json';assert not report.exists() and not (RUN/'campaign-01').exists()
    argv=[sys.executable,str(ENGINE),'--repo',str(ROOT),'--action','run','--build',str(RUN/'build-02'),
          '--output',str(RUN/'campaign-01'),'--operation-id',OPERATION]
    record=dict(status='RUNNING',started=now(),command=argv,operation_id=OPERATION,
                coordination_comment=6404919111,source_commit='151481e916bfed0fc23b0223ee04b2085d18e25e',
                current_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                software_files=98,cpu_affinity=sorted(os.sched_getaffinity(0)),parallel_emu_limit=1,
                previous_campaign_closed=old['status'],previous_archive_closed=closed['status'])
    save(report,record)
    with (RUN/'campaign-driver-01.stdout.log').open('xb') as stdout,(RUN/'campaign-driver-01.stderr.log').open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
        record['pid']=child.pid;save(report,record);code=child.wait()
    record.update(exit_code=code,finished=now(),status='PASS' if code==0 else 'FAILED',
                  stdout_sha256=sha(RUN/'campaign-driver-01.stdout.log'),stderr_sha256=sha(RUN/'campaign-driver-01.stderr.log'),
                  frozen_sources_unchanged=all(sha(ROOT/n)==v for n,v in pins.items()))
    state_path=RUN/'campaign-01/state.json'
    if state_path.exists():record['campaign_state']=json.loads(state_path.read_text())
    save(report,record);print(json.dumps(record))
    assert code==0 and record['frozen_sources_unchanged'],'fusion campaign failed; inspect state and raw evidence'

if __name__=='__main__':main()
