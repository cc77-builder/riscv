/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715/build-01/objects/q288.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715/build-01/source/q288.c \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715/build-01/source/q288.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715/build-01/source/split.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715/build-01/source/caller.h
