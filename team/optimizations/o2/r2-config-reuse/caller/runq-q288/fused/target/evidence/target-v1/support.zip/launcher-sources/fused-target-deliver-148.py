from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715')
PARENT=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan')
MODULE=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,v):path.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def read(path):return json.loads(path.read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def local(t):return datetime.datetime.fromisoformat(t).astimezone(datetime.timezone(datetime.timedelta(hours=8)))

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    assert git('status','--porcelain')==b''
    closure=read(RUN/'archive-driver-01.json');state=read(RUN/'campaign-01/state.json')
    assert closure['status']=='FUSED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED'
    assert state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None
    pins=read(RUN/'build-02/build.json')['software_files']
    assert len(pins)==98 and all(sha(ROOT/name)==pin for name,pin in pins.items())
    oldhead=git('rev-parse','HEAD').decode().strip()
    evidence=ROOT/MODULE/'evidence/target-v1';assert not evidence.exists()
    reportpath=ROOT/MODULE/'RESULT.md';assert not reportpath.exists()
    assert (ROOT/MODULE/'.gitattributes').read_bytes()==b'*.zip binary\n*.pack binary\n'
    archive=RUN/'evidence-pack-01';manifest=read(archive/'archive-manifest.json')
    history=read(archive/'history/manifest.json')
    assert sha(archive/'payload.zip')==manifest['payload_sha256'] and (archive/'payload.zip').stat().st_size==manifest['stored_bytes']
    assert manifest['historical_git']['manifest_sha256']==sha(archive/'history/manifest.json')
    assert manifest['historical_git']['pack_sha256']==history['pack_sha256']==sha(archive/'history/objects.pack')
    assert history['pack_bytes']==(archive/'history/objects.pack').stat().st_size
    assert history['command_sha256']==sha(archive/'history/commands.json')
    original=read(archive/'original-audit.json');audit=read(RUN/'host-audit-01/fresh-source-audit/result.json')
    assert original['status']=='FUSED_TARGET_RAW_EVIDENCE_AUDIT_PASS'
    assert audit['status']=='FUSED_TARGET_ARCHIVE_FRESH_SOURCE_AUDIT_PASS'
    rr=RUN/'campaign-01/runs/recovery';rp=RUN/'campaign-01/runs/replay'
    assert (rr/'validation.json').read_bytes()==(rp/'validation.json').read_bytes()
    assert sha(rr/'validation.json')=='357fe838e7bcccbfcaaab4340cbff48f39dee731142d300ee1c21a831564e4cb'
    value=read(rr/'validation.json');assert value['selection']['decision']=='VDOT_PREFERRED_IN_FIXED_PLAN'
    assert [m['cycles'] for m in value['selection']['methods']]==[[82314,82270],[90567,90629],[88453,88456,88420,88396],[62691,62692],[67298,67311]]
    for path in (rr,rp):
        stdout=(path/'stdout.log').read_text()
        assert re.search(r'Guest cycle spent: 2410050\b',stdout) and re.search(r'instrCnt = 1682220\b',stdout)
    shutil.copytree(archive,evidence/'archive')
    shutil.copytree(RUN/'host-audit-01',evidence/'audit-host')
    support={}
    for directory in ('build-01','elf-controls-02'):
        base=RUN/directory;assert base.is_dir()
        for p in sorted(base.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:support[p.relative_to(RUN).as_posix()]=p
    for p in sorted(RUN.iterdir()):
        if p.is_file():support['drivers/'+p.name]=p
    for name in ('fused-target-campaign-115.py','fused-target-audit-146.py',
                 'fused-host-audit-deliver-142.py','fused-host-audit-finalize-144.py',
                 'fused-host-audit-delivery-first-error-146.json','fused-target-deliver-148.py'):
        p=PARENT/name;assert p.is_file();support['launcher-sources/'+name]=p
    members={}
    with zipfile.ZipFile(evidence/'support.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in support.items():
            b=p.read_bytes();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.create_system=3
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,b,compresslevel=6);members[name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    with zipfile.ZipFile(evidence/'support.zip') as z:
        assert set(z.namelist())==set(members)
        for name,pin in members.items():
            b=z.read(name);assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256']
    save(evidence/'support-members.json',members)
    stderr=[]
    for label,path in (('recovery',rr),('replay',rp)):
        stderr.append(dict(name=label,bytes=(path/'stderr.log').stat().st_size,sha256=sha(path/'stderr.log')))
    if stderr[0]['bytes']==stderr[1]['bytes'] and stderr[0]['sha256']==stderr[1]['sha256']:
        detail=f"stderr 每份 {stderr[0]['bytes']:,} 字节、SHA `{stderr[0]['sha256']}`，两份原字节相同。"
    else:detail='stderr 的原始长度/SHA 分别保留在 summary.json；没有要求或声称 stderr 全字节相同。'
    tokens={'REPLAY_FINISH':local(read(rp/'result.json')['finished']).strftime('%H:%M:%S.%f'),
            'CAMPAIGN_FINISH':local(state['finished']).isoformat(),
            'MEMBERS':str(len(manifest['files'])),'RAW_BYTES':f"{manifest['raw_bytes']:,}",
            'ZIP_BYTES':f"{manifest['stored_bytes']:,}",'ZIP_SHA':manifest['payload_sha256'],
            'AUDIT_FINISH':local(closure['finished']).isoformat(),'STDERR_DESCRIPTION':detail}
    report=(PARENT/'fused-target-result-template-148.md').read_text()
    for name,text in tokens.items():report=report.replace('@@'+name+'@@',text)
    assert '@@' not in report;reportpath.write_text(report)
    summary=dict(status='FUSED_TARGET_ORIGINAL_EVIDENCE_CLOSED',source_head_at_delivery=oldhead,
                 target_source_commit='151481e916bfed0fc23b0223ee04b2085d18e25e',closure=closure,
                 selection=value['selection'],validation_sha256=sha(rr/'validation.json'),stderr=stderr,
                 support_sha256=sha(evidence/'support.zip'),support_members=len(members),
                 history_objects=len(history['objects']),history_pack_sha256=history['pack_sha256'],
                 normal_totals=dict(guest_cycles=2410050,retired=1682220),frozen_sources_unchanged=True)
    save(evidence/'summary.json',summary)
    names=[str(p.relative_to(ROOT)) for p in evidence.rglob('*') if p.is_file()]+[str(reportpath.relative_to(ROOT))]
    git('add','-f','--',*names)
    staged=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1]
    assert set(staged)==set(names) and not set(staged)&set(pins)
    proof={}
    for name in staged:
        raw=(ROOT/name).read_bytes();stored=git('show',':'+name);assert stored==raw,name
        proof[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    p=evidence/'all-blob-check.json'
    save(p,dict(status='ALL_ORIGINAL_EVIDENCE_AND_GIT_BLOBS_EQUAL',files=proof,
                manifest_history_pack_chain_verified=True,proof_itself_checked_separately=True))
    git('add','-f','--',str(p.relative_to(ROOT)));assert git('show',':'+p.relative_to(ROOT).as_posix())==p.read_bytes()
    subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
    assert all(sha(ROOT/name)==pin for name,pin in pins.items())
    subprocess.run(['git','commit','-m','Close full-Q fusion target comparison and reproducible raw evidence'],cwd=ROOT,check=True)
    assert git('status','--porcelain')==b''
    result=dict(status='FUSED_TARGET_DELIVERY_COMMITTED',head=git('rev-parse','HEAD').decode().strip(),
                archive_sha256=manifest['payload_sha256'],archive_bytes=manifest['stored_bytes'],
                archive_members=len(manifest['files']),support_sha256=summary['support_sha256'],
                support_members=len(members),all_evidence_files=len(proof)+1,source_files_unchanged=98)
    save(RUN/'delivery-01.json',result);print(json.dumps(result))

if __name__=='__main__':main()
