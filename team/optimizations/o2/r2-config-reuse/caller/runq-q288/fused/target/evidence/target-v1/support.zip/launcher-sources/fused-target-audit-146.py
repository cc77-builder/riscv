from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-fused-target-20261026-0715')
MODULE=ROOT/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target'

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    state=json.loads((RUN/'campaign-01/state.json').read_text())
    assert state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None
    active=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:words=(p/'cmdline').read_bytes().split(b'\0')
        except (PermissionError,FileNotFoundError,ProcessLookupError):continue
        if words and Path(os.fsdecode(words[0])).name=='emu':active.append(int(p.name))
    assert not active,('EMU remains',active)
    pins=json.loads((RUN/'build-02/build.json').read_text())['software_files']
    assert len(pins)==98 and all(sha(ROOT/name)==pin for name,pin in pins.items())
    assert sha(MODULE/'host_audit.py')=='0fa2f707274aa90a8e45839966e0caf849a2d80ec370292ffee75020d9239d91'
    report=RUN/'archive-driver-01.json';assert not report.exists()
    record=dict(status='RUNNING',started=now(),contract=state['contract'],commands=[],new_emu_runs=0,
                outer_command_host_seconds=1800,inner_fresh_audit_host_seconds=900,
                source_files_protected=98,cpu_affinity=sorted(os.sched_getaffinity(0)))
    save(report,record)
    commands=[
        ('pack',[sys.executable,str(MODULE/'archive.py'),'--action','pack','--build',str(RUN/'build-02'),
                 '--run',str(RUN/'campaign-01'),'--output',str(RUN/'evidence-pack-01')]),
        ('fresh-source',[sys.executable,str(MODULE/'host_audit.py'),'--action','audit','--repo',str(ROOT),
                         '--archive',str(RUN/'evidence-pack-01'),'--output',str(RUN/'host-audit-01')]),
    ]
    try:
        for label,argv in commands:
            assert all(sha(ROOT/name)==pin for name,pin in pins.items())
            stdout=RUN/('archive-'+label+'-01.stdout.log');stderr=RUN/('archive-'+label+'-01.stderr.log')
            item=dict(name=label,command=argv,started=now(),status='RUNNING',host_timeout_seconds=1800)
            record['commands'].append(item);save(report,record)
            with stdout.open('xb') as out,stderr.open('xb') as err:
                child=subprocess.Popen(argv,cwd=ROOT,stdout=out,stderr=err)
                item['pid']=child.pid;save(report,record)
                try:code=child.wait(timeout=1800)
                except subprocess.TimeoutExpired:
                    item.update(timed_out=True,status='FAILED_HOST_BUDGET',finished=now());save(report,record)
                    child.terminate()
                    try:child.wait(timeout=15)
                    except subprocess.TimeoutExpired:child.kill();child.wait(timeout=15)
                    raise
            item.update(exit_code=code,finished=now(),status='PASS' if code==0 else 'FAILED',
                        raw_sha256=dict(stdout=sha(stdout),stderr=sha(stderr)))
            save(report,record);assert code==0,label+' failed; preserve original evidence'
        archive=json.loads((RUN/'evidence-pack-01/archive-manifest.json').read_text())
        host=json.loads((RUN/'host-audit-01/host-resource.json').read_text())
        audit=json.loads((RUN/'host-audit-01/fresh-source-audit/result.json').read_text())
        assert host['status']=='FROZEN_FUSED_AUDIT_WITH_DURABLE_HOST_BUDGET_PASS'
        assert audit['status']=='FUSED_TARGET_ARCHIVE_FRESH_SOURCE_AUDIT_PASS'
        assert all(sha(ROOT/name)==pin for name,pin in pins.items())
        record.update(status='FUSED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED',finished=now(),
                      archive_sha256=archive['payload_sha256'],archive_bytes=archive['stored_bytes'],
                      archive_members=len(archive['files']),raw_bytes=archive['raw_bytes'],
                      audit_status=audit['status'],resource_adapter_status=host['status'],frozen_sources_unchanged=True)
        save(report,record);print(json.dumps(record))
    except BaseException as error:
        record.update(status='FAILED',error=repr(error),finished=now());save(report,record);raise

if __name__=='__main__':main()
