from pathlib import Path
import base64, datetime, hashlib, json, os, shutil, subprocess, sys, time
def sha(raw): return hashlib.sha256(raw).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
out=Path("/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/paired16-rvv-20261106-0740/host-01")
pins=[{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/generate.py","sha256":"b1d127cfc60d9b3fe942b90fd8a1faa0800726d56b081ebd183ca4e611c9a77b","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/generate.py"},{"relative":"team/optimizations/o2/r2-config-reuse/public/gemv.S","sha256":"9b8e03d1827ad70105d11566b635c49900c495b3fad6e871a8e25d9fc414a6d2","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/public/gemv.S"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/screen.py","sha256":"39bfbe63942d15ad5bee4e32e08153c2edf56cc8ce2058f74c199550f16cf5ae","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/screen.py"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/model.py","sha256":"703667b537c652b22a7dd82f8e3d3a7a42e965d7b5df7d4627b78e0d7358cc82","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/model.py"},{"relative":"team/optimizations/o2/r2-safe-tail/machine_model.py","sha256":"8fb2ac208d8db9083464fb839c06b46ec365234d72b819822563830dad90171e","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-safe-tail/machine_model.py"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/generate.py","sha256":"e2862fb802754c473a0c9cb8a949b30ed55eaee647aae9ef7e1d566168122987","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/runq-q288/generate.py"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/oracle.c","sha256":"6e72ed5b4e6b4ea804d34212e9e84d9001207eea076a26a8a835f2a1c29f9dec","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/runq-q288/oracle.c"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/q288.h","sha256":"f8e4df00dba860487c168f6990edbf2dc8814291b825d30762c7ecad61821cc2","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/runq-q288/q288.h"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/caller.h","sha256":"8f8ebbdfc64f506549b8fcb91700fc80dd91b1fd0a5be64aaed504ebcfa0c38e","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/caller.h"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/split/split.h","sha256":"94ccdc8e6212c0c0d7ef0e8795c8edcdc9a02e173802bea18965bbce5e01e222","source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-config-reuse/caller/split/split.h"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv/CONTRACT.md","sha256":"523bb74834eaa2a2c8a59530c24f011aa8ed743157b6f0fa585c234f73851553","source":"/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv/CONTRACT.md"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv/generate.py","sha256":"ac3b61a164e948f2f3518407fb9fd3d07582649038786afb707fa660ae00823b","source":"/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv/generate.py"},{"relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv/screen.py","sha256":"fe2168eab295f3a232e1905192dbaeeeba37d5c96f94487ccb5180637b2c1d29","source":"/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv/screen.py"}]
assert not out.exists(), 'fresh output required; inspect existing receipt rather than rerun'
assert set(os.sched_getaffinity(0)) == {2}, 'one authorized CPU, logical CPU2'
cc=shutil.which('riscv64-linux-gnu-gcc')
objdump=shutil.which('riscv64-linux-gnu-objdump')
assert cc and objdump, 'existing GNU RV64 compiler and objdump required'
loaded=[]
for item in pins:
    raw=Path(item['source']).read_bytes()
    assert sha(raw)==item['sha256'], 'source SHA mismatch: '+item['source']
    loaded.append((item,raw))
out.mkdir(parents=True)
(out/'driver.py').write_bytes(base64.b64decode(sys.argv[1]))
snapshot=out/'inputs/source'
for item,raw in loaded:
    dest=snapshot/item['relative']
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(raw)
record={'started':now(),'pid':os.getpid(),'cpu_affinity':sorted(os.sched_getaffinity(0)),
        'source_files':pins,'compiler':cc,'compiler_sha256':sha(Path(cc).read_bytes()),
        'compiler_version':subprocess.run([cc,'--version'],capture_output=True,text=True,check=True).stdout.splitlines()[0],
        'hardware_changed':False,'new_emu_runs':0,'target_runtime_qualified':False,'performance_qualified':False,
        'commands':[],'status':'running'}
def save():
    (out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
save()
def command(argv,label):
    start=time.monotonic()
    result=subprocess.run([str(x) for x in argv],cwd=out,capture_output=True,timeout=240)
    (out/(label+'.stdout.log')).write_bytes(result.stdout)
    (out/(label+'.stderr.log')).write_bytes(result.stderr)
    row={'label':label,'argv':[str(x) for x in argv],'exit_code':result.returncode,
         'duration_seconds':time.monotonic()-start,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)}
    record['commands'].append(row);save()
    print(json.dumps({'stage':label,'exit_code':result.returncode,'seconds':row['duration_seconds'],'at':now()}),flush=True)
    if result.returncode:
        print(result.stderr.decode(errors='replace')[-6000:],flush=True)
        raise RuntimeError('stage failed: '+label)
leaf=snapshot/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv'
prefix=[cc,'-march=rv64gcv','-mabi=lp64d','-mno-relax']
try:
    command([sys.executable,'-B',leaf/'generate.py','--repo',snapshot,'--output',out/'generated'],'00-generate')
    command(prefix+['-c',out/'generated/paired16.S','-o',out/'paired16.o'],'01-assemble')
    command(prefix+['-static','-no-pie','-nostdlib','-nostartfiles',
             '-Wl,--build-id=none,--no-relax,-Ttext=0x80000000,-e,q288_paired16_rvv',
             out/'paired16.o','-o',out/'paired16.elf'],'02-link')
    command([objdump,'-d',out/'paired16.elf'],'03-disassemble')
    command([sys.executable,'-B',leaf/'screen.py','--repo',snapshot,
             '--elf',out/'paired16.elf','--output',out/'screen'],'04-screen')
    for item in pins:
        assert sha(Path(item['source']).read_bytes())==item['sha256'], 'source changed during screen'
    result=json.loads((out/'screen/result.json').read_text())
    record.update(status=result['status'],finished=now(),elf_sha256=sha((out/'paired16.elf').read_bytes()),
                  result_sha256=sha((out/'screen/result.json').read_bytes()))
    save()
    first=result['numeric']['cases'][0]['methods']
    print(json.dumps({'status':record['status'],'output':str(out),'elf_sha256':record['elf_sha256'],
         'cases':len(result['numeric']['cases']),'controls':result['controls'],
         'instructions':{name:value['function_instructions'] for name,value in first.items()},
         'certificate':result['certificate'],'result_sha256':record['result_sha256']}),flush=True)
except BaseException as error:
    record.update(status='FAILED',finished=now(),error=type(error).__name__+': '+str(error))
    save()
    raise
