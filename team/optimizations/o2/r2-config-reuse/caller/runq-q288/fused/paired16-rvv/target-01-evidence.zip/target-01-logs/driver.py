from pathlib import Path
import base64,datetime,hashlib,json,os,subprocess,sys,time,traceback
cfg=json.loads(r'''{"root":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/paired16-rvv-20261106-0740","inputs":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/paired16-rvv-20261106-0740/target-inputs-01","windows_leaf":"/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-zufan-full-20261022/team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv","relative":"team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/paired16-rvv","am":"/home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am","base_manifest_sha256":"8f07c4f7e54bdcb9942fc7878c91fe3b1124b62e2162973f5ec0dfcd1acfc0ab","controller":{"CONTRACT.md":"523bb74834eaa2a2c8a59530c24f011aa8ed743157b6f0fa585c234f73851553","generate.py":"ac3b61a164e948f2f3518407fb9fd3d07582649038786afb707fa660ae00823b","screen.py":"fe2168eab295f3a232e1905192dbaeeeba37d5c96f94487ccb5180637b2c1d29","TARGET_CONTRACT.md":"5561d4a11dbba28faa22377d46991705799bdb16fc8d931be9631de00338589b","target.py":"363639f58d2074a5b65e9adb28d64e1b420e89ed82124c1afb12ae7df8bf14e6","check_target.py":"dd1ec5af3da225920325541238267dccd690dbbea30024dc0a9844ef722c8235","run_target.py":"eac7451136e7cfd926aea8c4e6cc9a21376520a85ed5e1dbb9888c91ba5d822a"},"references":{"paired16.elf":{"source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/paired16-rvv-20261106-0740/host-01/paired16.elf","sha256":"fb3c030efa7aa347029a69f6aabe82c912cbbb85294b27cf407a01ea58a314f3"},"paired16-result.json":{"source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/paired16-rvv-20261106-0740/host-01/screen/result.json","sha256":"6a9e418223ad9b44235f5b4216419288e0d9f6302dfdfed0295e1d26130b5fa0"},"gs32.elf":{"source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/gs32-rvv-20261106-0640/screen-02/gs32.elf","sha256":"8316e32939385653c1c4f7e257443529c19dc71df8b5991552a2ab1453069daa"},"gs32-result.json":{"source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/gs32-rvv-20261106-0640/screen-02/numeric-01/result.json","sha256":"a5dfb2bbe82f48b6070ec768e7c39aaa04039585965dd369333a7d88599b84f6"},"timer-reference.elf":{"source":"/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-tail-target-20261026-1400/build-01/vdot-perf.elf","sha256":"610c499f46f1fe73074f626d8990bdcbdbc5f78c30ce8fc4a835495b0e392faa"}}}''')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda data:hashlib.sha256(data).hexdigest()
def need(ok,why):
    if not ok: raise ValueError(why)
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
root,inputs=Path(cfg['root']),Path(cfg['inputs'])
repo=inputs/'source'
leaf=repo/cfg['relative']
build=root/'target-build-01'
report=root/'target-check-01.json'
state_path=root/'target-01-run.json'
logs=root/'target-01-logs'
need(sorted(os.sched_getaffinity(0))==[2],'only allocated CPU2')
need(not build.exists() and not report.exists() and not state_path.exists() and not logs.exists(),'fresh target job')
need(not leaf.exists() and not (inputs/'references').exists() and not (inputs/'controller-inputs.json').exists(),'new controller append only')
need(sha((inputs/'base-inputs.json').read_bytes())==cfg['base_manifest_sha256'],'unchanged base inventory')
base=json.loads((inputs/'base-inputs.json').read_text())
for relative,item in base.items():
    need(sha((repo/relative).read_bytes())==item['sha256'],'fixed base '+relative)
for name,pin in cfg['controller'].items():
    need(sha((Path(cfg['windows_leaf'])/name).read_bytes())==pin,'Windows controller '+name)
for name,item in cfg['references'].items():
    need(sha(Path(item['source']).read_bytes())==item['sha256'],'actual screened reference '+name)
logs.mkdir()
(logs/'driver.py').write_bytes(base64.b64decode(sys.argv[1]))
state=dict(status='RUNNING',started=now(),cpu_affinity=[2],compiler_workers=1,emu_runs=0,
           source_base_head='5c7cd127b12a46d4927ddb6f0ef359fde0ba4c91',base_manifest_sha256=cfg['base_manifest_sha256'],
           target_runtime_qualified=False,performance_qualified=False,commands=[])
save(state_path,state)
try:
    leaf.mkdir(parents=True)
    (inputs/'references').mkdir()
    for name,pin in cfg['controller'].items():
        content=(Path(cfg['windows_leaf'])/name).read_bytes()
        need(sha(content)==pin,'controller stable at copy '+name)
        with (leaf/name).open('xb') as dest: dest.write(content)
        need(sha((leaf/name).read_bytes())==pin,'frozen controller '+name)
    for name,item in cfg['references'].items():
        content=Path(item['source']).read_bytes()
        need(sha(content)==item['sha256'],'reference stable at copy '+name)
        with (inputs/'references'/name).open('xb') as dest: dest.write(content)
        need(sha((inputs/'references'/name).read_bytes())==item['sha256'],'frozen reference '+name)
    save(inputs/'controller-inputs.json',cfg)
    commands=[
      ('build',['/usr/bin/python3','-B',str(leaf/'target.py'),'--repo',str(repo),'--am-home',cfg['am'],'--output',str(build)]),
      ('check',['/usr/bin/python3','-B',str(leaf/'check_target.py'),'--repo',str(repo),'--build',str(build),
        '--paired-elf',str(inputs/'references/paired16.elf'),'--paired-result',str(inputs/'references/paired16-result.json'),
        '--gs32-elf',str(inputs/'references/gs32.elf'),'--gs32-result',str(inputs/'references/gs32-result.json'),
        '--timer-reference',str(inputs/'references/timer-reference.elf'),'--output',str(report)])]
    for name,argv in commands:
        start=time.monotonic()
        with (logs/(name+'.stdout.log')).open('wb') as stdout,(logs/(name+'.stderr.log')).open('wb') as stderr:
            p=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,timeout=240)
        record=dict(name=name,argv=argv,returncode=p.returncode,elapsed_seconds=time.monotonic()-start,
                    stdout_sha256=sha((logs/(name+'.stdout.log')).read_bytes()),
                    stderr_sha256=sha((logs/(name+'.stderr.log')).read_bytes()))
        state['commands'].append(record)
        save(state_path,state)
        print(json.dumps(record),flush=True)
        need(p.returncode==0,name+' failed: '+(logs/(name+'.stderr.log')).read_text()[-12000:])
    for relative,item in base.items():
        need(sha((repo/relative).read_bytes())==item['sha256'],'base unchanged after target '+relative)
    for name,pin in cfg['controller'].items():
        need(sha((leaf/name).read_bytes())==pin,'controller unchanged after target '+name)
    proof=json.loads(report.read_text())
    need(proof['status']=='PAIRED16_TARGET_ELF_DATASET_TIMER_PATH_PASS','actual target proof')
    state.update(status='PAIRED16_GNU_TARGET_BUILD_CHECK_PASS',proof_sha256=sha(report.read_bytes()),
                 elf_sha256=proof['elf_sha256'],bin_sha256=proof['bin_sha256'],
                 instructions={key:value.get('expected_csr_instret') for key,value in proof['paths'].items()},
                 fullmin=proof['fullmin_oracle'])
except BaseException as error:
    state.update(status='FAILED',error=repr(error))
    (logs/'driver-error.log').write_text(traceback.format_exc())
    raise
finally:
    state['finished']=now()
    save(state_path,state)
    print(json.dumps(state,indent=2),flush=True)
