from pathlib import Path
import hashlib,json,os,shutil
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/first-forward-rvv-20261106-pro5')
out=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/first-forward-rvv-20261106-pro5/target-evidence-01')
assert sorted(os.sched_getaffinity(0))==[0]
expected={'target-01/results.json':'1bd3cb9e63068bc94ed3f0b72c731b0b8bd5d09d162d8ff056c57fb39ff05c54','target-01/state.json':'61f11816700945316b0bbdb0d4781f4c3f322275d5e6bf189ae012689b1ef029','target-launch-01/state.json':'ef1355038a2bd76584a96e89cfec866e9e41018e1a55df4693fc51f96da2c3e3','controller-05/run.py':'976cacfb48631042e57e9d2393ddca4653866cc07142e1b0b49185b7719e18f6','launch-target-01.py':'ec93e1afe5404caa8f9196f9dadce3adf0f68a3d1ce4e008d4fa76596a646537'}
for name,digest in expected.items():
 p=root/name;assert p.is_file() and not p.is_symlink(),str(p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
files=[]
for group in ['target-01','target-launch-01','controller-05']:
 for p in sorted((root/group).rglob('*')):
  if p.is_file() or p.is_symlink():files.append({'path':p.relative_to(root).as_posix(),'bytes':p.lstat().st_size,'symlink':p.is_symlink()})
assert len(files)<1500
body={'root':str(root),'files':files,'controller_top_names':sorted(p.name for p in (root/'controller-05').iterdir()),'source_sha_verified':expected,'new_guest_runs':0}
dest=out/'source-inventory.json'
with dest.open('x',encoding='utf-8',newline='\n') as f:json.dump(body,f,indent=2);f.write('\n')
copied={}
for rel in ['controller-05/binding.json','controller-05/frozen-target-closure.json','controller-05/frozen-target-data.json','config-01.json','launch-target-01.py']:
 p=root/rel
 if p.exists():
  b=p.read_bytes();dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as f:f.write(b)
  copied[rel]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
summary={g:{'files':sum(1 for x in files if x['path'].startswith(g+'/')),'bytes':sum(x['bytes'] for x in files if x['path'].startswith(g+'/'))} for g in ['target-01','target-launch-01','controller-05']}
print(json.dumps({'groups':summary,'symlinks':[x for x in files if x['symlink']],'files_over_16MiB':[x for x in files if x['bytes']>16777216],'controller_top_names':body['controller_top_names'],'copied':copied,'inventory_bytes':dest.stat().st_size if False else (out/'source-inventory.json').stat().st_size,'inventory_sha256':hashlib.sha256((out/'source-inventory.json').read_bytes()).hexdigest(),'new_guest_runs':0},indent=2))
