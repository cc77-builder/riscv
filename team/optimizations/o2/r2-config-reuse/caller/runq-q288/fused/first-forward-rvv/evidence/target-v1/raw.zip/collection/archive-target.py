from pathlib import Path
import datetime,hashlib,json,os,zipfile
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/first-forward-rvv-20261106-pro5')
out=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/first-forward-rvv-20261106-pro5/target-evidence-01')
assert sorted(os.sched_getaffinity(0))==[0]
def digest(b):return hashlib.sha256(b).hexdigest()
inventory_raw=(out/'source-inventory.json').read_bytes()
assert digest(inventory_raw)=='e28d0fa846f11e1e9c6ce4f61319ec1f27c1156f70dc8783d8b20b699095cf62'
inventory=json.loads(inventory_raw)
state_raw=(root/'target-01/state.json').read_bytes()
results_raw=(root/'target-01/results.json').read_bytes()
assert digest(state_raw)=='61f11816700945316b0bbdb0d4781f4c3f322275d5e6bf189ae012689b1ef029'
assert digest(results_raw)=='1bd3cb9e63068bc94ed3f0b72c731b0b8bd5d09d162d8ff056c57fb39ff05c54'
state=json.loads(state_raw);results=json.loads(results_raw)
assert state['new_emu_runs']==3 and state['active']==[] and state['cleanup_unknown']==[] and state['cleanup_errors']==[] and state['launch_state_unknown']==[]
assert all(x['cleanup_verified'] and x['receipt_cleanup_verified'] and not x['reference_group_present'] and not x['launcher_group_present'] for x in state['launcher_receipts'])
excluded={}
for case in ['fr','gs32','paired16']:
 name='target-01/'+case+'/image.bin'
 excluded[name]={'reason':'Original 77115360-byte method image retained at source; common build/recipe and exact hash retained. No source file deleted.','bytes':results['target_images']['images'][case]['bytes'],'sha256_from_original_result':results['target_images']['images'][case]['sha256']}
selected=[]
for item in inventory['files']:
 name=item['path']
 assert not item['symlink'],name
 p=root/name
 assert p.is_file() and not p.is_symlink() and p.stat().st_size==item['bytes'],name
 if name in excluded:continue
 assert '__pycache__' not in p.parts and p.suffix!='.pyc',name
 assert item['bytes']<=16*1024*1024,name
 selected.append(('source/'+name,p))
for name in ['config-01.json','launch-target-01.py','target-01.resource-contract.json']:
 selected.append(('source/'+name,root/name))
for name in ['source-inventory.json','inventory-target.py','archive-target.py','external-operation.json']:
 selected.append(('collection/'+name,out/name))
assert len(set(n for n,p in selected))==len(selected)
assert sum(p.stat().st_size for n,p in selected)<=64*1024*1024
members={}
sources={}
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(selected):
  b=p.read_bytes();h=digest(b)
  info=zipfile.ZipInfo(name,date_time=(2026,11,6,12,6,26))
  info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
  members[name]={'bytes':len(b),'sha256':h};sources[name]=p
for name,p in sources.items():
 assert digest(p.read_bytes())==members[name]['sha256'],'source changed during collection: '+name
for rec in state['records']:
 case=rec['name'];base='source/target-01/'+case+'/'
 for stream in ['stdout.log','stderr.log']:
  assert members[base+stream]['sha256']==rec['raw_sha256'][stream],case+stream
  assert members[base+stream]['bytes']==rec['raw_bytes'][stream],case+stream
 assert members[base+'validation.json']['sha256']==rec['validation_sha256'],case+' validation'
with zipfile.ZipFile(archive,'r') as z:
 assert set(z.namelist())==set(members)
 for name,meta in members.items():
  b=z.read(name);assert len(b)==meta['bytes'] and digest(b)==meta['sha256'],name
manifest={'schema':'first-forward-rvv-target-v1-original-evidence','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(root),'contract':'r2-s3-first-forward-rvv-v1','status':state['status'],'archive':{'file':'raw.zip','bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),'members':len(members),'uncompressed_bytes':sum(x['bytes'] for x in members.values())},'files':members,'omitted_large_method_images_retained_at_source':excluded,'verification':{'all_member_bytes_and_sha256_read_back':True,'source_files_unchanged_during_collection':True,'six_raw_logs_match_original_receipts':True,'three_validation_files_match_original_receipts':True,'new_guest_runs_for_collection':0},'qualification':{'target_correctness_qualified':results['target_correctness_qualified'],'performance_qualified':results['performance_qualified'],'full_retirement_window_audited':results['full_retirement_window_audited']}}
with (out/'manifest.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(manifest,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'archive':manifest['archive'],'manifest_bytes':(out/'manifest.json').stat().st_size,'manifest_sha256':digest((out/'manifest.json').read_bytes()),'verification':manifest['verification'],'qualification':manifest['qualification']},indent=2))
