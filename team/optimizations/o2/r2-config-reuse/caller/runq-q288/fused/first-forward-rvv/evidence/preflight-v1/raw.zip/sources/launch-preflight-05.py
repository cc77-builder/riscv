"""Complete original provenance data and re-audit existing reference/physical inputs."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import sys
import time

BASE = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
ROOT = BASE / 'runs/first-forward-rvv-20261106-pro5'
REL = Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/first-forward-rvv')
LEAF = BASE / 'checkout/source' / REL
WIN = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan')
JOB = WIN / 'runs/first-forward-rvv-20261106-pro5'
DATA_SHA = '343c29e9afee3872eca4c9828c6cc5d80c4046589e434c44665dcab217c3f4ee'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def check():
    assert os.sched_getaffinity(0) == {0} and sys.dont_write_bytecode
    executed, commands = set(), []
    def observe(event, args):
        if event == 'exec':
            filename = getattr(args[0], 'co_filename', '')
            if filename.startswith('/') and filename.endswith('.py'):
                executed.add(str(Path(filename).resolve()))
        elif event == 'subprocess.Popen':
            commands.append(dict(executable=str(args[0]), argv=args[1], cwd=str(args[2]) if args[2] else None))
    sys.addaudithook(observe)
    phase, controller = ROOT / 'preflight-05', ROOT / 'controller-05'
    run = None
    try:
        run = load('first_forward_frozen_preflight', controller / 'run.py')
        cfg = run.b.CFG
        record, files, identity, hardware, profile, checker = run.qualified(
            ROOT / 'build-02', ROOT / 'reference-02', Path(cfg['adapter']), Path(cfg['identity']))
        checker.verify_files(files)
        save(phase / 'runtime-inputs.json', files)
        save(phase / 'physical-profile.json', dict(identity=identity, hardware_pins=hardware, hardware_profile=profile))
        actual = {}
        for name in ('t17_profile_suite', 't17_profile_snapshot', 't17_profile_git_sources', 't17_profile_artifact_guard'):
            module = sys.modules[name]
            path = Path(module.__file__).resolve()
            actual[name] = dict(path=str(path), sha256=sha(path))
        physical = run.b.cr.old.r.parent.t17.p
        path = Path(physical.hardware_profile.__code__.co_filename).resolve()
        actual['actual_clean_profile_function'] = dict(path=str(path), sha256=sha(path))
        expected = {
            't17_profile_suite': ('team/optimizations/o2/fullcore/run_suite.py', '7bc68d73cd830ceb8fb9aa18469ebe6ff3efcdf56de6922049e05556b0e02475'),
            't17_profile_git_sources': ('team/optimizations/o2/result-width/h1/performance/build_profile.py', '1650856fbe5a6626072ec0e6dfb5dcca86eacdcc805c7d10d542cfcc0f5be5b8'),
            't17_profile_artifact_guard': ('team/scripts/artifact_guard.py', '95eabdc0dc6191df4b03062e432ecc38877cc0c9626a81cdd002a4627ab54a85'),
        }
        for name, (relative, digest) in expected.items():
            assert actual[name] == dict(path=str(controller / 'target-support' / relative), sha256=digest)
        assert actual['actual_clean_profile_function']['sha256'] == '1c4c467f43ede68fd30b1063868d8f02d71fbe8a5442f2da180210468db9a642'
        assert actual['t17_profile_snapshot']['sha256'] == '8a66fb75324ee1834401ec71b5c578141de6268a074253d37eb5494046c932d0'
        assert not any(os.environ.get(key) for key in ('GIT_DIR', 'GIT_WORK_TREE'))
        save(phase / 'actual-physical-helpers.json', actual)
        result = dict(contract=run.b.CONTRACT, status='FIRST_FORWARD_RVV_TARGET_PREFLIGHT_PASS_NO_EMU',
            controller=str(controller), build=str(ROOT / 'build-02'), reference=str(ROOT / 'reference-02'),
            controller_binding_sha256=sha(controller / 'binding.json'),
            frozen_target_closure_sha256=sha(controller / 'frozen-target-closure.json'),
            frozen_target_data_sha256=sha(controller / 'frozen-target-data.json'),
            build_result_sha256=sha(ROOT / 'build-02/result.json'),
            reference_results_sha256=sha(ROOT / 'reference-02/results.json'),
            normal_images_sha256=sha(ROOT / 'normal-images-02.json'),
            runtime_input_files=len(files), runtime_inputs_sha256=sha(phase / 'runtime-inputs.json'),
            physical_profile_sha256=sha(phase / 'physical-profile.json'),
            actual_physical_helpers_sha256=sha(phase / 'actual-physical-helpers.json'),
            emu_sha256=profile['emu_sha256'], reference_sha256=identity['reference_sha256'],
            source_files=profile['source_files'], dependency_files=profile['dependency_files'], generated_files=profile['generated_files'],
            reference_cases_reaudited=5, new_builds=0, new_reference_runs=0, new_target_emu_runs=0,
            performance_qualified=False, resource_profile_frozen=False,
            checked=run.c.base.f.h.now(), cpu_affinity=[0])
        save(phase / 'result.json', result)
        print(json.dumps(result), flush=True)
    finally:
        files = []
        for filename in sorted(executed):
            path = Path(filename)
            if path.is_file() and str(path).startswith('/home/lizufan/'):
                files.append(dict(path=str(path), sha256=sha(path)))
        save(phase / 'executed-python-sources.json', dict(
            mechanism='read-only Python exec audit events in a fresh process; includes spec-loaded modules',
            executed_project_sources=files, subprocesses=commands,
            current_repository_python_sources=[row for row in files if Path(row['path']).is_relative_to(BASE / 'checkout/source')],
            no_controller_code_modified=True))


def main():
    begin = time.monotonic()
    assert os.sched_getaffinity(0) == {0} and sys.dont_write_bytecode
    phase, controller = ROOT / 'preflight-05', ROOT / 'controller-05'
    assert not phase.exists() and not controller.exists() and not (LEAF / 'complete_data.py').exists()
    source = WIN / 'working-zufan-full-20261022' / REL / 'complete_data.py'
    assert sha(source) == DATA_SHA
    shutil.copyfile(source, LEAF / 'complete_data.py')
    assert sha(LEAF / 'complete_data.py') == DATA_SHA
    assert not (ROOT / 'launch-preflight-05.py').exists()
    shutil.copyfile(JOB / 'launch-preflight-05.py', ROOT / 'launch-preflight-05.py')
    assert sha(ROOT / 'owned-command-helper/check.py') == '0c81b6620b2c417ef73a251899bbe3af0ec4749832dd76ad2631b3e6fbd1386f'
    h = load('first_forward_frozen_preflight_owner', ROOT / 'owned-command-helper/check.py')
    phase.mkdir()
    state = dict(contract='r2-s3-first-forward-rvv-v1', status='RUNNING', started=h.now(), cpu_affinity=[0],
                 new_builds=0, new_reference_runs=0, new_target_emu_runs=0, performance_qualified=False)
    save(phase / 'state.json', state)
    fixed_paths = [LEAF / 'complete_data.py', ROOT / 'launch-preflight-05.py', JOB / 'first-token-frozen-manifest.json',
                   ROOT / 'controller-03/binding.json', ROOT / 'controller-04/binding.json',
                   ROOT / 'build-02/result.json', ROOT / 'build-02/inputs.json',
                   ROOT / 'build-02/first-forward-rvv.elf', ROOT / 'build-02/first-forward-rvv.bin',
                   ROOT / 'reference-02/results.json', ROOT / 'reference-02/state.json', ROOT / 'reference-02/runtime-inputs.json']
    fixed = {str(path): sha(path) for path in fixed_paths}
    save(phase / 'owner-inputs.json', fixed)

    def interrupted(signum, frame):
        raise InterruptedError('preflight signal ' + str(signum))

    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    try:
        h.command([sys.executable, '-B', LEAF / 'complete_data.py', '--controller', ROOT / 'controller-04',
                   '--output', controller], phase, 'complete-data', timeout=90)
        h.command([sys.executable, '-B', ROOT / 'launch-preflight-05.py', '--check'], phase, 'check', timeout=240)
        result = json.loads((phase / 'result.json').read_text())
        assert result['status'] == 'FIRST_FORWARD_RVV_TARGET_PREFLIGHT_PASS_NO_EMU'
        state.update(status=result['status'], result_sha256=sha(phase / 'result.json'))
    except BaseException as error:
        state.update(status='FAILED', error=repr(error)); raise
    finally:
        changed = [path for path, value in fixed.items() if not Path(path).is_file() or sha(path) != value]
        state.update(finished=h.now(), elapsed_seconds=time.monotonic() - begin, changed_inputs=changed)
        if changed:
            state.update(status='FAILED', input_identity_error=True)
        save(phase / 'state.json', state)
        exported = JOB / 'preflight-05'
        assert not exported.exists()
        exported.mkdir()
        for path in phase.iterdir():
            if path.is_file():
                shutil.copyfile(path, exported / path.name)
                assert sha(path) == sha(exported / path.name)
        for name in ('frozen-target-closure.json', 'frozen-target-data.json', 'binding.json'):
            if (controller / name).is_file():
                shutil.copyfile(controller / name, exported / ('controller-' + name))
                assert sha(controller / name) == sha(exported / ('controller-' + name))
        print(json.dumps(state), flush=True)
    assert not changed


if __name__ == '__main__':
    check() if sys.argv[1:] == ['--check'] else main()
