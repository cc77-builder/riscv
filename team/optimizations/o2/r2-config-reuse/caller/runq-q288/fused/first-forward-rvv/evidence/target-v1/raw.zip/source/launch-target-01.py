"""Freeze and launch the original three-case target queue after slot assignment.

This owner adds no guest logic or acceptance rules. It uses the frozen run.py
CLI unchanged, retains its pre/post-run checks, and exports only small records.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import sys
import time

BASE = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
ROOT = BASE / 'runs/first-forward-rvv-20261106-pro5'
JOB = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/runs/first-forward-rvv-20261106-pro5')
CONTROLLER = ROOT / 'controller-05'
PROFILE = ROOT / 'target-01.resource-contract.json'
OUTPUT = ROOT / 'target-01'
OPERATION = 'f3e06512-04c6-427c-a0cf-5bfe42a2120c'
CPUS = (0, 2, 3)
RUN_SHA = '976cacfb48631042e57e9d2393ddca4653866cc07142e1b0b49185b7719e18f6'
BINDING_SHA = '0e03ff7964bd17f7d06cdf32e1f984b3ba5c7765a073b10f3e17f6492a431bca'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def export_small(source, dest):
    if source.is_file():
        assert source.stat().st_size <= 2 * 1024 * 1024
        assert not dest.exists()
        shutil.copyfile(source, dest)
        assert sha(source) == sha(dest)


def main():
    begin = time.monotonic()
    assert sys.dont_write_bytecode and os.sched_getaffinity(0) == set(CPUS), 'three formally assigned slots required'
    phase = ROOT / 'target-launch-01'
    assert not phase.exists() and not PROFILE.exists() and not OUTPUT.exists()
    assert sha(CONTROLLER / 'run.py') == RUN_SHA and sha(CONTROLLER / 'binding.json') == BINDING_SHA
    assert sha(ROOT / 'preflight-05/result.json') == '998ce7c328636e53ee066345b297cd7b2663a0c7db51c50c247fc2378bfa608f'
    binding = json.loads((CONTROLLER / 'binding.json').read_text()); cfg = binding['config']
    helper = ROOT / 'owned-command-helper/check.py'
    assert sha(helper) == '0c81b6620b2c417ef73a251899bbe3af0ec4749832dd76ad2631b3e6fbd1386f'
    h = load('first_forward_target_owner', helper)
    phase.mkdir()
    state = dict(contract=binding['contract'], status='PREPARING', operation_id=OPERATION,
                 started=h.now(), cpu_affinity=list(CPUS), target_correctness_qualified=False,
                 performance_qualified=False, profile_path=str(PROFILE), campaign_output=str(OUTPUT))
    save(phase / 'state.json', state)
    fixed = {str(path): sha(path) for path in (Path(__file__).resolve(), CONTROLLER / 'binding.json',
             CONTROLLER / 'run.py', ROOT / 'build-02/result.json', ROOT / 'reference-02/results.json',
             ROOT / 'normal-images-02.json', ROOT / 'preflight-05/result.json')}
    save(phase / 'owner-inputs.json', fixed)
    common = [sys.executable, '-B', CONTROLLER / 'run.py', '--build', ROOT / 'build-02',
              '--reference', ROOT / 'reference-02', '--adapter', Path(cfg['adapter']), '--identity', Path(cfg['identity']),
              '--output', OUTPUT, '--profile', PROFILE]
    save(phase / 'planned-commands.json', dict(freeze=[str(x) for x in [*common, '--freeze', '--cpus', '0,2,3', '--operation-id', OPERATION]],
        campaign=[str(x) for x in common], unchanged_run_sha256=RUN_SHA, target_cases=['fr', 'gs32', 'paired16']))

    def interrupted(signum, frame):
        raise InterruptedError('target owner signal ' + str(signum))

    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    try:
        h.command([*common, '--freeze', '--cpus', '0,2,3', '--operation-id', OPERATION], phase, 'freeze', timeout=300)
        profile = json.loads(PROFILE.read_text())
        assert profile['status'] == 'FROZEN_BEFORE_EMU' and profile['cpu_slots'] == list(CPUS)
        assert profile['target_images'] == json.loads((ROOT / 'normal-images-02.json').read_text())
        state.update(status='PROFILE_FROZEN_ENTERING_CAMPAIGN', profile_sha256=sha(PROFILE))
        save(phase / 'state.json', state)
        export = JOB / 'target-launch-01'; assert not export.exists(); export.mkdir()
        export_small(PROFILE, export / 'resource-contract.json')
        export_small(phase / 'planned-commands.json', export / 'planned-commands.json')
        # Campaign and case runners retain their original owner, timeout and
        # cleanup behavior. The outer allowance includes their bounded cleanup.
        h.command(common, phase, 'campaign', timeout=29100)
        actual = json.loads((OUTPUT / 'state.json').read_text())
        assert actual['status'] == 'FIRST_FORWARD_RVV_TARGET_OBSERVATIONS_COMPLETE'
        assert actual['new_emu_runs'] == 3 and not actual['active'] and not actual['cleanup_unknown']
        state.update(status=actual['status'], target_correctness_qualified=True,
                     campaign_state_sha256=sha(OUTPUT / 'state.json'), results_sha256=sha(OUTPUT / 'results.json'))
    except BaseException as error:
        state.update(status='FAILED_OR_PARTIAL', error=repr(error)); raise
    finally:
        changed = [path for path, digest in fixed.items() if not Path(path).is_file() or sha(path) != digest]
        state.update(finished=h.now(), elapsed_seconds=time.monotonic() - begin, changed_inputs=changed)
        if changed:
            state.update(status='FAILED_OR_PARTIAL', target_correctness_qualified=False)
        save(phase / 'state.json', state)
        export = JOB / 'target-launch-01'
        export.mkdir(exist_ok=True)
        for path in phase.iterdir():
            if path.is_file() and not (export / path.name).exists():
                export_small(path, export / path.name)
        for name in ('state.json', 'results.json'):
            export_small(OUTPUT / name, export / ('campaign-' + name))
        print(json.dumps(state), flush=True)
    assert not changed


if __name__ == '__main__':
    main()
