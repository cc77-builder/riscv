# P/PQ reference batch

CPU1; GNU -j1; exactly three serial original NEMU processes at most; 100M API calls / 600s internal / 630s owner per process; 2100s whole batch including preparation and cleanup. No automatic extension; no target EMU; no performance qualification.
