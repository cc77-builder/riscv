/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/consumer-build-01/objects/main.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/consumer-build-01/source/main.c \
 /home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am/libs/klib/include/klib.h \
 /home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am/am/am.h \
 /home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am/am/include/arch/riscv64-xs.h \
 /home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am/am/include/arch/riscv64-nemu.h \
 /home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am/am/include/arch/riscv32-nemu.h \
 /home/lizufan/riscv-lab/t17-clean-20261024-0854/clean-02/xs-env/nexus-am/libs/klib/include/printf.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/consumer-build-01/source/consumer_w2.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/consumer-build-01/source/consumer.h
