"""Explicit, comparable native compiler settings for new O1/T14 builds.

Legacy receipts remain valid only for their frozen workflow. This contract is
required when selecting a new O1 reference build instead of the historical EMU.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import subprocess
import zipfile
import copy

MAKE_ARGS = ["CONFIG=MinimalConfig", "NUM_CORES=1", "EMU_THREADS=1", "JVM_XMX=12G",
             "OPT_FAST=-O3", "OPT_SLOW=-O0", "EMU_TRACE=0", "WITH_CHISELDB=0",
             "WITH_CONSTANTIN=0", "WITH_ROLLINGDB=0", "-j2"]
SPLIT_MAKE_ARGS = [arg if arg != "JVM_XMX=12G" else "JVM_XMX=6G" for arg in MAKE_ARGS]
SPLIT_MAKE_ARGS.insert(4, "JVM_XSS=16m")
SPLIT_PROFILES = ("split-v1", "split-clang-v1", "split-clang-v2")
CLANG_PROFILES = ("split-clang-v1", "split-clang-v2")
CLANG_COMMANDS = {"cxx": "clang++-19", "cc": "clang-19"}
CLANG_LINK = dict(driver="cxx", linker="ld", archiver="ar", pch_suffix=".gch", pch_include="-include-pch")
NATIVE_RUNTIME_ROLES = ("cxx", "cc", "ar", "ld", "verilator_bin", "firtool", "perl")
SPLIT_PHASES = [
    dict(name="scala-compile", mill_args=["-i", "-Djvm-xmx=6G", "-Djvm-xss=16m", "xiangshan.test.compile"],
         environment=dict(JAVA_OPTS="-Xmx3g -XX:ActiveProcessorCount=2", JAVA_TOOL_OPTIONS="-XX:ActiveProcessorCount=2")),
    dict(name="fir-elaborate", make_args=["sim-verilog", "CONFIG=MinimalConfig", "NUM_CORES=1", "JVM_XMX=6G",
         "JVM_XSS=16m", "CHISEL_TARGET=chirrtl", "-j1"],
         environment=dict(JAVA_OPTS="-Xmx1g -XX:ActiveProcessorCount=2", JAVA_TOOL_OPTIONS="-XX:ActiveProcessorCount=2")),
    dict(name="fir-lower", firtool_args=["build/rtl/SimTop.fir", "--format=fir", "--split-verilog", "-o", "build/rtl",
         "--mlir-disable-threading", "--repl-seq-mem", "--repl-seq-mem-file=SimTop.sv.conf", "-O=release",
         "--disable-annotation-unknown", "--lowering-options=explicitBitcast,disallowLocalVariables,disallowPortDeclSharing,locationInfoStyle=none"]),
    dict(name="memory-generate", script="scripts/gen_sep_mem.sh",
         arguments=["scripts/vlsi_mem_gen", "build/rtl/SimTop.sv.conf", "build/rtl"]),
    dict(name="rtl-postprocess", implementation="root-Makefile-default-assertions-and-git-comment-v1"),
    dict(name="native-compile", make_args=["emu", *SPLIT_MAKE_ARGS],
         environment=dict(JAVA_OPTS="-Xmx1g -XX:ActiveProcessorCount=2", JAVA_TOOL_OPTIONS="-XX:ActiveProcessorCount=2")),
]


def environment():
    """Only tool bootstrap settings may enter a new native build.

    In particular, do not inherit Make variables, BASH_ENV, preload/include
    paths or PGO flags. activate.sh reconstructs project paths inside this
    environment; its bytes belong to the hardware input inventory.
    """
    names = ("HOME", "PATH", "JAVA_HOME", "JAVA_OPTS", "JAVA_TOOL_OPTIONS",
             "COURSIER_REPOSITORIES", "TEAM_XS_ENV_ROOT")
    result = {key: os.environ[key] for key in names if key in os.environ}
    result.update(LANG="C.UTF-8", LC_ALL="C.UTF-8", TZ="UTC")
    return result


def probe_tools(profile="direct", firtool_dir=None):
    """Resolve compiler payloads, rejecting unbound launcher indirection."""
    if profile not in ("direct", *SPLIT_PROFILES):
        raise ValueError("unsupported native recipe profile")
    result = {}
    clang = profile in CLANG_PROFILES
    selected = [("cxx", "clang++-19" if clang else "g++", "--version"),
        ("cc", "clang-19" if clang else "gcc", "--version"),
        ("java", "java", "-version"), ("bash", "bash", "--version"),
        ("sh", "/bin/sh", "-c"), ("time", "/usr/bin/time", "--version"), ("mill", "mill", "--version"),
        ("verilator", "verilator", "--version"),
        ("firtool", str((Path(firtool_dir) if firtool_dir is not None else
                        Path.home()/".cache/llvm-firtool/1.62.1/bin") / "firtool"), "--version")]
    if profile in SPLIT_PROFILES:
        selected += [("python", "python3", "--version"), ("make", "make", "--version")]
    if profile == "split-clang-v2":
        selected += [("ar", "ar", "--version"), ("ld", "ld", "--version"), ("ldd", "/usr/bin/ldd", "--version"),
                     ("perl", "/usr/bin/perl", "--version")]
    for role, command, option in selected:
        path = shutil.which(command)
        if not path:
            raise ValueError("missing compiler " + command)
        # clang++ is commonly a symlink to clang. Preserve the driver basename
        # for C++ linking, while independently binding its resolved payload.
        path = Path(path).absolute() if clang and role in CLANG_COMMANDS else Path(path).resolve()
        # The supported Mill 0.12 launcher is itself the executable JAR. A
        # shell wrapper's hash would leave its actual compiler payload unbound.
        if role == "mill" and not zipfile.is_zipfile(path):
            raise ValueError("mill must resolve directly to its executable JAR payload")
        command = ([result["sh"]["path"], str(path), option] if role == "mill" else [str(path), option])
        if role == "sh":
            # GNU time uses execvp, whose ENOEXEC fallback is /bin/sh for
            # Mill's executable JAR. Dash has no --version option; record a
            # successful shell probe together with its executable digest.
            command.append("printf '%s\\n' 'POSIX shell ENOEXEC fallback'")
        result[role] = dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                           version=subprocess.check_output(command, text=True, stderr=subprocess.STDOUT))
        if clang and role in CLANG_COMMANDS:
            result[role]["payload_path"] = str(path.resolve())
            if not re.search(r"\bclang version 19\.", result[role]["version"]):
                raise ValueError(profile + " requires Clang 19: " + role)
    # Ubuntu's verilator executable is a Perl launcher; normal (non-debug)
    # operation dispatches to its sibling binary. The restricted environment
    # excludes VERILATOR_ROOT/VERILATOR_BIN, so there is no inherited override.
    payload = Path(result["verilator"]["path"]).with_name("verilator_bin")
    if not payload.is_file():
        raise ValueError("missing sibling Verilator compiler payload: " + str(payload))
    payload = payload.resolve()
    result["verilator_bin"] = dict(path=str(payload), sha256=hashlib.sha256(payload.read_bytes()).hexdigest(),
        version=subprocess.check_output([str(payload), "--version"], text=True, stderr=subprocess.STDOUT))
    return result


def verilator_support(root):
    """Bind installed Make rules and runtime sources used by generated C++."""
    root = Path(root).resolve()
    paths = sorted(path for path in (root / "include").rglob("*") if path.is_file())
    paths.append(root / "bin/verilator_includer")
    files = {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    return dict(root=str(root), files=files)


def compiler_runtime(tools):
    """Resolve the shared-library closure of the trusted installed compilers."""
    files = {}
    binaries = {str(Path(tools[role]["path"]).resolve()) for role in NATIVE_RUNTIME_ROLES}
    for binary in sorted(binaries):
        result = subprocess.run([tools["ldd"]["path"], binary], text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if "not found" in result.stdout:
            raise ValueError("unresolved native compiler library: " + binary)
        if result.returncode:
            if "not a dynamic executable" in result.stdout or "statically linked" in result.stdout:
                continue
            raise ValueError("cannot resolve native compiler libraries: " + binary)
        for name in re.findall(r"(/[^\s]+)\s+\(", result.stdout):
            path = Path(name).resolve()
            files[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    if not all(any(Path(name).name.startswith(prefix) for name in files)
               for prefix in ("libclang-cpp.so.", "libLLVM.so.")):
        raise ValueError("missing dynamically loaded Clang/LLVM implementation")
    return dict(roles=list(NATIVE_RUNTIME_ROLES), files=dict(sorted(files.items())))


def probe_linked_tools(profile, firtool_dir=None):
    tools = probe_tools(profile, firtool_dir)
    config = subprocess.check_output([tools["verilator"]["path"], "-V"], text=True)
    roots = re.findall(r"^\s*VERILATOR_ROOT\s*=\s*(\S+)\s*$", config, re.MULTILINE)
    if len(set(roots)) != 1:
        raise ValueError("cannot bind installed Verilator runtime root")
    return dict(compilers=tools, verilator_support=verilator_support(roots[0]), compiler_runtime=compiler_runtime(tools))


def capture(root, profile="direct", firtool_dir=None):
    # Probe in precisely the environment used by the build; explicitly pass
    # these compiler paths to Make instead of merely recording clang --version.
    if profile not in ("direct", *SPLIT_PROFILES):
        raise ValueError("unsupported native recipe profile")
    probe_name = "probe_linked_tools" if profile == "split-clang-v2" else "probe_tools"
    # Preserve the original contract shape when no explicit selection is made.
    selected_dir = str(Path(firtool_dir).resolve()) if firtool_dir is not None else None
    probe_args = repr(profile) + (", firtool_dir=" + repr(selected_dir) if selected_dir is not None else "")
    probe = ("import json,runpy; helper=runpy.run_path(" + repr(str(Path(__file__).resolve())) +
             "); print(json.dumps(helper[" + repr(probe_name) + "](" + probe_args + ")))")
    command = "source team/scripts/activate.sh\npython3 -c " + shlex.quote(probe)
    clean = environment()
    captured = json.loads(subprocess.check_output(["bash", "-c", command], cwd=root, text=True, env=clean))
    support = captured["verilator_support"] if profile == "split-clang-v2" else None
    runtime = captured["compiler_runtime"] if profile == "split-clang-v2" else None
    if support is not None:
        captured = captured["compilers"]
    metadata = Path(root) / ".mill-version"
    result = dict(schema=2, make_args=list(MAKE_ARGS), compilers=captured,
                mill_launch=[captured["sh"]["path"], captured["mill"]["path"]],
                launch_metadata={".mill-version": dict(sha256=hashlib.sha256(metadata.read_bytes()).hexdigest(),
                                                       value=metadata.read_text(encoding="utf-8").strip())},
                environment_sha256=hashlib.sha256(json.dumps(clean, sort_keys=True).encode()).hexdigest(),
                recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    if profile in SPLIT_PROFILES:
        result.update(schema=3, profile=profile, make_args=list(SPLIT_MAKE_ARGS), phases=copy.deepcopy(SPLIT_PHASES),
                      split_script_sha256=hashlib.sha256(Path(__file__).with_name("split_recipe.py").read_bytes()).hexdigest())
    if profile in CLANG_PROFILES:
        result["compiler_commands"] = dict(CLANG_COMMANDS)
    if profile == "split-clang-v2":
        result.update(native_link=dict(CLANG_LINK), verilator_support=support, compiler_runtime=runtime)
    if selected_dir is not None:
        result["firtool_directory"] = selected_dir
    return result


def validate(contract):
    if not isinstance(contract, dict):
        raise ValueError("unsupported native build contract")
    if "firtool_directory" in contract:
        directory = contract["firtool_directory"]
        if (not isinstance(directory, str) or not PurePosixPath(directory).is_absolute()
                or ".." in PurePosixPath(directory).parts or "\x00" in directory):
            raise ValueError("invalid explicit firtool directory")
    if contract.get("schema") == 2:
        if contract.get("make_args") != MAKE_ARGS or any(name in contract for name in ("profile", "phases", "split_script_sha256")):
            raise ValueError("unsupported native build contract")
    elif contract.get("schema") == 3:
        if (contract.get("profile") not in SPLIT_PROFILES or contract.get("make_args") != SPLIT_MAKE_ARGS or
                contract.get("phases") != SPLIT_PHASES or
                not re.fullmatch(r"[0-9a-f]{64}", contract.get("split_script_sha256", ""))):
            raise ValueError("unsupported split native build contract")
    else:
        raise ValueError("unsupported native build contract")
    if contract.get("profile") in CLANG_PROFILES:
        if contract.get("compiler_commands") != CLANG_COMMANDS:
            raise ValueError("missing Clang 19 driver selection")
        for role, command in CLANG_COMMANDS.items():
            tool = contract.get("compilers", {}).get(role, {})
            if (PurePosixPath(tool.get("path", "")).name != command or
                    not PurePosixPath(tool.get("payload_path", "")).is_absolute() or
                    not re.search(r"\bclang version 19\.", tool.get("version", ""))):
                raise ValueError("split Clang profile requires bound Clang 19 driver: " + role)
    elif "compiler_commands" in contract:
        raise ValueError("Clang driver selection requires split Clang profile")
    if contract.get("profile") == "split-clang-v2":
        support = contract.get("verilator_support", {})
        files = support.get("files", {})
        if (contract.get("native_link") != CLANG_LINK or
                not PurePosixPath(support.get("root", "")).is_absolute() or not isinstance(files, dict) or
                not {"include/verilated.mk", "include/verilated.h", "include/verilated.cpp", "bin/verilator_includer"} <= files.keys()):
            raise ValueError("incomplete Clang link/runtime contract")
        for name, digest in files.items():
            if (PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts or
                    not re.fullmatch(r"[0-9a-f]{64}", digest)):
                raise ValueError("invalid Verilator runtime inventory")
        runtime = contract.get("compiler_runtime", {})
        libraries = runtime.get("files", {})
        if (runtime.get("roles") != list(NATIVE_RUNTIME_ROLES) or not isinstance(libraries, dict) or
                not all(any(PurePosixPath(name).name.startswith(prefix) for name in libraries)
                        for prefix in ("libclang-cpp.so.", "libLLVM.so."))):
            raise ValueError("missing native compiler implementation libraries")
        for name, digest in libraries.items():
            if (not PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts or
                    not re.fullmatch(r"[0-9a-f]{64}", digest)):
                raise ValueError("invalid native compiler library inventory")
    elif any(name in contract for name in ("native_link", "verilator_support", "compiler_runtime")):
        raise ValueError("explicit link/runtime contract requires split-clang-v2")
    if not all(re.fullmatch(r"[0-9a-f]{64}", contract.get(key, ""))
               for key in ("environment_sha256", "recipe_sha256")):
        raise ValueError("incomplete native build contract")
    metadata = contract.get("launch_metadata", {})
    if (set(metadata) != {".mill-version"} or not isinstance(metadata[".mill-version"], dict)
            or not metadata[".mill-version"].get("value")
            or not re.fullmatch(r"[0-9a-f]{64}", metadata[".mill-version"].get("sha256", ""))):
        raise ValueError("missing Mill launcher metadata identity")
    roles = ("cxx", "cc", "java", "bash", "sh", "time", "mill", "verilator", "verilator_bin", "firtool")
    if contract["schema"] == 3:
        roles += ("python", "make")
    if contract.get("profile") == "split-clang-v2":
        roles += ("ar", "ld", "ldd", "perl")
    for role in roles:
        tool = contract.get("compilers", {}).get(role, {})
        if (not PurePosixPath(tool.get("path", "")).is_absolute() or not tool.get("version")
                or not re.fullmatch(r"[0-9a-f]{64}", tool.get("sha256", ""))):
            raise ValueError("missing native tool identity: " + role)
    if contract.get("mill_launch") != [contract["compilers"]["sh"]["path"], contract["compilers"]["mill"]["path"]]:
        raise ValueError("missing bound Mill shell launch command")


def make_overrides(contract):
    validate(contract)
    result = ["SHELL=" + contract["compilers"]["bash"]["path"],
            # Make expands TIMELOG in its own scope. Shell quoting preserves
            # the expression until then, including output paths with spaces.
            "TIME_CMD=" + shlex.join([contract["compilers"]["time"]["path"], "-avp", "-o", "$(TIMELOG)"]),
            "CXX=" + contract["compilers"]["cxx"]["path"],
            "CC=" + contract["compilers"]["cc"]["path"]]
    if contract.get("profile") == "split-clang-v2":
        result += ["LINK=" + shlex.join([contract["compilers"]["cxx"]["path"],
                   "--ld-path=" + contract["compilers"]["ld"]["path"]]),
                   "AR=" + contract["compilers"]["ar"]["path"], "CFG_GCH_IF_CLANG=.gch",
                   "CFG_CXXFLAGS_PCH_I=-include-pch", "PYTHON3=" + contract["compilers"]["python"]["path"],
                   "PERL=" + contract["compilers"]["perl"]["path"]]
    return result


def make_command(contract, products=None):
    validate(contract)
    executable = contract["compilers"]["make"]["path"] if contract["schema"] == 3 else "make"
    args = [executable, "emu", *contract["make_args"], *make_overrides(contract)]
    if products is not None:
        args.append("BUILD_DIR=" + str(products))
    return shlex.join(args) + "\n"


def execution_command(contract, pins_path, output):
    """Select an explicit fresh recipe; split never resumes a direct build."""
    validate(contract)
    if contract["schema"] == 2:
        return make_command(contract)
    return shlex.join([contract["compilers"]["python"]["path"], str(Path(__file__).with_name("split_recipe.py").resolve()),
                       "--pins", str(pins_path), "--output", str(Path(output) / "split")]) + "\n"


def verify(root, expected):
    validate(expected)
    options = {"firtool_dir": expected["firtool_directory"]} if "firtool_directory" in expected else {}
    if capture(root, expected.get("profile", "direct"), **options) != expected:
        raise ValueError("native compiler/build contract changed")


def firtool_directory(contract):
    """Use the recorded selector, or the legacy bound executable's directory."""
    validate(contract)
    return contract.get("firtool_directory", str(PurePosixPath(contract["compilers"]["firtool"]["path"]).parent))
