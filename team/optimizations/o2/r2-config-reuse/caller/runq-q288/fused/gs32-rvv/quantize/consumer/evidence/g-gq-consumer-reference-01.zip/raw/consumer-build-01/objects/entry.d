/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/consumer-build-01/objects/entry.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/quantize-gs32-20261106-pro3/consumer-build-01/source/entry.S
