from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess,os,importlib.util,struct
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
monitor=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
target=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target'
runroot=root.parents[1]/'runs/fullq-phased-target-20261026-1255'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='fcf4a11fc569cb2a8fcb4e18d96ec2764b228557'
assert git('branch','--show-current').decode().strip()=='work/lizufan-dev' and git('status','--porcelain')==b''
assert not (root/'.git/index.lock').exists()
record=json.loads((runroot/'build-03/build.json').read_text())
pins=record['software_files'];assert record['accepted'] is True and record['exit_code']==0 and len(pins)==106
assert all(sha(root/n)==v for n,v in pins.items())
comparison=json.loads((monitor/'q288-phased-image-comparison-171.json').read_text())
assert comparison['load_segments_equal'] and set(comparison['changed_sections'])=={'.debug_line','.debug_info','.debug_line_str'}
for b,files in comparison['images'].items():
 for n,v in files.items():assert sha(runroot/b/n)==v['sha256']
assert sha(runroot/'build-03/vdot-perf.bin')==sha(runroot/'build-02/vdot-perf.bin')
for n in ('q288-phased-build-03-launch-failure-171.json','q288-phased-image-comparison-171.json'):
 dest=runroot/n;assert not dest.exists();dest.write_bytes((monitor/n).read_bytes())
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
spec=importlib.util.spec_from_file_location('phased_target_ready',target/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
controls=m.elf_controls(runroot/'build-03',runroot/'elf-controls-03')
spec=importlib.util.spec_from_file_location('phased_target_audit_ready',target/'archive.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
auditors=a.tools()
assert m.sources(root)==pins
busy=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=(p/'exe').resolve().name
  if exe in ('emu','verilator','cc1','cc1plus','make','g++','riscv64-linux-gnu-gcc'):busy.append(dict(pid=int(p.name),exe=exe))
 except (OSError,RuntimeError):pass
assert not busy,busy
owned=[(target/n).relative_to(root).as_posix() for n in ('generate.py','run.py','main.c','archive.py','CONTRACT.md')]
git('add','-f','--',*owned)
staged=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1]
assert set(staged)==set(owned) and len(staged)==5,staged
git('diff','--cached','--check')
commit=subprocess.run(['git','-C',str(root),'commit','-m','test: freeze phased Q288 same-ELF target contract'],capture_output=True,text=True)
receipt=dict(command=commit.args,exit_code=commit.returncode,stdout=commit.stdout,stderr=commit.stderr)
(runroot/'freeze-commit-command.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert commit.returncode==0,receipt
head=git('rev-parse','HEAD').decode().strip()
assert git('status','--porcelain')==b'' and set(git('diff','--name-only','HEAD^','HEAD').decode().splitlines())==set(owned)
assert m.sources(root)==pins
report=dict(status='PHASED_TARGET_FROZEN_AND_READY',finished=datetime.now(timezone(timedelta(hours=8))).isoformat(),
 commit=head,parent=git('rev-parse','HEAD^').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),
 build=(runroot/'build-03').as_posix(),build_source_commit=record['source_commit'],
 sources={n:sha(target/n) for n in ('generate.py','run.py','main.c','archive.py','CONTRACT.md')},
 source_closure=len(pins),supplementary_auditors=auditors,elf_sha256=sha(runroot/'build-03/vdot-perf.elf'),
 bin_sha256=sha(runroot/'build-03/vdot-perf.bin'),loaded_program_equal_build02=True,
 only_elf_debug_sections_changed=sorted(comparison['changed_sections']),
 control_status=controls['status'],actual_array_and_fp_mutants=len(controls['controls']),
 phased_semantic_controls=controls['phased_semantic_controls'],selector_control_status=controls['selector_regression']['status'],
 no_busy_build_or_emu=True,new_emu_runs=0)
(runroot/'readiness-final.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
