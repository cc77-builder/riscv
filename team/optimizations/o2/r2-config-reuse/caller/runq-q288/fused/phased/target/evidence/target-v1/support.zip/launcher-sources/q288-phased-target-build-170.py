from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess,os,importlib.util
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
monitor=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
target=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target'
runroot=root.parents[1]/'runs/fullq-phased-target-20261026-1255'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='fcf4a11fc569cb2a8fcb4e18d96ec2764b228557' and git('status','--porcelain')==b''
pins=json.loads((runroot/'build-02/build.json').read_text())['software_files']
assert all(sha(root/n)==v for n,v in pins.items())
changes=json.loads((monitor/'q288-phased-target-patch-169.json').read_text())
assert set(changes)=={'archive.py','CONTRACT.md'} and not (runroot/'build-03').exists()
for n,text in changes.items():(target/n).write_text(text,encoding='utf-8')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
spec=importlib.util.spec_from_file_location('phased_target_actual_run3',target/'run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
identity=root/m.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
result=m.build(root,identity,runroot/'build-03')
for n in ('vdot-perf.elf','vdot-perf.bin'):assert sha(runroot/'build-03'/n)==sha(runroot/'build-02'/n),n
controls=m.elf_controls(runroot/'build-03',runroot/'elf-controls-03')
spec=importlib.util.spec_from_file_location('phased_target_audit3',target/'archive.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
auditors=a.tools()
pins3=json.loads((runroot/'build-03/build.json').read_text())['software_files']
assert len(pins3)==106 and all(sha(root/n)==v for n,v in pins3.items())
assert {n for n in pins if pins[n]!=pins3[n]}=={(target/n).relative_to(root).as_posix() for n in changes}
report=dict(status='PHASED_TARGET_FINAL_BUILD_AND_ELF_CONTROLS_PASS',finished=datetime.now(timezone(timedelta(hours=8))).isoformat(),
 build=(runroot/'build-03').as_posix(),sources={n:sha(target/n) for n in ('generate.py','run.py','main.c','archive.py','CONTRACT.md')},
 source_closure=len(pins3),supplementary_auditors=auditors,elf_sha256=sha(runroot/'build-03/vdot-perf.elf'),
 bin_sha256=sha(runroot/'build-03/vdot-perf.bin'),image_bytes_equal_build02=True,build_result=result,
 control_status=controls['status'],new_emu_runs=0)
(runroot/'readiness-final.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='build_result'},indent=2))
