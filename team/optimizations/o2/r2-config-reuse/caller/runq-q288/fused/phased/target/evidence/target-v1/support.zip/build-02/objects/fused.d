/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/objects/fused.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/source/fused.S
