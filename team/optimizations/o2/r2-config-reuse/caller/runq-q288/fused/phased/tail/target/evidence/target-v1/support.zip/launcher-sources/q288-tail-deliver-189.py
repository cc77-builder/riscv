from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess,traceback,zipfile

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=ROOT.parents[1]/'runs/fullq-tail-target-20261026-1400'
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
MODULE=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/tail')
TARGET=MODULE/'target'
FROZEN='a9583d1c0f30565c97a85775b489f1466fa34cad'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for raw in iter(lambda:f.read(1048576),b''):h.update(raw)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def need(ok,message):
    if not ok:raise ValueError(message)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def pack(path,files):
    members={}
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in sorted(files.items()):
            raw=p.read_bytes();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.create_system=3
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw,compresslevel=6)
            members[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    with zipfile.ZipFile(path) as z:
        need(set(z.namelist())==set(members) and len(z.namelist())==len(members),'exact support inventory')
        for name,pin in members.items():
            raw=z.read(name);need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'support original bytes '+name)
    return dict(archive_sha256=sha(path),archive_bytes=path.stat().st_size,members=members)

def main(base):
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1])
    need(re.fullmatch('[0-9a-f]{40}',base) and git('rev-parse','HEAD').decode().strip()==base and
         git('status','--porcelain')==b'','exact clean delivery base')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    api=read(RUN/'api-delivery-01.json')
    need(api['status']=='Q288_ORDINARY_C_TWO_VARIANT_DELIVERED' and api['base']==FROZEN and api['commit']==base,
         'only reviewed ordinary C delivery follows frozen target')
    changed=set(filter(None,git('diff','--name-only','-z',FROZEN,base).decode().split('\0')))
    need(changed==set(api['files']),'exact intervening API paths')
    for name,pin in api['files'].items():need(sha(ROOT/name)==pin['sha256'],'delivered API byte identity '+name)
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name not in ('emu','verilator_bin','cc1','cc1plus','make','ninja'),'no active heavy task')
        except OSError:pass
    closure=read(RUN/'archive-driver-01.json');ready=read(RUN/'preparation-01.json')
    need(closure['status']=='TAIL_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED' and closure['head']==FROZEN and
         ready['status']=='TAIL_TARGET_FROZEN_AND_READY' and ready['commit']==FROZEN,'original frozen evidence closed')
    need(sha(RUN/'preparation-01.json')==closure['preparation_sha256'],'same preparation receipt sealed by original audit')
    pins=read(RUN/'build-01/build.json')['software_files'];auditors=ready['supplementary_auditors']
    need(len(pins)==115 and len(auditors)==5 and ready['source_files']==pins and auditors==closure['supplementary_auditors'],'original source identities')
    need(all(pins[n]==pin for n,pin in auditors.items() if n in pins),'overlapping frozen identities agree')
    need(sha(RUN/'screen-01/result.json')==ready['static_result_sha256'] and
         sha(RUN/'elf-controls-01/result.json')==ready['target_controls_sha256'],'same original static and target control results')
    def check_inputs():
        for name,pin in {**pins,**auditors}.items():need(sha(ROOT/name)==pin,'frozen runtime input '+name)
        for name,pin in ready['source_sha256'].items():need(sha(ROOT/MODULE/name)==pin,'all eleven candidate source/doc identities '+name)
    check_inputs()
    archive=RUN/'evidence-pack-01';fresh=RUN/'fresh-source-audit-01'
    manifest=read(archive/'archive-manifest.json');history=read(archive/'history/manifest.json')
    need({p.relative_to(archive).as_posix() for p in archive.rglob('*') if p.is_file()}==
         {'payload.zip','archive-manifest.json','original-audit.json','history/manifest.json','history/objects.pack','history/commands.json'},'exact six archive files')
    for name,pin in closure['archive_files'].items():need(sha(archive/name)==pin,'closed raw archive '+name)
    need(manifest['payload_sha256']==sha(archive/'payload.zip') and manifest['stored_bytes']==(archive/'payload.zip').stat().st_size,'raw payload identity')
    need(manifest['historical_git']['manifest_sha256']==sha(archive/'history/manifest.json') and
         manifest['historical_git']['pack_sha256']==history['pack_sha256']==sha(archive/'history/objects.pack') and
         history['command_sha256']==sha(archive/'history/commands.json'),'historical original Git objects and receipts')
    need(sha(fresh/'result.json')==closure['fresh_source_result_sha256'],'actual fresh-source result identity')
    recovery=RUN/'campaign-01/runs/recovery';replay=RUN/'campaign-01/runs/replay'
    need((recovery/'validation.json').read_bytes()==(replay/'validation.json').read_bytes() and
         sha(recovery/'validation.json')==closure['validation_sha256'],'same sealed original and replay validation')
    value=read(recovery/'validation.json');selection=value['selection']
    need(value['status']=='TAIL_TARGET_DIFFTEST_AND_PLAN_PASS' and
         selection==read(archive/'original-audit.json')['selection'],'actual original selected result, including KEEP/HOLD')
    context_path=RUN/'context-comparison-01.json';context=read(context_path)
    need(context['status']=='Q288_CROSS_IMAGE_SOURCE_AND_DATA_IDENTITY_PASS' and
         context['driver_sha256']==sha(MONITOR/'q288-context-compare-193.py')=='7e4c5ceb13a19ee13245800eff0a9e85166a05ba84fd25e73d5cdc3a790ce3e3' and
         context['inputs']['tail']['original_audit_sha256']==closure['archive_files']['original-audit.json'] and
         context['inputs']['tail']['elf_sha256']==ready['elf_sha256'] and
         context['tail_fixed_plan_selection']==selection,'actual sealed cross-image identity and context diagnostic')
    evidence=ROOT/TARGET/'evidence/target-v1';result_path=ROOT/TARGET/'RESULT.md';receipt=RUN/'delivery-01.json'
    need(not evidence.exists() and not result_path.exists() and not receipt.exists(),'new target evidence delivery')
    record=dict(status='COPYING',started=now(),base=base,source_freeze_commit=FROZEN,driver_sha256=sha(__file__),
        closure_sha256=sha(RUN/'archive-driver-01.json'),new_emu_runs=0)
    save(receipt,record)
    try:
        shutil.copytree(archive,evidence/'archive');shutil.copytree(fresh,evidence/'fresh-source')
        shutil.copyfile(context_path,evidence/'context-comparison.json')
        need(sha(context_path)==sha(evidence/'context-comparison.json'),'exact context diagnosis record')
        for directory,label in ((archive,'archive'),(fresh,'fresh-source')):
            for p in directory.rglob('*'):
                if p.is_file():need(sha(p)==sha(evidence/label/p.relative_to(directory)),'verbatim sealed evidence copy')
        support={}
        for directory in ('screen-01','static-command-01','elf-controls-01'):
            base_dir=RUN/directory;need(base_dir.is_dir(),'preserved static/control evidence '+directory)
            for p in base_dir.rglob('*'):
                if p.is_file() and '__pycache__' not in p.parts:support[p.relative_to(RUN).as_posix()]=p
        for p in RUN.iterdir():
            if p.is_file() and p!=receipt:support['drivers/'+p.name]=p
        for name in ('q288-tail-inputs-183.json','q288-tail-build-184.py','q288-tail-launch-186.py',
                     'q288-tail-seal-187.py','q288-tail-deliver-189.py','q288-context-compare-193.py'):
            p=MONITOR/name;need(p.is_file(),'actual driver source '+name);support['launcher-sources/'+name]=p
        driver_pins={'q288-tail-inputs-183.json':'fb108dd308dd386b811d4842e74a0cbbeaa90b57a268b84f1f309dfbd9dd26b3',
            'q288-tail-build-184.py':ready['launcher_sha256'],
            'q288-tail-launch-186.py':'b82e75485be2db8709418826c9f7e830f1223fe69de3b55a62fae768b286f406',
            'q288-tail-seal-187.py':closure['launcher_sha256'],'q288-tail-deliver-189.py':sha(__file__),
            'q288-context-compare-193.py':context['driver_sha256']}
        for name,pin in driver_pins.items():need(sha(MONITOR/name)==pin,'actual executed or frozen driver bytes '+name)
        support_manifest=pack(evidence/'support.zip',support);save(evidence/'support-members.json',support_manifest)
        traces=[dict(name=name,bytes=(p/'stderr.log').stat().st_size,sha256=sha(p/'stderr.log'))
            for name,p in (('recovery',recovery),('replay',replay))]
        need(traces[0]['sha256']==traces[1]['sha256'] and traces[0]['bytes']==traces[1]['bytes'],'raw replay trace equality')
        archived={v['path']:v for v in manifest['files']}
        for trace in traces:
            pin=archived['run/runs/'+trace['name']+'/stderr.log']
            need(trace['bytes']==pin['raw_bytes'] and trace['sha256']==pin['raw_sha256'],'same sealed original stderr '+trace['name'])
        summary=dict(status='TAIL_TARGET_ORIGINAL_EVIDENCE_CLOSED',source_freeze_commit=FROZEN,source_head_at_delivery=base,
            closure=closure,selection=selection,validation_sha256=sha(recovery/'validation.json'),stderr=traces,
            static_result_sha256=ready['static_result_sha256'],target_controls_sha256=ready['target_controls_sha256'],
            cross_image_context_sha256=sha(context_path),cross_image_performance_portability_established=False,
            elf_sha256=ready['elf_sha256'],bin_sha256=ready['bin_sha256'],source_files_unchanged=115,
            supplementary_auditors=5,distinct_source_and_auditor_files=len(set(pins)|set(auditors)),
            support_sha256=support_manifest['archive_sha256'],support_members=len(support_manifest['members']),
            history_objects=len(history['objects']),history_pack_sha256=history['pack_sha256'],
            frozen_sources_unchanged=True,all_original_and_failed_evidence_retained=True,
            original_campaign_new_emu_runs=3,delivery_new_emu_runs=0,hardware_changed=False,stable_default_changed=False)
        save(evidence/'summary.json',summary)
        rows='\n'.join('| '+m['label']+' | '+', '.join(map(str,m['cycles']))+' | '+', '.join(map(str,m['instructions']))+' |' for m in selection['methods'])
        comparisons='\n'.join('- '+c['comparison']+f"：最慢候选 {c['worst_candidate']} / 最快基线 {c['best_baseline']}；保守减少 {100*c['reduction']:.9f}% 周期（负值表示增加），门槛通过={c['qualified']}。" for c in selection['software_comparisons'])
        context_rows=[]
        for name in ('q288_phased_vdot','q288_fused_rvv4'):
            c=context['cross_image_common_method_cycles'][name];addresses=context['common_functions'][name]['addresses']
            context_rows.append('| '+name+' | '+', '.join(map(str,c['phased']['cycles']))+' | '+', '.join(map(str,c['tail']['cycles']))+
                ' | '+hex(addresses['phased'])+' / '+hex(addresses['tail'])+' |')
        context_table='\n'.join(context_rows)
        diagnostic=context['descriptive_diagnostics']
        context_finding=('PV和FR的跨批变化方向相反，排序翻转。' if diagnostic['opposite_mean_change_directions'] and
            diagnostic['common_method_ordering_reversed'] else '共同PV/FR的跨批原始变化如上；仅作上下文诊断。')
        common_entries_equal=all(v['addresses']['phased']==v['addresses']['tail'] for v in context['common_functions'].values())
        data_address_deltas=sorted({v['addresses']['tail']-v['addresses']['phased'] for v in context['common_arrays'].values()})
        mutable_address_deltas=sorted({v['tail']['address']-v['phased']['address'] for v in context['mutable_object_layout'].values()})
        packed_addresses={n:context['common_arrays']['q_packed']['addresses'][n]+context['common_arrays']['q_packed']['value_offset'] for n in ('phased','tail')}
        layout_note=(f"共同四函数入口地址相同={common_entries_equal}；十项输入/计划数组地址变化集合为{data_address_deltas}字节，"
            f"记录的输出/slots/context/计时缓冲变化集合为{mutable_address_deltas}字节。packed有效起点为"
            f"{hex(packed_addresses['phased'])} / {hex(packed_addresses['tail'])}。这些是实际布局差异，尚未隔离为周期变化的原因。")
        selected=selection['selected_method'] or '无新选择；上下文门槛未通过'
        result_path.write_text(f'''# Q288 两位 tail-agnostic：完整目标对照闭合

结论：`{selection['decision']}`，本合同选择 `{selected}`；`tail_promoted={selection['tail_promoted']}`。完整原始观察及预定选择器决定采用或保留，重放不增加样本数。R5稳定默认、T17 RTL和原有回退入口均保持。

| 方法 | 原始周期 | CSR instret |
|---|---|---|
{rows}

{comparisons}

八窗固定顺序 `FR,PV,TV,FR | FR,TV,PV,FR`，每窗前一次同方法完整Q selfwarm。四个FR全部保留，1%锚点和TV同时保守胜过PV/FR至少0.5%的门槛在运行前冻结；未晋级时按原规则保留合格PV或FR，锚点失败则HOLD。具体合同见 [CONTRACT.md](CONTRACT.md)，实际选择及源码身份见 [summary.json](evidence/target-v1/summary.json)。

## 唯一候选变化及其依据

TV相对PV只将764字节函数体内偏移60/336的两条e8 vsetivli从 `0xc0047057` 改为 `0xc4047057`。131字整数核、两阶段算术、寻址语义、FP顺序、ABI及最后TU返回配置保持；不是新RTL。

当前内部vdot合同接受vta/vma四种策略组合，目的高96位始终清零；本候选没有扩大该合法域。

[静态合同](../CONTRACT.md)要求真实GNU ELF的精确两位差异、既有完整算术证明、任意尾值非干扰，以及完整机器码数值/地址/ABI模型共同成立。17源实际静态筛选通过；错误X/W/reduction被独立语义与数值检查拒绝，尾部流/身份控制和实际目标数组、FP及选择器控制均保留。目标verifier在首次EMU之前即重新计算并与缓存完整严格比较，通过后才冻结。

[硬件来源分析](../HARDWARE.md)将普通向量load的旧vd依赖消除条件绑定到实际T17输入。它支持尝试该假设，但本轨迹没有逐条记录普通load的ignoreOldVd事件，故不能把全部周期变化定量归因到某一RF读或IQ等待。自定义dot本身早已免除相应旧vd依赖。没有宣称取消RAT查询、物理寄存器分配、load微操作或固定FU时延。

## 正确性、拒错、恢复和重放

原三进程按负控→恢复→重放执行；负控按预定拒绝高96位错误，恢复/重放均完整DiffTest通过。每个正常进程包含22次完整Q、6336个输出、7128个整数核、124417条custom（含1条probe）、41472条计时custom，以及32项CSR/COUNTER事件。两份validation原字节相同；两份stderr各{traces[0]['bytes']:,}字节，SHA `{traces[0]['sha256']}` 相同。

冻结提交 `{FROZEN}`，115项运行源及5项补充审计器分别核对；两集合有重叠，实际并集为{len(set(pins)|set(auditors))}文件。ELF SHA `{ready['elf_sha256']}`，BIN SHA `{ready['bin_sha256']}`。原build的构建时基点仍按记录保留，不回写成冻结提交。全部旧phased/fused/acc8源与已经闭合的运行证据未改、未重跑。

## 原文封存与可复现边界

原文归档{len(manifest['files'])}成员、{manifest['raw_bytes']:,}字节；ZIP {manifest['stored_bytes']:,}字节，SHA `{manifest['payload_sha256']}`。新Python进程只使用已封存源码、必要历史Git对象及明确补充审计器复算，八个原依赖拒绝根、退出码及完整原文结果相等检查全部通过，见 [fresh-source result](evidence/target-v1/fresh-source/result.json)。宿主审计使用冻结900秒durable适配，零新增EMU；启动端仍需要所列审计源码，不宣称仅一个ZIP就自足。

静态、GNU构建/实际ELF破坏、准备记录及驱动源保留在 [support成员清单](evidence/target-v1/support-members.json) 对应ZIP；所有原始与失败证据保留，没有为了通过封存而改旧缓存、官方验证程序或判定阈值。

普通C显式入口、去重导出、相同布局回退及真实最终链接检查见 [使用说明](../../README.md)。API链接检查仅证明实际调用和完整函数字节，不把新的ELF地址/布局自动授予本批周期资格。

## 跨镜像上下文敏感性

离线 [完整身份/地址对照](evidence/target-v1/context-comparison.json) 核实PV、FR、FV和公共计时器在两批中完整函数字节相同，十个输入/slot计划数组原字节相同，父硬件/参考身份相同；同时记录实际函数、输入、输出、slots及context地址和函数指针映射。两批的slot编号计划相同，但各slot所指的方法不同，完整调用历史与ELF上下文不相同。

| 共同方法 | 原phased批周期 | 本TA批周期 | 两批入口地址 |
|---|---|---|---|
{context_table}

{layout_note}

{context_finding}上述跨批数据只作上下文诊断，不能用一个统一倍率校正，不能把旧批FV→PV与新批PV→TV收益相乘，也不能选旧批较慢FR作TV分母。原1%锚点只约束各自批内稳定性；不事后改变任何冻结判据。

本批固定计划的选择结果按原规则保留，但跨ELF普遍加速与单一old-vd机制因果份额尚未建立。若后续需要量化两位策略的净作用，应另立合同，在相同函数槽/数据地址/调用与预热计划下，仅改变这两条机器字，实验身份放外部记录；本轮没有执行该额外EMU，也不把它追加为本批门禁。更广采用仍须实际消费者最终ELF与使用条件下的周期比较。

## 资格范围与取舍

资格限本次固定合成、已量化、已打包的288×288 Q及具名FR比较。没有计入pack、量化、模型加载、token或模型质量；同方法selfwarm不是所有缓存全热的证明。软件改变没有改变这次T17硬件实物；本轮没有新增ASIC面积、时序或功耗测量，也没有将局部Q收益推广到完整应用。
''')
        names=sorted([result_path.relative_to(ROOT).as_posix()]+[p.relative_to(ROOT).as_posix() for p in evidence.rglob('*') if p.is_file()])
        need(not set(names)&set(pins) and not set(names)&set(api['files']),'only new TA evidence/result paths')
        for name in names:
            if name.endswith(('.zip','.pack','.gz')):
                attrs=git('check-attr','binary','text','--',name).decode();need(': binary: set' in attrs and ': text: unset' in attrs,'archive byte-preserving Git attributes')
        need(git('rev-parse','HEAD').decode().strip()==base and git('diff','--name-only')==b'' and git('diff','--cached','--name-only')==b'','no concurrent tracked/index mutation')
        git('add','-f','--',*names)
        need(set(filter(None,git('diff','--cached','--name-only','-z').decode().split('\0')))==set(names),'exact new TA staged paths')
        for name in names:need(git('show',':'+name)==(ROOT/name).read_bytes(),'staged evidence raw bytes '+name)
        git('diff','--cached','--check');check_inputs()
        git('-c','gc.auto=0','commit','-m','Seal two-bit Q288 tail experiment with original evidence and fixed selection')
        need(git('status','--porcelain')==b'','clean TA evidence delivery')
        record.update(status='TAIL_TARGET_DELIVERY_COMMITTED',finished=now(),commit=git('rev-parse','HEAD').decode().strip(),
            tree=git('rev-parse','HEAD^{tree}').decode().strip(),files={n:dict(bytes=(ROOT/n).stat().st_size,sha256=sha(ROOT/n)) for n in names},
            selection=selection,summary_sha256=sha(evidence/'summary.json'),frozen_sources_unchanged=True)
        save(receipt,record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(receipt,record)
        (RUN/'delivery-01.traceback.txt').write_text(traceback.format_exc());raise
    print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);main(p.parse_args().base)
