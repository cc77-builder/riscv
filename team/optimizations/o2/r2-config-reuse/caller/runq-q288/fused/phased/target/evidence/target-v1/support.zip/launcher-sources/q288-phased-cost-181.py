from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,traceback

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255')
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
TARGET=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target')
HEAD='34092ebcf579a5de76e70cadfb6a5333173891ae'
sys.dont_write_bytecode=True
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def need(ok,message):
    if not ok:raise ValueError(message)

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1])
    closure=read(RUN/'archive-driver-02.json')
    need(closure['status']=='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED','closed repaired fresh-source archive')
    auditor=closure['auditor_commit']
    need(git('rev-parse','HEAD').decode().strip()==auditor and git('rev-parse','HEAD^').decode().strip()==HEAD and
         git('status','--porcelain')==b'','exact clean auditor commit over original freeze')
    expected={(TARGET/n).as_posix() for n in ('archive_json.py','ARCHIVE-JSON-CONTRACT.md')}
    need(set(git('diff','--name-only','-z',HEAD,auditor).decode().strip('\0').split('\0'))==expected,'only two supplementary audit inputs added')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name!='emu','no overlapping EMU')
        except OSError:pass
    closure=read(RUN/'archive-driver-02.json')
    need(closure['status']=='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED','closed fresh-source archive')
    pins=read(RUN/'build-03/build.json')['software_files']
    need(len(pins)==106 and all(sha(ROOT/n)==pin for n,pin in pins.items()),'all frozen sources unchanged')
    payload_path=MONITOR/'q288-phased-cost-inputs-177.json'
    need(sha(payload_path)=='ec169e0f8a40e3ee54f3bf8cf1c52a626280b372f0d3468109169dc755c176c5','reviewed analysis payload')
    payload=read(payload_path);need(set(payload['files'])=={'cost.py','COST-CONTRACT.md'},'two new analysis files')
    stage=RUN/'cost-stage-01';output=RUN/'cost-01'
    need(not stage.exists() and not output.exists(),'fresh offline outputs')
    stage.mkdir();record=dict(status='INSTALLING',started=now(),launcher_sha256=sha(__file__),new_emu_runs=0)
    save(stage/'driver.json',record)
    try:
        for name,text in payload['files'].items():
            p=ROOT/TARGET/name;need(not p.exists(),'new analysis source '+name);p.write_text(text)
        need(sha(ROOT/TARGET/'cost.py')=='aef8d6cb4a6466d291b5fb276ee424ad0f5f0c3dd26a73ba2aef078b98589ff8' and
             sha(ROOT/TARGET/'COST-CONTRACT.md')=='26ebc2b6d02527b8b2e26b72e4537a49dff7867543f88146936f01771ff0fec4','installed exact analysis bytes')
        seal=dict(contract=payload['contract'],source_freeze_commit=HEAD,archive_files=closure['archive_files'],
                  fresh_source_result_sha256=closure['fresh_source_result_sha256'])
        seal_path=stage/'seal.json';save(seal_path,seal)
        helper=ROOT/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target/host_audit.py'
        need(sha(helper)=='0fa2f707274aa90a8e45839966e0caf849a2d80ec370292ffee75020d9239d91','fixed durable process helper')
        spec=importlib.util.spec_from_file_location('phased_cost_durable',helper);host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
        argv=[sys.executable,'-I','-B',str(ROOT/TARGET/'cost.py'),'--repo',str(ROOT),'--archive',str(RUN/'evidence-pack-02'),
              '--seal',str(seal_path),'--seal-sha256',sha(seal_path),'--fresh-audit',str(RUN/'fresh-source-audit-02/result.json'),
              '--output',str(output)]
        record.update(status='RUNNING',seal_sha256=sha(seal_path));save(stage/'driver.json',record)
        result=host.durable_child(argv,cwd=ROOT,env=dict(os.environ),seconds=600,out=stage/'analysis-command')
        need(result.returncode==0,'actual sealed trace diagnostics failed; original stderr retained')
        checked=read(output/'result.json');need(checked['status']=='PHASED_COST_DIAGNOSTIC_PASS','actual trace accepted')
        need(all(sha(ROOT/n)==pin for n,pin in pins.items()),'runtime sources remain frozen')
        record.update(status='PHASED_COST_CLOSED',finished=now(),result_sha256=sha(output/'result.json'),
            coordinates=checked['coordinates'],source_files_unchanged=106);save(stage/'driver.json',record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(stage/'driver.json',record)
        (stage/'failure.traceback.txt').write_text(traceback.format_exc());raise
    print(result.stdout.decode())

if __name__=='__main__':main()
