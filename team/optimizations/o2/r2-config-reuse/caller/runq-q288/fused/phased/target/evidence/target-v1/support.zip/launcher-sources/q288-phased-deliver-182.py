from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,zipfile

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=ROOT.parents[1]/'runs/fullq-phased-target-20261026-1255'
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
TARGET=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def need(ok,message):
    if not ok:raise ValueError(message)
def pack(path,files):
    members={}
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in sorted(files.items()):
            raw=p.read_bytes();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.create_system=3
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw,compresslevel=6)
            members[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    with zipfile.ZipFile(path) as z:
        need(set(z.namelist())==set(members),'exact ZIP inventory')
        for name,pin in members.items():
            raw=z.read(name);need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'stored member '+name)
    return dict(archive_sha256=sha(path),archive_bytes=path.stat().st_size,members=members)

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1])
    closure=read(RUN/'archive-driver-02.json');cost_driver=read(RUN/'cost-stage-01/driver.json')
    need(closure['status']=='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED' and cost_driver['status']=='PHASED_COST_CLOSED','completed original evidence and offline diagnostics')
    head=git('rev-parse','HEAD').decode().strip();need(head==closure['auditor_commit'],'exact auditor source commit')
    need(git('diff','--name-only')==b'' and git('diff','--cached','--name-only')==b'' and not (ROOT/'.git/index.lock').exists(),'no tracked edits or staged work')
    untracked=set(filter(None,git('ls-files','--others','--exclude-standard','-z').decode().split('\0')))
    need(untracked<={(TARGET/n).as_posix() for n in ('cost.py','COST-CONTRACT.md')},'no unrelated untracked source work')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name!='emu','no active target run')
        except OSError:pass
    pins=read(RUN/'build-03/build.json')['software_files'];need(len(pins)==106 and all(sha(ROOT/n)==v for n,v in pins.items()),'all 106 frozen inputs unchanged')
    need(sha(ROOT/TARGET/'cost.py')=='aef8d6cb4a6466d291b5fb276ee424ad0f5f0c3dd26a73ba2aef078b98589ff8' and
         sha(ROOT/TARGET/'COST-CONTRACT.md')=='26ebc2b6d02527b8b2e26b72e4537a49dff7867543f88146936f01771ff0fec4','exact new analysis sources')
    evidence=ROOT/TARGET/'evidence/target-v1';cost_evidence=ROOT/TARGET/'evidence/cost-v1'
    need(not evidence.exists() and not cost_evidence.exists() and not (RUN/'delivery-01.json').exists(),'fresh delivery outputs')
    need(not (ROOT/TARGET/'RESULT.md').exists() and not (ROOT/TARGET/'COST.md').exists(),'new bounded result documents')
    archive=RUN/'evidence-pack-02';manifest=read(archive/'archive-manifest.json');history=read(archive/'history/manifest.json')
    for n,pin in closure['archive_files'].items():need(sha(archive/n)==pin,'raw archive identity '+n)
    need(manifest['payload_sha256']==sha(archive/'payload.zip') and manifest['stored_bytes']==(archive/'payload.zip').stat().st_size,'payload identity')
    need(manifest['historical_git']['manifest_sha256']==sha(archive/'history/manifest.json') and
         history['pack_sha256']==manifest['historical_git']['pack_sha256']==sha(archive/'history/objects.pack'),'historical object chain')
    need(sha(RUN/'fresh-source-audit-02/result.json')==closure['fresh_source_result_sha256'],'isolated closure identity')
    recovery=RUN/'campaign-01/runs/recovery';replay=RUN/'campaign-01/runs/replay'
    need((recovery/'validation.json').read_bytes()==(replay/'validation.json').read_bytes(),'identical replay validation')
    value=read(recovery/'validation.json');select=value['selection'];need(select['decision']=='PHASED_PREFERRED_IN_FIXED_PLAN','qualified phased selection')
    cost=read(RUN/'cost-01/result.json');need(cost['status']=='PHASED_COST_DIAGNOSTIC_PASS' and
         cost['original_selection']==select and cost_driver['result_sha256']==sha(RUN/'cost-01/result.json'),'same sealed diagnostic selection')
    attributes=ROOT/TARGET.parent/'.gitattributes'
    need(not attributes.exists(),'new local evidence byte-preservation rules')
    attributes.write_text('*.zip binary\n*.pack binary\n')
    shutil.copytree(archive,evidence/'archive');shutil.copytree(RUN/'fresh-source-audit-02',evidence/'fresh-source')
    support={}
    for directory in ('build-01','build-02','elf-controls-03'):
        base=RUN/directory;need(base.is_dir(),'preserved earlier build/control directory '+directory)
        for p in sorted(base.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:support[p.relative_to(RUN).as_posix()]=p
    for p in sorted(RUN.iterdir()):
        if p.is_file():support['drivers/'+p.name]=p
    launcher_names=('q288-phased-target-source-165.json','q288-phased-target-build-166.py',
        'q288-phased-target-patch-167.json','q288-phased-build-01-failure-167.json','q288-phased-target-build-168.py',
        'q288-phased-target-patch-169.json','q288-phased-target-build-170.py','q288-phased-build-03-launch-failure-171.json',
        'q288-phased-image-comparison-171.json','q288-phased-freeze-172.py','q288-phased-launch-173.py',
        'q288-phased-cost-contract-176.md','q288-phased-cost-inputs-177.json','q288-phased-seal-178.py',
        'q288-phased-cost-179.py','q288-phased-json-adapter-180.json','q288-phased-reseal-180.py',
        'q288-phased-cost-181.py','q288-phased-deliver-182.py')
    for name in launcher_names:
        p=MONITOR/name;need(p.is_file(),'launcher evidence '+name);support['launcher-sources/'+name]=p
    support_manifest=pack(evidence/'support.zip',support);save(evidence/'support-members.json',support_manifest)
    cost_files={}
    for directory in ('cost-01','cost-stage-01'):
        for p in sorted((RUN/directory).rglob('*')):
            if p.is_file():cost_files[p.relative_to(RUN).as_posix()]=p
    cost_evidence.mkdir(parents=True);cost_manifest=pack(cost_evidence/'raw.zip',cost_files);save(cost_evidence/'members.json',cost_manifest)
    stderr=[dict(name=label,bytes=(p/'stderr.log').stat().st_size,sha256=sha(p/'stderr.log')) for label,p in (('recovery',recovery),('replay',replay))]
    need(stderr[0]['sha256']==stderr[1]['sha256'] and stderr[0]['bytes']==stderr[1]['bytes'],'identical raw replay trace')
    totals={}
    for label,p in (('recovery',recovery),('replay',replay)):
        stdout=(p/'stdout.log').read_text();totals[label]=dict(guest_cycles=int(re.search(r'Guest cycle spent:\s*(\d+)',stdout)[1]),retired=int(re.search(r'instrCnt =\s*(\d+)',stdout)[1]))
    summary=dict(status='PHASED_TARGET_ORIGINAL_EVIDENCE_CLOSED',source_freeze_commit='34092ebcf579a5de76e70cadfb6a5333173891ae',
        source_head_at_delivery=head,closure=closure,selection=select,validation_sha256=sha(recovery/'validation.json'),
        stderr=stderr,support_sha256=support_manifest['archive_sha256'],support_members=len(support_manifest['members']),
        history_objects=len(history['objects']),history_pack_sha256=history['pack_sha256'],normal_totals=totals,
        frozen_sources_unchanged=True,source_files_unchanged=106,old_failed_evidence_retained=True,new_emu_runs=3)
    save(evidence/'summary.json',summary)
    save(cost_evidence/'summary.json',dict(status='PHASED_COST_ORIGINAL_TRACE_DIAGNOSTICS_CLOSED',result_sha256=sha(RUN/'cost-01/result.json'),
        raw_archive_sha256=cost_manifest['archive_sha256'],members=len(cost_manifest['members']),windows=cost['windows'],
        coordinates=cost['coordinates'],source_files_unchanged=106,new_emu_runs=0,new_performance_qualification=False))
    rows='\n'.join('| '+m['label']+' | '+', '.join(map(str,m['cycles']))+' | '+', '.join(map(str,m['instructions']))+' |' for m in select['methods'])
    comparisons='\n'.join('- '+c['comparison']+f"：最慢候选 {c['worst_candidate']} 对最快基线 {c['best_baseline']}，保守少 {100*c['reduction']:.9f}% 周期。" for c in select['software_comparisons'])
    report=f'''# Q288 phased：完整目标对照闭合

结论：`{select['decision']}`，本合同选择 `{select['selected_method']}`。这是软件排程收益，T17/RTL与R5默认未改变。资格只覆盖固定合成、已量化、已打包288×288 Q；具名RVV对照和原fused入口保留。

| 方法 | 原始周期 | CSR instret |
|---|---|---|
{rows}

{comparisons}

八窗顺序 `FR,FV,PV,FR | FR,PV,FV,FR`，各窗前执行相同方法完整Q selfwarm；四个FR均纳入1%锚点和分母。0.5%最坏候选对最好基线门槛在实验前冻结；replay不是额外样本。源码与合同见 [CONTRACT.md](CONTRACT.md)，原始选择及身份见 [summary.json](evidence/target-v1/summary.json)。

## 正确性与原文复现

negative按预定拒绝高96位错误；recovery/replay均完整DiffTest、6336输出、22次Q调用、124417 custom/41472 timed custom和32 CSR/COUNTER事件通过。两份validation原字节一致，stderr各{stderr[0]['bytes']:,}字节且SHA `{stderr[0]['sha256']}`相同。运行收据保留真实起止时间和PID，不用回放增加样本数。

冻结源码提交 `34092ebcf579a5de76e70cadfb6a5333173891ae` 的106项源保持不变。真实build-03 ELF SHA `bcbe7088f3548813d8ea24fd3a71ce5cb268e7074e7573bb74680d641e5a33b4`、BIN SHA `73bc3a0e8b6d172cb427b09c2f6ff5ca2e0b56c0e0c1617b426cdc20bf84342d`。实际GNU编译/权威object、全部数组与完整机器路径通过；8项数组/FP、3项PV双重语义和5项selector控制保留。

归档原文{len(manifest['files'])}成员、{manifest['raw_bytes']:,}字节，ZIP {manifest['stored_bytes']:,}字节、SHA `{manifest['payload_sha256']}`。隔离新Python进程仅使用归档源闭包、必要历史Git对象与明确补充审计器完成复算，原依赖guard和完整原文结果相等检查通过。启动端仍需要这些已交付补充审计源码，不宣称仅凭单ZIP可运行。命令/guard/进程收据位于 [fresh-source](evidence/target-v1/fresh-source/result.json)。

## 已保留的失败和适配

build-01缺失旧q288_full链接根、build-03启动器误要求调试段也逐字节相等，以及首次归档tuple/list缓存比较失败均保留在support及原运行目录。没有重写旧结果或重跑EMU。build-02/03的实际BIN和全部LOAD段相同，仅3个调试section变化；build记录的构建时HEAD仍保留其原值。

首次归档的唯一差异是四个 `phased_certificate.mode_phases` 元素的tuple/list表示。新 [archive_json.py](archive_json.py) 依据 [限定合同](ARCHIVE-JSON-CONTRACT.md) 只转换这一字段，继续执行原完整相等判据，并通过3项类型/值拒错及其他字段不隐藏控制。原106源、缓存和失败回执均未改；新归档使用02身份，隔离子进程使用同一适配。

## 范围与使用

此处既不计pack/量化/权重初始化，也不包含token、训练模型质量或ASIC数据；同ELF仍包含固定代码/地址上下文。原fused/FR与R5默认可回退。完整接受坐标与消费者跨度见 [COST.md](COST.md)，退休跨度不等于独占执行成本。
'''
    (ROOT/TARGET/'RESULT.md').write_text(report)
    table=[]
    for w in cost['windows']:
        if 'supply' not in w:continue
        f,s=w['fu'],w['supply']
        table.append(f"| {w['seq']} / {w['label']} | {w['cycles']} | {f['enqueue_to_accept']['mean']:.6f} | {f['accept_to_response']['minimum']}–{f['accept_to_response']['maximum']} | {f['target_output_stall_events']} | {s['producers_retired_wait_union_cycles']} | {s['producers_retired_and_ready_without_request_observed']} | {s['producers_retired_in_source_bound_empty_domain']} |")
    cost_report='''# Phased 周期坐标诊断

本分析只复用已闭合的同ELF原始轨迹，新增EMU为0，不另授性能资格。指标在查看本批测量结果前记录于 [COST-CONTRACT.md](COST-CONTRACT.md)。身份和8项时间坐标反例、既有11项身份/计数反例均通过；运行原文、命令收据、结果及逐请求坐标见 [cost evidence](evidence/cost-v1/summary.json)。

| 窗口 / 方法 | Q周期 | 分配→接受均值 | 接受→响应范围 | 出口STALL事件 | 两load及配置已退休后的等待并集 | 其中直接观测ready且无请求 | 其中源绑定空域 |
|---|---:|---:|---:|---:|---:|---:|---:|
'''+ '\n'.join(table)+'''

每个vdot窗口含10368个请求。逐请求绑定同一ROB分配世代、真实机器地址以及两个低64位load生产者的最近写者；同拍压缩退休保持同一观测时刻。每窗10367组程序邻接对完整划分为10044组核内、288组量化组间、35组tile间；接受顺序倒置保留负数，不删样本。

“两load及配置已退休后”采用 `max(enqueue,load-W-retire,load-X-retire,vset-retire)` 的严格开区间，重叠区间取并集。它是源已完成的保守上界，不是实际operand-ready时刻。缺少STATE不能被当作直接ready；空域仅依据绑定的硬件observer日志条件解释。程序相邻接受间隔可重叠并包含其他接受，不得当作可相加、可全部消除的bubble预算。

完整整数核、FP conversion/add的退休跨度也已记录，但不是执行单元独占周期。当前观测无法直接判定IQ选择、RF端口、物理寄存器释放、cache延迟或FP完成的因果份额；response→commit是退休等待，不能写成写回背压。只在实际源及完整Q对照共同支持时提出下一软件实验，不能从单个坐标统计推导RTL或token收益。
'''
    (ROOT/TARGET/'COST.md').write_text(cost_report)
    names=[attributes.relative_to(ROOT).as_posix()]+[(TARGET/n).as_posix() for n in ('cost.py','COST-CONTRACT.md','RESULT.md','COST.md')]
    names+=sorted(p.relative_to(ROOT).as_posix() for base in (evidence,cost_evidence) for p in base.rglob('*') if p.is_file())
    need(not set(names)&set(pins),'no frozen source staged')
    for n in names:
        if n.endswith(('.zip','.pack','.gz')):
            attrs=git('check-attr','binary','text','--',n).decode()
            need(': binary: set' in attrs and ': text: unset' in attrs,'raw archive Git attributes '+n)
    git('add','-f','--',*names)
    need(set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==set(names),'exact evidence path set')
    proof={}
    for n in names:
        raw=(ROOT/n).read_bytes();need(git('show',':'+n)==raw,'every staged raw Git byte '+n)
        proof[n]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    git('diff','--cached','--check');need(all(sha(ROOT/n)==pin for n,pin in pins.items()),'runtime inputs unchanged at commit')
    git('-c','gc.auto=0','commit','-m','Close phased full-Q performance and sealed consumer timing evidence')
    need(git('status','--porcelain')==b'','clean phased delivery')
    delivered=dict(status='PHASED_TARGET_AND_COST_DELIVERY_COMMITTED',head=git('rev-parse','HEAD').decode().strip(),
        base=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),files=proof,archive_sha256=manifest['payload_sha256'],
        cost_archive_sha256=cost_manifest['archive_sha256'],source_files_unchanged=106,
        finished=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat())
    save(RUN/'delivery-01.json',delivered);print(json.dumps({k:v for k,v in delivered.items() if k!='files'},indent=2))

if __name__=='__main__':main()
