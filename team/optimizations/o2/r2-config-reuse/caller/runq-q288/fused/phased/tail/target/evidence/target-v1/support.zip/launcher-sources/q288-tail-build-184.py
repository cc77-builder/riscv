from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,re,subprocess,sys,traceback

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=ROOT.parents[1]/'runs/fullq-tail-target-20261026-1400'
PRIOR=ROOT.parents[1]/'runs/fullq-phased-target-20261026-1255'
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
MODULE=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/tail')
PAYLOAD_SHA='fb108dd308dd386b811d4842e74a0cbbeaa90b57a268b84f1f309dfbd9dd26b3'
sys.dont_write_bytecode=True
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def need(ok,message):
    if not ok:raise ValueError(message)
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main(base):
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    need(re.fullmatch('[0-9a-f]{40}',base) and git('rev-parse','HEAD').decode().strip()==base and
         git('status','--porcelain')==b'','exact clean preparation base')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name not in ('emu','cc1','cc1plus','verilator_bin','ninja'),'no concurrent runtime/build')
        except OSError:pass
    closure=read(PRIOR/'archive-driver-02.json')
    need(closure['status']=='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED','previous full evidence closure')
    need(sha(PRIOR/'fresh-source-audit-02/result.json')==closure['fresh_source_result_sha256'],'fresh-source receipt identity')
    for n,pin in closure['archive_files'].items():need(sha(PRIOR/'evidence-pack-02'/n)==pin,'previous raw archive '+n)
    selected=read(PRIOR/'evidence-pack-02/original-audit.json')['selection']
    need(selected['decision']=='PHASED_PREFERRED_IN_FIXED_PLAN' and selected['selected_id']==1,'qualified phased incumbent')
    previous_pins=read(PRIOR/'build-03/build.json')['software_files']
    need(len(previous_pins)==106 and all(sha(ROOT/n)==pin for n,pin in previous_pins.items()),'all previous frozen sources intact')
    payload_path=MONITOR/'q288-tail-inputs-183.json';need(sha(payload_path)==PAYLOAD_SHA,'reviewed eleven-file TA payload')
    payload=read(payload_path);files=payload['files']
    names=sorted((MODULE/n).as_posix() for n in files)
    need(len(files)==11 and all(not (ROOT/n).exists() for n in names),'new candidate source paths')
    need(not RUN.exists(),'fresh independent candidate outputs');RUN.mkdir(parents=True)
    record=dict(status='INSTALLING',started=now(),launcher_sha256=sha(__file__),base=base,new_emu_runs=0,
        prior_archive_closure_sha256=sha(PRIOR/'archive-driver-02.json'),prior_selected_method=selected['selected_method'])
    save(RUN/'preparation-01.json',record)
    try:
        for name,text in files.items():
            p=ROOT/MODULE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
            need(sha(p)==payload['sha256'][name],'installed exact source '+name)
        helper=ROOT/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target/host_audit.py'
        need(sha(helper)=='0fa2f707274aa90a8e45839966e0caf849a2d80ec370292ffee75020d9239d91','fixed durable helper')
        host=load('tail_build_durable',helper)
        record['status']='STATIC_SCREEN';save(RUN/'preparation-01.json',record)
        command=host.durable_child([sys.executable,'-I','-B',str(ROOT/MODULE/'screen.py'),'--repo',str(ROOT),
            '--output',str(RUN/'screen-01')],cwd=ROOT,env=dict(os.environ),seconds=300,out=RUN/'static-command-01')
        need(command.returncode==0,'actual GNU static screen failed; raw receipt retained')
        screened=read(RUN/'screen-01/result.json')
        need(screened['status']=='TAIL_STATIC_SCREEN_PASS' and len(screened['source_files'])==17 and
             screened['new_emu_runs']==0,'complete actual static acceptance')
        m=load('tail_target_actual_builder',ROOT/MODULE/'target/run.py')
        identity=ROOT/m.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
        record.update(status='TARGET_BUILD',static_result_sha256=sha(RUN/'screen-01/result.json'));save(RUN/'preparation-01.json',record)
        built=m.build(ROOT,identity,RUN/'build-01')
        need(read(RUN/'build-01/build.json')['accepted'] is True,'target actual build accepted')
        recomputed=m.verification(ROOT,RUN/'build-01')
        need(recomputed==read(RUN/'build-01/elf-validation.json'),'exact cached and recomputed verifier equality before any EMU')
        record.update(status='ELF_CONTROLS');save(RUN/'preparation-01.json',record)
        controls=m.elf_controls(RUN/'build-01',RUN/'elf-controls-01')
        need(controls['status']=='TAIL_TARGET_ACTUAL_ELF_CONTROLS_PASS','all actual target mutants rejected')
        a=load('tail_target_archive_identity',ROOT/MODULE/'target/archive.py');auditors=a.tools()
        pins=read(RUN/'build-01/build.json')['software_files']
        need(len(pins)==115 and m.sources(ROOT)==pins and all(sha(ROOT/n)==v for n,v in pins.items()),'complete 115-source closure')
        need(all(sha(ROOT/n)==pin for n,pin in previous_pins.items()),'all previous sources remain immutable')
        need(set(git('diff','--name-only','-z').decode().strip('\0').split('\0'))<={''},'no tracked source edits')
        need(git('rev-parse','HEAD').decode().strip()==base,'preparation base unchanged before freeze')
        git('add','-f','--',*names)
        need(set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==set(names),'exact eleven new candidate files staged')
        for name in names:need(git('show',':'+name)==(ROOT/name).read_bytes(),'exact Git source bytes '+name)
        git('diff','--cached','--check');git('-c','gc.auto=0','commit','-m','Freeze two-bit tail-agnostic Q288 candidate and controlled target comparison')
        head=git('rev-parse','HEAD').decode().strip();need(git('status','--porcelain')==b'','frozen candidate clean')
        record.update(status='TAIL_TARGET_FROZEN_AND_READY',finished=now(),commit=head,tree=git('rev-parse','HEAD^{tree}').decode().strip(),
            source_files=pins,supplementary_auditors=auditors,static_result_sha256=sha(RUN/'screen-01/result.json'),
            target_controls_sha256=sha(RUN/'elf-controls-01/result.json'),cached_verification_exact=True,
            elf_sha256=sha(RUN/'build-01/vdot-perf.elf'),bin_sha256=sha(RUN/'build-01/vdot-perf.bin'),
            source_sha256=payload['sha256'],previous_frozen_sources_unchanged=True)
        save(RUN/'preparation-01.json',record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(RUN/'preparation-01.json',record)
        (RUN/'preparation-01.traceback.txt').write_text(traceback.format_exc());raise
    print(json.dumps({k:v for k,v in record.items() if k not in ('source_files','supplementary_auditors')},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);main(p.parse_args().base)
