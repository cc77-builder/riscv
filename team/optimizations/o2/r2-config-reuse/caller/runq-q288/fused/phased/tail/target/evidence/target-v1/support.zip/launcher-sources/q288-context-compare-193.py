from pathlib import Path
import hashlib,importlib.util,json,os,struct,sys,traceback,zipfile

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUNS=ROOT.parents[1]/'runs'
TAIL=RUNS/'fullq-tail-target-20261026-1400'
PHASED=RUNS/'fullq-phased-target-20261026-1255'
TARGET=ROOT/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/tail/target/run.py'
sys.dont_write_bytecode=True
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def need(ok,message):
    if not ok:raise ValueError(message)

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:1])
    out=TAIL/'context-comparison-01.json';need(not out.exists(),'new read-only comparison result')
    need(sha(TARGET)=='7d0c350b63b158f4b9f7597ba81f59d62226e5dc4a8eadb525d73c3ad0964d93','frozen target parser binding')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name!='emu','comparison only after target runs end')
        except OSError:pass
    spec=importlib.util.spec_from_file_location('q288_context_identity',TARGET);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    configurations={
        'phased':(PHASED,'03','02','bcbe7088f3548813d8ea24fd3a71ce5cb268e7074e7573bb74680d641e5a33b4'),
        'tail':(TAIL,'01','01','610c499f46f1fe73074f626d8990bdcbdbc5f78c30ce8fc4a835495b0e392faa')}
    inputs={};elfs={};selections={}
    for label,(base,build_id,seal_id,elf_pin) in configurations.items():
        state=read(base/'campaign-01/state.json');need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None,'closed '+label+' campaign')
        closure=read(base/('archive-driver-'+seal_id+'.json'))
        need(closure['status']==label.upper()+'_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED','closed '+label+' archive')
        archive=base/('evidence-pack-'+seal_id);original=archive/'original-audit.json'
        need(sha(original)==closure['archive_files']['original-audit.json'],'sealed '+label+' selection')
        selections[label]=read(original)['selection']
        build=base/('build-'+build_id);path=build/'vdot-perf.elf';br=read(build/'build.json')
        need(sha(path)==elf_pin==br['artifacts']['vdot-perf.elf'],'actual sealed '+label+' ELF')
        with zipfile.ZipFile(archive/'payload.zip') as z:
            need(digest(z.read('build/vdot-perf.elf'))==elf_pin,'archived and current ELF same '+label)
        elfs[label]=m.g.ELF(path.read_bytes())
        plan=read(build/'source/manifest.json')
        wrappers=[row['wrapper'] for row in plan['rows']]
        need(elfs[label].symbol_data('q_wrappers')==struct.pack('<3Q',*[elfs[label].symbols[n][0] for n in wrappers]),'actual wrapper pointer mapping '+label)
        inputs[label]=dict(elf_sha256=elf_pin,build_record_sha256=sha(build/'build.json'),
            original_audit_sha256=sha(original),closure_sha256=sha(base/('archive-driver-'+seal_id+'.json')),
            parent_identity_sha256=sha(base/'campaign-01/parent-identity.json'),
            configuration_sha256=sha(base/'campaign-01/configuration.json'),
            wrapper_table=wrappers,wrapper_table_address=elfs[label].symbols['q_wrappers'][0],
            wrapper_table_sha256=digest(elfs[label].symbol_data('q_wrappers')),plan=plan['plan'],call_plan=plan['call_plan'])
    need(inputs['phased']['parent_identity_sha256']==inputs['tail']['parent_identity_sha256']==m.parent.PARENT_IDENTITY_SHA,
         'same frozen hardware/reference parent identity')
    functions={}
    for name in ('q288_phased_vdot','q288_fused_rvv4','q288_fused_vdot','split_measure'):
        bodies={label:elf.symbol_data(name) for label,elf in elfs.items()}
        need(bodies['phased']==bodies['tail'],'unchanged complete common function '+name)
        functions[name]=dict(bytes=len(bodies['phased']),sha256=digest(bodies['phased']),
            addresses={label:elf.symbols[name][0] for label,elf in elfs.items()})
    arrays={}
    for name in ('q_weights','q_weight_scale','q_inputs','q_input_scale','q_golden','q_packed',
                 'q_order','q_methods','q_functional_order','q_functional_datasets'):
        raw={label:elf.symbol_data(name) for label,elf in elfs.items()}
        need(raw['phased']==raw['tail'],'identical common input/plan array '+name)
        arrays[name]=dict(bytes=len(raw['phased']),sha256=digest(raw['phased']),value_offset=16 if name=='q_packed' else 0,
            addresses={label:elf.symbols[name][0] for label,elf in elfs.items()})
    e=elfs['tail'];old=e.symbol_data('q288_phased_vdot');new=e.symbol_data('q288_tail_vdot')
    need(len(old)==len(new)==764,'complete two-slot function sizes')
    differences=[dict(offset=i,old=struct.unpack_from('<I',old,i)[0],new=struct.unpack_from('<I',new,i)[0])
        for i in range(0,len(old),4) if old[i:i+4]!=new[i:i+4]]
    need(differences==[dict(offset=i,old=0xc0047057,new=0xc4047057) for i in (60,336)],'exact two vta-bit function delta')
    slots=dict(phased_address=e.symbols['q288_phased_vdot'][0],tail_address=e.symbols['q288_tail_vdot'][0],
        phased_sha256=digest(old),tail_sha256=digest(new),differences=differences)
    mutable_objects={name:{label:dict(address=elf.symbols[name][0],bytes=elf.symbols[name][1],
        value_offset=16 if name in ('q_output','q_slots') else 0) for label,elf in elfs.items()}
        for name in ('q_output','q_slots','q_context','q_measurement','q_samples')}
    callers={name:{label:dict(address=elf.symbols[name][0],bytes=len(elf.symbol_data(name)),
        sha256=digest(elf.symbol_data(name))) for label,elf in elfs.items()}
        for name in ('main','q_fault_probe')}
    cycles={label:{row['wrapper']:dict(cycles=row['cycles'],instructions=row['instructions'],mean_cycles=row['mean_cycles'])
        for row in selected['methods']} for label,selected in selections.items()}
    need(inputs['phased']['plan']==inputs['tail']['plan'] and inputs['phased']['call_plan']==inputs['tail']['call_plan'],'same slot-index plan, distinct wrapper assignment')
    common_cycles={name:dict(phased=cycles['phased'][name],tail=cycles['tail'][name],
        descriptive_mean_change=(cycles['tail'][name]['mean_cycles']/cycles['phased'][name]['mean_cycles']-1))
        for name in ('q288_phased_vdot','q288_fused_rvv4')}
    pv=common_cycles['q288_phased_vdot'];fr=common_cycles['q288_fused_rvv4']
    diagnostics=dict(opposite_mean_change_directions=pv['descriptive_mean_change']*fr['descriptive_mean_change']<0,
        common_method_ordering_reversed=(pv['phased']['mean_cycles']-fr['phased']['mean_cycles'])*
            (pv['tail']['mean_cycles']-fr['tail']['mean_cycles'])<0,
        descriptive_only=True,changes_frozen_selection=False)
    result=dict(status='Q288_CROSS_IMAGE_SOURCE_AND_DATA_IDENTITY_PASS',driver_sha256=sha(__file__),inputs=inputs,
        parser_source=Path(m.g.__file__).relative_to(ROOT).as_posix(),parser_sha256=sha(m.g.__file__),
        common_functions=functions,common_arrays=arrays,mutable_object_layout=mutable_objects,
        caller_code_layout=callers,same_image_candidate_slots=slots,cycles=cycles,
        cross_image_common_method_cycles=common_cycles,descriptive_diagnostics=diagnostics,tail_fixed_plan_selection=selections['tail'],
        new_emu_runs=0,performance_rule_changed=False,new_performance_qualification=False,
        causal_policy_effect_identified=False,stable_default_changed=False,
        interpretation='Complete common function and input bytes match, but ELF layout and wrapper assignment/history are not the same experimental context. Fixed-plan qualification remains intact; cross-image percentages are not composable and the two policy bits are not isolated at the same address.')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],result_sha256=sha(out),functions=functions,arrays=arrays,
        mutable_objects=mutable_objects,callers=callers,candidate_slots=slots,common_method_cycles=common_cycles,
        descriptive_diagnostics=diagnostics,new_emu_runs=0),indent=2))

if __name__=='__main__':
    try:main()
    except BaseException as error:
        path=TAIL/'context-comparison-01.failure.json'
        if not path.exists():path.write_text(json.dumps(dict(status='CONTEXT_COMPARISON_FAILED',driver_sha256=sha(__file__),error=repr(error),traceback=traceback.format_exc(),new_emu_runs=0),indent=2)+'\n')
        raise
