from pathlib import Path
import copy,datetime,hashlib,importlib.util,json,os,subprocess,sys,traceback

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=ROOT.parents[1]/'runs/fullq-phased-target-20261026-1255'
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
TARGET=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target')
FROZEN='34092ebcf579a5de76e70cadfb6a5333173891ae'
PAYLOAD_SHA='65736b7a99414df638ab43ea460ce7fd5ac51ffc5cdcd5fcd99da6f90642f154'
sys.dont_write_bytecode=True
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def need(ok,message):
    if not ok:raise ValueError(message)

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    need(git('rev-parse','HEAD').decode().strip()==FROZEN and git('status','--porcelain')==b'','clean original frozen checkout')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name not in ('emu','cc1','cc1plus','verilator_bin','ninja'),'no concurrent runtime/build')
        except OSError:pass
    build=RUN/'build-03';campaign=RUN/'campaign-01';pins=read(build/'build.json')['software_files']
    need(len(pins)==106 and all(sha(ROOT/n)==pin for n,pin in pins.items()),'all frozen source bytes')
    need(read(campaign/'state.json')['status']=='SPLIT_CAMPAIGN_PASS','closed original campaign')
    need(read(RUN/'archive-driver-01.json')['status']=='FAILED','original failed archive receipt retained')
    diagnosis=read(RUN/'seal-failure-diagnosis-01.json')
    need(diagnosis['json_normalized_equal'] is True and len(diagnosis['differences'])==4 and
         [d['path'] for d in diagnosis['differences']]==['/phased_certificate/mode_phases/'+str(i) for i in range(4)],
         'exact diagnosed representation failure')
    need(sha(build/'elf-validation.json')==diagnosis['cached_file_sha256']=='d3ab20bbb54d0ed6f878d804efa2ab5d6208b5d4a83470ecf7805761496f4d31',
         'original cached verification untouched')
    payload=MONITOR/'q288-phased-json-adapter-180.json'
    need(sha(payload)==PAYLOAD_SHA,'reviewed compatibility payload')
    files=read(payload);need(set(files)=={'archive_json.py','ARCHIVE-JSON-CONTRACT.md'},'exact two new files')
    out=RUN/'evidence-pack-02';fresh=RUN/'fresh-source-audit-02';receipt=RUN/'archive-driver-02.json'
    need(not out.exists() and not fresh.exists() and not receipt.exists(),'fresh sealing identity')
    need(all(not (ROOT/TARGET/n).exists() for n in files),'new source paths')
    record=dict(status='INSTALLING',started=now(),launcher_sha256=sha(__file__),source_freeze_commit=FROZEN,
        original_failed_receipt_sha256=sha(RUN/'archive-driver-01.json'),diagnosis_sha256=sha(RUN/'seal-failure-diagnosis-01.json'),
        new_emu_runs=0,source_files=106)
    save(receipt,record)
    try:
        for name,text in files.items():(ROOT/TARGET/name).write_text(text)
        path=ROOT/TARGET/'archive_json.py'
        need(sha(path)=='d1359825a72350f41718d382132f20ca2a4f68464df1a8d8d72a27878722660a','new adapter identity')
        spec=importlib.util.spec_from_file_location('phased_json_reseal',path);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
        actual=a.e.verification(ROOT,build);fixed=a.json_certificate(actual);cached=read(build/'elf-validation.json')
        need(actual!=cached and fixed==cached,'only exact representation conversion closes full strict comparison')
        controls=[]
        for name,value in (('changed-mode-value',[(8,8),(4,31),(8,8),(4,32)]),
                           ('wrong-python-container',[[8,8],[4,32],[8,8],[4,32]]),
                           ('wrong-element-type',[(8,8),(4,32),(8,8),(True,32)])):
            wrong=copy.deepcopy(actual);wrong['phased_certificate']['mode_phases']=value
            try:a.json_certificate(wrong)
            except ValueError as error:controls.append(dict(name=name,error=str(error)))
            else:raise ValueError('representation mutant accepted '+name)
        wrong=copy.deepcopy(actual);wrong['image_sha256']='0'*64
        need(a.json_certificate(wrong)!=cached and a.json_certificate(wrong)['image_sha256']=='0'*64,
             'unrelated altered field remains visible to original full comparison')
        controls.append(dict(name='unrelated-image-identity-not-hidden',rejected_by='original complete cached-result comparison'))
        save(RUN/'json-adapter-controls-01.json',dict(status='EXACT_JSON_REPRESENTATION_CONTROLS_PASS',controls=controls,
             actual_cached_equal=False,adapted_cached_equal=True,source_files_unchanged=106))
        names=sorted((TARGET/n).as_posix() for n in files)
        git('add','-f','--',*names)
        need(set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==set(names),'only new auditor files staged')
        for name in names:need(git('show',':'+name)==(ROOT/name).read_bytes(),'exact staged bytes '+name)
        git('diff','--cached','--check');git('-c','gc.auto=0','commit','-m','Preserve phased evidence with exact JSON certificate representation adapter')
        head=git('rev-parse','HEAD').decode().strip();need(git('status','--porcelain')==b'','clean auditor commit')
        record.update(status='AUDITOR_FROZEN',auditor_commit=head,supplementary_auditors=a.tools());save(receipt,record)
        packed=a.pack(build,campaign,out);record.update(status='PACKED',packed=packed);save(receipt,record)
        checked=a.audit_snapshot(out,fresh)
        need(checked['status']=='PHASED_TARGET_ARCHIVE_FRESH_SOURCE_AUDIT_PASS','fresh source complete acceptance')
        need(a.e.sources(ROOT)==pins and all(sha(ROOT/n)==pin for n,pin in pins.items()),'frozen sources remain identical')
        need(git('rev-parse','HEAD').decode().strip()==head and git('status','--porcelain')==b'','auditor head remains clean')
        record.update(status='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED',finished=now(),fresh_source=checked,
            archive_files={n:sha(out/n) for n in ('payload.zip','archive-manifest.json','original-audit.json')},
            fresh_source_result_sha256=sha(fresh/'result.json'),frozen_sources_unchanged=True)
        save(receipt,record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(receipt,record)
        (RUN/'archive-driver-02.traceback.txt').write_text(traceback.format_exc());raise
    print(json.dumps({k:v for k,v in record.items() if k not in ('fresh_source','supplementary_auditors')},indent=2))

if __name__=='__main__':main()
