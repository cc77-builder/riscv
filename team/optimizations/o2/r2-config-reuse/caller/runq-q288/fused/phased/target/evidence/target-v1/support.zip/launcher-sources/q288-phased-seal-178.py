from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,traceback

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255')
TARGET=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target')
HEAD='34092ebcf579a5de76e70cadfb6a5333173891ae'
sys.dont_write_bytecode=True
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def need(ok,message):
    if not ok:raise ValueError(message)

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    need(git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b'','frozen clean checkout')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    busy=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            name=(p/'exe').resolve().name
            if name=='emu' or name in ('cc1','cc1plus','verilator_bin','ninja'):busy.append((p.name,name))
        except OSError:pass
    need(not busy,'no concurrent EMU/heavy build: '+repr(busy))
    build=RUN/'build-03';campaign=RUN/'campaign-01';state=read(campaign/'state.json')
    need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None and
         state['active_result'] is None and state['new_emu_runs']==3,'closed original campaign')
    records=read(campaign/'completed-runs.json')
    need(len(records)==3 and records[0]['status']=='EXPECTED_VDOT_HIGHBIT_REJECTION' and
         all(r['exit_code']==0 and r['process_started'] and not r.get('timed_out') for r in records[1:]),'three closed receipts')
    pins=read(build/'build.json')['software_files'];need(len(pins)==106,'fixed source count')
    need(all(sha(ROOT/n)==pin for n,pin in pins.items()),'unchanged frozen source')
    need(sha(build/'vdot-perf.elf')=='bcbe7088f3548813d8ea24fd3a71ce5cb268e7074e7573bb74680d641e5a33b4' and
         sha(build/'vdot-perf.bin')=='73bc3a0e8b6d172cb427b09c2f6ff5ca2e0b56c0e0c1617b426cdc20bf84342d','build-03 image identity')
    recovery=campaign/'runs/recovery/validation.json';replay=campaign/'runs/replay/validation.json'
    need(recovery.read_bytes()==replay.read_bytes(),'replayed validation equality')
    path=ROOT/TARGET/'archive.py';need(sha(path)=='9107271e4d16dc0a3b0ae23478037612b403b71837be9c835f2d2d35f4635557','frozen archive adapter')
    spec=importlib.util.spec_from_file_location('seal_phased_archive',path);archive=importlib.util.module_from_spec(spec);spec.loader.exec_module(archive)
    need(archive.e.sources(ROOT)==pins,'exact source identity closure')
    out=RUN/'evidence-pack-01';fresh=RUN/'fresh-source-audit-01';receipt=RUN/'archive-driver-01.json'
    need(not out.exists() and not fresh.exists() and not receipt.exists(),'fresh sealing outputs')
    record=dict(status='RUNNING',started=now(),launcher_sha256=sha(__file__),head=HEAD,build=str(build),campaign=str(campaign),
        source_files=106,validation_sha256=sha(recovery),new_emu_runs=0,cpu_affinity=sorted(os.sched_getaffinity(0)))
    save(receipt,record)
    try:
        packed=archive.pack(build,campaign,out);record.update(status='PACKED',packed=packed);save(receipt,record)
        checked=archive.audit_snapshot(out,fresh)
        need(checked['status']=='PHASED_TARGET_ARCHIVE_FRESH_SOURCE_AUDIT_PASS','new source closed audit')
        need(archive.e.sources(ROOT)==pins and all(sha(ROOT/n)==pin for n,pin in pins.items()),'sources remain frozen')
        need(git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b'','checkout remains clean')
        record.update(status='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED',finished=now(),fresh_source=checked,
            archive_files={n:sha(out/n) for n in ('payload.zip','archive-manifest.json','original-audit.json')},
            fresh_source_result_sha256=sha(fresh/'result.json'),frozen_sources_unchanged=True)
        save(receipt,record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(receipt,record)
        (RUN/'archive-driver-01.traceback.txt').write_text(traceback.format_exc());raise
    print(json.dumps(dict(status=record['status'],finished=record['finished'],packed=packed,
        archive_files=record['archive_files'],fresh_source_result_sha256=record['fresh_source_result_sha256']),indent=2))

if __name__=='__main__':main()
