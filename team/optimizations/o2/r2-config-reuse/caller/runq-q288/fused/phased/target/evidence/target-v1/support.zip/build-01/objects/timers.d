/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-01/objects/timers.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-01/source/timers.S
