from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
runroot=root.parents[1]/'runs/fullq-tail-target-20261026-1400'
prior=root.parents[1]/'runs/fullq-phased-target-20261026-1255'
target=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/tail/target'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='a9583d1c0f30565c97a85775b489f1466fa34cad'
assert git('status','--porcelain')==b'' and not (root/'.git/index.lock').exists()
ready=read(runroot/'preparation-01.json');assert ready['status']=='TAIL_TARGET_FROZEN_AND_READY'
assert ready['commit']=='a9583d1c0f30565c97a85775b489f1466fa34cad' and ready['cached_verification_exact'] is True
assert ready['prior_archive_closure_sha256']==sha(prior/'archive-driver-02.json')=='7289ccac077065f155a86f0beb4658d1b22f6c28d62284c865d612de7739223c'
closure=read(prior/'archive-driver-02.json');assert closure['status']=='PHASED_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED'
assert sha(prior/'evidence-pack-02/original-audit.json')==closure['archive_files']['original-audit.json']
selection=read(prior/'evidence-pack-02/original-audit.json')['selection']
assert selection['decision']=='PHASED_PREFERRED_IN_FIXED_PLAN' and selection['selected_id']==1
assert sha(runroot/'screen-01/result.json')==ready['static_result_sha256']=='f6a50e1697fb950eb9c8840c8dfdc67ffe68806324ec24c7f1c0c07d2bc4916e'
assert sha(runroot/'elf-controls-01/result.json')==ready['target_controls_sha256']=='fd0fb21e1a5106bfe7b87b201b0a44c3cb97d74679b96c078bd646a8588ea4ff'
br=read(runroot/'build-01/build.json')
assert br['accepted'] is True and len(br['software_files'])==115 and br['software_files']==ready['source_files']
assert len(ready['supplementary_auditors'])==5
for name,pin in {**br['software_files'],**ready['supplementary_auditors']}.items():assert sha(root/name)==pin,name
for name,pin in br['artifacts'].items():assert sha(runroot/'build-01'/name)==pin,name
assert sha(runroot/'build-01/vdot-perf.elf')=='610c499f46f1fe73074f626d8990bdcbdbc5f78c30ce8fc4a835495b0e392faa'
assert sha(runroot/'build-01/vdot-perf.bin')=='9c4fe592b18336546abee6f8f024beb752141079604edfdd2ced846fa11571a0'
assert not (runroot/'campaign-01').exists()
busy=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=(p/'exe').resolve().name
  if exe in ('emu','verilator','verilator_bin','cc1','cc1plus','make','g++','ninja','riscv64-linux-gnu-gcc'):busy.append(dict(pid=int(p.name),exe=exe))
 except (OSError,RuntimeError):pass
assert not busy,busy
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
argv=[sys.executable,'-B',str(target/'run.py'),'--repo',str(root),'--action','run',
      '--build',str(runroot/'build-01'),'--output',str(runroot/'campaign-01'),
      '--operation-id','20261026-LiZufan001-tail-target-v1-1424']
os.execv(sys.executable,argv)
