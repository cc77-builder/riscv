from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,traceback

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-tail-target-20261026-1400')
TARGET=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/tail/target')
HEAD='a9583d1c0f30565c97a85775b489f1466fa34cad'
sys.dont_write_bytecode=True
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def need(ok,message):
    if not ok:raise ValueError(message)

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    need(git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b'','frozen clean checkout')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    busy=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            name=(p/'exe').resolve().name
            if name=='emu' or name in ('cc1','cc1plus','verilator_bin','ninja'):busy.append((p.name,name))
        except OSError:pass
    need(not busy,'no concurrent EMU/heavy build: '+repr(busy))
    build=RUN/'build-01';campaign=RUN/'campaign-01';state=read(campaign/'state.json')
    need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None and
         state['active_result'] is None and state['new_emu_runs']==3,'closed original campaign')
    records=read(campaign/'completed-runs.json')
    need(len(records)==3 and records[0]['status']=='EXPECTED_VDOT_HIGHBIT_REJECTION' and
         all(r['exit_code']==0 and r['process_started'] and not r.get('timed_out') for r in records[1:]),'three closed receipts')
    pins=read(build/'build.json')['software_files'];need(len(pins)==115,'fixed source count')
    need(all(sha(ROOT/n)==pin for n,pin in pins.items()),'unchanged frozen source')
    need(sha(build/'vdot-perf.elf')=='610c499f46f1fe73074f626d8990bdcbdbc5f78c30ce8fc4a835495b0e392faa' and
         sha(build/'vdot-perf.bin')=='9c4fe592b18336546abee6f8f024beb752141079604edfdd2ced846fa11571a0','build-01 image identity')
    recovery=campaign/'runs/recovery/validation.json';replay=campaign/'runs/replay/validation.json'
    need(recovery.read_bytes()==replay.read_bytes(),'replayed validation equality')
    path=ROOT/TARGET/'archive.py';need(sha(path)=='ee95fcf094a1af5541dc2eb3578275535e2426f19c9326403151efdc8e2e165e','frozen archive adapter')
    spec=importlib.util.spec_from_file_location('seal_tail_archive',path);archive=importlib.util.module_from_spec(spec);spec.loader.exec_module(archive)
    need(archive.e.sources(ROOT)==pins,'exact source identity closure')
    ready=read(RUN/'preparation-01.json');auditors=archive.tools()
    need(ready['status']=='TAIL_TARGET_FROZEN_AND_READY' and ready['commit']==HEAD and
         ready['source_files']==pins and ready['cached_verification_exact'] is True,'exact preparation closure')
    need(len(auditors)==5 and auditors==ready['supplementary_auditors'],'exact supplementary auditor map')
    need(all(pins[n]==pin for n,pin in auditors.items() if n in pins),'overlapping source identities agree')
    need(all(sha(ROOT/n)==pin for n,pin in auditors.items()),'unchanged supplementary auditors')
    need(sha(RUN/'screen-01/result.json')==ready['static_result_sha256'] and
         sha(RUN/'elf-controls-01/result.json')==ready['target_controls_sha256'],'static and ELF control receipts')
    out=RUN/'evidence-pack-01';fresh=RUN/'fresh-source-audit-01';receipt=RUN/'archive-driver-01.json'
    need(not out.exists() and not fresh.exists() and not receipt.exists(),'fresh sealing outputs')
    record=dict(status='RUNNING',started=now(),launcher_sha256=sha(__file__),head=HEAD,build=str(build),campaign=str(campaign),
        source_files=115,supplementary_auditors=auditors,distinct_source_and_auditor_files=len(set(pins)|set(auditors)),
        preparation_sha256=sha(RUN/'preparation-01.json'),validation_sha256=sha(recovery),new_emu_runs=0,cpu_affinity=sorted(os.sched_getaffinity(0)))
    save(receipt,record)
    try:
        packed=archive.pack(build,campaign,out);record.update(status='PACKED',packed=packed);save(receipt,record)
        checked=archive.audit_snapshot(out,fresh)
        need(checked['status']=='TAIL_TARGET_ARCHIVE_FRESH_SOURCE_AUDIT_PASS','new source closed audit')
        need(archive.e.sources(ROOT)==pins and archive.tools()==auditors and
             all(sha(ROOT/n)==pin for n,pin in {**pins,**auditors}.items()),'sources and auditors remain frozen')
        need(git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b'','checkout remains clean')
        record.update(status='TAIL_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED',finished=now(),fresh_source=checked,
            archive_files={n:sha(out/n) for n in ('payload.zip','archive-manifest.json','original-audit.json')},
            fresh_source_result_sha256=sha(fresh/'result.json'),frozen_sources_unchanged=True)
        save(receipt,record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(receipt,record)
        (RUN/'archive-driver-01.traceback.txt').write_text(traceback.format_exc());raise
    print(json.dumps(dict(status=record['status'],finished=record['finished'],packed=packed,
        archive_files=record['archive_files'],fresh_source_result_sha256=record['fresh_source_result_sha256']),indent=2))

if __name__=='__main__':main()
