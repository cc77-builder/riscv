from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess,os,importlib.util
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
monitor=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
target=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target'
runroot=root.parents[1]/'runs/fullq-phased-target-20261026-1255'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='fcf4a11fc569cb2a8fcb4e18d96ec2764b228557' and git('status','--porcelain')==b''
old=json.loads((monitor/'q288-phased-target-source-165.json').read_text())
changes=json.loads((monitor/'q288-phased-target-patch-167.json').read_text())
record=json.loads((runroot/'build-01/build.json').read_text())
assert record['accepted'] is False and record['error']=="KeyError('q288_full')" and not (runroot/'build-02').exists()
for n,v in old.items():assert (target/n).read_text()==v,n
for n,pin in record['software_files'].items():assert sha(root/n)==pin,n
assert set(changes)=={'generate.py','run.py','CONTRACT.md'}
(runroot/'build-01-launch-failure.json').write_text((monitor/'q288-phased-build-01-failure-167.json').read_text())
for n,text in changes.items():(target/n).write_text(text,encoding='utf-8')
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
spec=importlib.util.spec_from_file_location('phased_target_actual_run2',target/'run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
identity=root/m.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
result=m.build(root,identity,runroot/'build-02')
controls=m.elf_controls(runroot/'build-02',runroot/'elf-controls-02')
pins=json.loads((runroot/'build-02/build.json').read_text())['software_files']
assert all(sha(root/n)==v for n,v in pins.items())
report=dict(status='PHASED_TARGET_BUILD_AND_ELF_CONTROLS_PASS',finished=datetime.now(timezone(timedelta(hours=8))).isoformat(),build=(runroot/'build-02').as_posix(),sources={n:sha(target/n) for n in old},source_closure=len(pins),build_accepted=result.get('accepted'),control_status=controls['status'],new_emu_runs=0)
(runroot/'readiness.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
