from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess,os,importlib.util,zipfile
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
monitor=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
target=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target'
runroot=root.parents[1]/'runs/fullq-phased-target-20261026-1255'
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='fcf4a11fc569cb2a8fcb4e18d96ec2764b228557'
assert git('status','--porcelain')==b'' and not (root/'.git/index.lock').exists()
assert not target.exists() and not runroot.exists()
procs=subprocess.check_output(['ps','-eo','pid=,comm='],text=True)
busy=[line for line in procs.splitlines() if line.split()[-1] in ('emu','verilator','mill','cc1','cc1plus','make','ninja')]
assert not busy,('Build/run busy',busy)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target/evidence/target-v1/archive/payload.zip') as z:pins=json.loads(z.read('build/build.json'))['software_files']
assert all(sha(root/n)==v for n,v in pins.items())
payload=json.loads((monitor/'q288-phased-target-source-165.json').read_text())
assert set(payload)=={'main.c','generate.py','run.py','archive.py','CONTRACT.md'}
target.mkdir()
for n,t in payload.items():(target/n).write_text(t,encoding='utf-8')
assert all(sha(root/n)==v for n,v in pins.items())
runroot.mkdir(parents=True)
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
pre=dict(started=datetime.now(timezone(timedelta(hours=8))).isoformat(),source_head=git('rev-parse','HEAD').decode().strip(),sources={n:sha(target/n) for n in payload},frozen98_unchanged=True,process_scan_busy=busy)
(runroot/'installation.json').write_text(json.dumps(pre,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('phased_target_actual_run',target/'run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
identity=root/m.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
result=m.build(root,identity,runroot/'build-01')
control=m.elf_controls(runroot/'build-01',runroot/'elf-controls-01')
assert all(sha(root/n)==v for n,v in pins.items())
report=dict(status='PHASED_TARGET_BUILD_AND_ELF_CONTROLS_PASS',finished=datetime.now(timezone(timedelta(hours=8))).isoformat(),build=runroot.as_posix()+'/build-01',sources={n:sha(target/n) for n in payload},build_status=result.get('status'),control_status=control['status'],new_emu_runs=0)
(runroot/'readiness.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
