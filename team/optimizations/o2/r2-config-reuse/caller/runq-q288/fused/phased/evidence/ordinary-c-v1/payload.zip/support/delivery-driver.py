from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys,traceback,zipfile

ROOT=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
RUN=ROOT.parents[1]/'runs/fullq-tail-target-20261026-1400'
PRIOR=ROOT.parents[1]/'runs/fullq-phased-target-20261026-1255'
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-workspace-reuse-20261026-0141')
MODULE=Path('team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased')
HEAD='a9583d1c0f30565c97a85775b489f1466fa34cad'
PAYLOAD_SHA='b4503d17c736ac4cd87fa43fbb42372bc96de776ff8c02efeae01ae08680b5f1'
sys.dont_write_bytecode=True
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def now():return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
def need(ok,message):
    if not ok:raise ValueError(message)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
    need(git('rev-parse','HEAD').decode().strip()==HEAD and git('status','--porcelain')==b'','exact clean frozen head')
    need(not (ROOT/'.git/index.lock').exists(),'no index lock')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:need((p/'exe').resolve().name not in ('emu','verilator_bin','cc1','cc1plus','make','ninja'),'no concurrent EMU/heavy build')
        except OSError:pass
    closures={}
    for name,base,suffix in (('tail',RUN,'01'),('phased',PRIOR,'02')):
        path=base/('archive-driver-'+suffix+'.json');record=read(path)
        need(record['status']==name.upper()+'_TARGET_RAW_ARCHIVE_FRESH_SOURCE_CLOSED','closed '+name+' runtime evidence')
        need(sha(base/('fresh-source-audit-'+suffix)/'result.json')==record['fresh_source_result_sha256'],'closed fresh source '+name)
        closures[name]={'path':str(path),'sha256':sha(path),'fresh_source_result_sha256':record['fresh_source_result_sha256']}
    payload_path=MONITOR/'q288-api-inputs-188.json';need(sha(payload_path)==PAYLOAD_SHA,'reviewed API payload')
    payload=read(payload_path);files=payload['files']
    expected={'phased.h','tail/tail.h','export.py','example.c','c_api_check.py','README.md'}
    need(set(files)==expected and all(not (ROOT/MODULE/n).exists() for n in files),'six fresh explicit API source paths')
    evidence=ROOT/MODULE/'evidence/ordinary-c-v1';need(not evidence.exists(),'fresh API evidence path')
    receipt=RUN/'api-delivery-01.json';need(not receipt.exists(),'fresh API operation identity')
    record=dict(status='INSTALLING',started=now(),base=HEAD,driver_sha256=sha(__file__),payload_sha256=PAYLOAD_SHA,
        runtime_closures=closures,new_emu_runs=0)
    save(receipt,record)
    try:
        for name,text in files.items():
            p=ROOT/MODULE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
            need(sha(p)==payload['sha256'][name],'installed exact API bytes '+name)
        host_path=ROOT/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/target/host_audit.py'
        need(sha(host_path)=='0fa2f707274aa90a8e45839966e0caf849a2d80ec370292ffee75020d9239d91','fixed durable helper')
        host=load('q288_api_durable',host_path);results={};outputs={}
        for variant,base,build_id in (('tail',RUN,'01'),('phased',PRIOR,'03')):
            out=RUN/('api-check-'+variant+'-01');command_dir=RUN/('api-command-'+variant+'-01')
            need(not out.exists() and not command_dir.exists(),'new per-variant API outputs')
            record.update(status='CHECKING_'+variant.upper());save(receipt,record)
            command=host.durable_child([sys.executable,'-I','-B',str(ROOT/MODULE/'c_api_check.py'),
                '--repo',str(ROOT),'--variant',variant,'--build',str(base/('build-'+build_id)),
                '--output',str(out)],cwd=ROOT,env=dict(os.environ),seconds=300,out=command_dir)
            need(command.returncode==0,'actual GNU C API check '+variant+' failed; all raw outputs retained')
            result=read(out/'result.json')
            need(result['status']=='Q288_ORDINARY_C_FINAL_LINK_AND_TARGET_BYTES_PASS' and result['variant']==variant and
                 result['new_emu_runs']==0 and result['new_target_runtime_qualification'] is False and
                 result['new_performance_qualification'] is False and result['stable_default_changed'] is False,
                 'bounded actual API acceptance '+variant)
            results[variant]=result;outputs[variant]=(out,command_dir)
        frozen=read(RUN/'build-01/build.json')['software_files']
        need(len(frozen)==115 and all(sha(ROOT/n)==pin for n,pin in frozen.items()),'all runtime sources unchanged')
        need(git('rev-parse','HEAD').decode().strip()==HEAD and git('diff','--name-only')==b'' and
             git('diff','--cached','--name-only')==b'','no concurrent source or index mutation')
        evidence.mkdir(parents=True);members={}
        for variant,dirs in outputs.items():
            for label,directory in zip(('check','command'),dirs):
                for p in sorted(directory.rglob('*')):
                    if p.is_file():members[variant+'/'+label+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
        members['support/delivery-driver.py']=Path(__file__).read_bytes()
        members['support/api-inputs.json']=payload_path.read_bytes()
        manifest={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in sorted(members.items())}
        archive=evidence/'payload.zip'
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for name,raw in sorted(members.items()):
                info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                info.external_attr=0o100644<<16;z.writestr(info,raw)
        with zipfile.ZipFile(archive) as z:
            need(sorted(z.namelist())==sorted(manifest),'all API evidence members retained')
            for name,pin in manifest.items():
                raw=z.read(name);need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'API archive raw equality '+name)
        save(evidence/'manifest.json',dict(archive_sha256=sha(archive),members=manifest))
        summary=dict(status='Q288_ORDINARY_C_TWO_VARIANT_DELIVERY_PASS',started=record['started'],finished=now(),
            runtime_closures=closures,source_sha256=payload['sha256'],archive_sha256=sha(archive),
            archive_members=len(manifest),original_bytes=sum(v['bytes'] for v in manifest.values()),
            variants={n:dict(status=v['status'],consumer_elf_sha256=v['consumer_elf_sha256'],
                target_elf_sha256=v['target_elf_sha256'],exported_symbols=v['exported_symbols'],
                function_sha256=v['function_sha256'],actual_C_calls=v['actual_C_calls'],
                qualified_runtime_sources_checked=v['qualified_runtime_sources_checked'],
                call_decoder_controls=v['call_decoder_controls'],
                cached_result_representation_adapter=v['cached_result_representation_adapter']) for n,v in results.items()},
            new_emu_runs=0,new_target_runtime_qualification=False,new_performance_qualification=False,
            stable_default_changed=False,frozen_sources_unchanged=True)
        save(evidence/'summary.json',summary)
        evidence_names={'payload.zip','manifest.json','summary.json'}
        need({p.name for p in evidence.iterdir()}==evidence_names and all((evidence/n).is_file() for n in evidence_names),'exact three evidence files')
        for name,pin in payload['sha256'].items():need(sha(ROOT/MODULE/name)==pin,'tested API source unchanged before staging '+name)
        names=sorted([(MODULE/n).as_posix() for n in files]+[(MODULE/'evidence/ordinary-c-v1'/n).as_posix() for n in evidence_names])
        need(len(names)==9,'six source and three evidence files')
        git('add','-f','--',*names)
        need(set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==set(names),'exact API staged paths')
        for name in names:need(git('show',':'+name)==(ROOT/name).read_bytes(),'actual staged bytes '+name)
        git('diff','--cached','--check');git('-c','gc.auto=0','commit','-m','Expose explicit Q288 C entries and verify both final linked variants')
        need(git('status','--porcelain')==b'','clean C API delivery')
        record.update(status='Q288_ORDINARY_C_TWO_VARIANT_DELIVERED',finished=now(),commit=git('rev-parse','HEAD').decode().strip(),
            tree=git('rev-parse','HEAD^{tree}').decode().strip(),files={n:dict(bytes=(ROOT/n).stat().st_size,sha256=sha(ROOT/n)) for n in names},
            summary_sha256=sha(evidence/'summary.json'),frozen_sources_unchanged=True)
        save(receipt,record)
    except BaseException as error:
        record.update(status='FAILED',finished=now(),error=repr(error));save(receipt,record)
        (RUN/'api-delivery-01.traceback.txt').write_text(traceback.format_exc());raise
    print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))

if __name__=='__main__':main()
