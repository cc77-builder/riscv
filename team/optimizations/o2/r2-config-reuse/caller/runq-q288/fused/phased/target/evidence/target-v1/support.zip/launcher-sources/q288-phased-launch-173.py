from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
runroot=root.parents[1]/'runs/fullq-phased-target-20261026-1255'
target=root/'team/optimizations/o2/r2-config-reuse/caller/runq-q288/fused/phased/target'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='34092ebcf579a5de76e70cadfb6a5333173891ae'
assert git('status','--porcelain')==b'' and not (root/'.git/index.lock').exists()
ready=json.loads((runroot/'readiness-final.json').read_text());assert ready['status']=='PHASED_TARGET_FROZEN_AND_READY'
br=json.loads((runroot/'build-03/build.json').read_text())
assert br['accepted'] is True and len(br['software_files'])==106
for name,pin in {**br['software_files'],**ready['supplementary_auditors']}.items():assert sha(root/name)==pin,name
for name,pin in br['artifacts'].items():assert sha(runroot/'build-03'/name)==pin,name
assert not (runroot/'campaign-01').exists()
busy=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  exe=(p/'exe').resolve().name
  if exe in ('emu','verilator','cc1','cc1plus','make','g++','riscv64-linux-gnu-gcc'):busy.append(dict(pid=int(p.name),exe=exe))
 except (OSError,RuntimeError):pass
assert not busy,busy
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
argv=[sys.executable,'-B',str(target/'run.py'),'--repo',str(root),'--action','run',
      '--build',str(runroot/'build-03'),'--output',str(runroot/'campaign-01'),
      '--operation-id','20261026-LiZufan001-phased-target-v1-1312']
os.execv(sys.executable,argv)
