/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/objects/oracle.o: \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/source/oracle.c \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/source/q288.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/source/split.h \
 /home/lizufan/riscv-lab/r5-firstdot-20261026-0056/runs/fullq-phased-target-20261026-1255/build-02/source/caller.h
