import importlib.util,json,sys
from pathlib import Path
original=Path(sys.argv[1]);root=Path(sys.argv[2]);reference=Path(sys.argv[3])
spec=importlib.util.spec_from_file_location('frozen_fixed_anchor',original)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOT=root
module.main()
new=json.loads((root/'anchor-diagnostic-01.json').read_text());old=json.loads(reference.read_text())
different=[k for k in set(old)|set(new) if old.get(k)!=new.get(k)]
assert set(different)<= {'started','finished'},different
(root/'replay-comparison.json').write_text(json.dumps(dict(status='ANCHOR_REPLAY_EXACT_EXCEPT_TIME',different_fields=different,all_other_fields_equal=True,new_emu_runs=0),indent=2)+'\n')
