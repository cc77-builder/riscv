from pathlib import Path
import base64,hashlib,importlib.util,json,os,shutil,subprocess,sys,time,zipfile

os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
root=Path(__file__).resolve().parent
out=root/'historical-probe-02'
out.mkdir(exist_ok=False)
payload=base64.b64decode((root/'history-input-01.b64').read_text().strip(),validate=True)
assert hashlib.sha256(payload).hexdigest()=='c4395b8b29ae5c421ffb969b8533225baf21ed3b281e085207a93499ecfd197b'
(out/'input.zip').write_bytes(payload)
with zipfile.ZipFile(out/'input.zip') as z:z.extractall(out/'input')
source=out/'source';shutil.copytree(root/'offline-01/repo',source)
module=source/'team/optimizations/o2/r2-config-reuse/caller/fixed-weight'
shutil.copyfile(root/'fixed-weight/archive.py',module/'archive.py')
parent=module.parent/'split/archive.py'
shutil.copyfile(root/'upstream/team/optimizations/o2/r2-config-reuse/caller/split/archive.py',parent)
identity=source/'team/optimizations/o2/repro/evidence/clean-reproduction-v1/reports/identity-02.json'
identity.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(out/'input/parent-identity.json',identity)
guard=source/'team/optimizations/o2/repro/evidence/clean-reproduction-v1/analysis/detached-audit.py'
guard.parent.mkdir(parents=True,exist_ok=True)
raw=(root/'probe-assets/detached-audit.py').read_bytes()
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='560462e932c2315cb17786f2ee65a18b9ddcee5e'
shutil.copyfile(root/'probe-assets/detached-audit.py',guard)
sys.path.insert(0,str(module))
spec=importlib.util.spec_from_file_location('archive_probe',module/'archive.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
history=a.install_history(out/'input',source,out)
probe=module/'probe_parent_identity.py'
probe.write_text('''from pathlib import Path
import argparse,json,hashlib,subprocess
import run as e
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
identity=e.ROOT/e.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
actual=e.parent.parent_identity(e.ROOT,identity)
frozen=e.parent.t17.a.frozen_f
paths=[p.as_posix() for p in frozen.CHECKER_PATHS if p!=frozen.H1DIR/'build_profile.py']
pins={}
for name in paths:
 raw=subprocess.check_output(['git','show',frozen.g.BASE+':'+name],cwd=e.ROOT)
 assert raw==(e.ROOT/name).read_bytes()
 pins[name]=hashlib.sha256(raw).hexdigest()
result=dict(status='FROZEN_PARENT_IDENTITY_WITH_MINIMAL_ORIGINAL_GIT_PASS',base=frozen.g.BASE,
 checker_blobs=pins,parent_identity_sha256=e.g.sha(identity),parent_contract=actual['contract'],
 new_emu_runs=0,physical_external_inputs_revalidated=False)
assert not args.output.exists();args.output.write_text(json.dumps(result,indent=2)+'\\n')
''')
argv=[sys.executable,'-I','-B',str(guard),'--checkout',str(source),'--script',str(probe),
      '--report',str(out/'guard.json'),'--deny-root',str(root/'offline-01/repo'),
      '--deny-root','/home/lizufan/riscv-lab','--deny-root','/home/riscv/riscv-lab',
      '--','--output',str(out/'probe.json')]
start=time.time();p=subprocess.run(argv,cwd=source,capture_output=True,env=a.clean_environment(),timeout=120)
for n,b in [('stdout.log',p.stdout),('stderr.log',p.stderr)]:(out/n).write_bytes(b)
record=dict(command=argv,exit_code=p.returncode,elapsed_seconds=time.time()-start,source_object_count=len(history['objects']),
 driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),archive_tool_sha256=hashlib.sha256((module/'archive.py').read_bytes()).hexdigest(),
 guard_source_sha256=hashlib.sha256(guard.read_bytes()).hexdigest(),new_emu_runs=0,
 raw_sha256={n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ('stdout.log','stderr.log')})
(out/'driver.json').write_text(json.dumps(record,indent=2)+'\n')
assert p.returncode==0,p.stderr.decode()
proof=json.loads((out/'guard.json').read_text());assert proof['status']=='T17_DETACHED_AUDIT_PASS' and not proof['rejected_runtime_accesses']
print(json.dumps(dict(record,probe=json.loads((out/'probe.json').read_text()),guard_status=proof['status']),indent=2))
