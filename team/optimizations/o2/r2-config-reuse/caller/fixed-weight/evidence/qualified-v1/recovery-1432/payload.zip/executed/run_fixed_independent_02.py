import concurrent.futures,datetime,hashlib,json,os,platform,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=Path("/workspace/scratch/8badfa91c8fb/fixed-audit-20261025-1456-02");OUT.mkdir(exist_ok=False)
os.sched_setaffinity(0,{0,1,2,3})
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
mod=ROOT/'team/optimizations/o2/r2-config-reuse/caller/fixed-weight';restored=ROOT/'fixed-restored-01'
layout=OUT/'anchor-layout';layout.mkdir()
for name,target in [('source',ROOT),('build-02',restored/'runtime/build'),('run-01',restored/'runtime/run')]: (layout/name).symlink_to(target,target_is_directory=True)
shutil.copytree(restored/'post-checks/post',layout/'post-01')
for name in ('mutations.json','statistics.json'):shutil.copyfile(mod/'evidence/qualified-v1/reports'/name,layout/'post-01'/name)
tasks=[
 ('fresh-source',[sys.executable,'-B',str(mod/'archive.py'),'--action','audit-snapshot','--archive',str(mod/'evidence/qualified-v1/runtime'),'--output',str(OUT/'fresh-source')]),
 ('statistics',[sys.executable,'-B',str(mod/'statistics_check.py'),'--build',str(restored/'runtime/build'),'--run',str(restored/'runtime/run'),'--output',str(OUT/'statistics.json')]),
 ('anchor',[sys.executable,'-B',str(ROOT/'replay_fixed_anchor.py'),str(restored/'post-checks/monitor/anchor-diagnostic-02.py'),str(layout),str(restored/'post-checks/preparation/anchor-diagnostic-01.json')])]
def run(item):
 name,argv=item;start=now()
 with (OUT/(name+'-stdout.log')).open('wb') as stdout,(OUT/(name+'-stderr.log')).open('wb') as stderr:p=subprocess.run(argv,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=240)
 row=dict(name=name,command=argv,cwd=str(ROOT),started=start,finished=now(),exit_code=p.returncode,cpu_affinity=sorted(os.sched_getaffinity(0)),new_emu_runs=0)
 for stream in ('stdout','stderr'):
  f=OUT/(name+'-'+stream+'.log');row[stream]=dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 (OUT/(name+'-execution.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(dict(name=name,exit_code=p.returncode,started=start,finished=row['finished'])),flush=True)
 return row
start=now()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: rows=list(pool.map(run,tasks))
receipt=dict(status='PASS' if all(r['exit_code']==0 for r in rows) else 'FAIL',started=start,finished=now(),python=sys.version,platform=platform.platform(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=rows,new_emu_runs=0)
(OUT/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
sys.exit(0 if receipt['status']=='PASS' else 1)
