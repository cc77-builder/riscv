# Fixed-weight sealed library independent byte audit

Status: INDEPENDENT_SEALED_FIXED_LIBRARY_BYTE_IDENTITY_PASS

Four archive members, 27 functions, 21880 total machine-code bytes.

Each function is identical in the extracted public archive member, original sealed object,
sealed final consumer.elf, and qualified runtime vdot-perf.elf.

Input SHA256 identities, cached-evidence checks, individual function hashes, and commands
are recorded in result.json, inputs-before.json, inputs-after.json, and commands/.

No compilation, relink, or EMU execution was performed. Existing performance HOLD remains.

| Function | Member | Bytes | SHA256 |
|---|---|---:|---|
| config_reuse_gemv_16x64_basic_rvv | gemv.o | 2340 | 6120d030ff0554a290808e8c558c37574126e484c16b921e349801f2049efc80 |
| config_reuse_gemv_16x64_basic_vdot | gemv.o | 4064 | 0bca11ba99695b90c726b5be678ecc904067a3861940ebd1423a7fb9cfcfd732 |
| config_reuse_gemv_16x64_reuse_rvv | gemv.o | 1432 | 902d7053a5d589be80cd29ad6426c3bcbc81a11f79d92e30385b0b328dd3a4d5 |
| config_reuse_gemv_16x64_reuse_vdot | gemv.o | 2432 | fa182f5acbbeac8edd3db7efb729c242f77d83786435713861b5f29b6a2d3e57 |
| config_reuse_gemv_4x13_basic_rvv | gemv.o | 228 | 1c5acbe10427ce28bf36c8de45cf23d184661ef380adb8a44da4321e852722f3 |
| config_reuse_gemv_4x13_basic_vdot | gemv.o | 560 | 557fc1d2c76f331c41467be2c7abcd6dcf96b7fc1206eee3b7b49e532766ad85 |
| config_reuse_gemv_4x13_reuse_rvv | gemv.o | 172 | ab8769ad4a5d514afc967087152fef342e51637532ba063426a0de4ae1d19572 |
| config_reuse_gemv_4x13_reuse_vdot | gemv.o | 452 | 5131bab9c40bc7437915d102193fdbd9723ce969eaed3703fd48dd1dee1679b6 |
| config_reuse_gemv_4x8_basic_rvv | gemv.o | 228 | 9df75f6cf559a652cb0614d16bf1b90bdc1e11ac7d82a2989430a9d9594c760b |
| config_reuse_gemv_4x8_basic_vdot | gemv.o | 144 | 8282f1c3f4ba12f5417bee2dd05f5af2bca43c460abcb19721a72e84cabe6eb0 |
| config_reuse_gemv_4x8_reuse_rvv | gemv.o | 168 | 91023ebba26450c69cd7be20beca7adc173fe448af49f73d02edd0ff4f2d5465 |
| config_reuse_gemv_4x8_reuse_vdot | gemv.o | 120 | 0ca4123ae9480ce5eaaba4b4a0a8f1d56381aa6cde55481452b52c8eba4fe9ad |
| config_reuse_gemv_8x32_basic_rvv | gemv.o | 676 | c33e1fb01a939cf68d4a867a5daf6b5fe4dc7bf9536d644808949ef555052def |
| config_reuse_gemv_8x32_basic_vdot | gemv.o | 1024 | 8d1477ca1b46f467b7db2fda88c63ae728babb076b2efe4263a79365df3a774b |
| config_reuse_gemv_8x32_reuse_rvv | gemv.o | 448 | ea86a50cd67113246dae98ef7ce8db4e0d1383f453d889c6aad6cf2579857513 |
| config_reuse_gemv_8x32_reuse_vdot | gemv.o | 656 | 3bca83077ccd7529ff6f80c9002441c99d27d3113aa8b10769ad26f3c4e9c64d |
| firstdot_gemv_8x32_reuse_rvv | strong.o | 452 | f304ee128fbac736755d1fe7d03b6d8e8f6ea30e625dc1937f379445e6c23137 |
| fixed_packed | fixed.o | 264 | a23c761d0a1f599d0e9b0d94e78d7af4e504f064a73f6d6a841502a578a5b870 |
| fixed_split | fixed.o | 188 | fe4f86e9acfc1b0b01bb51da629a215a33d26a9ef8ddb6caf9df890fdf8ecdab |
| r4_gemv_8x32_basic_rvv | strong.o | 1060 | 6f7c75562128eecc42c54ef840d0a6d04bd9446a4703e595ee61ffa432b5ecbe |
| r4_gemv_8x32_reuse_rvv | strong.o | 740 | 20ee57db9abe4bf501608dc6680ff9ccc39c7ccd5fcadb637026da20edc2afc4 |
| split_gemv_8x32_rvv0 | kernels.o | 1060 | b17cf05f583cdfe98080cf329ee22b6ce7250d1f029bcc1604b774403006c1b5 |
| split_gemv_8x32_rvv1 | kernels.o | 740 | b1d6b2d13452386e7aeaf62937e58eca4780d3a6c72c22bcd7cf8cc1bd35dd9f |
| split_gemv_8x32_rvv2 | kernels.o | 676 | 308e724cf6fe6eac3a38dff3c1cd8c4cf373aad8ec97faf752917e18c749b585 |
| split_gemv_8x32_rvv3 | kernels.o | 452 | 2e977143be3bfde28a8c1b824686f8265fd41484931d05715ecf44d3596377d6 |
| split_gemv_8x32_rvv4 | kernels.o | 448 | 8842f65de742638a3d8c28e4bea273acf6841c4aab6819f282017803d0b6f59c |
| split_gemv_8x32_vdot | kernels.o | 656 | 3c0a2c78c5f3f7ae9ca09ad74ab7e63fa9df936eea1059850ae55cf1eedc624b |
