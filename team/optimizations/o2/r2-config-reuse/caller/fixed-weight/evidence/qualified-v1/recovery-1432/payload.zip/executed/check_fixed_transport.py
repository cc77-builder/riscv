import hashlib,importlib.util,json,shutil,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MOD=ROOT/'team/optimizations/o2/r2-config-reuse/caller/fixed-weight'
SOURCE=MOD/'evidence/qualified-v1/runtime'
OUT=ROOT/'fixed-transport-checks-01'
OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('fixed_restore_transport',MOD/'restore_archive.py')
restore=importlib.util.module_from_spec(spec);spec.loader.exec_module(restore)
transport=json.loads((SOURCE/'transport.json').read_text())
names=['transport.json',*transport['metadata'],*[p['path'] for p in transport['parts']]]
checks=[]
with tempfile.TemporaryDirectory(prefix='fixed-transport-checks-') as temp:
 base=Path(temp);source=base/'published';source.mkdir()
 for name in names:
  dst=source/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/name,dst)
 assert not (source/'payload.zip').exists()
 positive=base/'restored'
 receipt=restore.restore(source,positive)
 assert (positive/'payload.zip').read_bytes()==(SOURCE/'payload.zip').read_bytes()
 for name in transport['metadata']:assert (positive/name).read_bytes()==(SOURCE/name).read_bytes()
 (OUT/'restoration.json').write_text(json.dumps(receipt,indent=2)+'\n')
 checks.append(dict(case='published_parts_only',passed=True,zip_bytes=transport['bytes'],sha256=transport['sha256'],metadata_exact=True))
 def expect_reject(label,source,dest,expected):
  try:restore.restore(source,dest)
  except ValueError as exc:
   assert expected in str(exc),(label,str(exc))
   checks.append(dict(case=label,passed=True,error=str(exc),completed_payload_exists=(dest/'payload.zip').exists()))
  else:raise AssertionError('unexpected acceptance: '+label)
 part=source/transport['parts'][0]['path']
 with part.open('r+b') as f:
  f.seek(12345);b=f.read(1);f.seek(12345);f.write(bytes([b[0]^1]))
 expect_reject('bit_flip_in_fragment',source,base/'corrupt-output','fragment identity')
 shutil.copyfile(SOURCE/part.name,part)
 altered=json.loads((source/'transport.json').read_text());altered['parts'][0],altered['parts'][1]=altered['parts'][1],altered['parts'][0]
 (source/'transport.json').write_text(json.dumps(altered))
 expect_reject('fragment_order',source,base/'wrong-order-output','ordered fragment names')
 shutil.copyfile(SOURCE/'transport.json',source/'transport.json')
 existing=base/'preexisting';existing.mkdir();(existing/'keep').write_bytes(b'unchanged')
 expect_reject('preexisting_output',source,existing,'fresh output')
 assert (existing/'keep').read_bytes()==b'unchanged'
record=dict(status='FIXED_WEIGHT_FRAGMENT_TRANSPORT_CHECKS_PASS',checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),restore_source_sha256=hashlib.sha256((MOD/'restore_archive.py').read_bytes()).hexdigest(),transport_sha256=hashlib.sha256((SOURCE/'transport.json').read_bytes()).hexdigest(),checks=checks,new_emu_runs=0)
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
