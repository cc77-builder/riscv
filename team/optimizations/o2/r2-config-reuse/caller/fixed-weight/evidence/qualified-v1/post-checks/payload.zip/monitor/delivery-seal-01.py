"""Seal a staged, documented delivery; never invokes Git or an EMU."""
from pathlib import Path
import hashlib,json,os,shutil,time

ROOT=Path('/home/lizufan/riscv-lab/r2s3-fixed-weight-20261025-0920')
PUBLISH=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s3-fixed-weight-20261025-0920')
REL=Path('team/optimizations/o2/r2-config-reuse/caller/fixed-weight')
OPERATION='20261025-LiZufan001-r2s3-fixed-weight-0920'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def need(ok,why):
 if not ok:raise ValueError(why)
def save(p,value):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
def copy(src,dst):
 need(src.is_file() and not src.is_symlink(),'regular source required')
 need(not dst.exists(),'fresh evidence destination required: '+str(dst))
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 need(sha(src)==sha(dst),'copy differs')
def filemap(root):
 out={}
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'unexpected evidence symlink')
  if p.is_file():out[p.relative_to(root).as_posix()]=p
 return out

def main():
 os.sched_setaffinity(0,{0})
 source,build,run,post,stage=ROOT/'source',ROOT/'build-02',ROOT/'run-01',ROOT/'post-01',ROOT/'delivery-01'
 module=PUBLISH/REL;evidence=module/'evidence/qualified-v1';out=ROOT/'seal-01'
 state=read(run/'state.json');pr=read(post/'postprocess.json');sr=read(stage/'stage-receipt.json')
 need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['operation_id']==OPERATION and
      state['new_emu_runs']==3 and state['active_pid'] is None and state['active_result'] is None,'original campaign closed')
 need(pr['status']=='FIXED_WEIGHT_POSTPROCESSING_PASS' and pr['original_run_state_sha256']==sha(run/'state.json'),'original accepted postprocessing')
 need(sr['status']=='QUALIFIED_ARTIFACTS_STAGED_NOT_PUBLISHED' and sr['new_emu_runs']==0,'original stage')
 staged={r['path']:r for r in sr['staged_files']};existing=filemap(module)
 need(set(existing)==set(staged)|{'RESULT.md'},'unexpected files before final sealing')
 for name,row in staged.items():
  need(sha(existing[name])==row['sha256'] and existing[name].stat().st_size==row['bytes'],'staged bytes changed: '+name)
 result=(module/'RESULT.md').read_text()
 need('{{' not in result and 'HOLD_CONTEXT_VARIATION' in result and OPERATION in result,'filled actual RESULT required')
 summary=read(evidence/'reports/summary.json')
 need(all(g['decision']=='HOLD_CONTEXT_VARIATION' and g['selected_method'] is None for g in summary['by_count'].values()),'actual HOLD decision')
 need(sha(build/'build.json')==sr['build_sha256']==pr['original_build_sha256']==summary['build_sha256'],'accepted build identity')
 need(sha(build/'vdot-perf.bin')==sr['image_sha256']==pr['image_sha256']==summary['image_sha256'],'accepted image identity')
 br=read(build/'build.json')
 source_pins={}
 for name,pin in br['software_files'].items():
  need(sha(source/name)==pin,'native frozen runtime source changed: '+name)
  need(sha(PUBLISH/name)==pin,'published runtime source differs: '+name)
  source_pins[name]=pin
 need(len(source_pins)==74,'accepted source closure count')
 linked=read(post/'library/library.json')
 for name in ('fixed.h','split.h','caller.h','fixed_entries.h','fixed.c','gemv.S','strong.S','kernels.S','example.c','libxs_fixed_weight_8x32.a'):
  need(sha(module/'public'/name)==sha(post/'library'/name),'actual public artifact differs: '+name)
 need(not out.exists(),'fresh sealing output');out.mkdir()
 copy(Path(__file__).resolve(),out/'executed-seal.py')
 checks=evidence/'delivery-checks'
 copy(Path(__file__).resolve(),checks/'executed-seal.py')
 copy(stage/'stage-receipt.json',checks/'stage-receipt.json')
 save(checks/'source-identity.json',dict(status='NATIVE_AND_WINDOWS_RUNTIME_SOURCE_BYTES_IDENTICAL',
      build_sha256=sha(build/'build.json'),image_sha256=sha(build/'vdot-perf.bin'),software_files=source_pins,
      scope='74 accepted runtime input files, not a new build or runtime qualification'))
 diagnostic=ROOT/'diagnostic-01'
 if diagnostic.exists():
  command=read(diagnostic/'command.json')
  need(set(command['raw_sha256'])=={'stdout.log','stderr.log'},'complete diagnostic log identities')
  for name,pin in command['raw_sha256'].items():need(sha(diagnostic/name)==pin,'diagnostic raw receipt mismatch')
  optional=ROOT/'anchor-diagnostic-01.json'
  if optional.exists():
   result=read(optional)
   need(command['process_started'] and command['exit_code']==0 and not command.get('timed_out') and
        result['status']=='POSTHOC_QUALIFIED_ANCHOR_TIMING_DECOMPOSITION' and
        result['build_sha256']==sha(build/'build.json') and result['image_sha256']==sha(build/'vdot-perf.bin') and
        result['state_sha256']==sha(run/'state.json') and
        result['diagnostic_source_sha256']==sha(diagnostic/'executed-diagnostic.py')=='f5bb66665dcdfac3d9827bdd43dec5fe72c6ad08eda3c059ce74c2b750f2ba12' and
        result['new_emu_runs']==0 and result['qualification_unchanged'] is True,'accepted optional diagnostic identity')
  for name,path in filemap(diagnostic).items():copy(path,evidence/'anchor-diagnostic'/name)
  if optional.exists():copy(optional,evidence/'anchor-diagnostic/result.json')
  # An optional diagnostic failure remains evidence and cannot change HOLD.
  need((evidence/'anchor-diagnostic/command.json').exists(),'original diagnostic receipt required')
 manifest_path=evidence/'delivery-manifest.json';need(not manifest_path.exists(),'fresh final manifest')
 rows=[]
 for name,path in filemap(module).items():
  data=path.read_bytes()
  rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),
      git_blob_sha1=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()))
 doc_paths=('team/docs/development-route-current.md','开发计分板.md')
 docs={name:sha(PUBLISH/name) for name in doc_paths}
 manifest=dict(format='fixed-weight-delivery-manifest-v1',operation_id=OPERATION,
      created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),base_commit='3d56e84aca5cc63bf235f6fbcf76ce8079c9581c',
      path_root=REL.as_posix(),self_excluded='evidence/qualified-v1/delivery-manifest.json',
      files=rows,related_documents=docs,image_sha256=sha(build/'vdot-perf.bin'),build_sha256=sha(build/'build.json'),
      original_run_state_sha256=sha(run/'state.json'),postprocess_sha256=sha(post/'postprocess.json'),
      overall_decision='HOLD_CONTEXT_VARIATION',new_emu_runs_during_sealing=0,
      scope='Exact delivered bytes; Git index/commit/remote checks are recorded separately in publication receipts')
 save(manifest_path,manifest)
 for row in rows:need(sha(module/row['path'])==row['sha256'],'file changed while sealing')
 receipt=dict(status='DOCUMENTED_DELIVERY_SEALED_NOT_PUBLISHED',manifest_sha256=sha(manifest_path),
      files_excluding_manifest=len(rows),bytes_excluding_manifest=sum(r['bytes'] for r in rows),
      related_documents=docs,source_files=74,new_emu_runs=0,git_publication_pending=True)
 save(out/'seal-receipt.json',receipt);print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
