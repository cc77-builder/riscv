#!/usr/bin/env python3
"""Read-only independent audit of sealed fixed-weight archive machine bytes.

No compilation, relink, simulation, or primary runtime/archive audit is invoked.
All outputs are confined to this script's independent directory.
"""
import ast
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/8badfa91c8fb/xiangshan-round-20261025-1432')
OUT = Path(__file__).resolve().parent
SEALED = ROOT / 'fixed-restored-01/post-checks/post/library'
RUNTIME = ROOT / 'fixed-restored-01/runtime/build'
CALLER = ROOT / 'team/optimizations/o2/r2-config-reuse/caller'
PUBLIC = CALLER / 'fixed-weight/public/libxs_fixed_weight_8x32.a'
PARSER = ROOT / 'team/optimizations/o2/r2-safe-tail/linked_gate.py'
MEMBERS = ('fixed.o', 'gemv.o', 'strong.o', 'kernels.o')
PREFIXES = ('fixed_', 'config_reuse_gemv_', 'r4_gemv_', 'firstdot_gemv_', 'split_gemv_')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def require(condition, message):
    if not condition:
        raise ValueError(message)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def command(label, argv, output=None):
    base = OUT / 'commands' / label
    base.mkdir(parents=True, exist_ok=False)
    completed = subprocess.run(argv, cwd=OUT, capture_output=True, check=False)
    stdout = output or (base / 'stdout.log')
    stdout.write_bytes(completed.stdout)
    stderr = base / 'stderr.log'
    stderr.write_bytes(completed.stderr)
    receipt = dict(argv=argv, cwd=str(OUT), returncode=completed.returncode,
        stdout_path=str(stdout), stdout_bytes=len(completed.stdout),
        stdout_sha256=sha(completed.stdout), stderr_path=str(stderr),
        stderr_bytes=len(completed.stderr), stderr_sha256=sha(completed.stderr))
    save(base / 'command.json', receipt)
    require(completed.returncode == 0, f'{label}: command returned {completed.returncode}')
    require(not completed.stderr, f'{label}: unexpected stderr')
    return completed.stdout, receipt

def main():
    started = utc()
    if hasattr(os, 'sched_getaffinity'):
        os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    ar = shutil.which('ar')
    require(ar is not None, 'host ar unavailable')
    source_paths = [Path(__file__).resolve(), PARSER, CALLER / 'experiment.py',
        CALLER / 'split/generate.py', CALLER / 'fixed-weight/library.py']
    artifacts = [PUBLIC, SEALED / 'libxs_fixed_weight_8x32.a',
        *(SEALED / member for member in MEMBERS), SEALED / 'consumer.elf',
        SEALED / 'library.json', RUNTIME / 'vdot-perf.elf', RUNTIME / 'build.json',
        SEALED / 'example.o', SEALED / 'link-all.o']
    paths = source_paths + artifacts + [Path(ar)]
    before = {str(path): dict(bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
              for path in paths}
    save(OUT / 'inputs-before.json', before)
    state = dict(status='RUNNING', started=started, inputs_before=before,
        commands=[], functions={}, scope='sealed-artifact machine-byte identity only',
        new_compilations=0, new_links=0, new_emu_runs=0,
        cpu_affinity=sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None)
    save(OUT / 'result.json', state)
    try:
        raw, receipt = command('ar-version', [ar, '--version'])
        state['commands'].append(receipt)
        raw, receipt = command('members', [ar, 't', str(PUBLIC)])
        state['commands'].append(receipt)
        require(raw.decode().splitlines() == list(MEMBERS), 'exact archive member inventory/order')
        require(PUBLIC.read_bytes() == (SEALED / 'libxs_fixed_weight_8x32.a').read_bytes(),
            'public archive differs from original sealed archive')

        spec = importlib.util.spec_from_file_location('independent_fixed_elf_reader', PARSER)
        elf_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(elf_module)
        ELF = elf_module.ELF
        extracted = OUT / 'members'
        extracted.mkdir(exist_ok=False)
        objects, original_objects = {}, {}
        for name in MEMBERS:
            raw, receipt = command('extract-' + name, [ar, 'p', str(PUBLIC), name], extracted / name)
            state['commands'].append(receipt)
            require(raw == (SEALED / name).read_bytes(), f'extracted/original object mismatch: {name}')
            objects[name] = ELF(raw)
            original_objects[name] = ELF((SEALED / name).read_bytes())
            require(objects[name].kind == original_objects[name].kind == 1, f'non-ET_REL member: {name}')

        # Reconstruct the inventory from its reviewed source definitions, independently
        # of the cached library.json function inventory.
        tree = ast.parse((CALLER / 'split/generate.py').read_text())
        leaves_assignment = [node for node in tree.body if isinstance(node, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == 'LEAVES' for target in node.targets)]
        require(len(leaves_assignment) == 1, 'unique LEAVES source definition')
        six_leaves = ast.literal_eval(leaves_assignment[0].value)
        public_leaves = {'config_reuse_gemv_' + shape + '_' + variant + '_' + method
            for shape in ('4x8', '8x32', '16x64', '4x13')
            for variant in ('basic', 'reuse') for method in ('vdot', 'rvv')}
        new_leaves = {'split_gemv_8x32_' + ('vdot' if i == 0 else 'rvv' + str(i - 1))
            for i in range(6)}
        wanted = {'fixed_packed', 'fixed_split', *public_leaves,
            *(row[0] for row in six_leaves), *new_leaves}
        require(len(wanted) == 27, 'expected 27 functions')
        public = {name for obj in objects.values() for name in obj.symbols if name.startswith(PREFIXES)}
        require(public == wanted, f'public function inventory mismatch: {public ^ wanted}')
        state['expected_function_inventory'] = sorted(wanted)
        state['inventory_derivation'] = dict(public='caller/experiment.py:PUBLIC_LEAVES (16)',
            strong='caller/split/generate.py:LEAVES (6, including 3 overlapping public)',
            split='caller/split/generate.py:NEW (6)', wrappers=['fixed_packed', 'fixed_split'])

        final = ELF((SEALED / 'consumer.elf').read_bytes())
        actual = ELF((RUNTIME / 'vdot-perf.elf').read_bytes())
        require(final.kind == 2 and final.entry == final.symbols['fixed_link_entry'][0]
            and not any(p[0] in (2, 3) for p in final.segments)
            and any(p[0] == 1 and p[1] & 1 and p[3] <= final.entry < p[3] + p[5] for p in final.segments),
            'consumer must be a static ET_EXEC with loaded executable entry')
        require(not any(section[1] in (4, 9) and section[5] for section in final.sections),
            'consumer contains unresolved relocation sections')
        require(actual.kind == 2, 'qualified runtime ELF must be ET_EXEC')
        state['consumer_checks'] = dict(kind='ET_EXEC', entry=hex(final.entry),
            entry_symbol='fixed_link_entry', dynamic_or_interpreter_segments=False,
            entry_in_executable_file_backed_segment=True, nonempty_relocation_sections=False,
            undefined_strong_symbols=False)

        cached = json.loads((SEALED / 'library.json').read_text())
        require(cached['status'] == 'FIXED_WEIGHT_GNU_LIBRARY_AND_FINAL_LINK_PASS', 'unexpected cached status')
        require(cached['qualified_image_sha256'] == sha((RUNTIME / 'vdot-perf.elf').read_bytes()),
            'cached qualified ELF hash mismatch')
        require(cached['qualified_build_sha256'] == sha((RUNTIME / 'build.json').read_bytes()),
            'cached qualified build.json hash mismatch')
        for name, expected in cached['artifacts'].items():
            require(sha((SEALED / name).read_bytes()) == expected, f'cached artifact hash mismatch: {name}')
        require(set(cached['functions']) == wanted, 'cached function inventory mismatch')
        for name in sorted(wanted):
            owners = [member for member, obj in objects.items() if name in obj.symbols]
            require(len(owners) == 1, f'non-unique function owner: {name}')
            owner = owners[0]
            copies = dict(extracted_member=objects[owner].symbol_data(name),
                original_sealed_object=original_objects[owner].symbol_data(name),
                consumer_elf=final.symbol_data(name),
                qualified_runtime_elf=actual.symbol_data(name))
            require(all(raw == copies['extracted_member'] for raw in copies.values()),
                f'function machine bytes differ across artifacts: {name}')
            code = copies['extracted_member']
            require(len(code) > 0, f'zero-length function: {name}')
            reference = dict(member=owner, bytes=len(code), sha256=sha(code))
            require(cached['functions'][name] == reference, f'cached function evidence mismatch: {name}')
            state['functions'][name] = dict(**reference, four_way_bytes_equal=True,
                per_artifact_sha256={key: sha(raw) for key, raw in copies.items()})

        # Source and artifact inputs must remain byte-identical during this audit.
        after = {str(path): dict(bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
                 for path in paths}
        save(OUT / 'inputs-after.json', after)
        require(before == after, 'audit inputs changed during read-only verification')
        state.update(status='INDEPENDENT_SEALED_FIXED_LIBRARY_BYTE_IDENTITY_PASS',
            archive_members=list(MEMBERS), function_count=len(wanted),
            compared_function_bytes=sum(row['bytes'] for row in state['functions'].values()),
            public_archive_equals_sealed=True, extracted_members_equal_sealed_objects=True,
            cached_evidence_matches_actual=True, inputs_unchanged=True,
            qualified_image_sha256=sha((RUNTIME / 'vdot-perf.elf').read_bytes()),
            consumer_elf_sha256=sha((SEALED / 'consumer.elf').read_bytes()),
            public_archive_sha256=sha(PUBLIC.read_bytes()),
            limitations=['This rechecks sealed artifacts, and is not a new GNU rebuild.',
                'This performs no additional ISA/full-core/DiffTest execution.',
                'This does not establish new performance qualifications or alter the HOLD decision.'])
    except BaseException as exc:
        state.update(status='FAILED', error=repr(exc))
        raise
    finally:
        state['finished'] = utc()
        save(OUT / 'result.json', state)
    lines = ['# Fixed-weight sealed library independent byte audit', '',
        'Status: ' + state['status'], '',
        f"Four archive members, {state['function_count']} functions, {state['compared_function_bytes']} total machine-code bytes.",
        '', 'Each function is identical in the extracted public archive member, original sealed object,',
        'sealed final consumer.elf, and qualified runtime vdot-perf.elf.', '',
        'Input SHA256 identities, cached-evidence checks, individual function hashes, and commands',
        'are recorded in result.json, inputs-before.json, inputs-after.json, and commands/.', '',
        'No compilation, relink, or EMU execution was performed. Existing performance HOLD remains.', '',
        '| Function | Member | Bytes | SHA256 |', '|---|---|---:|---|']
    lines += [f"| {name} | {row['member']} | {row['bytes']} | {row['sha256']} |"
              for name, row in state['functions'].items()]
    (OUT / 'REVIEW.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({key: state[key] for key in ('status', 'function_count', 'compared_function_bytes',
        'public_archive_sha256', 'consumer_elf_sha256', 'qualified_image_sha256', 'inputs_unchanged',
        'new_compilations', 'new_links', 'new_emu_runs')}, indent=2))

if __name__ == '__main__':
    main()
