"""Stage already qualified artifacts; no build, EMU, Git mutation or publication.

Run manually only after the original campaign and postprocess-driver-02 close.
All original inputs remain in place. A failed staging directory is retained.
"""
from pathlib import Path, PurePosixPath
import hashlib,json,os,shutil,subprocess,sys,time,zipfile

ROOT=Path('/home/lizufan/riscv-lab/r2s3-fixed-weight-20261025-0920')
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-r2s3-fixed-weight-20261025-0920')
PUBLISH=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s3-fixed-weight-20261025-0920')
REL=Path('team/optimizations/o2/r2-config-reuse/caller/fixed-weight')
BUILD_SHA='4bb8959fc1b3eb94640b9d7b5222920ddbde8332f9401c6bbad2c15765d7eca4'
IMAGE_SHA='ec41c369d718a30b8b82edad5adea06c52366b44dadcf19f137bf78deb6fa22c'
OPERATION='20261025-LiZufan001-r2s3-fixed-weight-0920'
RENDERER_SHA='83f83e67008377ba6bea890409ca3f90ec669cc10461ac89a6a3163009fd91e8'
ARCHIVES={
 'independent-checks':('independent-checks-01','bdb5552f31c73dd8cf26933c275a17dbedc22ba5d4ba48b65c1f4dd38a63d797','612123ad8e6f65eeae2d57aa4e88250da007b01034f33863558e35fb2c0dd83b'),
 'history-checks':('history-checks-01','fc000fa12dd5ca6ca276450bad837a66de10511ca5f240d01d73317bce741c0b','5e15aefcd82930f028e4578fa9d9cbf231146632116f2d24cf093ff74f5d4bd0')}
CORE=('CONTRACT.md','fixed.h','fixed.c','main.c','generate.py','trace.py','run.py')
PUBLIC=('fixed.h','split.h','caller.h','fixed_entries.h','fixed.c','gemv.S','strong.S','kernels.S','example.c','libxs_fixed_weight_8x32.a')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def need(ok,why):
 if not ok:raise ValueError(why)
def save(p,value):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def copy(src,dst):
 need(src.is_file() and not src.is_symlink(),'regular source required: '+str(src))
 need(not dst.exists(),'fresh destination required: '+str(dst))
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 need(sha(src)==sha(dst),'copied bytes differ: '+str(src))
def files(root):
 for p in sorted(root.rglob('*')):
  need(not p.is_symlink(),'unexpected evidence symlink: '+str(p))
  if p.is_file() and '__pycache__' not in p.parts:yield p
def verify_zip(payload,manifest):
 m=read(manifest);wanted={r['path']:r for r in m['files']}
 need(len(wanted)==len(m['files']),'duplicate manifest member')
 with zipfile.ZipFile(payload) as z:
  names=z.namelist();need(len(names)==len(set(names)) and set(names)==set(wanted),'archive inventory')
  for name in names:
   rel=PurePosixPath(name);r=wanted[name]
   need(not rel.is_absolute() and '..' not in rel.parts and '\\' not in name and str(rel)==name,'unsafe member')
   info=z.getinfo(name);need(not info.is_dir() and info.file_size==r['bytes'],'member length')
   need(hashlib.sha256(z.read(name)).hexdigest()==r['sha256'],'member digest')
 return m

def main():
 os.sched_setaffinity(0,{0})
 source,build,run,post,out=ROOT/'source',ROOT/'build-02',ROOT/'run-01',ROOT/'post-01',ROOT/'delivery-01'
 state=read(run/'state.json');receipt=read(post/'postprocess.json')
 need(state['status']=='SPLIT_CAMPAIGN_PASS' and state['active_pid'] is None and state['active_result'] is None and
      state['new_emu_runs']==3 and state['operation_id']==OPERATION and
      state['contract']=='r2-s3-fixed-weight-8x32-v1','closed original campaign')
 need(receipt['status']=='FIXED_WEIGHT_POSTPROCESSING_PASS' and receipt['new_emu_runs']==0,'postprocessing prerequisite')
 need(sha(build/'build.json')==BUILD_SHA and sha(build/'vdot-perf.bin')==IMAGE_SHA,'qualified build/image')
 need(receipt['original_build_sha256']==BUILD_SHA and receipt['image_sha256']==IMAGE_SHA and
      receipt['original_run_state_sha256']==sha(run/'state.json'),'postprocessing bound to original campaign')
 for name,pin in receipt['reports'].items():need(sha(post/name)==pin,'accepted report drift: '+name)
 closed=read(post/'snapshot-audit/result.json')
 need(sha(post/'runtime/archive-manifest.json')==closed['archive_manifest_sha256'],'audited runtime manifest')
 raw_manifest=read(post/'runtime/archive-manifest.json')
 need(sha(post/'runtime/payload.zip')==raw_manifest['payload_sha256'] and
      (post/'runtime/payload.zip').stat().st_size==raw_manifest['stored_bytes'],'audited runtime payload')
 history=read(post/'runtime/history/manifest.json')
 need(sha(post/'runtime/history/manifest.json')==raw_manifest['historical_git']['manifest_sha256'] and
      sha(post/'runtime/history/objects.pack')==history['pack_sha256']==raw_manifest['historical_git']['pack_sha256'] and
      sha(post/'runtime/history/commands.json')==history['command_sha256'],'audited original Git objects')
 need(sha(post/'snapshot-audit/command.json')==closed['command_sha256'] and
      sha(post/'snapshot-audit/guard.json')==closed['dependency_probe_sha256'],'audited child receipt and dependency probe')
 br=read(build/'build.json')
 for name in CORE:
  pin=br['software_files'][(REL/name).as_posix()]
  need(sha(source/REL/name)==sha(PUBLISH/REL/name)==pin,'published/frozen core: '+name)
 for name,pin in receipt['tool_pins'].items():need(sha(source/REL/name)==sha(PUBLISH/REL/name)==pin,'published post tool: '+name)
 linked=read(post/'library/library.json')
 for name,pin in linked['artifacts'].items():need(sha(post/'library'/name)==pin,'library artifact: '+name)
 for name,pin in linked['sources'].items():need(sha(post/'library'/name)==pin,'library source: '+name)
 need(sha(MONITOR/'result-tables-02.py')==RENDERER_SHA,'reviewed table renderer')
 for _,(stem,payload_pin,manifest_pin) in ARCHIVES.items():
  need(sha(MONITOR/(stem+'.zip'))==payload_pin and sha(MONITOR/(stem+'.manifest.json'))==manifest_pin,'independent transport pins')
  verify_zip(MONITOR/(stem+'.zip'),MONITOR/(stem+'.manifest.json'))
 need(not out.exists(),'fresh delivery staging directory');out.mkdir()
 copy(Path(__file__).resolve(),out/'executed-stage.py')
 stage=out/'module';stage.mkdir();evidence=stage/'evidence/qualified-v1'
 host=out/'host/result.json';host.parent.mkdir()
 with zipfile.ZipFile(MONITOR/'independent-checks-01.zip') as z:host.write_bytes(z.read('host-02/result.json'))
 argv=[sys.executable,'-B',str(MONITOR/'result-tables-02.py'),'--post',str(post),'--build',str(build),'--host',str(host),'--output',str(out/'tables')]
 record=dict(command=argv,cwd=str(out),started=time.time(),process_started=False,
      pid=None,exit_code=None,timed_out=False,timeout_seconds=30)
 try:
  with (out/'renderer.stdout.log').open('xb') as stdout,(out/'renderer.stderr.log').open('xb') as stderr:
   p=subprocess.Popen(argv,cwd=out,stdout=stdout,stderr=stderr)
   record.update(process_started=True,pid=p.pid)
   try:record['exit_code']=p.wait(timeout=30)
   except subprocess.TimeoutExpired:
    record['timed_out']=True;p.kill();record['exit_code']=p.wait();raise
  need(record['exit_code']==0,'result rendering failed; logs retained')
 except BaseException as exc:
  record['error']=repr(exc);raise
 finally:
  record.update(finished=time.time(),raw_sha256={n:sha(out/n) for n in
      ('renderer.stdout.log','renderer.stderr.log') if (out/n).exists()})
  save(out/'renderer-command.json',record)
 for name in (*CORE,*receipt['tool_pins']):copy(source/REL/name,stage/name)
 (stage/'.gitattributes').write_text('# Preserve source and sealed evidence bytes on every platform.\n* -text\n')
 for name in PUBLIC:copy(post/'library'/name,stage/'public'/name)
 for path in files(post/'runtime'):copy(path,evidence/'runtime'/path.relative_to(post/'runtime'))
 reports={'statistics.json':post/'statistics.json','library.json':post/'library/library.json',
          'host.json':host,'mutations.json':post/'mutations.json','snapshot-audit.json':post/'snapshot-audit/result.json',
          'summary.json':out/'tables/summary.json'}
 for name,path in reports.items():copy(path,evidence/'reports'/name)
 for role,(stem,_,_) in ARCHIVES.items():
  copy(MONITOR/(stem+'.zip'),evidence/role/'payload.zip')
  copy(MONITOR/(stem+'.manifest.json'),evidence/role/'manifest.json')
 locations=read(MONITOR/'locations-preflight-01.json')
 locations['delivery']=dict(native_root=str(ROOT),
     windows_publish=r'D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\working-r2s3-fixed-weight-20261025-0920',
     windows_monitor=r'D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\monitor-r2s3-fixed-weight-20261025-0920',
     windows_source_entrance=r'D:\Projects\competitions\2026-10-CIE-RISCV-XiangShan\working-zufan-full-20261022',
     publish_wsl_mount=str(PUBLISH),monitor_wsl_mount=str(MONITOR),
     native_build=str(build),native_run=str(run),native_post=str(post),native_staging=str(out),
     original_campaign_operation='1bcd341bbd2162e3d9e297ccd2678ca0.4be77b8ec1560c7d25fb2e6f8b10b569',
     original_sources_remain_in_place=True,cleanup_authorized=False,cloud_evidence='See independent-checks and history-checks member manifests')
 save(evidence/'locations.json',locations)
 # Archive supporting attempts/receipts; the complete qualified build/run are
 # already in runtime/payload.zip and remain untouched at their original paths.
 members={}
 def add(path,name):
  need(name not in members and path.is_file() and not path.is_symlink(),'support member collision/type: '+name)
  members[name]=path
 for dirname in ('commands','library','snapshot-audit','prior-tools'):
  for path in files(post/dirname):add(path,'post/'+path.relative_to(post).as_posix())
 for name in ('postprocess.json','executed-driver.py'):add(post/name,'post/'+name)
 for path in files(ROOT/'host-01'):add(path,'prior-host/'+path.relative_to(ROOT/'host-01').as_posix())
 for path in sorted(ROOT.iterdir()):
  if path.is_file():add(path,'preparation/'+path.name)
 for path in sorted(MONITOR.iterdir()):
  if path.is_file() and path.suffix in ('.py','.md','.json'):add(path,'monitor/'+path.name)
 for path in files(out/'tables'):add(path,'rendered/'+path.relative_to(out/'tables').as_posix())
 for name in ('executed-stage.py','renderer-command.json','renderer.stdout.log','renderer.stderr.log'):add(out/name,'delivery/'+name)
 pack=evidence/'post-checks';pack.mkdir(parents=True)
 rows=[]
 with zipfile.ZipFile(pack/'payload.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,path in sorted(members.items()):
   data=path.read_bytes();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.create_system=3
   info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
   z.writestr(info,data,compresslevel=9)
   rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),source=str(path)))
 save(pack/'manifest.json',dict(format='fixed-weight-post-checks-zip-v1',files=rows,
      sha256=sha(pack/'payload.zip'),bytes=(pack/'payload.zip').stat().st_size,
      scope='Supporting checks, original preparation failures, prior tools and executed packaging; not additional EMU runs'))
 verify_zip(pack/'payload.zip',pack/'manifest.json')
 # Refuse an unexpected destination before touching any delivery files.
 staged=list(files(stage));existing=list(files(PUBLISH/REL))
 allowed=set(CORE)|set(receipt['tool_pins'])
 need(all(p.relative_to(PUBLISH/REL).as_posix() in allowed for p in existing),'unexpected existing delivery file')
 for path in staged:
  dest=PUBLISH/REL/path.relative_to(stage)
  if dest.exists():need(sha(dest)==sha(path),'existing module differs: '+str(dest))
 for path in staged:
  dest=PUBLISH/REL/path.relative_to(stage)
  if not dest.exists():copy(path,dest)
 delivery=dict(status='QUALIFIED_ARTIFACTS_STAGED_NOT_PUBLISHED',files=len(staged),new_emu_runs=0,
   image_sha256=IMAGE_SHA,build_sha256=BUILD_SHA,stage=str(stage),publish=str(PUBLISH/REL),
   result_doc_pending=True,git_publication_pending=True,source_files_unchanged=True,
   staged_files=[dict(path=p.relative_to(stage).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in staged])
 save(out/'stage-receipt.json',delivery)
 print(json.dumps({k:delivery[k] for k in ('status','files','image_sha256','build_sha256','new_emu_runs')},indent=2))

if __name__=='__main__':main()
