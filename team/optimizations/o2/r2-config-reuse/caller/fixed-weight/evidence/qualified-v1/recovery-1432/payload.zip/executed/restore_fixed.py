import base64, hashlib, json, os, shutil, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MOD=ROOT/'team/optimizations/o2/r2-config-reuse/caller/fixed-weight'
records=json.loads((ROOT/'fixed-recovery-identities.json').read_text())
checked=[]
for row in records:
    dest=MOD/row['local_path']
    if 'transfer_name' in row:
        if row.get('chunks'):
            data=b''.join(base64.b64decode((ROOT/'transfer'/f"{row['transfer_name']}-{i}.b64").read_text(),validate=False) for i in range(row['chunks']))
        else:
            data=base64.b64decode((ROOT/'transfer'/f"{row['transfer_name']}.b64").read_text(),validate=False)
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists(): assert dest.read_bytes()==data, dest
        else: dest.write_bytes(data)
    data=dest.read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['sha256'],str(dest)
    if 'bytes' in row: assert len(data)==row['bytes']
    checked.append(dict(path=row['local_path'],sha256=row['sha256'],bytes=len(data)))
evidence=MOD/'evidence/qualified-v1'
out=ROOT/'fixed-restored-01'
out.mkdir(exist_ok=False)
archives=[]
for name in ('runtime','independent-checks','history-checks','post-checks'):
    directory=evidence/name
    m=json.loads((directory/('archive-manifest.json' if name=='runtime' else 'manifest.json')).read_text())
    payload=directory/'payload.zip'
    pin=m.get('payload_sha256',m.get('sha256'))
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==pin
    assert payload.stat().st_size==m.get('stored_bytes',m.get('bytes'))
    rows=m['files']; expected={r['path']:r for r in rows}
    assert len(expected)==len(rows)
    target=out/name
    target.mkdir()
    total=0
    with zipfile.ZipFile(payload) as z:
        assert len(z.infolist())==len(rows)
        assert set(z.namelist())==set(expected)
        for member in z.infolist():
            p=Path(member.filename)
            assert not p.is_absolute() and '..' not in p.parts and not member.is_dir()
            assert not ((member.external_attr>>16)&0o170000)==0o120000
            data=z.read(member);r=expected[member.filename]
            assert len(data)==r.get('raw_bytes',r.get('bytes'))
            assert hashlib.sha256(data).hexdigest()==r.get('raw_sha256',r.get('sha256'))
            dest=target/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
            total+=len(data)
    if 'raw_bytes' in m: assert total==m['raw_bytes']
    archives.append(dict(name=name,files=len(rows),raw_bytes=total,stored_bytes=payload.stat().st_size,sha256=pin))
receipt=dict(status='FIXED_WEIGHT_RECOVERY_BYTES_PASS',files=checked,archives=archives)
(ROOT/'fixed-recovery-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(status=receipt['status'],transport_files=len(checked),archives=archives),indent=2))
