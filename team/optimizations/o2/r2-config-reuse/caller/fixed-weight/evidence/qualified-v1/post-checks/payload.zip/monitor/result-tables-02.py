"""Render arithmetic from accepted reports; does not qualify runtime evidence."""
from pathlib import Path
import argparse,hashlib,json,shutil

NAMES=('S3/reuse vdot','S0/basic RVV','S0/reuse RVV','S3/basic RVV','firstdot/reuse RVV','S3/reuse RVV')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,why):
 if not ok:raise ValueError(why)
def f(v):return f'{v:.6f}'

def make(post,build,host,out):
 stat=read(post/'statistics.json');raw=read(post/'runtime/original-audit.json')
 linked=read(post/'library/library.json');closure=read(post/'snapshot-audit/result.json')
 host_result=read(host);mutations=read(post/'mutations.json')
 need(stat['status']=='FIXED_WEIGHT_INDEPENDENT_UART_STATISTICS_PASS' and raw['status']=='FIXED_WEIGHT_RAW_EVIDENCE_AUDIT_PASS' and
      closure['status']=='FIXED_WEIGHT_ARCHIVE_FRESH_SOURCE_AUDIT_PASS' and linked['status']=='FIXED_WEIGHT_GNU_LIBRARY_AND_FINAL_LINK_PASS' and
      host_result['status']=='FIXED_C_LIFECYCLE_AND_BYTE_FAULTS_PASS' and mutations['status']=='FIXED_WEIGHT_TARGETED_NEGATIVES_PASS',
      'all independent report prerequisites')
 image=sha(build/'vdot-perf.bin');br=sha(build/'build.json')
 need(stat['qualified_image_sha256']==raw['image_sha256']==closure['image_sha256']==linked['qualified_image_sha256']==
      host_result['qualified_image_sha256']==mutations['image_sha256']==image,'one actual image identity')
 need(stat['build_sha256']==linked['qualified_build_sha256']==host_result['qualified_build_sha256']==br,'one actual build identity')
 need(raw['selection']['by_count']==stat['by_count'] and closure['selection']==raw['selection'],'independent selection agreement')
 library_hash=sha(post/'library/libxs_fixed_weight_8x32.a')
 need(library_hash==linked['artifacts']['libxs_fixed_weight_8x32.a'],'actual library still matches accepted artifact')
 for protected in (build,post/'runtime',post/'library',post/'snapshot-audit',host.parent):
  need(not out.is_relative_to(protected),'render output overlaps accepted input: '+str(protected))
 need(not out.exists(),'fresh report-rendering output');out.mkdir()
 shutil.copyfile(Path(__file__).resolve(),out/'executed-renderer.py')
 lines=['# 接受报告中的计算表','',
        '以下各组均使用12个正式方法样本；周期是完整 stream，包含该组初始化。所有数字从同一镜像的独立统计与原文审计一致结果生成。','']
 summary={}
 for count in (1,4):
  g=stat['by_count'][str(count)];methods=g['methods'];vdot=methods[6]
  rvv=next(m for m in methods[7:12] if m['leaf']==g['observed_lowest_rvv'])
  lines += [f'## N={count}'+('（主组）' if count==4 else '（初始化对照）'),'','| 算法 | packed均值/拍 | split均值/拍 | split均值/N | 同算法周期减少 | 三数据集最小减少 | 接口门槛 |',
            '| --- | ---: | ---: | ---: | ---: | ---: | --- |']
  for i,name in enumerate(NAMES):
   pair=g['pairs'][i]
   lines.append(f'| {name} | {f(methods[i]["mean"])} | {f(methods[i+6]["mean"])} | {f(methods[i+6]["mean_per_vector_including_setup"])} | {f(100*pair["reduction"])}% | {f(100*min(pair["by_dataset"]))}% | {"PASS" if pair["passed"] else "STOP"} |')
  reduction=1-vdot['total']/rvv['total'];anchor=max(a['variation'] for a in g['anchors']);worst=min(g['vdot_reduction_by_dataset_order'])
  lines += ['',f'- 最低总周期 RVV：`{rvv["leaf"]}`，均值 {f(rvv["mean"])} 拍。',
            f'- split vdot 均值 {f(vdot["mean"])} 拍，相对该 RVV 周期减少 {f(100*reduction)}%，比值 RVV/vdot={f(rvv["total"]/vdot["total"])}。',
            f'- 三数据集最大锚点变化 {f(100*anchor)}%；六格最小 vdot 改善 {f(100*worst)}%。',
            f'- 判定：`{g["decision"]}`；selected_method=`{g["selected_method"]}`。','',
            '| 数据集 | 顺序 | vdot两样本总周期 | 最低总周期RVV的两样本总周期 | vdot周期减少 |',
            '| --- | --- | ---: | ---: | ---: |']
  for d in range(3):
   for o in range(2):
    k=d*2+o
    lines.append(f'| {d} | {"正向" if o==0 else "反向"} | {vdot["by_dataset_order"][k]} | {rvv["by_dataset_order"][k]} | {f(100*g["vdot_reduction_by_dataset_order"][k])}% |')
  lines += ['']
  summary[str(count)]=dict(decision=g['decision'],selected_method=g['selected_method'],interface_qualified=g['interface_qualified'],
      fastest_rvv=rvv['leaf'],vdot_mean=vdot['mean'],rvv_mean=rvv['mean'],vdot_mean_per_vector=vdot['mean']/count,
      vdot_reduction=reduction,rvv_over_vdot=rvv['total']/vdot['total'],max_anchor_variation=anchor,
      worst_vdot_cell_reduction=worst,interface_reduction_range=[min(p['reduction'] for p in g['pairs']),max(p['reduction'] for p in g['pairs'])])
 report=dict(status='ACCEPTED_REPORT_TABLES_RENDERED',scope='rendered arithmetic only; runtime qualification remains in the linked reports',
     by_count=summary,primary_count=4,primary_decision=stat['decision'],image_sha256=image,build_sha256=br,
     library_sha256=library_hash,library_functions=len(linked['functions']),
     report_hashes={n:sha(post/n) for n in ('statistics.json','runtime/original-audit.json','snapshot-audit/result.json','library/library.json','mutations.json')},
     host_report_sha256=sha(host),renderer_sha256=sha(Path(__file__)))
 (out/'tables.md').write_text('\n'.join(lines)+'\n');(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('post','build','host','output'):p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();v=make(a.post.resolve(),a.build.resolve(),a.host.resolve(),a.output.resolve())
 print(json.dumps(v,indent=2))
