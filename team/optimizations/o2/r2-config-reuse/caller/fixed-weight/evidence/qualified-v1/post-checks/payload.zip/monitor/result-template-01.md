# 固定 A、连续 x 的 8×32 C 消费者：工程结果

合同：`r2-s3-fixed-weight-8x32-v1`。本轮操作：`20261025-LiZufan001-r2s3-fixed-weight-0920`。

{{CONCLUSION}}

本模块提供显式可选的 `fixed_packed` / `fixed_split` 和独立静态库，使用方法及回退见 [README](README.md)。这是同一块 A 在一个有界 stream 内保持固定的工程示例，尚未接入真实 LLM。R5 稳定入口、既有公共库、生产 RTL、官方程序及旧 hoisted 的 HOLD 结论均保持原有身份。

## 1. 本次解决的问题

上一轮 split 调用对照在每次 GEMV 前复制完整的 288 字节输入。固定权重消费者可以复用 A 的准备工作，因此不能直接套用那一轮的接口收益。本次先把 packed 对照改为：每个完整 stream 只复制一次 256 字节 A，每步仅复制新的 32 字节 x，再与直接访问分离 A/X 的 split 比较。

两边使用相同六类既有算术实现，捕获一次 context 字段，每步一次间接叶调用，并保留每步的完整 128 位槽和 INT32 输出。没有把复制移出 packed 计时窗、删除较快 RVV 或合并不同镜像的数据。主组 N=4；N=1 是初始化对照，其他 N 不在本合同内。

计时包含 stream 函数内的 A 准备、x 更新、循环、调用、槽写入及输出提取。context 构造、guard/golden 准备在两边计时外。每窗前使用同一 firstdot RVV 做一次匹配 N 的完整 conditioning，全部计时结束后才输出 UART。总周期/N 是包含初始化的摊销均值，不是通过 N1/N4 相减推导的稳态成本。

## 2. 实际性能与事前门槛

每 N/普通方法有 12 个正式样本：三个数据集、正反两种调用次序、每格两个样本。完整计划为 504 窗，含 288 个正式方法窗和 48 个正式锚点窗；first/warmup 同样保留在原文中。正常恢复与独立重放的全部 504 窗逐项一致。

接口采用门槛按 N 分别判断：六组同算法 split/packed 均须减少至少 5% 总周期，任何数据集退化不得超过 1%。算法选择还要求每数据集锚点变化不超过 1%，且 vdot 在全部六个 dataset×order 格中至少胜过该 N 的最低总周期 split RVV 0.5%。全部使用原先固定的整数比较；没有事后放宽门槛。

{{TABLES}}

这些结果只适用于本镜像、本输入形状及调用计划。接口变化和同接口中的 vdot/RVV 算法差异分别列出。不能将与旧逐次复制 288B 实验的数字相减来归因，也不能把上述周期减少视为完整应用、LLM 或硬件提频收益。

## 3. 正确性、可复算性和可用库

| 层级 | 本轮证据 | 范围 |
| --- | --- | --- |
| 实际 GNU / ELF | 独立编译两个 C 单元；实际命令、选项、生成源码、ELF/BIN、旧叶逐字节及所有 split 机器字证书通过 | 每 N/六算法/两接口的真实标量路径、地址、调用数和每步槽/Y 写入；split 不访问 packed scratch |
| 实际整核 / DiffTest | 3 次新进程：vd0 bit100 负控、正常恢复、独立重放 | 负控在本 BIN 的首个 split/vdot 指令拒错；每正常进程 168 个功能 stream、8 个运行中 judge 控制、504 窗、15,104 条 vdot 提交 |
| 原始退休与计数证据 | 完整 RETIRE PC/word/call 路径、CSR/ROB 身份、指令计数、周期和 O2 两槽协议均一致 | 没有未完成窗口或悬挂事务；只凭 GOOD TRAP 不足以通过 |
| 实际 C 包装的独立主机检查 | 504 场景；84 个 kind-0 场景各 2112 字节翻转 bit0，共 177,408 次；336 次模拟 CSR 故障；8 个原控制 | scalar leaf/CSR 替身，不执行 RVV/vdot 机器指令，不替代目标程序计时 main |
| 包装与门禁反例 | 4 类实际 C 变异、8 类实际 ELF 路径/证书反例、两 N 的独立整数边界与不同 RVV 赢家、真实原文 counter ROB flag 变异 | 包括 stale x、输出覆盖、遗漏最后一步及错步数值；N1 可漏检的步间地址错误由 N4 拒绝 |
| 独立统计 | 只用标准库重建 504 窗计划、读原 UART、重算全部 N 分组、锚点和选择字段 | 与主审计的完整 selection 字典相等；不导入原选择函数计算预期值 |
| GNU 静态库 | 4 个实际 archive 成员逐一抽取；最终静态 ELF 完成重定位，27 个函数与已运行镜像逐字节一致，无未解符号 | 独立可选库；不得与定义同名 packed/config-reuse/r4/firstdot/split 符号的其他库混链；没有额外 ISA 进程 |
| 原文封存与独立目录复算 | {{ARCHIVE_COUNTS}}；新的 Python 进程从归档源码闭包、固定父 identity 和绑定审计器复算 | 冻结 T17 访问探针自检通过、无原目录拒绝访问；结果与原审计完全一致 |

运行器兼容既有状态名称 `SPLIT_CAMPAIGN_PASS` / `SPLIT_DIFFTEST_COUNTER_PATH_PASS`；本轮身份由各回执中的独立 `contract` 和 BIN SHA 区分，不能仅凭旧状态字符串混用结果。

离线复算额外携带 19 个原始 Git 对象，满足冻结 gate 的六次 `git show BASE:path`。内层临时 Git 不使用全局/系统配置、模板、alternates 或原对象缓存；其 HEAD 指向旧 checker 的 BASE，不代表当前硬件源码。当前软件身份由 74 份构建源码的逐文件 SHA 约束。启动器仍需本提交的源码 checkout。访问探针检查 Python 文件/目录访问和显式子进程路径，不是 OS 沙箱，也没有重新验收当前外部 EMU/NEMU 实物或新机器安装。

## 4. 身份与交付位置

| 项目 | 身份 |
| --- | --- |
| 开发基点 | `3d56e84aca5cc63bf235f6fbcf76ce8079c9581c` |
| 实际 BIN SHA256 | `ec41c369d718a30b8b82edad5adea06c52366b44dadcf19f137bf78deb6fa22c` |
| 接受的 build.json SHA256 | `4bb8959fc1b3eb94640b9d7b5222920ddbde8332f9401c6bbad2c15765d7eca4` |
| 固定 T17 父 identity SHA256 | `4a89872d0463163ea0be83f680843352e01354043f5709509d822353221258eb` |
| 可选库 SHA256 | `{{LIBRARY_SHA}}` |

源码及公共接口在本目录和 `public/`；[位置清单](evidence/qualified-v1/locations.json) 记录 Windows 发布树、Linux 原运行、阶段输出及共享依赖。[交付清单](evidence/qualified-v1/delivery-manifest.json) 固定文件字节，承载提交由 Git 历史和协调 Issue 定位。

- [独立统计](evidence/qualified-v1/reports/statistics.json)、[原文审计](evidence/qualified-v1/runtime/original-audit.json) 和 [新目录复算](evidence/qualified-v1/reports/snapshot-audit.json)。
- [可选库验收](evidence/qualified-v1/reports/library.json)、[主机判定检查](evidence/qualified-v1/reports/host.json)、[针对性反例](evidence/qualified-v1/reports/mutations.json)。
- `runtime/` 保留成功与预期负控的原始命令、日志、回执、源快照、原始对象包及成员清单；`independent-checks/`、`history-checks/` 和 `post-checks/` 保留独立检查、准备失败、传输和后处理原件。

## 5. 失败与准备过程

首次从 NTFS linked worktree 获取原生 Git 输入因 Windows git-file 路径不能直接作为 Linux repository 使用而停止；随后从已核实的真实 `.git` 入口获取，并复用原 Git 对象供体。第一次稀疏源加载还暴露旧闭包遗漏 `r2-safe-tail/machine_model.py`，发生在实际 GNU 编译前；只在新适配器补入依赖，build-02 才构建本轮 BIN。原始失败目录和日志保留，没有改旧 gate 或官方程序。

主机检查的早期版本和后续加强版分别留存；加强版绑定接受的 build/image，并补齐错步数值反例和变异源码。最小历史对象的第一次辅助 probe 在复制的 guard 末尾多出一个空行，未作为冻结 guard 资格；第二次使用原始 Git blob 对应的完全相同字节通过。两次工具、回执和差异均保留。正式归档强制原 parent archive 与 T17 guard 的固定 SHA。

{{RUN_TIMES}}

## 6. 工程边界与后续建议

本轮没有改 RTL，因此没有新的 FU/父级/整核时序、面积、功耗或频率结论；正式赛事材料、平台提交及人工验收仍由成员负责。官方 Q01～Q07 未取得新的可核验确认，继续按现行内部合同开发，不将其写成官方认可。

当前成果足以复用本合同的固定 A、有界连续 x 接口。下一项软件优化应先取得实际消费者的形状、量化、A/X 生命周期和调用序列，再比较完整路径与最快合格 RVV；不继续盲目扩大这一个示例矩阵。

本轮实查还发现原生源码的 Git 对象借用链已包含 7 个目录。链中任一供体被清理都可能影响后续 Git 操作；已在协调 Issue 补充保护并记录每条 alternates SHA。后续 R0 可在独立范围内统一固定对象供体，再验证引用与保全，避免链条逐轮增长。本轮保留全部现有链、T17/AM/NEMU/flash、冻结实验、失败证据及旧 R3 未知回执/旧锁；完成本包不自动授权清理它们。
