"""One-shot postprocessing, invoked manually only after the campaign closes."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,traceback

ROOT=Path('/home/lizufan/riscv-lab/r2s3-fixed-weight-20261025-0920')
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-r2s3-fixed-weight-20261025-0920')
PUBLISH=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/working-r2s3-fixed-weight-20261025-0920')
REL=Path('team/optimizations/o2/r2-config-reuse/caller/fixed-weight')
BASE='3d56e84aca5cc63bf235f6fbcf76ce8079c9581c'
PINS={
 'archive.py':'2d7f69fc4b99d2f83ee276c7acc24f9a8db16e21b3a0521b7102aecd6cbba578',
 'harness_check.py':'a66ee75df39ac56233decb4071d2812c017cc4d273d052ae008677390d39e070',
 'mutations.py':'cac31a8a1c6b3766e0635aa8b5281357bf00260eddc65495349e404d772fec6b',
 'statistics_check.py':'dfd4f7797dc373a0639083a4634d317ba60be5709c0ee98603d3998362660d77',
 'library.py':'c9b263f3440b7a748a7bc5c64bee5e4d7e3f4c0e9bca7a5406b7697af5fe0486',
 'README.md':'4e5ecb3da3c6e249b1382629310d7e9d88262bbe6c770af744db078d0328f0bf'}
BUILD_SHA='4bb8959fc1b3eb94640b9d7b5222920ddbde8332f9401c6bbad2c15765d7eca4'
IMAGE_SHA='ec41c369d718a30b8b82edad5adea06c52366b44dadcf19f137bf78deb6fa22c'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def require(ok,message):
 if not ok:raise ValueError(message)
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')

os.sched_setaffinity(0,{0})
source,build,run,out=ROOT/'source',ROOT/'build-02',ROOT/'run-01',ROOT/'post-01'
state=read(run/'state.json')
require(state['status']=='SPLIT_CAMPAIGN_PASS' and state['new_emu_runs']==3 and state['active_pid'] is None and state['active_result'] is None,'closed original campaign required')
require(sha(build/'build.json')==BUILD_SHA and sha(build/'vdot-perf.bin')==IMAGE_SHA,'fixed accepted build/image')
records=read(run/'completed-runs.json');require(len(records)==3,'exact original process count')
for rec in records:
 require(rec['process_started'] and not rec.get('timed_out') and rec['exit_code']==int(rec['negative']),'actual completed process')
 proc=Path('/proc')/str(rec['pid'])/'cmdline'
 if proc.exists():require(b'/build/emu' not in proc.read_bytes(),'original EMU PID still active')
br=read(build/'build.json')
for rel,pin in br['software_files'].items():require(sha(source/rel)==pin,'frozen source drift before postprocessing: '+rel)
for name,pin in PINS.items():require(sha(MONITOR/('prepared-01-'+name))==pin,'prepared post-tool drift: '+name)
for repo in (source,PUBLISH):
 for name,pin in PINS.items():
  dest=repo/REL/name
  allowed={pin}
  if name=='harness_check.py':allowed.add('ec0a3c1455b858d8c62595aa7473612f3b2129190450625aa57da64de11b87da')
  require(not dest.exists() or sha(dest) in allowed,'unexpected existing post-tool; preserve and inspect: '+str(dest))
require(not out.exists(),'new postprocessing directory required');out.mkdir()
shutil.copyfile(Path(__file__).resolve(),out/'executed-driver.py')
receipt=dict(status='STARTED',started=time.time(),original_build_sha256=BUILD_SHA,image_sha256=IMAGE_SHA,
             original_run_state_sha256=sha(run/'state.json'),tool_pins=PINS,new_emu_runs=0,
             cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[],prior_tools={})
save(out/'postprocess.json',receipt)
try:
 for role,repo in (('native',source),('windows',PUBLISH)):
  module=repo/REL
  for name,pin in PINS.items():
   dest=module/name
   if dest.exists():
    previous=out/'prior-tools'/role/name;previous.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(dest,previous);receipt['prior_tools'][role+'/'+name]=sha(previous)
   shutil.copyfile(MONITOR/('prepared-01-'+name),dest)
   require(sha(dest)==pin,'installed tool differs: '+role+'/'+name)
 save(out/'postprocess.json',receipt)
 sys.path.insert(0,str(source/REL));import run as e
 import importlib.util
 spec=importlib.util.spec_from_file_location('fixed_post_archive',source/REL/'archive.py')
 archive=importlib.util.module_from_spec(spec);spec.loader.exec_module(archive)
 guard=source/archive.GUARD
 raw=subprocess.check_output(['git','show',BASE+':'+archive.GUARD.as_posix()],cwd=source,env=archive.clean_environment())
 require(hashlib.sha256(raw).hexdigest()==archive.GUARD_SHA,'original frozen guard bytes')
 if guard.exists():require(guard.read_bytes()==raw,'existing frozen guard differs')
 else:guard.parent.mkdir(parents=True,exist_ok=True);guard.write_bytes(raw)
 archive.tools()
 identity=source/e.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
 f,_=e.parent.runtime(source,e.parent.parent_identity(source,identity))
 module=source/REL
 commands=[
  ('mutations',[sys.executable,'-B',str(module/'mutations.py'),'--build',str(build),'--run',str(run),'--output',str(out/'mutations.json')]),
  ('statistics',[sys.executable,'-B',str(module/'statistics_check.py'),'--build',str(build),'--run',str(run),'--output',str(out/'statistics.json')]),
  ('library',[sys.executable,'-B',str(module/'library.py'),'--qualified-build',str(build),'--output',str(out/'library')]),
  ('archive-pack',[sys.executable,'-B',str(module/'archive.py'),'--action','pack','--build',str(build),'--run',str(run),'--output',str(out/'runtime')]),
  ('archive-snapshot',[sys.executable,'-B',str(module/'archive.py'),'--action','audit-snapshot','--archive',str(out/'runtime'),'--output',str(out/'snapshot-audit')])]
 for label,argv in commands:
  receipt['current_action']=label;save(out/'postprocess.json',receipt)
  record=f.command(argv,source,out/'commands'/label,timeout=900)
  receipt['commands'].append(record);save(out/'postprocess.json',receipt)
 for rel,pin in br['software_files'].items():require(sha(source/rel)==pin,'frozen source drift after postprocessing: '+rel)
 expected={'mutations.json':'FIXED_WEIGHT_TARGETED_NEGATIVES_PASS',
           'statistics.json':'FIXED_WEIGHT_INDEPENDENT_UART_STATISTICS_PASS',
           'library/library.json':'FIXED_WEIGHT_GNU_LIBRARY_AND_FINAL_LINK_PASS',
           'snapshot-audit/result.json':'FIXED_WEIGHT_ARCHIVE_FRESH_SOURCE_AUDIT_PASS'}
 for name,status in expected.items():require(read(out/name)['status']==status,'postprocessing acceptance: '+name)
 receipt.update(status='FIXED_WEIGHT_POSTPROCESSING_PASS',current_action=None,reports={n:sha(out/n) for n in expected})
except BaseException as exc:
 receipt.update(status='FAILED',error=repr(exc));traceback.print_exc();raise
finally:
 receipt['finished']=time.time();save(out/'postprocess.json',receipt)
print(json.dumps({k:receipt[k] for k in ('status','original_build_sha256','image_sha256','reports','new_emu_runs')},indent=2))
