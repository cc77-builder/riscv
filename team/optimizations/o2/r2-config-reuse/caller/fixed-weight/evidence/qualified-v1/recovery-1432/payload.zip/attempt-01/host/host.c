#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define FIXED_HOST_TEST 1
#define main fixed_guest_main
#include "main.c"

#undef main
static unsigned active_d,active_kind,active_mode,active_n,leaf_calls;
static void must(int ok,unsigned line) {
    if(!ok) { fprintf(stderr,"HOST_REJECT line=%u step=%u\n",line,leaf_calls);exit(1); }
}
#define CHECK(x) must((x),__LINE__)
static void scalar_leaf(const int8_t *a,const int8_t *x,struct caller_slot *s,unsigned mode,unsigned kind) {
    CHECK(mode==active_mode && kind==active_kind && leaf_calls<active_n);
    CHECK(s==fixed_slots.value.value+leaf_calls*8);
    CHECK(a==(mode?(int8_t *)fixed_arena.bytes+a_offset:fixed_packed_buffer.value.bytes));
    CHECK(x==(mode?(int8_t *)fixed_arena.bytes+x_offset+32*leaf_calls:fixed_packed_buffer.value.bytes+256));
    for(unsigned i=0;i<256;++i) CHECK(a[i]==fixed_inputs[active_d][i]);
    for(unsigned i=0;i<32;++i) CHECK(x[i]==fixed_inputs[active_d][256+32*leaf_calls+i]);
    int64_t sums[8]={0};
    for(unsigned k=0;k<32;++k) for(unsigned r=0;r<8;++r) sums[r]+=(int64_t)a[r*32+k]*x[k];
    for(unsigned r=0;r<8;++r) {
        CHECK(sums[r]==scalar_golden[active_d][leaf_calls][r]);
        s[r].value=(int32_t)sums[r];
        for(unsigned j=0;j<3;++j)s[r].high[j]=0;
    }
    ++leaf_calls;
}
void config_reuse_gemv_8x32_reuse_vdot(const int8_t *p,void *s){scalar_leaf(p,p+256,s,0,0);}
void r4_gemv_8x32_basic_rvv(const int8_t *p,void *s){scalar_leaf(p,p+256,s,0,1);}
void r4_gemv_8x32_reuse_rvv(const int8_t *p,void *s){scalar_leaf(p,p+256,s,0,2);}
void config_reuse_gemv_8x32_basic_rvv(const int8_t *p,void *s){scalar_leaf(p,p+256,s,0,3);}
void firstdot_gemv_8x32_reuse_rvv(const int8_t *p,void *s){scalar_leaf(p,p+256,s,0,4);}
void config_reuse_gemv_8x32_reuse_rvv(const int8_t *p,void *s){scalar_leaf(p,p+256,s,0,5);}
void split_gemv_8x32_vdot(const int8_t *a,const int8_t *x,struct caller_slot *s){scalar_leaf(a,x,s,1,0);}
void split_gemv_8x32_rvv0(const int8_t *a,const int8_t *x,struct caller_slot *s){scalar_leaf(a,x,s,1,1);}
void split_gemv_8x32_rvv1(const int8_t *a,const int8_t *x,struct caller_slot *s){scalar_leaf(a,x,s,1,2);}
void split_gemv_8x32_rvv2(const int8_t *a,const int8_t *x,struct caller_slot *s){scalar_leaf(a,x,s,1,3);}
void split_gemv_8x32_rvv3(const int8_t *a,const int8_t *x,struct caller_slot *s){scalar_leaf(a,x,s,1,4);}
void split_gemv_8x32_rvv4(const int8_t *a,const int8_t *x,struct caller_slot *s){scalar_leaf(a,x,s,1,5);}
void _putc(char c){(void)c;abort();}
void split_measure(void *c,struct caller_measurement *m,uintptr_t f){(void)c;(void)m;(void)f;abort();}
int main(void) {
    unsigned cases=0,byte_faults=0,csr_faults=0,original_controls=0;
    const unsigned aa[3]={96,97,601},xx[3]={512,513,35};
    prepare_golden();
    for(unsigned d=0;d<7;++d) for(unsigned l=0;l<3;++l) for(unsigned ni=0;ni<2;++ni)
        for(unsigned mode=0;mode<2;++mode) for(unsigned kind=0;kind<6;++kind) {
        unsigned n=ni?4:1;
        initialize(d,kind,n,l);
        CHECK(a_offset==aa[l] && x_offset==xx[l]);
        CHECK(fixed_context.a==(int8_t *)fixed_arena.bytes+aa[l]);
        CHECK(fixed_context.x==(int8_t *)fixed_arena.bytes+xx[l]);
        CHECK(fixed_context.y==fixed_y.value.value && fixed_context.slots==fixed_slots.value.value);
        CHECK(fixed_context.packed==fixed_packed_buffer.value.bytes && fixed_context.count==n);
        CHECK(fixed_context.packed_entry==packed_entries[kind] && fixed_context.split_entry==split_entries[kind]);
        for(unsigned i=0;i<1024;++i) {
            unsigned char want=0xa6;
            if(i>=aa[l] && i<aa[l]+256)want=(unsigned char)fixed_inputs[d][i-aa[l]];
            if(i>=xx[l] && i<xx[l]+128)want=(unsigned char)fixed_inputs[d][256+i-xx[l]];
            CHECK(fixed_arena.bytes[i]==want);
        }
        active_d=d;active_kind=kind;active_mode=mode;active_n=n;leaf_calls=0;
        if(mode)fixed_split(&fixed_context);else fixed_packed(&fixed_context);
        CHECK(leaf_calls==n && judge(d,kind,n,mode)==0);
        if(kind==0) {
            unsigned char *regions[5]={fixed_arena.bytes,(unsigned char *)&fixed_packed_buffer,
                (unsigned char *)&fixed_slots,(unsigned char *)&fixed_y,(unsigned char *)&fixed_context};
            const unsigned sizes[5]={1024,320,544,160,64};
            for(unsigned region=0;region<5;++region)for(unsigned i=0;i<sizes[region];++i) {
                regions[region][i]^=1;CHECK(judge(d,kind,n,mode)!=0);
                regions[region][i]^=1;CHECK(judge(d,kind,n,mode)==0);++byte_faults;
            }
            uint64_t *csr[4]={&host_vl,&host_vt,&host_vs,&host_vc};
            for(unsigned i=0;i<4;++i) {
                *csr[i]^=1;CHECK(judge(d,kind,n,mode)!=0);
                *csr[i]^=1;CHECK(judge(d,kind,n,mode)==0);++csr_faults;
            }
            if(d==0 && l==1 && n==4 && mode==1) {
                original_controls=controls();CHECK(original_controls==8 && judge(d,kind,n,mode)==0);
            }
        }
        memset(&fixed_arena,0x11,sizeof(fixed_arena));
        memset(&fixed_packed_buffer,0x22,sizeof(fixed_packed_buffer));
        memset(&fixed_slots,0x33,sizeof(fixed_slots));
        memset(&fixed_y,0x44,sizeof(fixed_y));
        memset(&fixed_context,0x55,sizeof(fixed_context));
        ++cases;
    }
    printf("FIXED_HOST_PASS cases=%u byte_faults=%u csr_faults=%u controls=%u\n",cases,byte_faults,csr_faults,original_controls);
    return 0;
}
