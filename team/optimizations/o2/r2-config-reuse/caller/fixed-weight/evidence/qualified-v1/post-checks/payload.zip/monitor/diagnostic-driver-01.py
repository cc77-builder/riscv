"""One optional diagnostic after accepted postprocessing; never starts an EMU."""
from pathlib import Path
import hashlib,json,os,shutil,sys
ROOT=Path('/home/lizufan/riscv-lab/r2s3-fixed-weight-20261025-0920')
MONITOR=Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-r2s3-fixed-weight-20261025-0920')
REL=Path('team/optimizations/o2/r2-config-reuse/caller/fixed-weight')
os.sched_setaffinity(0,{0})
source=ROOT/'source';out=ROOT/'diagnostic-01'
script=MONITOR/'anchor-diagnostic-02.py'
if out.exists():raise ValueError('Fresh optional diagnostic directory required')
if hashlib.sha256(script.read_bytes()).hexdigest()!='f5bb66665dcdfac3d9827bdd43dec5fe72c6ad08eda3c059ce74c2b750f2ba12':
 raise ValueError('Reviewed diagnostic source differs')
if json.loads((ROOT/'post-01/postprocess.json').read_text())['status']!='FIXED_WEIGHT_POSTPROCESSING_PASS':
 raise ValueError('Original postprocessing not accepted')
sys.path.insert(0,str(source/REL));import run as e
identity=source/e.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
f,_=e.parent.runtime(source,e.parent.parent_identity(source,identity))
try:
 receipt=f.command([sys.executable,'-B',str(script)],source,out,timeout=300)
 print(json.dumps(receipt,indent=2))
finally:
 if out.is_dir():
  shutil.copyfile(script,out/'executed-diagnostic.py')
  shutil.copyfile(Path(__file__).resolve(),out/'executed-driver.py')
