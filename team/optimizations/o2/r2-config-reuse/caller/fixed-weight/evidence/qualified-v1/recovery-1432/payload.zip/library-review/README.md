# 独立二进制复核入口

最终结果：`attempt-02/result.json`，状态 `INDEPENDENT_SEALED_FIXED_LIBRARY_BYTE_IDENTITY_PASS`。

- 4 个 public archive 成员与原 sealed 对象全文件相等。
- 27 个函数的机器字节在公开库成员、原 sealed 对象、consumer.elf、qualified runtime vdot-perf.elf 四处一致；总计 21,880 字节。
- 原 library.json 的 artifact hashes、27 个函数大小/所属成员/SHA256 均与实际文件一致。
- consumer 是具有可执行加载入口、无动态/解释器段、无残留重定位段、无强未定义符号的 ET_EXEC。
- qualified runtime ELF 的加载映像与 vdot-perf.bin 相等，二者哈希均与 build.json 一致；library.json 的 qualified_image_sha256 实际绑定 BIN。
- 输入 SHA256 前后相同；本次没有编译、重新链接或运行 EMU，不改变原 HOLD。

`attempt-02/review.py` 是最终脚本；`attempt-02/commands` 保留本机 ar 版本、成员列表及四次抽取的命令回执和 stdout/stderr；`attempt-02/inputs-before.json` 与 `inputs-after.json` 保留输入身份。

## 首次尝试记录

根目录原 `review.py`、`result.json`、`commands`、`run.stdout.log`、`run.stderr.log` 原样保留。首次脚本把 `qualified_image_sha256` 误解为 ELF 哈希，于此断言失败；源码 `fixed-weight/run.py:134` 明确此字段是 BIN 的 SHA256。最终脚本修正自身字段读取，并加做 ELF/BIN 字节桥接及 build.json 双文件哈希核对。此失败属于独立复核脚本，不是原项目缺陷。

## 最终产物 SHA256

- `attempt-02/review.py`: `8979db9dcdc36b89b657a3763cba27f5313d13c82bd58ea8da1f79cbbbe62f3f`
- `attempt-02/result.json`: `c5ab997e5b28d54edb3d4b10e5eab93539a020aa91518d1c3aabffeb7f003b6b`
- `attempt-02/REVIEW.md`: `30024b5b6dcaefdc662ff993e7cf3fd785a74e06768288d5fb8c8b2dc4eb1993`
- `attempt-02/inputs-before.json`: `5d5c3cd597c9e75144fec5ed746672a31e36bcf5a54c6f852548ba3a0f50e053`
- `attempt-02/inputs-after.json`: `5d5c3cd597c9e75144fec5ed746672a31e36bcf5a54c6f852548ba3a0f50e053`
