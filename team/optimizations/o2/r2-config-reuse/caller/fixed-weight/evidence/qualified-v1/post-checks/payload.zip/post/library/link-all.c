#include "fixed_entries.h"
static int8_t a[256],x[128],packed[288];
static int32_t y[32];
static _Alignas(16) struct caller_slot slots[32];
static struct fixed_context context={a,x,y,slots,packed,0,0,4};
static caller_leaf const old_entries[6]={config_reuse_gemv_8x32_reuse_vdot,r4_gemv_8x32_basic_rvv,r4_gemv_8x32_reuse_rvv,config_reuse_gemv_8x32_basic_rvv,firstdot_gemv_8x32_reuse_rvv,config_reuse_gemv_8x32_reuse_rvv};
static split_leaf const new_entries[6]={split_gemv_8x32_vdot,split_gemv_8x32_rvv0,split_gemv_8x32_rvv1,split_gemv_8x32_rvv2,split_gemv_8x32_rvv3,split_gemv_8x32_rvv4};
void fixed_link_entry(void) {
    for(unsigned i=0;i<6;++i) {
        context.packed_entry=old_entries[i];context.split_entry=new_entries[i];
        fixed_packed(&context);fixed_split(&context);
    }
}
