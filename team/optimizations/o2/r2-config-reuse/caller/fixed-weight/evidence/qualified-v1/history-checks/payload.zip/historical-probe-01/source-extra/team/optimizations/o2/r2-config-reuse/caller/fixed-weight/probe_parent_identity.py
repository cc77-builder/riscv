from pathlib import Path
import argparse,json,hashlib,subprocess
import run as e
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
identity=e.ROOT/e.parent.REPRO/'evidence/clean-reproduction-v1/reports/identity-02.json'
actual=e.parent.parent_identity(e.ROOT,identity)
frozen=e.parent.t17.a.frozen_f
paths=[p.as_posix() for p in frozen.CHECKER_PATHS if p!=frozen.H1DIR/'build_profile.py']
pins={}
for name in paths:
 raw=subprocess.check_output(['git','show',frozen.g.BASE+':'+name],cwd=e.ROOT)
 assert raw==(e.ROOT/name).read_bytes()
 pins[name]=hashlib.sha256(raw).hexdigest()
result=dict(status='FROZEN_PARENT_IDENTITY_WITH_MINIMAL_ORIGINAL_GIT_PASS',base=frozen.g.BASE,
 checker_blobs=pins,parent_identity_sha256=e.g.sha(identity),parent_contract=actual['contract'],
 new_emu_runs=0,physical_external_inputs_revalidated=False)
assert not args.output.exists();args.output.write_text(json.dumps(result,indent=2)+'\n')
