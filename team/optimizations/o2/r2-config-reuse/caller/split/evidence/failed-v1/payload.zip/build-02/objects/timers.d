/home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-02/objects/timers.o: \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-02/source/timers.S
