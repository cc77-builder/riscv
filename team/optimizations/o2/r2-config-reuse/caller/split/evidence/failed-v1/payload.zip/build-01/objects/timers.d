/home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/objects/timers.o: \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/source/timers.S
