/home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-03/objects/strong.o: \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-03/source/strong.S
