/home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/objects/main.o: \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/source/main.c \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/source/split.h \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/source/caller.h \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/source/data.h
