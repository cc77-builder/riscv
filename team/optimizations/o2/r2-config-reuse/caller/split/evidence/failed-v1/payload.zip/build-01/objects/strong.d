/home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/objects/strong.o: \
 /home/lizufan/riscv-lab/r2s3-split-20261025-0716/build-01/source/strong.S
