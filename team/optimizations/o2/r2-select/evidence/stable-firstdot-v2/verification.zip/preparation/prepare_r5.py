from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

OLD = Path('/home/lizufan/riscv-lab/context-intervention-20261026-0000/checkout/source')
ROOT = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
STORE = Path('/home/lizufan/riscv-lab/r0-native-store-20261025-1541/store')
BASE = 'cd4463660686079d365705bfd8f37a86c73161d4'
HEAD = 'a9455e08c06a39be24957d71ef1c905b666a1bc3'
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])
assert not ROOT.exists(), 'preserve existing native attempt'
assert subprocess.check_output(['git', '-C', str(OLD), 'rev-parse', 'HEAD'], text=True).strip() == HEAD
ROOT.mkdir()
records = []

def run(label, argv):
    p = subprocess.run(argv, capture_output=True)
    (ROOT / (label + '.stdout.log')).write_bytes(p.stdout)
    (ROOT / (label + '.stderr.log')).write_bytes(p.stderr)
    records.append(dict(label=label, argv=argv, exit_code=p.returncode))
    (ROOT / 'prepare-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert p.returncode == 0, (label, p.returncode, p.stderr.decode(errors='replace')[-1000:])
    return p.stdout.decode().strip()

run('checkout', ['python3', '-B', str(OLD / 'team/scripts/prepare-native-source.py'), 'checkout', '--store', str(STORE), '--mode', 'shared', '--output', str(ROOT / 'checkout'), '--threads', '2'])
bundle = ROOT / 'ancestor.bundle'
run('bundle', ['git', '-C', str(OLD), '-c', 'pack.threads=2', 'bundle', 'create', str(bundle), 'HEAD', '^' + BASE])
repo = ROOT / 'checkout/source'
git = ['git', '-C', str(repo)]
run('bundle-verify', git + ['bundle', 'verify', str(bundle)])
run('fetch', git + ['-c', 'gc.auto=0', 'fetch', '--no-tags', str(bundle), 'HEAD'])
run('branch', git + ['checkout', '-b', 'work/r5-firstdot-20261026-0056', 'FETCH_HEAD'])
actual = run('head', git + ['rev-parse', 'HEAD'])
assert actual == HEAD
assert not run('status', git + ['status', '--porcelain=v1', '--untracked-files=all'])
state = dict(status='R5_SOURCE_READY', finished=datetime.now(timezone.utc).isoformat(), head=actual,
    tree=run('tree', git + ['rev-parse', 'HEAD^{tree}']), source=str(repo),
    bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),
    alternates=(repo / '.git/objects/info/alternates').read_text().splitlines())
(ROOT / 'prepare-state.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(state, indent=2))
