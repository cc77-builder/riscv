from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056')
REPO = ROOT / 'checkout/source'
REL = Path('team/optimizations/o2/r2-select')
BASE = 'a9455e08c06a39be24957d71ef1c905b666a1bc3'
MONITOR = Path('/mnt/d/Projects/competitions/2026-10-CIE-RISCV-XiangShan/monitor-r5-firstdot-20261026-0056')
OUT = ROOT / 'delivery-01'
EVIDENCE = REPO / REL / 'evidence/stable-firstdot-v2'
os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:2])

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args]).decode().strip()

assert git('rev-parse', 'HEAD') == BASE
assert not git('diff', '--name-only') and not git('diff', '--cached', '--name-only')
assert not OUT.exists() and not EVIDENCE.exists()
payload = json.loads(Path(sys.argv[1]).read_bytes())
for name, item in payload.items():
    path = REPO / name
    assert path.resolve().is_relative_to(REPO)
    if item.get('expected_blob'):
        assert git('hash-object', '--no-filters', str(path)) == item['expected_blob'], name
    else:
        assert not path.exists(), name
    assert sha(item['text'].encode()) == item['sha256'], name

OUT.mkdir()
EVIDENCE.mkdir(parents=True)
for name, item in payload.items():
    path = REPO / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(item['text'].encode())
    assert sha(path.read_bytes()) == item['sha256']

verification = ROOT / 'verify-01'
result = json.loads((verification / 'result.json').read_bytes())
assert result['status'] == 'R5_FIRSTDOT_STABLE_SOURCE_PACKAGE_PASS'
assert result['new_emu_runs'] == result['new_nemu_runs'] == 0
for name, expected in result['input_sha256'].items():
    assert sha((REPO / name).read_bytes()) == expected, name
assert sha((REPO / REL / 'FIRSTDOT_STABLE_MANIFEST.json').read_bytes()) == result['manifest_sha256']

commands = []
def run(label, argv):
    completed = subprocess.run(argv, capture_output=True)
    (OUT / (label + '.stdout.log')).write_bytes(completed.stdout)
    (OUT / (label + '.stderr.log')).write_bytes(completed.stderr)
    commands.append(dict(label=label, argv=argv, exit_code=completed.returncode))
    save(OUT / 'commands.json', commands)
    assert completed.returncode == 0, (label, completed.returncode)
    return completed.stdout

doc = (REPO / REL / 'FIRSTDOT_STABLE.md').read_text()
blocks = re.findall(r'```c\n(.*?)```', doc, re.S)
assert len(blocks) == 1
snippet = OUT / 'document-example.c'
snippet.write_text(blocks[0])
sdk = verification / 'relocated-sdk'
assert (sdk / 'include/selected_gemv.h').is_file(), str(sdk)
compiler = ['riscv64-linux-gnu-gcc', '-std=c11', '-march=rv64gcv', '-mabi=lp64d', '-mno-relax', '-ffreestanding', '-O2', '-I' + str(sdk / 'include')]
for label, defines in [('default', []), ('rvv', ['-DXS_GEMV_FORCE_RVV=1'])]:
    obj = OUT / (label + '.o')
    linked = OUT / (label + '-linked.o')
    run(label + '-compile', [*compiler, *defines, '-c', str(snippet), '-o', str(obj)])
    run(label + '-link', ['riscv64-linux-gnu-ld', '-r', '--no-relax', str(obj), str(sdk / 'libxs_gemv_firstdot.a'), '-o', str(linked)])
    assert not run(label + '-nm', ['riscv64-linux-gnu-nm', '-u', str(linked)]).strip()

save(OUT / 'document-check.json', dict(status='DOCUMENT_EXAMPLE_GNU_COMPILE_LINK_PASS',
    source_sha256=sha(snippet.read_bytes()), modes=['default', 'force-rvv-1'],
    new_emu_runs=0, claim='Compilation and relocatable integration only'))

files = {}
for path in verification.rglob('*'):
    if path.is_file():
        assert not path.is_symlink()
        files['verify-01/' + path.relative_to(verification).as_posix()] = path
for path in OUT.rglob('*'):
    if path.is_file():
        files['delivery-01/' + path.relative_to(OUT).as_posix()] = path
for path in ROOT.iterdir():
    if path.is_file() and path.name != 'ancestor.bundle':
        assert path.suffix in ('.log', '.json'), path
        files['preparation/' + path.name] = path
for name in ('prepare_r5.py', 'install_r5_sources.py', 'sources-v1.json', 'seal_r5.py', 'docs-v2.json', 'tool-receipts.json'):
    path = MONITOR / name
    assert path.is_file(), path
    files['preparation/' + name] = path
members = {}
archive = EVIDENCE / 'verification.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(files.items()):
        raw = path.read_bytes()
        info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o100644 << 16)
        z.writestr(info, raw)
        members[name] = dict(bytes=len(raw), sha256=sha(raw))
manifest = dict(format='r5-firstdot-stable-evidence-zip-v1', source_base_commit=BASE,
    operation_id='20261026-LiZufan001-r5-firstdot-0056',
    archive='verification.zip', archive_bytes=archive.stat().st_size,
    archive_sha256=sha(archive.read_bytes()), members=members)
save(EVIDENCE / 'archive-manifest.json', manifest)

recovered = ROOT / 'sealed-recovery-01'
assert not recovered.exists()
recovered.mkdir()
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) and set(z.namelist()) == set(members)
    for name, item in members.items():
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        raw = z.read(name)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        path = recovered / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        assert path.read_bytes() == files[name].read_bytes()
shutil.copyfile(verification / 'result.json', EVIDENCE / 'result.json')
(EVIDENCE / '.gitattributes').write_text('*.zip binary\n')
delivery = dict(status='R5_FIRSTDOT_DELIVERY_BYTES_PASS', completed=datetime.now(timezone.utc).isoformat(),
    source_base_commit=BASE, native_source=str(REPO), verification_output=str(verification),
    delivery_output=str(OUT), recovered_output=str(recovered), windows_monitor=str(MONITOR),
    archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
    members=len(members), expanded_bytes=sum(x['bytes'] for x in members.values()),
    every_member_written_and_compared=True, document_example='DOCUMENT_EXAMPLE_GNU_COMPILE_LINK_PASS',
    documentation_sha256={k: v['sha256'] for k, v in payload.items()},
    original_frozen_pins_unchanged=True, original_source_entry_untouched=True,
    original_verification_status=result['status'],
    failed_preparation_receipts_preserved=True, new_emu_runs=0, new_nemu_runs=0)
save(EVIDENCE / 'delivery.json', delivery)
save(ROOT / 'delivery-state.json', delivery)
print(json.dumps(delivery, ensure_ascii=False, indent=2))
