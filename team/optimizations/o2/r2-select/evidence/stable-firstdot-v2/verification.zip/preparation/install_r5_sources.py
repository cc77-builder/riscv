from pathlib import Path
import hashlib
import importlib.util
import json
import sys

repo = Path('/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source')
relative = Path('team/optimizations/o2/r2-select')
payload = json.loads(Path(sys.argv[1]).read_bytes())
for name, item in payload.items():
    target = repo / relative / name
    assert target.resolve().is_relative_to(repo / relative)
    assert not target.exists(), str(target)
    raw = item['text'].encode('utf-8')
    assert hashlib.sha256(raw).hexdigest() == item['sha256'], name
for name, item in payload.items():
    target = repo / relative / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(item['text'].encode('utf-8'))
    assert hashlib.sha256(target.read_bytes()).hexdigest() == item['sha256']
spec = importlib.util.spec_from_file_location('r5v2', repo / relative / 'verify_firstdot_stable.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
matrix = json.loads((repo / module.EVIDENCE / 'reports/matrix-audit-01.json').read_bytes())
manifest = dict(contract=module.CONTRACT, operation_id='20261026-LiZufan001-r5-firstdot-0056', api_version=2,
    source_base_commit='a9455e08c06a39be24957d71ef1c905b666a1bc3',
    input_sha256={name: module.sha(repo / name) for name in sorted(module.REQUIRED_INPUTS)},
    selection=module.selection(matrix),
    hardware=dict(source_commit='34bae6d4acceac939f958199dae53c14bc1f6183',
        emu_sha256='ff840528eb1009e94906eefb3773ca321050f309553543ab26f0db23c410e30f',
        reference_sha256='8af118e5519db7ef6001010a2d547707c5d47630412e80abfc3f343bfef987c9'),
    package=dict(archive='libxs_gemv_firstdot.a', headers=['include/selected_gemv.h', 'include/firstdot_gemv.h'],
        object_sha256=module.OBJECT_SHA, public_functions=16, source_aliases=8, runtime_dispatch=False,
        additional_elf_symbols=False, force_rvv_values=[0,1]),
    qualification=dict(matrix_manifest_sha256=module.MATRIX_SHA, c_manifest_sha256=module.C_SHA,
        basis='Firstdot original 33 performance + 3 ordinary C processes; re-audited raw evidence',
        new_emu_runs=0, new_nemu_runs=0, new_application_performance_qualified=False),
    rollback='Rebuild callers with the frozen V1 public include directory and libxs_gemv.a; do not mix versions accidentally')
target = repo / relative / 'FIRSTDOT_STABLE_MANIFEST.json'
assert not target.exists()
module.save(target, manifest)
print(json.dumps(dict(status='R5_SOURCES_INSTALLED', files=len(payload), input_pins=len(manifest['input_sha256']),
    manifest_sha256=module.sha(target)), indent=2))
