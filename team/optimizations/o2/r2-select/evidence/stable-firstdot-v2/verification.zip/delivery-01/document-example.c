#include <stdint.h>
#include "selected_gemv.h"
_Static_assert(XS_GEMV_STABLE_API_VERSION == 2, "GEMV V2 required");

struct slot { int32_t value; uint32_t high[3]; };
_Static_assert(sizeof(struct slot) == 16, "16-byte output slot");
static _Alignas(16) int8_t packed_ax[8 * 32 + 32];
static _Alignas(16) struct slot output_slots[8];

void run_8x32(void) {
    /* 先填写A和x，确保运行平台VS已启用。 */
    xs_gemv_8x32(packed_ax, output_slots);
}
