from pathlib import Path
import json,hashlib,subprocess,datetime
R=Path("/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source")
OUT=R.parents[1]/"runs/firstdot-identity-20261026-0203"
V=R/"team/optimizations/o2/r2-select/verify_firstdot_stable.py"
M=V.with_name("FIRSTDOT_STABLE_MANIFEST.json")
assert json.loads((OUT/"repro-state.json").read_text())["status"]=="BUG_REPRODUCED_WRONG_HARDWARE_ACCEPTED"
assert hashlib.sha256(V.read_bytes()).hexdigest()=="2a3ced33e2b3aa7fa131507a220f5aa56fff65cc0e71d20bec0e8674763073ca"
s=V.read_text()
edits=[
('CONTRACT = "r5-selected-firstdot-gemv-v2"\n','CONTRACT = "r5-selected-firstdot-gemv-v2"\nIDENTITY = Path("team/optimizations/o2/repro/evidence/clean-reproduction-v1/reports/identity-02.json")\n'),
('} | {"team/optimizations/o2/repro/evidence/clean-reproduction-v1/reports/identity-02.json"}','} | {str(IDENTITY)}'),
('def selection(matrix):','''def hardware_identity(manifest, identity):
    """Bind the public hardware claim to the already hash-pinned T17 identity."""
    expected = dict(source_commit=identity["source_commit"],
                    emu_sha256=identity["hardware_profile"]["emu_sha256"],
                    reference_sha256=identity["reference_sha256"])
    require(manifest.get("hardware") == expected, "V2 manifest T17 hardware identity")
    return expected


def selection(matrix):'''),
('identity_path = repo / "team/optimizations/o2/repro/evidence/clean-reproduction-v1/reports/identity-02.json"','identity_path = repo / IDENTITY'),
('    matrix, qualified, library_module = raw_qualification(repo, output)','    hardware = hardware_identity(manifest, read(repo / IDENTITY))\n    matrix, qualified, library_module = raw_qualification(repo, output)'),
('manifest_sha256=manifest_hash, verifier_sha256=sha(__file__), input_sha256=pins, selection=rows,','manifest_sha256=manifest_hash, verifier_sha256=sha(__file__), input_sha256=pins, selection=rows,\n        hardware=hardware, manifest_hardware_bound_to_pinned_identity=True,')]
for a,b in edits:assert s.count(a)==1;s=s.replace(a,b)
V.write_text(s,encoding="utf-8")
manifest=json.loads(M.read_bytes())
manifest["input_sha256"][str(V.relative_to(R))]=hashlib.sha256(V.read_bytes()).hexdigest()
good=(json.dumps(manifest,indent=2)+"\n").encode()
M.write_bytes(good)
cases=[]
for field in ("source_commit","emu_sha256","reference_sha256"):
 bad=json.loads(good);bad["hardware"][field]="0"*(40 if field=="source_commit" else 64);cases.append(("wrong-"+field,bad))
for label,value in (("missing",None),("list",[]),("extra",dict(manifest["hardware"],unexpected=True)),("missing-emu",{k:v for k,v in manifest["hardware"].items() if k!="emu_sha256"})):
 bad=json.loads(good)
 if value is None:del bad["hardware"]
 else:bad["hardware"]=value
 cases.append((label,bad))
reports=[]
def run(label,body):
 path=OUT/(label+"-manifest.json");path.write_bytes(body);M.write_bytes(body)
 dest=OUT/label
 with (OUT/(label+".stdout.log")).open("wb") as so,(OUT/(label+".stderr.log")).open("wb") as se:
  p=subprocess.run(["python3","-B",str(V),"--repo",str(R),"--output",str(dest)],stdout=so,stderr=se,timeout=600)
 return p.returncode,json.loads((dest/"state.json").read_text())
try:
 for label,bad in cases:
  code,state=run("reject-"+label,(json.dumps(bad,indent=2)+"\n").encode())
  assert code!=0 and state["status"]=="FAILED" and "V2 manifest T17 hardware identity" in state["error"],(label,code,state)
  assert not (OUT/("reject-"+label)/"package").exists()
  reports.append({"case":label,"exit_code":code,"state":state})
 code,state=run("after-fix",good)
 assert code==0 and state["status"]=="R5_FIRSTDOT_STABLE_SOURCE_PACKAGE_PASS",state
 result=json.loads((OUT/"after-fix/result.json").read_text())
 assert result["hardware"]==manifest["hardware"] and result["manifest_hardware_bound_to_pinned_identity"]
finally:M.write_bytes(good)
report={"status":"HARDWARE_IDENTITY_REJECTION_AND_FULL_QUALIFICATION_PASS","negative_cases":reports,
"positive_status":result["status"],"qualified_object_sha256":result["qualified_object_sha256"],
"manifest_restored":M.read_bytes()==good,"new_emu_runs":0,"new_nemu_runs":0,
"verifier_sha256":hashlib.sha256(V.read_bytes()).hexdigest(),"finished":datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/"regression.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({k:v for k,v in report.items() if k!="negative_cases"}))
