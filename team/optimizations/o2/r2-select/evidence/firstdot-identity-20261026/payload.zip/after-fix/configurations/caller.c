#include "selected_gemv.h"
#include "/home/lizufan/riscv-lab/r5-firstdot-20261026-0056/checkout/source/team/optimizations/o2/r2-select/public/selected_gemv.h"
_Static_assert(XS_GEMV_STABLE_API_VERSION == 2, "V2 required");
void call(const int8_t *a, void *b) { xs_gemv_4x8(a,b); }
