from pathlib import Path
import csv,gzip,hashlib,json,re,subprocess,datetime
R=Path('/home/riscv/riscv-lab/zjhwork2-review-20261018/repo')
O=Path('/home/riscv/riscv-lab/o2-c2-readyless-20261025/version-ledger')
O.mkdir(parents=True,exist_ok=True)
pins={}
def read(rel):
 p=R/rel;b=p.read_bytes()
 pins[rel]={'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 return (gzip.decompress(b) if p.suffix=='.gz' else b).decode('utf-8')
def tables(s):
 out=[]; section='';lines=s.splitlines();i=0
 while i<len(lines):
  if lines[i].startswith('#'):section=lines[i].lstrip('#').strip()
  if lines[i].startswith('|') and i+1<len(lines) and re.match(r'^\|[\s:|-]+\|$',lines[i+1]):
   h=[x.strip() for x in lines[i].strip('|').split('|')];i+=2;rows=[]
   while i<len(lines) and lines[i].startswith('|'):
    rows.append([x.strip() for x in lines[i].strip('|').split('|')]);i+=1
   out.append({'section':section,'columns':h,'rows':rows})
  else:i+=1
 return out
docs={
 't13':'team/docs/t13-performance.md',
 't14':'team/docs/t14-optimization.md',
 't15':'team/docs/t15-parameter-extension.md',
 'unified':'team/docs/unified-vdot-comparison-20261017.md',
 'o1':'team/optimizations/o1/README.md',
 't14_o1':'team/optimizations/o1/performance/README.md',
 'o1_o2':'team/optimizations/o2/performance/README.md',
 'o3':'team/workloads/o3-gemv/README.md',
 'o4':'team/optimizations/o4/O4结构与时序评估.md',
 'h1':'team/optimizations/o2/result-width/h1/H1_RESULT.md',
 'h1_core':'team/optimizations/o2/result-width/h1/fullcore/H1_FULLCORE_RESULT.md',
 'b0_h1':'team/optimizations/o2/result-width/h1/performance/B0_H1_RESULT.md',
 'fix_local':'team/optimizations/o2/r3-div-gate/RESULT.md',
 'fix_core':'team/optimizations/o2/r3-div-gate/fullcore/RESULT.md',
 'fix_cost':'team/optimizations/o2/r3-div-gate/PERFORMANCE_COST_RESULT.md',
 'c1':'team/optimizations/o2/r3-div-gate/c1/RESULT.md',
 'c2_attr':'team/optimizations/o2/r3-div-gate/c2-attribution/RESULT.md',
 'c2_g0':'team/optimizations/o2/r3-div-gate/c2-g0/RESULT.md',
 's1':'team/optimizations/o2/r2-vector-accum/VALIDATION.md',
 's2':'team/optimizations/o2/r2-safe-tail/FIXED_RESULT.md',
 'r4':'team/optimizations/o2/r2-select/ENTRY_RESULT.md',
 'merge_reg':'team/optimizations/o2/fullcore/MERGED_REGRESSION_RESULT.md',
}
D={k:read(v) for k,v in docs.items()}
for p in ['AGENTS.md','赛题要求与评分总览.md','team/docs/development-route-current.md']:
 read(p)
# Existing tables are transcribed as strings without changing aggregation or rounding.
source_tables={k:{'source':docs[k],'tables':tables(v)} for k,v in D.items()}
extra=[
 'team/optimizations/o1/evidence/20261018-performance-ab/files/work/results-01/comparison.csv',
 'team/workloads/o3-gemv/evidence/20261020-application/files/runs/results-03/comparison.csv',
 'team/optimizations/o2/result-width/h1/performance/evidence/20261021-performance/files/runs/results-01/comparison.csv',
 'team/optimizations/o2/r3-div-gate/performance/results/paired-windows.csv',
 'team/optimizations/o2/r3-div-gate/performance/results/samples.csv',
 'team/optimizations/o2/r3-div-gate/c2-attribution/evidence/fixed-sta-review.json',
 'team/optimizations/o1/evidence/20261018-fullcore-validation/files/runs/o1-fullcore-build-02/hardware-inputs.json.gz',
 'team/optimizations/o2/result-width/h1/performance/evidence/20261021-performance/files/runs/campaign-01/build-profile.json',
]
extra_data={}
for p in extra:
 if p.endswith('.csv'):extra_data[p]=list(csv.DictReader(read(p).splitlines()))
 else:extra_data[p]=json.loads(read(p))
# Complete existing contract/result links are retained as pinned sources.
contracts={
 't13':'team/spec/measurement.md','t14':'team/spec/t14-ablation.md','t15':'team/spec/t15-parameters.md',
 'unified':'team/workloads/unified-vdot/README.md',
 't14_o1':'team/optimizations/o1/performance/CONTRACT.md',
 'o1_o2':'team/optimizations/o2/performance/CONTRACT.md',
 'o3':'team/workloads/o3-gemv/CONTRACT.md','o4':'team/optimizations/o4/CONTRACT.md',
 'h1':'team/optimizations/o2/result-width/h1/CONTRACT.md',
 'b0_h1':'team/optimizations/o2/result-width/h1/performance/CONTRACT.md',
 'fix_cost':'team/optimizations/o2/r3-div-gate/cost/CONTRACT.md',
 'fix_performance':'team/optimizations/o2/r3-div-gate/performance/CONTRACT.md',
 'c1':'team/optimizations/o2/r3-div-gate/c1/CONTRACT.md',
 'c2_g0':'team/optimizations/o2/r3-div-gate/c2-g0/CONTRACT.md',
 's2':'team/optimizations/o2/r2-safe-tail/FIXED_LAYOUT.md',
 'r4':'team/optimizations/o2/r2-select/ENTRY_CONTRACT.md',
}
for p in contracts.values():read(p)
# Include source archive identity; existing archives are never repacked or altered.
archives=[
 'team/evidence/t14-optimization-20261016/archive-files.json',
 'team/optimizations/o1/evidence/20261018-performance-ab/archive-manifest.json',
 'team/optimizations/o2/evidence/20261019-performance-ab/archive-manifest.json',
 'team/optimizations/o4/evidence/20261020-cost/manifest.json',
 'team/optimizations/o2/result-width/h1/evidence/20261021-local/manifest.json',
 'team/optimizations/o2/result-width/h1/performance/evidence/20261021-performance/archive-manifest.json',
 'team/optimizations/o2/r3-div-gate/evidence/20261025-performance-cost/manifest.json',
 'team/optimizations/o2/r3-div-gate/c1/evidence/20261025-screen/manifest.json',
 'team/optimizations/o2/r3-div-gate/c2-g0/evidence/manifest.json',
]
archive_pins=[]
for p in archives:
 if (R/p).is_file():read(p);archive_pins.append(p)
unresolved_archive_names=[p for p in archives if not (R/p).is_file()]
identities={
 'T13':{'hardware_commit':'4460300e9557ad20ac152fa67b1827c5d62802dd','emu_sha256':'9903d6d8b3d59bed49090ca84d6bc06cb296de448d0baf7f7e9c90587e325b03'},
 'T14-original':{'hardware_commit':'2443fb1c101dfc5974ac208275a8b86d68a11e0f','emu_sha256':'60521f406816846f8724de13021906a3ebbffa7044f35e6ee93c28bed7bf96b5'},
 'T14-AB':{'hardware_commit':'72fc206a417e5781dded45433eae0de45f181458','resume_commit':'2dee53fcd8afd4678800b512a0716825c3f15b6f','emu_sha256':'081247df2c8220a37ee77be47a2c032bd0da0dba3544cd5e7bf0f63aaad45142'},
 'T15':{'hardware_commit':'65f6159e305adc10b4f8bd67812f3a6460ccf360','production_src_tree':'22a37b26e31e2f9e3b7864c04c4c2378a9bd851f','emu_sha256':'NOT_TESTED'},
 'O1-original':{'hardware_commit':'18c0ce08a40e889654bfe76d5435f272854ad7d0','emu_sha256':'b13b05a3b03d2dd178d5e07b55bda1e8d99d7a094d44cf30405241f9793170cb'},
 'O1-G4':{'hardware_commit':'a239dace720b32216e83fb5a514930d334c69a26','emu_sha256':'6699225b76ceae479060741026683bb03de069c1e10a4a94e463304ba1e322d0'},
 'O2-B0':{'hardware_commit':'b218cbc6e6b135e4ff219a902a9284a59d3c82c9','emu_sha256':'ac0123280bf6c742d27a7650505bc1d91db350d1519806edfd0be9c7ea208a57'},
 'H1':{'hardware_commit':'8b5024fcbd96986871cc40ce8c9fb71a67c495eb','emu_sha256':'e37b3c267cae29036bda0b6952a17db2523ca0b3a573d45281341d4207df8747','local_cost_identity':'9b6cf074951dbd51e1670c5fbc7111a97c362b3f + h1-production.patch + candidate-inputs.json; not clean HEAD'},
 'MERGED-H1':{'hardware_commit':'6d2abe403b07c297b8830a7d4f06e370b0a8e070','emu_sha256':'1a23dbab5f919da0fb06873c5a4db3ce5fec9eea7dfb98860cdd5fa2b062ec63'},
 'DIV-fix0f':{'hardware_commit':'0f12df675378556670afd0dd2153f47fcb330610','emu_sha256':'2d1db77cc407486a2387a4a69da2498b68d44980239025eebcc02370c02826e8'},
 'C1':{'hardware_commit':'3be0e3d9e500bd1aa772bcc8d4f8b023a2877c66','emu_sha256':'NOT_TESTED'},
 'C2-G0':{'hardware_commit':'0f12df675378556670afd0dd2153f47fcb330610','new_emu_sha256':'NOT_TESTED','kind':'source-bound abstract control proof, not new RTL'},
 'C2':{'hardware_commit':'NOT_TESTED','emu_sha256':'NOT_TESTED','kind':'reserved; main agent must add actual local RTL/FU/parent record'},
}
records=[]
def record(id,label,ident,source_ids,config,summary,decision,levels,metrics=None):
 records.append({'record_id':id,'label':label,'identity_ids':ident,'source_ids':source_ids,'contract_refs':[contracts[x] for x in source_ids if x in contracts],'configuration':config,'summary':summary,'decision':decision,'verification':levels,'metrics':metrics or {},'raw_evidence_location':'Follow pinned result documents and archive manifests; no historical execution repeated by ledger builder.'})
baselevels={'numeric_rtl':'NOT_TESTED','fu':'NOT_TESTED','real_parent':'NOT_TESTED','fullcore_difftest':'NOT_TESTED','cycles':'NOT_TESTED','area_sta':'NOT_TESTED','power':'NOT_TESTED','fullcore_fmax':'NOT_TESTED','independent_human_rebuild':'NOT_TESTED'}
def L(**kw):return dict(baselevels,**kw)
record('T13-20261015','T13 原基线',['T13'],['t13'],'MinimalConfig/1core/VLEN128; T12_TRACE=1,T13_TRACE=1; FU latency3,II4','126次功能/性能执行+1校准；1404性能窗口含重放','保留冻结基线',L(fullcore_difftest='PASS',cycles='PASS'),{'batch128_cycles_median':599.5,'chain256_cycles_median':2114,'batch_rvv_ratio_paired_median':1.1309})
record('T14-20261016','T14 输入拍乘积锁存',['T13','T14-original'],['t14'],'FUSED_INPUT=0/1；相同48镜像；各3dataset/4measured/3replay；paired-median','FU首次响应3→2拍，II4→3；13场景原文全部保留','后续优化基础；本合同无PPA',L(numeric_rtl='PASS',fu='PASS',fullcore_difftest='PASS',cycles='PASS'),{'batch128_cycles_before':599.5,'batch128_cycles_after':464,'paired_median_speedup':1.2906,'chain256_cycles_before':2114,'chain256_cycles_after':1857,'chain_speedup':1.1384})
record('T15-20261017','T15 INT16独立扩展',['T15'],['t15'],'独立ParamPipe s8x8/r32、s16x8/r64；不是生产SEW16','10022/10094完整128位；2拍输出、II3；无全核INT16','保留扩展证据',L(numeric_rtl='PASS',fu='PASS'),{'directed':[22,94],'random_per_mode':10000,'latency_cycles':2,'ii_cycles':3,'declared_register_bits':[290,418]})
record('UNIFIED-20261017','四项目同条件本机比较',['T14-original'],['unified'],'64镜像/384正式窗口；dot8/full128；Redoop含软件适配','保留T14/Jade/试水/Redoop全场景原表，不与后续新硬件跨合同排名','参考；非官方成绩',L(fullcore_difftest='PASS',cycles='PASS'),{'t14_batch128_mean':453.25,'jade_batch128_mean':260.25,'shishui_batch128_mean':292,'redoop_dot8_batch128_mean':744.75})
record('O1-AB-20261018','T14/O1 同镜像',['T14-AB','O1-original'],['t14_o1','o1'],'FUSED_INPUT1；HANDOFF0/1；16镜像；O1_TRACE1/T13_TRACE1','36次/478校验窗/192正式窗；batch改善；II3→2','O1冻结对照/回退',L(numeric_rtl='PASS',fu='PASS',real_parent='PASS',fullcore_difftest='PASS',cycles='PASS'),{'batch128_mean_cycles':[453.25,362.5],'decrease_pct':20.02,'o1_rvv_ratio_rounded':1.870})
record('O2-G4-20261019','O1/O2 同镜像',['O1-G4','O2-B0'],['o1_o2'],'FUSED1,HANDOFF/ELASTIC=1/0 vs0/1；对应只读观察器；16相同镜像','36次/478校验窗/192正式窗；II2→1、首响应2拍','O2后续主线；B0冻结',L(numeric_rtl='PASS',fu='PASS',real_parent='PASS',fullcore_difftest='PASS',cycles='PASS'),{'batch128_mean_cycles':[362.5,221],'decrease_pct':39.03,'o2_rvv_ratio_rounded':3.068,'latency_cycles':2,'ii_cycles':1})
record('O3-20261020','O3 GEMV应用',['O1-G4','O2-B0'],['o3'],'4尺寸×3dataset×basic/reuse×core/endtoend；768正式窗','O2相对O1 reuse/endtoend少0.62%～1.50%；K13慢于RVV','保留正负结果；不推广batch收益',L(fullcore_difftest='PASS',cycles='PASS'),{'shape_order':['4x8','8x32','16x64','4x13'],'o1_reuse_e2e_mean':[166.5,323.5,856.75,212],'o2_reuse_e2e_mean':[164,321.5,847.75,209.5]})
record('O4-20261020','O4 O1/O2成本',['O1-G4','O2-B0'],['o4'],'生产FU及真实VFEX4；无trace；Nangate45typical；五档STA','4映射/20STA/140路径；整体1ns未收敛','成本取舍；不是新硬件版本',L(area_sta='PASS_REPORTS_TIMING_NOT_CLOSED'),{'fu_area':[12525.142,17711.610],'parent_area':[281750.392,285271.7],'fu_dff':[1048,1838],'parent_dff':[16675,17267]})
record('H1-20261021','H1 低32位结果保存',['H1'],['h1','h1_core','b0_h1'],'O2＋H1；固定16镜像；同约束PPA','FU/父级+14全核通过；B0/H1 96对正式窗完全相同','保留减面积方案；时序退化保留',L(numeric_rtl='PASS',fu='PASS',real_parent='PASS',fullcore_difftest='PASS',cycles='PASS',area_sta='PASS_REPORTS_TIMING_NOT_CLOSED'),{'fu_area':17298.246,'parent_area':284879.882,'fu_area_decrease_pct':2.33386,'parent_area_decrease_pct':0.137349,'paired_cycles_equal':96,'degraded_windows':0})
record('MERGED-H1-20261024','合并H1及新夹具回归',['MERGED-H1'],['merge_reg'],'minimal/VLEN128；固定6d2硬件/1a23EMU','13正常+1预期负控；2实际新进程、12严格来源复用','相容软件测试硬件；不冒充B0/H1旧合同',L(fullcore_difftest='PASS'))
record('R2-S1-20261023','S1 向量累加软件',['MERGED-H1'],['s1'],'v2-fixed-layout; 4尺寸全矩阵; 768正式窗','v1布局有混杂不采用；v2三整块形状改善；K13 vdot退化','整块选择S1；K13保留更快RVV',L(fullcore_difftest='PASS',cycles='PASS'),{'shape_order':['4x8','8x32','16x64','4x13'],'s0_reuse_e2e':[164.5,318,846.5,210],'s1_reuse_e2e':[155,278.25,701.25,212.75],'fastest_rvv':[175,289,768.25,175]})
record('R2-S2-fixed-20261024','S2 安全尾部固定布局',['MERGED-H1'],['s2'],'fixed-layout主批384正式窗；强RVV探针另32正式窗只dataset0','K13 reuse210→187；强RVV175.25；basic246.25→298.25','不扩大S2采用',L(fullcore_difftest='PASS',cycles='PASS'),{'k13_reuse_cycles':[210,187],'k13_basic_cycles':[246.25,298.25],'strong_rvv_probe_mean':175.25,'probe_dataset_count':1})
record('R4-entry-20261024','普通C ABI GEMV入口',['MERGED-H1'],['r4'],'相同调用窗含参数/jal/叶函数/ret；384正式窗','33性能进程+3C进程；16函数/48case/96正常调用','4x8/8x32/16x64 S1 vdot；K13 S1 RVV',L(fullcore_difftest='PASS',cycles='PASS'),{'shape_order':['4x8','8x32','16x64','4x13'],'s0_reuse_vdot':[178.5,335.5,860,219.25],'s1_reuse_vdot':[169.75,292.5,717.25,219.75],'fastest_rvv':[187.5,300.75,779.5,187]})
record('DIV-fix0f-20261025','DIV取消关钟修复',['H1','DIV-fix0f'],['fix_local','fix_core','fix_cost'],'O2/H1；严格取消后空闲钟门禁；性能96对；五档STA','旧版严格门禁拒绝；修复48窗口144采样0额外脉冲；14全核和96对周期一致','当前保留正确性修复',L(numeric_rtl='PASS',fu='PASS',real_parent='PASS',fullcore_difftest='PASS',cycles='PASS',area_sta='PASS_REPORTS_TIMING_NOT_CLOSED'),{'parent_area':284614.946,'fu_area':17298.246,'paired_cycles_equal':96,'extra_idle_clock_pulses':0})
record('C1-20261025','C1 busy/owner保持编码',['C1'],['c1'],'对照fix0f；FU/真实父级；同Nangate/五档STA','35075拍13组；状态通过；15/45时序筛选失败','REJECT；未全核/周期',L(numeric_rtl='PASS',fu='PASS',real_parent='PASS',area_sta='REJECT_THRESHOLD'),{'parent_area':284587.548,'control_d_arrival_ns':[1.930584,0.798315],'int_icg_arrival_ns':[1.128021,1.727299],'ready_arrival_ns':[0.247821,0.266115],'vdot_r2r_arrival_ns':[1.356106,1.402385]})
record('C2-attribution-20261025','只读DIV路径归因',['DIV-fix0f','C1'],['c2_attr'],'原冻结网表/同nominal；2次STA/20查询','19有效路径+1owner/Q无路径；不将其当0ns','支持先G0；不采用C1',L(area_sta='PASS_ATTRIBUTION_ONLY'),{'fixed_vdot_lane4_ns':[1.356106,1.401305],'fixed_vdot_lane6_ns':[1.355025,1.402385],'int_gate_buffer_cells':[8,19]})
record('C2-G0-20261025','源码绑定空闲ready控制证明',['C2-G0'],['c2_g0'],'固定源/有效复位/正常接口；异步全核与同步夹具分别','48状态33600转移；双lane/SQRT/取消/复位；5变异检出','允许设计C2；未产生新RTL成绩',L(),{'abstract_control_proof':'PASS','reachable_states':48,'transitions':33600,'rob_checks':65536,'mutations_rejected':5})
record('C2-local-RESERVED','C2 去掉门控启动ready依赖',['C2'],[],'待主Agent填实际源码/配置/合同','占位不转授G0或C1资格','NOT_TESTED',L())
ledger={'schema_version':1,'generated_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'scope':'Historical evidence index; does not start new hardware execution. Future runs append records; never overwrite old results.','hardware_identities':identities,'records':records,'source_tables':source_tables,'extra_data':extra_data,'source_pins':pins,'archive_pin_refs':archive_pins,'unresolved_archive_names':unresolved_archive_names}
(O/'version-data-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
(O/'source-pins.json').write_text(json.dumps({'repo':str(R),'scope':'read-only sources','files':list(pins.values())},ensure_ascii=False,indent=2)+'\n')
(O/'builder-status.json').write_text(json.dumps({'status':'DRAFT_CREATED','records':len(records),'sources':len(pins),'missing_archive_paths':unresolved_archive_names},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'records':len(records),'sources':len(pins),'missing_archives':unresolved_archive_names},ensure_ascii=False))
