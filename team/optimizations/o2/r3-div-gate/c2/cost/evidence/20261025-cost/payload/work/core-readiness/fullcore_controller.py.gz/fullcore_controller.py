#!/usr/bin/env python3
"""Draft C2 fullcore controller. Execute only after independent cost acceptance.

No production edits, old build movement, software generation, or GitHub writes.
Never starts a build unless both current screen and independent audit pass.
This controller ends with a pending generated-RTL review, not final adoption.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

LAB = Path("/home/riscv/riscv-lab")
REPO = LAB / "o2-c2-readyless-20261025/repo"
MAIN = LAB / "zjhwork2-review-20261018/repo"
COST = LAB / "o2-c2-cost-20261025"
LOCAL = REPO.parent
BASE_RUN = LAB / "o2-r3-div-gate-fullcore-20261024"
SOURCE = "6704ce3502a7235cdb81697638c01ed23f6914f6"
BASE_SOURCE = "0f12df675378556670afd0dd2153f47fcb330610"
EXE = "src/main/scala/xiangshan/backend/exu/ExeUnit.scala"
EXE_SHA = "febbce48c4865ac5e1c7909f8494599a01ae2fee643ee53396635a0f403323a6"
BASE_EMU = "2d1db77cc407486a2387a4a69da2498b68d44980239025eebcc02370c02826e8"
LOCAL_MANIFEST = "5fe7ea1cd978cf14ef371380a51e64d942673e1c62c7ac3748698418237b1428"
BASE_MANIFEST = "9bda2d8c8ee254786ac8928588d3372b2b269bca89d6ec720eb1abf2c936be77"
BASE_PIN_SHA = "388e286327006c7a58494d434370aaaf7c36815f1abeaa517c40754c4e620bc5"
HARDWARE = ["src", "scripts", "build.sc", "Makefile", "Makefile.test", "team/scripts/activate.sh"]
ENTRY = REPO / "team/optimizations/o2/fullcore"
FLAGS = dict(config="MinimalConfig", NUM_CORES=1, EMU_THREADS=1, JVM_XMX="12G", BUILD_JOBS=2,
             VDOT_O2_ELASTIC="1", VDOT_O1_HANDOFF="0", VDOT_O1_TRACE="0",
             VDOT_T14_FUSED_INPUT="1", VDOT_O2_TRACE="1", VDOT_T12_TRACE="0", VDOT_T13_TRACE="1")


def need(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, data):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)


def verify_hashes(files):
    for raw, digest in files.items():
        path = Path(raw)
        need(path.is_absolute() and path.is_file(), "missing absolute frozen file: " + raw)
        need(sha(path) == digest, "frozen file changed: " + raw)


def validate_gate_fields(screen, audit, screen_sha):
    """Pure fail-closed schema gate; unit tests never launch hardware."""
    need(screen.get("status") == "C2_SCREEN_PASS", "cost screen has not passed")
    need(screen.get("fullcore_authorized_by_gate") is True, "fullcore gate is not true")
    need(screen.get("inputs_unchanged") is True, "cost inputs not certified unchanged")
    need(screen.get("candidate_head") == SOURCE, "cost screen is for another candidate")
    need(screen.get("local_manifest_sha256") == LOCAL_MANIFEST, "wrong local qualification")
    need(screen.get("baseline_manifest_sha256") == BASE_MANIFEST, "wrong baseline cost archive")
    need(screen.get("failures") == [], "cost screen records failures")
    comparisons = screen.get("comparisons")
    need(isinstance(comparisons, list) and len(comparisons) == 45 and
         all(row.get("pass_") is True for row in comparisons), "incomplete 45-path screen")
    need(audit.get("status") == "C2_COST_INDEPENDENT_AUDIT_PASS", "independent audit missing")
    need(audit.get("screening_pass") is True, "independent cost classification rejected")
    need(audit.get("paths") == audit.get("path_pass_count") == 45, "independent paths incomplete")
    need(audit.get("failures") == [] and audit.get("input_hashes_unchanged") is True,
         "independent audit has failures or input drift")
    need(audit.get("screen_result_sha256") == screen_sha, "audit is not bound to this screen")
    need(audit.get("candidate_head") == SOURCE and audit.get("candidate_exeunit_sha256") == EXE_SHA,
         "independent audit is for another candidate")
    need(audit.get("local_manifest_sha256") == LOCAL_MANIFEST, "audit local evidence mismatch")


def collect_gate_pins(screen_path, audit_dir):
    need(screen_path == COST / "screen-01/result.json", "unexpected current screen location")
    need(audit_dir == COST / "independent-review/final-audit-01", "unexpected independent audit")
    screen = read(screen_path)
    audit_path = audit_dir / "audit.json"
    audit = read(audit_path)
    validate_gate_fields(screen, audit, sha(screen_path))
    pins = {}
    for path in (screen_path.parent / "inputs.json", audit_dir / "inputs.json"):
        imported = read(path)
        need(isinstance(imported, dict) and imported, "empty evidence pin index")
        verify_hashes(imported)
        for key, value in imported.items():
            need(key not in pins or pins[key] == value, "conflicting cost inputs")
            pins[key] = value
        pins[str(path)] = sha(path)
    need(pins.get(str(screen_path)) == sha(screen_path), "audit input index omits exact screen")
    pins[str(screen_path)] = sha(screen_path)
    pins[str(audit_path)] = sha(audit_path)
    return pins


def collect_source_pins():
    need(git("rev-parse", "HEAD").decode().strip() == SOURCE, "candidate HEAD changed")
    need(sha(REPO / EXE) == EXE_SHA, "candidate RTL changed")
    need(not git("diff", "HEAD", "--", *HARDWARE), "dirty hardware inputs")
    need(not git("ls-files", "--others", "--exclude-standard", "--", *HARDWARE),
         "untracked hardware inputs")
    base_pin_path = BASE_RUN / "build-01/hardware-inputs.json"
    need(sha(base_pin_path) == BASE_PIN_SHA, "baseline hardware pin receipt changed")
    base = read(base_pin_path)
    need(base["source_commit"] == BASE_SOURCE and base["emu_sha256"] == BASE_EMU,
         "wrong baseline hardware identity")
    accepted_path = BASE_RUN / "final-validation.json"
    accepted = read(accepted_path)
    need(accepted["status"] == "R3_DIV_GATE_FULLCORE_PASS" and
         accepted["source_commit"] == BASE_SOURCE and accepted["emu_sha256"] == BASE_EMU,
         "baseline fullcore acceptance missing")
    local_path = LOCAL / "local-result.json"
    local = read(local_path)
    need(local["status"] == "C2_LOCAL_PASS_NOT_ADOPTED" and
         local["candidate"]["head"] == SOURCE and local["candidate"]["exeunit_sha256"] == EXE_SHA and
         local["candidate"]["baseline"] == BASE_SOURCE, "wrong C2 local identity")
    need(all(local[k] == "PASS" for k in ("fu", "real_parent", "generated_gate_cone")),
         "C2 local qualification not PASS")
    local_audit_path = LOCAL / "final-audit/audit.json"
    local_audit = read(local_audit_path)
    need(sha(local_audit_path) == local["audit_sha256"] and
         local_audit["status"] == "C2_FINAL_READONLY_AUDIT_PASS" and
         local_audit["candidate_head"] == SOURCE and local_audit["negative_controls"]["total"] == 27,
         "C2 local audit invalid")
    need(read(LOCAL / "supplement-01/supplement-replay.json")["status"] == "C2_PARENT_SUPPLEMENT_PASS"
         and read(LOCAL / "supplement-01/supplement-negative.json")["status"] == "C2_PARENT_SUPPLEMENT_NEGATIVE_PASS",
         "C2 supplementary local test missing")
    pins = {str(p): sha(p) for p in (base_pin_path, accepted_path, local_path, local_audit_path,
                                   LOCAL / "supplement-01/supplement-replay.json",
                                   LOCAL / "supplement-01/supplement-negative.json",
                                   MAIN / "build/emu", Path(__file__).resolve())}
    need(pins[str(MAIN / "build/emu")] == BASE_EMU, "baseline physical EMU changed")
    changed = []
    for name, digest in base["files"].items():
        actual = sha(REPO / name)
        pins[str(REPO / name)] = actual
        if actual != digest:
            changed.append(name)
    need(changed == [EXE], "candidate changes beyond ExeUnit")
    for name, digest in base["dependency_files"].items():
        need(sha(REPO / name) == digest, "candidate dependency changed: " + name)
        pins[str(REPO / name)] = digest
    # Freeze the committed tooling used by normal/negative/core/strict replay.
    for path in [*ENTRY.rglob("*.py"), REPO / "team/scripts/artifact_guard.py",
                 REPO / "team/scripts/check-vdot-run.py",
                 REPO / "team/optimizations/o1/audit/runtime_gate.py",
                 REPO / "team/workloads/vdot-perf/check.py"]:
        relative = path.relative_to(REPO).as_posix()
        need(hashlib.sha256(git("show", SOURCE + ":" + relative)).hexdigest() == sha(path),
             "runtime checker is not the committed version: " + relative)
        pins[str(path)] = sha(path)
    return pins, base


def generated_inventory(out, base_pins):
    build = out / "build-01"
    state, pins = read(build / "build-state.json"), read(build / "hardware-inputs.json")
    need(state["status"] == "O2_FULLCORE_BUILD_PASS" and state["build_exit_code"] == 0,
         "fullcore build did not pass")
    need(pins["source_commit"] == SOURCE and pins["profile"] == "observe", "wrong new build identity")
    need(all(type(pins.get(k)) is type(v) and pins.get(k) == v for k, v in FLAGS.items()),
         "new build profile differs")
    need(pins["dependency_files"] == base_pins["dependency_files"], "new build dependencies differ")
    need(set(pins["files"]) == set(base_pins["files"]) and
         {k for k in pins["files"] if pins["files"][k] != base_pins["files"][k]} == {EXE},
         "new build source comparison differs")
    need(pins["emu_sha256"] == sha(REPO / "build/emu") and pins["emu_sha256"] != BASE_EMU,
         "new physical EMU is not C2")
    before_rows = read(BASE_RUN / "build-01/generated-artifacts.json")
    after_rows = read(build / "generated-artifacts.json")
    manifests = {}
    for mode, rows, root in (("before", before_rows, MAIN), ("after", after_rows, REPO)):
        files = {}
        for row in rows:
            relative = Path(row["path"])
            need(not relative.is_absolute() and relative.parts[0] == "build" and
                 ".." not in relative.parts and str(relative) not in files, "invalid generated path")
            actual = root / relative
            need(actual.is_file() and actual.stat().st_size == row["bytes"] and
                 sha(actual) == row["sha256"], "generated product drift: " + str(actual))
            files[str(relative)] = row["sha256"]
        manifests[mode] = files
    a, b = manifests["before"], manifests["after"]
    changed = sorted(k for k in a.keys() & b.keys() if a[k] != b[k])
    need(a["build/rtl/VDotElastic.sv"] == b["build/rtl/VDotElastic.sv"], "VDot arithmetic/storage changed")
    result = dict(status="C2_GENERATED_INVENTORY_CAPTURED_REVIEW_PENDING",
                  source_commit=SOURCE, emu_sha256=pins["emu_sha256"],
                  baseline_source=BASE_SOURCE, baseline_emu_sha256=BASE_EMU,
                  added=sorted(b.keys()-a.keys()), removed=sorted(a.keys()-b.keys()),
                  changed=changed, source_differences=[EXE],
                  hardware_pins_sha256=sha(build / "hardware-inputs.json"),
                  generated_manifest_sha256=sha(build / "generated-artifacts.json"),
                  generated_equivalence_claim=False, cycle_comparison_authorized=False,
                  required_review="Inspect actual generated ExeUnit, reset/TE wiring, observers, compiler commands and every other changed/added/removed module before final fullcore acceptance.")
    save(out / "generated-review-pending.json", result)
    save(out / "new-hardware-pins.json", pins)
    return pins


def validate_stage(name, out):
    if name == "preflight":
        need(read(out / "preflight-01/result.json")["status"] == "O2_PREFLIGHT_ONLY_PASS",
             "software input preflight failed")
    elif name == "core":
        need(read(out / "core-01/result.json")["status"] == "O2_CORE_REGRESSION_PASS",
             "core regression did not pass")
    elif name == "supplements":
        need(read(out / "supplements-01/result.json")["status"] == "O2_SUPPLEMENTS_PASS",
             "supplement regression did not pass")
    elif name == "recheck":
        r = read(out / "recheck-01/result.json")
        need(r["status"] == "O2_G3_OFFLINE_RECHECK_PASS" and
             all(r.get(k) is True for k in ("checks_passed", "whole_suite_pass", "g3_complete",
                                            "normal_reference_recovery", "original_evidence_unchanged")),
             "strict original-log recheck incomplete")
        need(r.get("missing_jobs") == [] and r.get("missing_components") == [], "missing G3 jobs")


def run(args):
    need(args.execute, "--execute required; this draft never executes by default")
    need(args.output.is_absolute(), "output must be absolute")
    out = args.output.resolve()
    need(out.is_relative_to(LAB) and out not in (LAB, COST, LOCAL) and
         not out.is_relative_to(REPO) and not out.is_relative_to(MAIN),
         "output must be a fresh run root outside source checkouts")
    need(not out.exists(), "existing output must not be restarted or overwritten")
    need(not (REPO / "build").exists(), "C2 build exists; inspect/preserve explicitly, never overwrite")
    # Gates run before output creation and before any hardware tool invocation.
    gate_pins = collect_gate_pins(args.screen.resolve(), args.audit_dir.resolve())
    source_pins, base_pins = collect_source_pins()
    frozen = dict(gate_pins)
    for key, digest in source_pins.items():
        need(key not in frozen or frozen[key] == digest, "conflicting frozen identities")
        frozen[key] = digest
    verify_hashes(frozen)
    out.mkdir(parents=True, exist_ok=False)
    save(out / "frozen-inputs.json", frozen)
    (out / "controller.py.snapshot").write_bytes(Path(__file__).read_bytes())
    state = dict(status="C2_FULLCORE_RUNNING", started=now(), pid=os.getpid(), source_commit=SOURCE,
                 baseline_source=BASE_SOURCE, steps=[], fullcore_complete=False,
                 performance_measured=False, cycle_comparison_authorized=False, github_writes=False)
    save(out / "campaign-state.json", state)
    stages = [
        ("preflight", ["python3", "-B", str(ENTRY/"run_suite.py"), "--preflight-only", "--output", str(out/"preflight-01")]),
        ("host-fullcore", ["python3", "-B", "-m", "unittest", "discover", "-s", str(ENTRY), "-p", "test_*.py", "-v"]),
        ("host-workloads", ["python3", "-B", "-m", "unittest", "discover", "-s", str(ENTRY/"workloads"), "-p", "test_*.py", "-v"]),
        ("build", ["python3", "-B", str(ENTRY/"build_fullcore.py"), "--output", str(out/"build-01"), "--profile", "observe"]),
        ("core", ["python3", "-B", str(ENTRY/"run_suite.py"), "--output", str(out/"core-01"),
                  "--hardware-pins", str(out/"build-01/hardware-inputs.json"), "--emu", str(REPO/"build/emu"), "--jobs", "2"]),
        ("supplements", ["python3", "-B", str(ENTRY/"run_supplements.py"), "--output", str(out/"supplements-01"),
                         "--hardware-pins", str(out/"build-01/hardware-inputs.json"), "--emu", str(REPO/"build/emu"), "--jobs", "2"]),
        ("recheck", ["python3", "-B", str(ENTRY/"recheck.py"), "--campaign", str(out/"core-01"),
                     "--supplements", str(out/"supplements-01"), "--output", str(out/"recheck-01")]),
    ]
    try:
        pins = None
        for name, command in stages:
            verify_hashes(frozen)
            need(git("rev-parse", "HEAD").decode().strip() == SOURCE, "candidate HEAD drift")
            step = dict(name=name, command=command, cwd=str(REPO), started=now(), status="RUNNING")
            state["steps"].append(step)
            save(out/"campaign-state.json", state)
            print("START " + name, flush=True)
            with (out/(name+".log")).open("xb") as log:
                process = subprocess.Popen(command, cwd=REPO, stdout=log, stderr=subprocess.STDOUT,
                                           env=dict(os.environ, PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1"))
                step["pid"] = process.pid
                save(out/"campaign-state.json", state)
                rc = process.wait()
            step.update(exit_code=rc, finished=now(), log_sha256=sha(out/(name+".log")),
                        status="COMMAND_PASS" if rc == 0 else "COMMAND_FAILED")
            save(out/"campaign-state.json", state)
            need(rc == 0, name + " command failed; keep all outputs")
            validate_stage(name, out)
            if name == "build":
                pins = generated_inventory(out, base_pins)
                frozen[str(REPO/"build/emu")] = pins["emu_sha256"]
                for leaf in ("hardware-inputs.json", "generated-artifacts.json", "build-state.json"):
                    path = out/"build-01"/leaf
                    frozen[str(path)] = sha(path)
                save(out/"frozen-inputs-with-build.json", frozen)
            verify_hashes(frozen)
            step["status"] = "PASS"
            save(out/"campaign-state.json", state)
            print("PASS " + name, flush=True)
        core, supplement = read(out/"core-01/result.json"), read(out/"supplements-01/result.json")
        rows = core["runs"] + supplement["runs"]
        need(len(rows) == len({r["name"] for r in rows}) == 14, "wrong real-run inventory")
        negative = [r for r in rows if r["name"] == "negative-vdot"]
        need(len(negative) == 1 and negative[0]["status"] == "EXPECTED_VDOT_HIGHBIT_REJECTION" and
             negative[0]["exit_code"] != 0, "true negative failure missing")
        normal = [r for r in rows if r["name"] != "negative-vdot"]
        need(len(normal) == 13 and all(r["exit_code"] == 0 and r["observation_status"] == "O2_TRACE_PASS"
                                     for r in normal), "normal/full trace incomplete")
        result = dict(status="C2_FULLCORE_REGRESSION_PASS_PENDING_GENERATED_REVIEW", finished=now(),
                      source_commit=SOURCE, exeunit_sha256=EXE_SHA, emu_sha256=pins["emu_sha256"],
                      normal_jobs=13, expected_negative_jobs=1, matrix_unique=core["matrix_unique"],
                      matrix_executed=core["matrix_executed"],
                      hardware_pins_sha256=sha(out/"build-01/hardware-inputs.json"),
                      recheck_sha256=sha(out/"recheck-01/result.json"),
                      cost_screen_sha256=sha(args.screen), independent_audit_sha256=sha(args.audit_dir/"audit.json"),
                      regression_pass=True, fullcore_final_acceptance=False, cycle_comparison_authorized=False,
                      generated_review="PENDING", area_sta_qualification="Separate accepted cost screen",
                      next_step="Independently review generated differences/build comparability and seal a C2 final acceptance receipt before fair-cycle comparison.",
                      performance_measured=False, github_writes=False)
        save(out/"regression-result.json", result)
        state.update(status=result["status"], finished=now(), emu_sha256=pins["emu_sha256"])
        print(result["status"], flush=True)
    except BaseException as error:
        state.update(status="C2_FULLCORE_FAILED", error=repr(error), finished=now())
        raise
    finally:
        save(out/"campaign-state.json", state)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="Explicitly permit hardware execution only after both cost gates pass")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--screen", type=Path, default=COST/"screen-01/result.json")
    parser.add_argument("--audit-dir", type=Path, default=COST/"independent-review/final-audit-01")
    run(parser.parse_args())
