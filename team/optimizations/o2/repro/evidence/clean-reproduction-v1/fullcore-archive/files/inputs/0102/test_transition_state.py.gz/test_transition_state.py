"""Execute emitted transition control with SEW-aware scalar extraction.

This host model checks source-level AVL/data dependence; it is not an RTL,
NEMU or full-core test. It intentionally does not call generator arithmetic.
"""
import copy
from pathlib import Path
import re
import struct
import tempfile
import unittest
from unittest.mock import patch
import generate

MASK64 = (1 << 64) - 1


def replay(case):
    regs = [bytearray(r) for r in case["before"]]
    scalar = {}
    sew = vl = None
    operation = 0
    extraction = []
    configs = []
    for text in case["body_instructions"]:
        parts = text.replace(",", " ").split()
        mnemonic = parts[0]
        if mnemonic in ("vsetivli", "vsetvli"):
            target_sew = int(parts[3][1:])
            want_vl = 8 if target_sew == 8 else 4
            avl = int(parts[2], 0) if mnemonic == "vsetivli" else scalar[parts[2]]
            if avl != want_vl:
                raise ValueError(f"AVL {avl:#x} != {want_vl} before operation {operation}: {text}")
            sew, vl = target_sew, min(avl, 128 // target_sew)
            configs.append((sew, vl, avl))
        elif mnemonic == "vmv.x.s":
            register = int(parts[2][1:])
            lane_bits = int.from_bytes(regs[register], "little") & ((1 << sew) - 1)
            signed_value = lane_bits - (1 << sew) if lane_bits & (1 << (sew - 1)) else lane_bits
            scalar[parts[1]] = signed_value & MASK64
            extraction.append((sew, lane_bits, scalar[parts[1]]))
        elif mnemonic == "li":
            scalar[parts[1]] = int(parts[2], 0) & MASK64
        elif mnemonic == "xor":
            scalar[parts[1]] = (scalar[parts[2]] ^ scalar[parts[3]]) & MASK64
        elif mnemonic in (".word", "vdivu.vv", "vfdiv.vv"):
            spec = case["ops"][operation]
            if mnemonic == ".word":
                word = int(parts[1], 0)
                if word & 0xfe00707f != 0x0200000b:
                    raise ValueError("unexpected custom instruction encoding")
                dest, left, right = (word >> 7) & 31, (word >> 15) & 31, (word >> 20) & 31
                if (sew, vl, spec["op"]) != (8, 8, "vdot"):
                    raise ValueError("illegal dot configuration")
                aa = [x - 256 if x >= 128 else x for x in regs[left][:8]]
                bb = [x - 256 if x >= 128 else x for x in regs[right][:8]]
                result = sum(a * b for a, b in zip(aa, bb)) & 0xffffffff
                regs[dest][:] = result.to_bytes(4, "little") + bytes(12)
            else:
                dest, left, right = [int(p[1:]) for p in parts[1:]]
                if (sew, vl) != (32, 4):
                    raise ValueError("illegal DIV configuration")
                if mnemonic == "vdivu.vv":
                    if spec["op"] != "vidiv":
                        raise ValueError("DIV kind mismatch")
                    aa = struct.unpack("<4I", regs[left])
                    bb = struct.unpack("<4I", regs[right])
                    regs[dest][:] = struct.pack("<4I", *(a // b if b else 0xffffffff for a, b in zip(aa, bb)))
                else:
                    if spec["op"] != "vfdiv":
                        raise ValueError("DIV kind mismatch")
                    # Frozen diagnostic operands have finite exactly representable quotients.
                    aa = struct.unpack("<4f", regs[left])
                    bb = struct.unpack("<4f", regs[right])
                    regs[dest][:] = struct.pack("<4f", *(a / b for a, b in zip(aa, bb)))
            if (dest, left, right) != (spec["d"], spec["a"], spec["b"]):
                raise ValueError("instruction identity differs from operation manifest")
            operation += 1
        else:
            raise ValueError("unhandled transition instruction: " + text)
    if operation != len(case["ops"]):
        raise ValueError("missing emitted operation")
    if [list(r) for r in regs] != case["expected"]:
        raise ValueError("full 32-register result differs")
    if (sew, vl) != (8, 8):
        raise ValueError("final vtype/VL contract differs")
    return dict(operations=operation, extraction=extraction, configs=configs)


class TransitionStateTest(unittest.TestCase):
    def make_case(self, directory, initial=None):
        if initial is None:
            manifest = generate.generate(Path(directory)/"data")
        else:
            with patch.object(generate, "initial", return_value=initial):
                manifest = generate.generate(Path(directory)/"data")
        return manifest["cases"][-1]

    def test_complete_emitted_chain_all_18_operations(self):
        with tempfile.TemporaryDirectory() as d:
            result = replay(self.make_case(d))
        self.assertEqual(result["operations"], 18)
        self.assertEqual(len(result["extraction"]), 18)
        self.assertEqual(len(result["configs"]), 19)
        self.assertEqual(result["extraction"][0], (8, 0x21, 0x21))
        self.assertEqual({sew for sew, _, _ in result["extraction"]}, {8, 32})

    def test_original_32_bit_constant_reproduces_observed_bad_avl(self):
        with tempfile.TemporaryDirectory() as d:
            case = self.make_case(d)
        case["body_instructions"][3] = "li t3, 0xffffffffffffe429"
        with self.assertRaisesRegex(ValueError, "AVL 0xffffffffffffe408 != 8 before operation 1"):
            replay(case)

    def test_dot_outputs_beyond_signed_byte_and_byte_sign_boundaries(self):
        for left, right, want in [(2,64,128),(2,-65,-130),(1,-128,-128),(1,127,127)]:
            with self.subTest(want=want), tempfile.TemporaryDirectory() as d:
                initial = [[0]*16 for _ in range(32)]
                initial[8][0], initial[9][0] = left & 255, right & 255
                case = self.make_case(d, initial)
                result = replay(case)
                first = result["extraction"][0]
                lane = want & 255
                signed = lane - 256 if lane >= 128 else lane
                self.assertEqual(first, (8, lane, signed & MASK64))

    def test_unsigned_byte_extraction_mutant_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            initial = [[0]*16 for _ in range(32)]
            initial[8][0], initial[9][0] = 2, 64
            case = self.make_case(d, initial)
        case["body_instructions"][3] = "li t3, 0x88"
        with self.assertRaisesRegex(ValueError, "AVL 0xffffffffffffff08 != 8"):
            replay(case)

    def test_32_bit_extract_sign_extension_and_final_e8_restoration(self):
        for bits in [0x7fffffff, 0x80000000, 0xffffffff]:
            with self.subTest(bits=hex(bits)):
                regs = [[0]*16 for _ in range(32)]
                regs[4][:4] = bits.to_bytes(4, "little")
                signed = bits - (1 << 32) if bits & (1 << 31) else bits
                case = dict(before=regs, expected=copy.deepcopy(regs), ops=[],
                    body_instructions=["vsetivli zero, 4, e32, m1, tu, mu",
                                       "vmv.x.s t2, v4",
                                       f"li t3, {(signed ^ 8) & MASK64:#x}",
                                       "xor t2, t2, t3",
                                       "vsetvli zero, t2, e8, m1, tu, mu"])
                self.assertEqual(replay(case)["extraction"], [(32,bits,signed & MASK64)])

    def test_wrong_final_avl_and_missing_chain_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            case = self.make_case(d)
        wrong = copy.deepcopy(case)
        wrong["body_instructions"][-2] = "xor t2, t2, t2"
        with self.assertRaisesRegex(ValueError, "AVL 0x0 != 8"):
            replay(wrong)
        missing = copy.deepcopy(case)
        del missing["body_instructions"][2:5]
        with self.assertRaises(KeyError):
            replay(missing)


if __name__ == "__main__":
    unittest.main()
